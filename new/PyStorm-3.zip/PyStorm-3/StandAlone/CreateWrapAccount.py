from CommonCode.TestExecute.CommandLineArgumentsParser import CommandLineArgumentsParser
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from CommonCode.TestExecute.RunManager import RunManager
from CommonCode.TestExecute.TestContext import Test_Context
from StandAlone.CreateNewAccountFromData import NewAccountFactory

if __name__ == '__main__':
    CommandLineArgumentsParser.processArgumentsForWrapAccountCreation(Test_Context)
    RunManager.createFrameworkFolders(Test_Context)

    Test_Context.setSetting(ConfigOptions.RUN_HEADLESS, True)

    accountFactory = NewAccountFactory(Test_Context.getSetting(ConfigOptions.ENVIRONMENT),
                                       Test_Context.getSetting(ConfigOptions.WRAP_LOGIN_USER_NAME),
                                       Test_Context.getSetting(ConfigOptions.WRAP_LOGIN_PASSWORD))
    accountFactory.createNewAccountFromSourceFile(Test_Context.getSetting(ConfigOptions.SRC_FILE_NAME))
