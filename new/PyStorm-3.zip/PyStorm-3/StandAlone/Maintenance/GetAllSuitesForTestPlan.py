from CommonCode.API.ADORequests import AccessTokenEnum, ADORequests


def writeTestSuiteNames(testPlanId, envName):
    adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_READ_ACCESS_TOKEN)
    testSuites = adoRequests.getTestSuites(testPlanId)

    with open(f"{envName}suites.csv", "w", encoding="utf-8") as fp:
        testSuiteNames = [testSuite["name"] + "\n" for testSuite in testSuites]
        fp.writelines(testSuiteNames)


def saveAllTestSuitesToCSVFile():
    writeTestSuiteNames(1365253, "TE5")
    writeTestSuiteNames(1463138, "UE1")


def findDiffInTestSuites():
    # adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_READ_ACCESS_TOKEN)
    # te5Suites = [k["name"] for k in adoRequests.getTestSuites(1365253)]
    # ue1Suites = [k["name"] for k in adoRequests.getTestSuites(1463138)]

    print(1)


if __name__ == "__main__":
    # saveAllTestSuitesToCSVFile()
    findDiffInTestSuites()
