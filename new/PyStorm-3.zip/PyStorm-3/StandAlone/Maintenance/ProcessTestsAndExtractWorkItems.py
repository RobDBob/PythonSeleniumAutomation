# 1 copy all test methods from VSC search into a file
# 2 read file and process all test ids
# 3 use ADORequests to read state for each, highlight wrong test case state and list author
# ListAllTests.txt

import re
from pprint import pprint
from CommonCode.API.ADORequests import AccessTokenEnum, ADORequests
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from CommonCode.TestExecute.Objects.TestsToRunContainer import TestsToRunContainer
from CommonCode.TestExecute.TestContext import Test_Context


def getLocalTestIds():
    Test_Context.setSetting(ConfigOptions.TEST_FOLDER, "")
    localTests = TestsToRunContainer(Test_Context).getLocalTests()

    localTestIds = []
    for localTest in localTests:
        groups = re.search("test_C(\\d*)_", localTest._testMethodName)
        if groups:
            localTestIds.append(groups[1])
    return localTestIds

    # get all tests from ado with expected test case status
    # use wql query: 0287db7f-49f0-418d-b954-c203f0108b7c


def processLocalTestsAgainstADO():
    localTestIds = getLocalTestIds()

    perAuthorTests = {}
    adoRequests = ADORequests(AccessTokenEnum.WORK_ITEM_READ_ACCESS_TOKEN)
    expectedTestCaseTypes = ["Automated", "Automated - Skipped", "Automated - Triggered Manually"]

    maxPerAPIRequest = 200
    numberOfBatches = round(len(localTestIds) / maxPerAPIRequest)

    for batchNumber in range(numberOfBatches):
        workItemsToQuery = localTestIds[batchNumber * maxPerAPIRequest:(batchNumber + 1) * maxPerAPIRequest]
        workItemsDetail = adoRequests.getWorkItemsByIDs(workItemsToQuery)

        for workItemDetail in workItemsDetail:
            workItemID = workItemDetail["id"]
            actualTestCaseType = workItemDetail["fields"].get("Custom.TestCaseType")

            if actualTestCaseType in expectedTestCaseTypes and "PyStorm" in workItemDetail["fields"].get("System.Tags", ""):
                continue

            assignedTo = workItemDetail["fields"].get('System.AssignedTo', {}).get("displayName")

            if assignedTo not in perAuthorTests:
                perAuthorTests[assignedTo] = {}
            perAuthorTests[assignedTo].update({workItemID: {"TestCaseType": actualTestCaseType,
                                                            "Tags": workItemDetail["fields"].get("System.Tags", "")}})
    pprint(perAuthorTests)


def processADOTestsAgainstLocal():
    # get all tests for the test plan
    # run them against tests from local, see what stand outs
    # te5TestPlan = 1365253
    ue1TestPlan = 1463138
    adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_READ_ACCESS_TOKEN)
    testSuites = adoRequests.getTestSuites(ue1TestPlan)
    testSuiteIds = [k.get("id") for k in testSuites]

    allTests = adoRequests.getTestsPerTestSuites(ue1TestPlan, testSuiteIds)
    adoTestIds = [str(k.get("workItem", {}).get("id")) for k in allTests]

    localTestIds = getLocalTestIds()

    expectedTestCaseTypes = ["Automated", "Automated - Skipped", "Automated - Triggered Manually"]

    perAuthorTests = {}
    adoRequests = ADORequests(AccessTokenEnum.WORK_ITEM_READ_ACCESS_TOKEN)
    maxPerAPIRequest = 200
    numberOfBatches = round(len(adoTestIds) / maxPerAPIRequest)
    for batchNumber in range(numberOfBatches):
        workItemsToQuery = adoTestIds[batchNumber * maxPerAPIRequest:(batchNumber + 1) * maxPerAPIRequest]
        workItemsDetail = adoRequests.getWorkItemsByIDs(workItemsToQuery)

        for workItemDetail in workItemsDetail:
            workItemID = str(workItemDetail["id"])
            actualTestCaseType = workItemDetail["fields"].get("Custom.TestCaseType")

            if actualTestCaseType not in expectedTestCaseTypes:
                continue

            assignedTo = workItemDetail["fields"].get('System.AssignedTo', {}).get("displayName")

            if workItemID not in localTestIds:

                if assignedTo not in perAuthorTests:
                    perAuthorTests[assignedTo] = {}
                perAuthorTests[assignedTo].update({workItemID: actualTestCaseType})

    pprint(perAuthorTests)


if __name__ == "__main__":
    processLocalTestsAgainstADO()
    # processADOTestsAgainstLocal()
