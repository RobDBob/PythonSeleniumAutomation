

import pandas as pd
import numpy as np
import os
from azure.data.tables import TableClient, TableServiceClient

SOURCE_FILE = "flakyTestData.csv"
OUTCOME_FILE = "flakyTestMetricsSummary.csv"

TestAuthors = {
    "11389ba9-1424-6bc5-8932-72e65f35a4f3": "Roshlin Acharya",
    "abe3b4cb-3368-6080-a8e1-d9d91f187784": "Arnab Chakraborty",
    '7f339f0b-29c4-6cd8-96c2-65c2ae00cedd': "Rashmi Siddappa",
    "2d177591-03ea-614f-a7ac-c7d0156f54fd": "Daniela Senkyrova",
    "0071dd77-5623-63d5-b4e9-98b39220b19a": "Robert Deringer",
    "762d4cab-d0dd-6137-b955-263a68cec593": "Nirmal J",
    "70a5f4dd-ff35-6bf6-96ce-31bf34c35139": "Sujata Behera",
    "270c037c-4f18-6968-a413-1275df53131b": "Divya Shetty Venkatesh",
    "6fbec1f5-41ef-6d14-aeca-86498cac78f6": "Christy Jayaseelan"

}


class ExtractTestDataFromTableToCSV:
    allTestIds = []

    def getResultsGrouppedByDate(self):
        azureTablesConnectionString = os.environ.get("RESULT_COLLECTION_CONNECTION_STRING")

        with TableServiceClient.from_connection_string(conn_str=azureTablesConnectionString) as tableServiceClient:
            queryFilter = "outcome eq 'Failed'"
            pythonTestResultsTableClient: TableClient = tableServiceClient.get_table_client("PyStormTestResults")

            testResultGrouppedByDate = {}
            for tableEntity in pythonTestResultsTableClient.query_entities(queryFilter):
                key = tableEntity.metadata.get("timestamp")
                testId = tableEntity.get("testCaseId")

                dateTimeKey = key.strftime("%Y-%m-%d")
                if dateTimeKey not in testResultGrouppedByDate:
                    testResultGrouppedByDate[dateTimeKey] = []
                
                if testId not in self.allTestIds:
                    self.allTestIds.append(testId)

                testResultGrouppedByDate[dateTimeKey].append({"testCaseId": testId, "outcome": False, "testOwnerId": tableEntity.get("testOwnerId")})
            return testResultGrouppedByDate
        
    def addPassesForMissingResults(self, resultsByDate: dict):
        testResults: list
        for _, testResults in resultsByDate.items():
            existingTestIds = [testResult.get("testCaseId") for testResult in testResults]
            missingTestIds = set(self.allTestIds) - set(existingTestIds)

            for missingTestId in missingTestIds:
                testResults.append({"testCaseId": missingTestId, "outcome": True, "testOwnerId": None})

    def flattenResults(self, resultsByDate: dict) -> list:
        flattenedResults = []
        for dateKey, testResults in resultsByDate.items():
            for testResult in testResults:
                flattenedResults.append({
                    "date": dateKey,
                    "testCaseId": testResult.get("testCaseId"),
                    "outcome": testResult.get("outcome"),
                    "testOwnerId": testResult.get("testOwnerId")
                })
        return flattenedResults
    
        
    def getDataAndSaveToCSV(self):
        resultsByDate = self.getResultsGrouppedByDate()
        self.addPassesForMissingResults(resultsByDate)
        flattenedResults = self.flattenResults(resultsByDate)

        df = pd.DataFrame(flattenedResults)
        df.to_csv(SOURCE_FILE, index=False)


class ProcessResultsIdentifyFlaky:
    def loadFromCSV(self):
        # --- Load the CSV ---
        # If your file uses TABs, set sep="\t"; if it's commas, set sep=","
        df = pd.read_csv(SOURCE_FILE,
            sep=",",
            header=0,                    # update to None if no header row
            dtype={"testCaseId": "Int64"},   # allow null-safe integer
            dayfirst=True
        )
        df["outcome"] = df["outcome"].astype(str).str.strip().str.upper().eq("TRUE")

        # AuthorGuid present only for fails; keep NaN for passes
        df["testOwnerId"] = df["testOwnerId"].replace({"": np.nan}).str.lower()

        return df

    def getFlakyTestMetrics(self, df) -> float:
        # Sort by TestId and Date for flip calculations
        df.sort_values(by=['testCaseId', 'date'], inplace=True)

        # Group by TestId to compute metrics
        summary = []

        for testId, group in df.groupby('testCaseId'):
            # assume all owners for given group are same
            testOwners = group["testOwnerId"].values[group["testOwnerId"].notna()]
            testOwnerName = TestAuthors.get(testOwners[0], "Unknown")


            executions = len(group)
            passes = group['outcome'].sum()
            failures = executions - passes
            passRate = passes / executions if executions > 0 else 0

            # Mixed outcomes flag
            mixedOutcomes = 1 if passes > 0 and failures > 0 else 0

            # Flip count: count changes between consecutive outcomes
            flips = (group['outcome'] != group['outcome'].shift(1)).sum() - 1 if executions > 1 else 0
            flipRate = flips / (executions - 1) if executions > 1 else 0

            # Flaky score
            flakyScore = 0
            if mixedOutcomes == 1:
                flakyScore = 0.6 * flipRate + 0.4 * (1 - passRate)

            summary.append({
                'testCaseId': testId,
                'testOwner': testOwnerName,
                'Executions': executions,
                'Passes': passes,
                'Failures': failures,
                'PassRate': round(passRate, 4),
                'MixedOutcomes': mixedOutcomes,
                'Flips': flips,
                'FlipRate': round(flipRate, 4),
                'FlakyScore': round(flakyScore, 4)
            })

        # Convert summary to DataFrame
        summaryDf = pd.DataFrame(summary)

        # Sort by FlakyScore descending for easy analysis
        summaryDf.sort_values(by='FlakyScore', ascending=False, inplace=True)

        # Output the summary
        print(f"Flaky Test Metrics Summary file '{OUTCOME_FILE}' with {len(summaryDf)}-rows")
        summaryDf.to_csv(OUTCOME_FILE, index=False)

    def getFlakyTestMetricsForWindow(self, df, startDate, outputFile=None):
        # Convert date column to datetime if not already
        df['date'] = pd.to_datetime(df['date'])
        
        # Filter to the specified date window
        mask = (df['date'] >= pd.to_datetime(startDate))
        filteredDf = df[mask].copy()
        
        if filteredDf.empty:
            print(f"No data found for the date window {startDate}")
            return pd.DataFrame()
        
        # Sort by TestId and Date for flip calculations
        filteredDf.sort_values(by=['testCaseId', 'date'], inplace=True)
        
        # Group by TestId to compute metrics
        summary = []
        
        for testId, group in filteredDf.groupby('testCaseId'):
            # assume all owners for given group are same
            testOwners = group["testOwnerId"].values[group["testOwnerId"].notna()]
            testOwnerName = TestAuthors.get(testOwners[0] if len(testOwners) > 0 else None, "Unknown")
            
            executions = len(group)
            passes = group['outcome'].sum()
            failures = executions - passes
            passRate = passes / executions if executions > 0 else 0
            
            # Mixed outcomes flag
            mixedOutcomes = 1 if passes > 0 and failures > 0 else 0
            
            # Flip count: count changes between consecutive outcomes
            flips = (group['outcome'] != group['outcome'].shift(1)).sum() - 1 if executions > 1 else 0
            flipRate = flips / (executions - 1) if executions > 1 else 0
            
            # Flaky score
            flakyScore = 0
            if mixedOutcomes == 1:
                flakyScore = 0.6 * flipRate + 0.4 * (1 - passRate)
            
            summary.append({
                'testCaseId': testId,
                'testOwner': testOwnerName,
                'Executions': executions,
                'Passes': passes,
                'Failures': failures,
                'PassRate': round(passRate, 4),
                'MixedOutcomes': mixedOutcomes,
                'Flips': flips,
                'FlipRate': round(flipRate, 4),
                'FlakyScore': round(flakyScore, 4)
            })
        
        # Convert summary to DataFrame
        summaryDf = pd.DataFrame(summary)
        
        # Sort by FlakyScore descending for easy analysis
        summaryDf.sort_values(by='FlakyScore', ascending=False, inplace=True)
        
        # Output the summary
        if outputFile is None:
            outputFile = f"flakyTestMetricsSummary_from_{startDate}.csv"
        print(f"Flaky Test Metrics Summary file '{outputFile}' with {len(summaryDf)} rows")
        print(summaryDf.head(30))
        summaryDf.to_csv(outputFile, index=False)
        
        return summaryDf


if __name__ == "__main__":
    from datetime import datetime, timedelta
    lastMonthDate = (datetime.now() + timedelta(weeks=-4)).strftime("%Y-%m-%d")

    ExtractTestDataFromTableToCSV().getDataAndSaveToCSV()
    
    processor = ProcessResultsIdentifyFlaky()
    df = processor.loadFromCSV()
    # processor.getFlakyTestMetrics(df)
    processor.getFlakyTestMetricsForWindow(df, lastMonthDate)
