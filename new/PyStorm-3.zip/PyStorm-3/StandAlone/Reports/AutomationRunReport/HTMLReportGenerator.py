import math
import os
import sys
from datetime import datetime, timedelta, timezone
import numpy
import pandas as pd
from CommonCode.API import APIConstants
from CommonCode.API.ADORequests import AccessTokenEnum, ADORequests
from CommonCode.API.Jira.JiraServiceWrapper import JiraWrapper
from CommonCode.TestExecute.Logging import PrintMessage

PROJECT_URL = "https://aamdev.visualstudio.com/Platform%20Transformation"

# pylint: disable = unsubscriptable-object


class HTMLReportGenerator:
    API_LIMIT = 200

    def __init__(self, testRunId):
        self.workItemsADORequests = ADORequests(AccessTokenEnum.WORK_ITEM_READ_ACCESS_TOKEN)
        self.testPlanADORequests = ADORequests(AccessTokenEnum.TEST_PLAN_READ_ACCESS_TOKEN)

        self.jiraWrapper = JiraWrapper()

        self.testRunId = testRunId
        self.runDetails: dict = self.testPlanADORequests.getRunDetails(testRunId)
        self.testResultsForCurrentRun = self.testPlanADORequests.getTestResultsForTestRun(
            testRunId, filterByOutcomes=[APIConstants.TEST_OUTCOME_FAILED, APIConstants.TEST_OUTCOME_BLOCKED])

        self._runsResults = pd.DataFrame()

    def getWorkItemsDetails(self, testResults):
        workItemIds = [k.get("testCase", {}).get("id") for k in testResults]
        workItemIdsChunks = numpy.array_split(workItemIds, math.ceil(len(workItemIds) / self.API_LIMIT))
        allWorkItems = []

        for workItemIdsChunk in workItemIdsChunks:
            workItems = self.workItemsADORequests.getWorkItemsByIDs(workItemIdsChunk)
            allWorkItems.extend(workItems)

        return allWorkItems

    def getDataForHTMLReport(self):
        runTitle: str = self.runDetails.get("name", "")
        runTitleTrimmed = runTitle.replace(" ", "").replace("-", "")

        reportData = {"urlTestRun": self.runDetails.get("webAccessUrl"),
                      "runName": self.runDetails.get("name")}

        filteredTestResultForCurrentRun = [k for k in self.testResultsForCurrentRun if k["outcome"] in [APIConstants.TEST_OUTCOME_FAILED,
                                                                                                        APIConstants.TEST_OUTCOME_BLOCKED]]

        if len(filteredTestResultForCurrentRun) == 0:
            PrintMessage("getDataForReport > No failed or bloked results found")
            return reportData, runTitleTrimmed

        workItems = self.getWorkItemsDetails(filteredTestResultForCurrentRun)

        failedTests = []
        blockedTests = []
        for testResult in filteredTestResultForCurrentRun:
            testCaseId = testResult.get("testCase", {}).get("id")
            testCaseName = testResult.get("testCase", {}).get("name")
            workItemDetails = [k for k in workItems if k["id"] == int(testCaseId)]
            assert workItemDetails, f"not found work item details for test case id: '{testCaseId}'"

            testPoint = testResult.get("testPoint", {}).get("id")

            tags: str = workItemDetails[0].get("fields", {}).get("System.Tags", "")

            entity = {
                "testCaseId": testCaseId,
                "testCaseName": testCaseName,
                "author": workItemDetails[0].get("fields", {}).get("System.AssignedTo", {}).get("displayName", ""),
                "tags": tags,
                "jiraIssueStatuses": self.jiraWrapper.getJiraTicketsStatuses(tags),
                "urlTestCase": f"{PROJECT_URL}/_workitems/edit/{testCaseId}",
                "urlResult": f"{PROJECT_URL}/_testManagement/runs?runId={self.testRunId}&_a=resultSummary&resultId={testResult.get('id')}",
                "urlExecutionHistory": f"{PROJECT_URL}//_testPlans/_results?testCaseId={testCaseId}&contextPointId={testPoint}",
                "failCount": self._getResultCount(testCaseId, APIConstants.TEST_OUTCOME_FAILED),
                "blockedCount": self._getResultCount(testCaseId, APIConstants.TEST_OUTCOME_BLOCKED),
                "consecutivefailCount": self._getResultCount(testCaseId, "failStreak"),

                # consecutiveblockedCount does not matter
                "consecutiveblockedCount": "-"
            }
            if testResult.get("outcome") == APIConstants.TEST_OUTCOME_FAILED:
                failedTests.append(entity)
            if testResult.get("outcome") == APIConstants.TEST_OUTCOME_BLOCKED:
                blockedTests.append(entity)

        reportData["failedTests"] = sorted(failedTests, key=lambda item: item["author"])
        reportData["blockedTests"] = sorted(blockedTests, key=lambda item: item["author"])
        return reportData, runTitleTrimmed

    def _getResultCount(self, testId, testOutcome):
        """
        Docstring for getResultNumber

        :param self: Description
        :param testId: Description
        :param testOutcome: Passed / Failed / Blocked
        """
        if self.runsResults[self.runsResults["testId"] == int(testId)].empty:
            return 0
        return int(self.runsResults[self.runsResults["testId"] == int(testId)][testOutcome].iloc[0])

    @property
    def runsResults(self) -> pd.DataFrame:
        if self._runsResults.empty:
            adoTestResults = []
            endDate = datetime.now(timezone.utc)
            startDate = endDate - timedelta(days=6)

            # Fetch historic test results
            dateAgo = endDate - timedelta(weeks=5)
            while startDate > dateAgo:
                adoTestResults.extend(self.testPlanADORequests.queryTestRunsBasedOnFilters(
                    filterByOutcomes=None,
                    planIds=self.runDetails.get("plan", {}).get("id"),
                    runTitle=self.runDetails.get("name", ""),
                    minLastUpdatedDate=f"{startDate.strftime('%Y-%m-%d')}T00:00:00Z",
                    maxLastUpdatedDate=f"{endDate.strftime('%Y-%m-%d')}T23:59:59Z",
                    state="completed"
                ))
                endDate = startDate - timedelta(days=1)
                startDate = endDate - timedelta(days=6)

            dataForDF = [{"testId": k["testCase"]["id"], "outcome": k["outcome"], "date": k["lastUpdatedDate"].split("T")[0]} for k in adoTestResults]

            df: pd.DataFrame = pd.DataFrame(dataForDF)

            df["testId"] = df["testId"].astype("int64")
            df["date"] = pd.to_datetime(df["date"], format="%Y-%m-%d")

            # Sort so the most recent result is first within each testId
            df: pd.DataFrame = df.sort_values(["testId", "date"], ascending=[True, False])

            # 1 for Failed, 0 for everything else
            m = df["outcome"].eq("Failed").astype(int)

            # cumprod() stays 1 until the first 0 in each group, then becomes 0 afterwards
            headRun = m.groupby(df["testId"]).cumprod()

            # The sum per testId is the length of the latest unbroken Fail  streak
            streaks = headRun.groupby(df["testId"]).sum().reset_index(name="failStreak")

            # Count occurrences of each Outcome per testId
            summary = (
                df.groupby(["testId", "outcome"]).size()
                .unstack("outcome", fill_value=0)            # make outcomes columns
                .reindex(columns=["Failed", "Passed", "Blocked"], fill_value=0)  # consistent column order
                .reset_index()
            )

            self._runsResults = streaks.merge(summary, on="testId").sort_values("testId")
        return self._runsResults


def main(runId):
    testRunFailedTests = HTMLReportGenerator(runId)
    reportData, runTitleTrimmed = testRunFailedTests.getDataForHTMLReport()

    from StandAlone.Reports.AutomationRunReport.HTMLReportHelper import generateReportFailedTests
    generateReportFailedTests(reportData, runId, runTitleTrimmed)


def getRunId():
    if len(sys.argv) < 2:
        runId = os.environ.get("TESTRUNID")

        if runId:
            PrintMessage(f"HTML Report> RunId found in environment variable: TESTRUNID: '{runId}'")

        return runId

    return sys.argv[1]


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    runId = getRunId()

    if runId:
        main(runId)
    else:
        PrintMessage("HTML Report> args error, missed run id? Run script as python -m ")
        PrintMessage("HTML Report> Run script as 'python -m StandAlone.Reports.AutomationRunReport.HTMLReportGenerator 2559517'")
