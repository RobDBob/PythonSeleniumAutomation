import itertools
import os
import unittest
from enum import Enum
from unittest.case import SkipTest
from CommonCode.API.ADORequests import AccessTokenEnum, ADORequests
from CommonCode.HelperFunctions import getTestIdFromTestName
from CommonCode.TestExecute import TestFuncs
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestExecute.Objects.TestBucket import TestBucket
from CommonCode.TestExecute.TestContext import TestContext


class TestFilerEnum(Enum):
    TEST_IDS = 1
    TEST_NAMES = 2
    CLASS_NAMES = 3


def dummyTestFunctionWithSkipException():
    raise SkipTest("Test marked as 'Automated - Skipped' in ADO Test Case WorkItem")


class TestsToRunContainer:
    MAIN_TEST_FOLDER = "Tests"
    TEST_FILE_PREFIX = "Tests"

    # WorkItemType = TestCase and TestCaseType = Automated - Skipped
    WIQL_AUTOMATED_SKIPPED_TEST_CASES = "b7a8b4ed-f90f-44a0-ac9b-edfd2c0c5957"

    # must stay as instance variable for the test re-run
    adoTestPoints: dict = None

    def __init__(self, testContext: TestContext):
        self.testContext: TestContext = testContext
        self.folderToSearch = os.path.join(self.MAIN_TEST_FOLDER, self.testContext.getSetting(ConfigOptions.TEST_FOLDER))

    def _getWorkItemsFromWIQLQuery(self, wiql):
        workItemsByQueryResult = ADORequests(AccessTokenEnum.WORK_ITEM_READ_ACCESS_TOKEN).getWorkItemsByWIQL(wiql)
        return [k.get("id") for k in workItemsByQueryResult.get("workItems", [])]

    def _updateLocalCopyOfADODataSkipSuitesNotPresentInLocal(self, localTests):
        """
        update internal list of test cases with ADO Data
        structure:
            {"testPointId": testPoint["id"],
             "testSuiteId": testSuiteId,
             "testSuiteName": testSuiteName}
        """

        def getTestCaseIdAndTestPointID(testPoints, testSuiteId, testSuiteName):
            """
            Returns dictionary of { testCaseId: {"testPointId": testPointId, "testSuite": testSuiteId }}
            """
            combo = {}
            for testPoint in testPoints.get("value", []):
                testId = int(testPoint["testCase"]["id"])
                combo[testId] = {"testPointId": testPoint["id"],
                                 "testSuiteId": testSuiteId,
                                 "testSuiteName": testSuiteName}
            return combo

        testPlan = self.testContext.getSetting(ConfigOptions.TEST_PLAN)
        if not testPlan:
            return
        localTestSuites = {k.ADO_TEST_SUITE for k in localTests}

        # if exists, then no reason to extract again
        if self.adoTestPoints or not testPlan:
            return

        adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_READ_ACCESS_TOKEN)
        testsWithADOData = {}
        for adoSuite in adoRequests.getTestSuites(testPlan):
            adoSuiteId = adoSuite["id"]
            adoSuiteName = adoSuite["name"]

            # skip test suites not present in local
            if adoSuiteName not in localTestSuites:
                continue

            PrintMessage(f"Get ADO test data for test suite: '{adoSuiteId}': '{adoSuiteName}'.")
            testPoints = adoRequests.getTestPoints(testPlan, adoSuiteId)
            testsWithTestPoints = getTestCaseIdAndTestPointID(testPoints, adoSuiteId, adoSuiteName)
            testsWithADOData.update(testsWithTestPoints)
        self.adoTestPoints = testsWithADOData

    def _discoverLocalTests(self, filterType: TestFilerEnum = None, expectedIdentifiers: list = None) -> dict:
        """
        Returns list of test su
        """

        testsFlatGen = self.getLocalTests()

        if expectedIdentifiers is None:
            return list(testsFlatGen)

        match filterType:
            case TestFilerEnum.TEST_IDS:
                return [k for k in testsFlatGen if getTestIdFromTestName(k._testMethodName) in expectedIdentifiers]
            case TestFilerEnum.TEST_NAMES:
                return [k for k in testsFlatGen if k._testMethodName in expectedIdentifiers]
            case TestFilerEnum.CLASS_NAMES:
                return [k for k in testsFlatGen if k.__class__.__name__ in expectedIdentifiers]
            case _:
                return list(testsFlatGen)

    def getLocalTests(self):
        loader = unittest.TestLoader()
        loader.testMethodPrefix = 'test_C'
        patternToUse = f"{self.TEST_FILE_PREFIX}*.py"
        allTests = loader.discover(self.folderToSearch, pattern=patternToUse)

        assert not loader.errors, str(loader.errors)

        PrintMessage(f"Discovered {allTests.countTestCases()} tests in folder {self.folderToSearch} "
                     f"with search pattern {patternToUse}")

        return TestFuncs.flattentTestsSuitesIntoGen(allTests)

    def getTestBucketsForRegressionRun(self, failedTests=None) -> list[dict]:
        """
        Groupping tests by unitTest class for execution purposes

        test bucket requires:
        - local unitTest class - to execute
        - list of relevant tests & relevant ADO data

        Returns test buckets for parallel test execution
        """
        def filterLocalTestsPerADOWIQLQueries(localTests, testsToRunWIQL):
            skippedTestIdsInADO = self._getWorkItemsFromWIQLQuery(self.WIQL_AUTOMATED_SKIPPED_TEST_CASES)
            testsToRun = self._getWorkItemsFromWIQLQuery(testsToRunWIQL)

            numberToBlock = 0
            localTestsToExecute = []
            for localTest in localTests:
                localTestMethodName = getattr(localTest, "_testMethodName")
                localTestId = getTestIdFromTestName(localTestMethodName)

                if testsToRun and localTestId not in testsToRun:
                    continue

                if localTestId in skippedTestIdsInADO:
                    numberToBlock += 1
                    setattr(localTest, localTestMethodName, dummyTestFunctionWithSkipException)

                localTestsToExecute.append(localTest)

            PrintMessage(f"Identified {len(localTestsToExecute)} tests to run, with {numberToBlock} to be marked as BLOCKED")

            return localTestsToExecute

        localTests = self._discoverLocalTests(TestFilerEnum.TEST_NAMES, failedTests)
        localTests = filterLocalTestsPerADOWIQLQueries(localTests, self.testContext.getSetting(ConfigOptions.WIQL_TESTS_TO_RUN))
        self._updateLocalCopyOfADODataSkipSuitesNotPresentInLocal(localTests)

        # with ado data present, remove all those tests that are not in ADO test plan
        localTests = [k for k in localTests if getTestIdFromTestName(k._testMethodName) in self.adoTestPoints]

        testBuckets = []
        for _, selectedGroupTests in itertools.groupby(localTests, type):
            filteredTestsSuite = unittest.TestSuite()
            filteredTestsSuite.addTests(selectedGroupTests)
            testBuckets.append(TestBucket(filteredTestsSuite, self.adoTestPoints))

        PrintMessage(f"Identified {len(testBuckets)} test buckets for execution")
        return testBuckets

    def getTestSuiteForSerialExecution(self):
        suite = unittest.TestSuite()
        if self.testContext.getSetting(ConfigOptions.TEST_IDS):
            testList = self._discoverLocalTests(TestFilerEnum.TEST_IDS, self.testContext.getSetting(ConfigOptions.TEST_IDS))
            suite.addTests(testList)

        elif self.testContext.getSetting(ConfigOptions.TEST_CLASS_NAMES):
            testList = self._discoverLocalTests(TestFilerEnum.CLASS_NAMES, self.testContext.getSetting(ConfigOptions.TEST_CLASS_NAMES))
            for _, selectedGroupTests in itertools.groupby(testList, type):
                suite.addTests(selectedGroupTests)
        return suite
