import json
import random
from os import path
from faker import Faker
from yaml import Loader, load
from CommonCode.TestHelpers.DateMethods import generateRequiredDateOfBirth, getFutureWeekdayFromTodayFormatted, getPastWeekdayFromTodayFormatted, getTodaysDate
from CommonCode.TestHelpers.StringMethods import getFakeUKAddress, getRandomNINString, getUniqueAlphaString, randomNumber, randomNumberAsString
from TestPages import PageEnums

# Added yaml anchors for generated values
# single '^' creates reference i.e. anchor
# single '+' populates field with anchored auto-generated value, requirement is: anchor (^) must be higher up in hierarchy than (+)
# values with # without ^ specified before will ignore it and use it as it is
# i.e.
# ^name GenerateRandomAutomName
# +name
# in above example +name will be replaced with same value generated in GenerateRandomAutomName
# for YAML anchors without generate functionalit needed use defalt & abd * anchor prefixes

# pylint: disable = invalid-name


class TestDataLoader:
    anchorGeneratorItems = {}
    AUTO_GEN_ANCHOR_SRC = "^"
    AUTO_GEN_ANCHOR_DST = "+"

    TEST_DATA_PARENT_FOLDER = "TestData"

    def __init__(self, testDataSubfolder: str):
        self.testDataSubfolder: str = testDataSubfolder

    def _getFilePath(self, fileName):
        return path.join(self.TEST_DATA_PARENT_FOLDER, self.testDataSubfolder, fileName)

    def _updateWithGeneratedData(self, dataToUpdate: dict, sectionName: str = None):
        """
        Updated dictionary file with generated values depending on used keywords i.e. GenereateRandomNIN
        """
        # reset values
        self.anchorGeneratorItems = {}

        if dataToUpdate and sectionName:
            section = dataToUpdate.get(sectionName, {})
            self.generateRandomValues(section)
            return section

        self.generateRandomValues(dataToUpdate)
        return dataToUpdate

    def generateRandomValues(self, dataToUpdate):
        # pylint: disable=invalid-name, unused-variable, eval-used
        def GenerateDOBFromAge(years, months):
            return generateRequiredDateOfBirth(years, months)

        def GenerateRandomNumber(minValue, maxValue):
            return randomNumber(minValue, maxValue)

        if isinstance(dataToUpdate, list):
            for subData in dataToUpdate:
                self.generateRandomValues(subData)
            return
        if dataToUpdate is None or not isinstance(dataToUpdate, dict):
            return

        for key, value in dataToUpdate.items():
            if isinstance(value, dict):
                self.generateRandomValues(dataToUpdate[key])
                continue
            if isinstance(value, list):
                self.generateRandomValues(value)
                continue

            anchorGeneratorKey = None
            match str(value):
                case testValue if testValue.startswith(self.AUTO_GEN_ANCHOR_SRC):
                    anchorGeneratorKey, generatorInstruction = testValue.split(" ")
                    anchorGeneratorKey = anchorGeneratorKey.removeprefix(self.AUTO_GEN_ANCHOR_SRC)
                    value = generatorInstruction
                case testValue if testValue.startswith(self.AUTO_GEN_ANCHOR_DST):
                    replacementKey = testValue.removeprefix(self.AUTO_GEN_ANCHOR_DST)
                    dataToUpdate[key] = self.anchorGeneratorItems.get(replacementKey, testValue)

            match str(value):
                case "GenerateRandomString":
                    dataToUpdate[key] = getUniqueAlphaString()
                case "GenerateRandomAutomName":
                    dataToUpdate[key] = getUniqueAlphaString("autom_")
                case "GenerateRandomDOB":
                    dataToUpdate[key] = Faker().date_between("-50y", "-20y")
                case "GenerateRandomEmail":
                    dataToUpdate[key] = Faker().ascii_safe_email()
                case "GenerateRandomMobilePhone":
                    dataToUpdate[key] = f"0{randomNumberAsString(1111111111, 9999999999)}"
                case "GenerateRandomUKAddress":
                    dataToUpdate[key] = getFakeUKAddress()
                case "GenerateRandomTrustCoCompanyName":
                    dataToUpdate[key] = f"Company {randomNumberAsString(111111, 999999)} TrustCo"
                case "GenerateRandomNIN":
                    firstBlockStr, lastBlockString = getRandomNINString()
                    dataToUpdate[key] = f"{firstBlockStr[0]}{firstBlockStr[1]}{randomNumberAsString(111111, 999999)}{lastBlockString[1]}"
                case "GenerateRandomMaritalStatus":
                    dataToUpdate[key] = random.choice([PageEnums.SINGLE,
                                                       PageEnums.MARRIED_CIVIL_PARTNERSHIP,
                                                       PageEnums.SEPARATED,
                                                       PageEnums.DIVORCED_DISSOLVED_CIVIL_PARTNERSHIP,
                                                       PageEnums.WIDOWED_SURVIVING_CIVIL_PARTNER])
                case "GenerateRandomBankAccount":
                    iban = Faker().iban()
                    dataToUpdate[key] = iban[len(iban) - 8:]  # 8 digit account number
                case "GenerateTodaysDate":
                    dataToUpdate[key] = getTodaysDate()
                case testValue if testValue.startswith("GenerateWorkDayDate+"):
                    _, daysAhead = testValue.split("+")
                    dataToUpdate[key] = getFutureWeekdayFromTodayFormatted(int(daysAhead))
                case testValue if testValue.startswith("GenerateWorkDayDateOnDot+"):
                    _, daysAhead = testValue.split("+")
                    dataToUpdate[key] = getFutureWeekdayFromTodayFormatted(int(daysAhead), avoid27thOnwards=False)
                case testValue if testValue.startswith("GeneratePastWorkingDayDate-"):
                    _, daysInPast = testValue.split("-")
                    dataToUpdate[key] = getPastWeekdayFromTodayFormatted(int(daysInPast))
                case testValue if testValue.startswith("GenerateDOBFromAge"):
                    dataToUpdate[key] = eval(testValue)
                case testValue if testValue.startswith("GenerateRandomNumber("):
                    dataToUpdate[key] = eval(testValue)
                case "GenerateRandomFloatAsText":
                    dataToUpdate[key] = f"{randomNumber(1, 100)}.00"

            # assiging generated value for given gen anchor
            if anchorGeneratorKey:
                self.anchorGeneratorItems[anchorGeneratorKey] = dataToUpdate[key]

    def getDictFromJsonFile(self, filePath) -> dict:
        with open(filePath, encoding="utf-8") as fp:
            return json.load(fp)

    def getDictFromYamlFile(self, filePath) -> dict:
        with open(filePath, encoding="utf-8") as fp:
            return load(fp, Loader)

    def getTestDataFromJsonFile(self, fileName, sectionName=None):
        filePath = self._getFilePath(fileName)
        fileContent = self.getDictFromJsonFile(filePath)
        return self._updateWithGeneratedData(fileContent, sectionName)

    def getTestDataFromYmlFile(self, fileName, sectionName=None):
        filePath = self._getFilePath(fileName)
        fileContent = self.getDictFromYamlFile(filePath)
        return self._updateWithGeneratedData(fileContent, sectionName)
