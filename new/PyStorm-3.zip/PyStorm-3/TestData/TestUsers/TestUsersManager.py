import json
from os import path
from TestData.TestUsers.TestUsersEnum import UserType


class TestUsersManager:
    testUsers = None

    def __init__(self, testEnvName):
        self._loadUsers(path.join("TestData", "TestUsers", f"TestUsers_{testEnvName}.json"))

    def _loadUsers(self, usersFilePath):
        with open(usersFilePath, encoding="utf-8") as fp:
            self.testUsers = json.load(fp)

    def getUserByType(self, userType: UserType):
        """
        Initially it'll return first user from list. To be expanded with some kind of heam/stack implementation
        """
        if userType.name in self.testUsers:
            return self.testUsers[userType.name][0]
        return None

    def getUserByNumber(self, userNumber):
        return self.getUserByKey(f"WRAP_{userNumber}")

    def getBOUserByNumber(self, userNumber):
        keyName = f"WRAP_{userNumber}"
        return self.testUsers[keyName]["BO_USER"], self.testUsers[keyName]["PASSWORD"]

    def getUserByKey(self, key):
        return self.testUsers[key]["USER"], self.testUsers[key]["PASSWORD"]
