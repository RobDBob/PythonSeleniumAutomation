# Use the official Python image as a base image
FROM python:3.11-slim

# Set the working directory
WORKDIR /app

# Copy your Selenium WebDriver script into the container
COPY . .

# install stuff
RUN apt-get update && apt-get install -y chromium-driver

# # Install required packages
RUN pip install -r requirements.txt

# Define the command to execute your script
CMD ["/bin/sh", "-c", "python -m StandAlone.DataInsertionPOC.RunScript > output.log 2>&1"]
