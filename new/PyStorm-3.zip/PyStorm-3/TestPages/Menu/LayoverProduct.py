from selenium.webdriver.common.by import By
from TestPages.Menu.Layover import Layover
from TestPages.Menu.MenuGroup import MenuGroup
from TestPages.PageObjects.BaseObjects.Button import Button


class LayoverProduct(Layover):
    productName: str

    def getMenuSectionOptions(self, menuGroupName: str) -> MenuGroup:
        menuGroup = MenuGroup(self.webdriver, self.element, menuGroupName)
        menuGroup.menuGroupForProductName = self.productName
        return menuGroup

    @property
    def backButton(self):
        return Button(self.webdriver, self.element, By.CSS_SELECTOR, "button[class='cno-return-button']")
