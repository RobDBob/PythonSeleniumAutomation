import operator
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.BusinessManagementPage import BusinessManagementPage
from TestPages.Menu.MenuGroup import MenuGroup
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.Support.HelpAndGuidesPage import HelpAndGuidesPage
from TestPages.Support.PlatformNewsAndUpdatePage import PlatformNewsAndUpdatePage
from TestPages.ToolsLiterature.ToolsPage import ToolsPage
from TestPages.WebDriver import ExpectedConditions as EC


class Layover(BaseTestObject):
    LAYOVER_LOCATOR = (By.XPATH, '//div[@role="main" and @class="cno-main"]')

    def __init__(self, webdriver):
        super().__init__(webdriver, webdriver, *self.LAYOVER_LOCATOR)
        self.waitForElement()

    def closeMenu(self):
        self.waitForElement()
        self.closeButton.waitForText("Close menu")
        self.closeButton.click()

    def getMenuSectionOptions(self, menuGroupName: str) -> MenuGroup:
        return MenuGroup(self.webdriver, self.element, menuGroupName)

    def getsupportItemsLink(self, supportItem):
        waitCondition = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//div[@class = 'cno-footer']"), supportItem)
        WebDriverWait(self.parentElement, 60).until(waitCondition)

    def waitForMenuIcons(self, adminMenuIcons: list):
        PrintMessage(f"Making attempt to locate menu: '{adminMenuIcons}'.", inStepMessage=True)
        for adminMenuIcon in adminMenuIcons:
            waitCondition = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//span[@class='icon']//parent::h2"), adminMenuIcon)
            WebDriverWait(self.parentElement, 60).until(waitCondition)
        PrintMessage(f"Verified presence of '{adminMenuIcons}'", inStepMessage=True)

    def waitForMenuFooterItem(self, footerItem):
        PrintMessage(f'Verifying {footerItem}', inStepMessage=True)
        waitCondition = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//ul[@class='cno-footer-links']//li"), footerItem)
        WebDriverWait(self.parentElement, 60).until(waitCondition)

    def waitForMenuHeading(self, menuLabel):
        waitCondition = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//div[@class = 'cno-section-heading']"), menuLabel)
        WebDriverWait(self.parentElement, 60).until(waitCondition)
        PrintMessage(f"Verified the Menu Heading '{menuLabel}'", inStepMessage=True)

    def openPlatformSettings(self):
        from TestPages.SettingsPage import SettingsPage
        self.platformSettings.click()
        return SettingsPage(self.parentElement)

    def navigateToHelpAndMenu(self):
        self.helpAndGuides.click()
        return HelpAndGuidesPage(self.parentElement)

    def navigateToNewsAndUpdates(self):
        self.platformNewsAndUpdates.click()
        return PlatformNewsAndUpdatePage(self.parentElement)

    def selectMenuItem(self,
                       menuGroupName,
                       menuItem,
                       subMenuName=None,
                       menuPageToOpen: str = None,
                       comparisonOperator: operator = operator.eq):
        menuGroup: MenuGroup = self.getMenuSectionOptions(menuGroupName)
        return menuGroup.selectMenuItem(menuItem,
                                        subMenuName,
                                        menuPageToOpen,
                                        comparisonOperator=comparisonOperator)

    def closeMenuAndNavigateBack(self, pageToNavigate):
        self.closeButton.click()
        if pageToNavigate == PageEnums.BUSINESS_MANAGEMENT:
            return BusinessManagementPage(self.parentElement)
        if pageToNavigate == PageEnums.PLATFORM_PAGE:
            return PlatformPage(self.parentElement)
        if pageToNavigate == PageEnums.TOOLS_PAGE:
            return ToolsPage(self.parentElement)
        return None

    @property
    def helpAndGuides(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "(//a[contains(text(),'Help and guides')])[2]")

    @property
    def platformNewsAndUpdates(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//a[contains(text(),'Platform news and updates')]")

    @property
    def platformSettings(self):
        return Button(self.webdriver, self.element, By.XPATH, "//*[text()='Platform settings']")

    @property
    def fnzLogo(self):
        return Button(self.webdriver, self.parentElement, By.CLASS_NAME, 'app-logo')

    @property
    def closeButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[@class='custom-navigation-close']")

    @property
    def adminMenuHeadingSection(self):
        return Button(self.webdriver, self.element, By.XPATH, "//div[text()='Admin']")

    @property
    def support(self):
        return Label(self.webdriver, self.element, By.XPATH, "//h2[contains(text(),'Support')]")

    @property
    def maintainAdviserCharging(self):
        return Button(self.webdriver, self.element, By.XPATH, "//a[text()='Maintain adviser charging']")

    @property
    def valuationUpdateLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Valuation Update']")

    @property
    def applyIncomeLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Apply Income']")

    @property
    def valuationAuthorisationLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Valuation Authorisation']")

    @property
    def maintainManagerLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Maintain Manager']")

    @property
    def orderCompletionLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Order Completion']")

    @property
    def createManagerLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Create Manager']")

    @property
    def managerAuthorisationLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Manager Authorisation']")

    @property
    def instrumentAuthorisationLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Instrument Authorisation']")

    @property
    def deferredTradesLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Deferred Trades']")

    @property
    def maintainInstrumentLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Maintain Instrument']")

    @property
    def authoriseWithdrawalsLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Authorise Withdrawals']")

    @property
    def createInstrumentLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Create Instrument']")

    @property
    def cashManagementAdministrationChargeLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Cash Management Administration Charge']")

    @property
    def authoriseCashManagementAdministrationChargeLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, "//a[text()='Authorise Cash Management Administration Charge']")
