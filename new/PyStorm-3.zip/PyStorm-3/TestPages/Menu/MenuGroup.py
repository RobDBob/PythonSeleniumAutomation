# pylint: skip-file
import operator
from retry import retry
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.Admin.AccountRestrictions.SuspendedActivityConfigurationPage import SuspendedActivityConfigurationPage
from TestPages.Admin.AccountRestrictions.SuspendedReasonAuthorisationPage import SuspendedReasonAuthorisationPage
from TestPages.Admin.AddProjectPage import IssueManagementAddProjectPage
from TestPages.Admin.AdministerAccountsAggregatedReportingPage import AdministerAccountsAggregatedReportingPage
from TestPages.Admin.AdministerAccountsCreateEditLinksPage import AdministerAccountsCreateEditLinksPage
from TestPages.Admin.AdministerAccountsFamilyTermsLinkedAccountsPage import AdministerAccountsFamilyTermsLinkedAccountsPage
from TestPages.Admin.AdviserFirmTermsHistoryPage import AdviserFirmTermsHistoryPage
from TestPages.Admin.AdviserReportGenerationPage import AdviserReportGenerationPage
from TestPages.Admin.AmendCompanyAddressPage import AmendCompanyAddressPage
from TestPages.Admin.AttachRemoveClientsPage import AttachRemoveClientsPage
from TestPages.Admin.AuthoriseAdviserFirmTermsPage import AuthoriseAdviserFirmTermsPage
from TestPages.Admin.AuthoriseBankAccountsPage import AuthoriseBankAccountsPage
from TestPages.Admin.AuthoriseBWAReferralsPage import AuthoriseBWAReferralsPage
from TestPages.Admin.AuthoriseCompletePricesPage import AuthoriseCompletePricesPage
from TestPages.Admin.AuthoriseCustomerTermsPage import AuthoriseCustomerTermsPage
from TestPages.Admin.AuthoriseDocumentationPage import AuthoriseDocumentationPage
from TestPages.Admin.AuthoriseManagerPage import AuthoriseManagerPage
from TestPages.Admin.AuthoriseProcessesPage import AuthoriseProcessesPage
from TestPages.Admin.AuthoriseReregLetterPage import AuthoriseReregLetterPage
from TestPages.Admin.AuthoriseSavingsDirectProcessesPage import AuthoriseSavingsDirectProcessesPage
from TestPages.Admin.AuthoriseWithdrawalsPage import AuthoriseWithdrawalsPage
from TestPages.Admin.BulkClientMailingPreferencePage import BulkClientMailingPreferencePage
from TestPages.Admin.BulkValuationsPage import BulkValuationsPage
from TestPages.Admin.Cash.AuthoriseCashManagementAdministrationChargePage import AuthoriseCashManagementAdministrationChargePage
from TestPages.Admin.Cash.AuthoriseChequeStatusPage import AuthoriseChequeStatusPage
from TestPages.Admin.Cash.AuthoriseDirectDebitFailuresPage import AuthoriseDirectDebitFailuresPage
from TestPages.Admin.Cash.CashManagementAdministrationChargePage import CashManagementAdministrationChargePage
from TestPages.Admin.Cash.CHAPSPage import CHAPSPage
from TestPages.Admin.Cash.CHAPSSTPLimitPage import CHAPSSTPLimitedPage
from TestPages.Admin.Cash.ChequeIDCapturePage import ChequeIDCapturePage
from TestPages.Admin.Cash.ChequeIDReceiptPage import ChequeIDReceiptPage
from TestPages.Admin.Cash.ChequeStatusPage import ChequeStatusPage
from TestPages.Admin.Cash.EndOfDayProcessingPage import EndOfDayProcessingPage
from TestPages.Admin.Cash.ManualCashAdjustmentsPage import ManualCashAdjustmentsPage
from TestPages.Admin.Cash.MatchedDirectDebitFailuresPage import MatchedDirectDebitFailuresPage
from TestPages.Admin.Cash.MatchedExpectationsPage import MatchedExpectationsPage
from TestPages.Admin.Cash.ResidualCashPaymentOutPage import ResidualCashPaymentsOutPage
from TestPages.Admin.Cash.UnmatchedDirectDebitFailuresPage import UnmatchedDirectDebitFailuresPage
from TestPages.Admin.Cash.UnmatchedExpectationsPage import UnmatchedExpectationsPage
from TestPages.Admin.Cash.UnmatchedTransfersPage import UnmatchedTransfersPage
from TestPages.Admin.CashStockMovementPage import CashStockMovementPage
from TestPages.Admin.ChangeOfAdviserPage import ChangeOfAdviserPage
from TestPages.Admin.CompletePricesForBondsPage import CompletePricesForBondsPage
from TestPages.Admin.CustomerMergePage import CustomerMergePage
from TestPages.Admin.CustomerTermsHistoryPage import CustomerTermsHistoryPage
from TestPages.Admin.DeferredTradesPage import DeferredTradesPage
from TestPages.Admin.EditCompanyAccess import EditCompanyAccess
from TestPages.Admin.FindAdviserPage import FindAdviserPage
from TestPages.Admin.FindWebsiteUsersPage import FindWebsiteUsersPage
from TestPages.Admin.HistoryPage import HistoryPage
from TestPages.Admin.HoldingsExternalAssetsWizardPage import HoldingsExternalAssetsWizardPage
from TestPages.Admin.Instruments.ApplyIncomePage import ApplyIncomePage
from TestPages.Admin.Instruments.CreateInstrumentPage import CreateInstrumentPage
from TestPages.Admin.Instruments.CreateManagerPage import CreateManagerPage
from TestPages.Admin.Instruments.InstrumentAuthorisationPage import InstrumentAuthorisationPage
from TestPages.Admin.Instruments.MaintainInstrumentPage import MaintainInstrumentPage
from TestPages.Admin.Instruments.MaintainManagerPage import MaintainManagerPage
from TestPages.Admin.Instruments.ValuationAuthorisationPage import ValuationAuthorisationPage
from TestPages.Admin.Instruments.ValuationUpdatePage import ValuationUpdatePage
from TestPages.Admin.ISAManagement.ConsolidatedTaxCertificatePage import ConsolidatedTaxCertificatePage
from TestPages.Admin.ISAManagement.FilterTaxCertificatePage import FilterTaxCertificatePage
from TestPages.Admin.ISAManagement.TaxReclaimPage import TaxReclaimPage
from TestPages.Admin.LegacyClientReportingPage import LegacyClientReportingPage
from TestPages.Admin.ListEditPortfolioPage import ListEditPortfolioPage
from TestPages.Admin.LogIssuePage import IssueManagementLogIssuePage
from TestPages.Admin.ManageIssueLogPage import IssueManagementManageIssueLogPage
from TestPages.Admin.ManualCashAdjustmentAuthorisePage import ManualCashAdjustmentAuthorisePage
from TestPages.Admin.MIAndReports.AuthoriseTimeLimitPage import AuthoriseTimeLimitPage
from TestPages.Admin.MIAndReports.EditTimeLimitPage import EditTimeLimitPage
from TestPages.Admin.MIAndReports.EFMOpenLinesEnquiryPage import EFMOpenLinesEnquiryPage
from TestPages.Admin.MIAndReports.InlandRevenueReportsPage import InlandRevenueReportsPage
from TestPages.Admin.MIAndReports.ManagementInfoReportsPage import ManagementInfoReportsPage
from TestPages.Admin.MIAndReports.TimeLimitHistoryPage import TimeLimitHistoryPage
from TestPages.Admin.MIFIRDataCapturePage import MIFIRDataCapturePage
from TestPages.Admin.ModelPortfoliosNewPortfolioPage import ModelPortfoliosNewPortfolioPage
from TestPages.Admin.NewAdviserPage import NewAdviserPage
from TestPages.Admin.NewWebsiteUserPage import NewWebsiteUserPage
from TestPages.Admin.OrderCompletionPage import OrderCompletionPage
from TestPages.Admin.OtherServices.AccountSearchPage import AccountSearchPage
from TestPages.Admin.OtherServices.AuthoriseFundingPage import AuthoriseFundingPage
from TestPages.Admin.OtherServices.BatchQueriesPage import BatchQueriesPage
from TestPages.Admin.OtherServices.ConversionForReregistrationPage import ConversionForReregistrationPage
from TestPages.Admin.OtherServices.FundingHistoryPage import FundingHistoryPage
from TestPages.Admin.OtherServices.HistoricStreamWorkflowPage import HistoricStreamWorkflowPage
from TestPages.Admin.OtherServices.IncompleteWizardsPage import IncompleteWizardsPage
from TestPages.Admin.OtherServices.ManualPlacementPage import ManualPlacementPage
from TestPages.Admin.OtherServices.OrderStatusQueriesPage import OrderStatusQueriesPage
from TestPages.Admin.OtherServices.RequestFundingPage import RequestFundingPage
from TestPages.Admin.OtherServices.ServiceListPage import ServiceListPage
from TestPages.Admin.OtherServices.ShadowingLogPage import ShadowingLogPage
from TestPages.Admin.OtherServices.TestSoapRequestPage import TestSoapRequestPage
from TestPages.Admin.PlatformSetup.CompanyWizardSetupPage import CompanyWizardSetupPage
from TestPages.Admin.PlatformSetup.NetworkWizardSetupPage import NetworkWizardSetupPage
from TestPages.Admin.PlatformSetup.SearchCriteriaPage import SearchCriteriaPage
from TestPages.Admin.RemunerationStatementPage import RemunerationStatementPage
from TestPages.Admin.ReportsPage import ReportsPage
from TestPages.Admin.RequestCorrection.AuthoriseCorrectionPage import AuthoriseCorrectionPage
from TestPages.Admin.RequestCorrection.RequestCorrectionPage import RequestCorrectionPage
from TestPages.Admin.SpecialTerms.DiscretionaryInvestmentManagementFeePage import DiscretionaryInvestmentManagementFeePage
from TestPages.Admin.SpecialTerms.ManageSchedulesPage import ManageSchedulesPage
from TestPages.Admin.TargetAllocationPage import TargetAllocationPage
from TestPages.Admin.Transfers.PostTransferDistributionPage import PostTransferDistributionPage
from TestPages.Admin.Transfers.TransfersOffPage import TransfersOffPage
from TestPages.Admin.UpdateAdviserFirmTermsPage import UpdateAdviserFirmTermsPage
from TestPages.Admin.UpdateCustomerTermsPage import UpdateCustomerTermsPage
from TestPages.Admin.UsersByGroupPage import UsersByGroupPage
from TestPages.Admin.ViewProjectsPage import ViewProjectsPage
from TestPages.ClientsPage import ClientsPage
from TestPages.ClientsTabs.SearchResults.AccountDetailsPage import AccountDetailsPage
from TestPages.ClientsTabs.SearchResults.AccountDetailsPageTrust import AccountDetailsPageTrust
from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
from TestPages.ClientsTabs.SearchResults.AccountsTransactionsTabPage import AccountsTransactionsTabPage
from TestPages.ClientsTabs.SearchResults.ClientDetailsBankDetailsPage import ClientDetailsBankDetailsPage
from TestPages.ClientsTabs.SearchResults.ClientDetailsCapitalGainsSettingsPage import ClientDetailsCapitalGainsSettingsPage
from TestPages.ClientsTabs.SearchResults.ClientDetailsMIFIRDecisionMakersPage import ClientDetailsMIFIRDecisionMakersPage
from TestPages.ClientsTabs.SearchResults.ClientDetailsSuspendedActivityPage import ClientDetailsSuspendedActivityPage
from TestPages.ClientsTabs.SearchResults.MigrateFromMPSPage import MigrateFromMPSPage
from TestPages.ClientsTabs.SearchResults.MigrateToMPSPage import MigrateToMPSPage
from TestPages.Mandates.AuditHistoryPage import AuditHistoryPage
from TestPages.Mandates.CreateExclusionGroupPage import CreateExclusionGroupPage
from TestPages.Mandates.SearchExclusionGroupPage import SearchExclusionGroupPage
from TestPages.Mandates.SetupAndSearchPage import SetupAndSearchPage
from TestPages.Menu import MenuConstants
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.ClientDetails.OrganisationDetails import OrganisationDetails
from TestPages.PageObjects.ClientDetails.PersonalDetailsPageBase import PersonalDetailsPageBase
from TestPages.PageObjects.Clients.AdviserPaymentsPage import AdviserPaymentsPage
from TestPages.PageObjects.DealReviewOrdersPage import DealReviewOrdersPage
from TestPages.PageObjects.Orders.OrdersOnHoldPage import OrdersOnHoldPage
from TestPages.ProductWizards.CapitalGainsScenarioToolPage import CapitalGainsScenarioToolPage
from TestPages.ProductWizards.CashAccountRegularPaymentInBasePage import CashAccountRegularPaymentInBasePage
from TestPages.ProductWizards.ISAEditRegularPaymentInPage import ISAEditRegularPaymentInPage
from TestPages.ProductWizards.ISAStocksAndSharesRegularPaymentInPage import ISAStocksAndSharesRegularPaymentInPage
from TestPages.ProductWizards.PersonalPortfolioRegularPaymentInPage import PersonalPortfolioRegularPaymentInPage
from TestPages.ProductWizards.PersonalPortfolioToSharesAndStocksISA import PersonalPortfolioToSharesAndStocksISA
from TestPages.ProductWizards.PortfolioInvestments.PPBuyInvestmentsOrderSetupPage import PPBuyInvestmentsOrderSetupPage
from TestPages.ProductWizards.PortfolioInvestments.PPSellInvestmentsOrderSetupPage import PPSellInvestmentsOrderSetupPage
from TestPages.ProductWizards.PortfolioInvestments.PPSSwitchInvestmentsOrderSetupPage import PPSSwitchInvestmentsOrderSetupPage
from TestPages.ProductWizards.PPEditRegularPaymentInPage import PPEditRegularPaymentInPage
from TestPages.ProductWizards.QuoteAndDealPage import QuoteAndDealPage
from TestPages.Trackingorders.ConversionsPage import ConversionsPage
from TestPages.Trackingorders.DealsAndSwitchesPage import DealsAndSwitchesPage
from TestPages.Trackingorders.InsuredFundDealsAndSwitchesPage import InsuredFundDealsAndSwitchesPage
from TestPages.Trackingorders.MPSmigrationstatusPage import MPSmigrationstatusPage
from TestPages.Trackingorders.PaymentAndWithdrawlPage import PaymentAndWithdrawlPage
from TestPages.Trackingorders.ProcessesPage import ProcessesPage
from TestPages.Trackingorders.TrackOrdersTransfersAndreregistrationsPage import TrackOrdersTransfersAndreregistrationsPage
from TestPages.Transactions.CorporateActionsPage import CorporateActionsPage
from TestPages.Transactions.FindDistributionsPage import FindDistributionsPage
from TestPages.Transactions.InvestmentTransactionsPage import InvestmentTransactionPage
from TestPages.Transactions.TaxReclaimPostingPage import TaxReclaimPostingPage
from TestPages.TransfersAndReregistrationsPage import TransfersAndReregistrationsPage
from TestPages.WebDriver import ExpectedConditions
from TestPages.Withdrawals.CreateOrdersWithdrawalsPage import CreateOrdersWithdrawalsPage
from TestPages.Wizards.AddNewClientWizard import AddNewClientWizard
from TestPages.Wizards.Bulk.FindClientsForBulkRebalancePage import FindClientsForBulkRebalancePage
from TestPages.Wizards.Bulk.FindClientsForBulkTradePage import FindClientsForBulkTradePage
from TestPages.Wizards.MaintainAdviserChargingWizard import MaintainAdviserChargingWizard
from TestPages.Wizards.ProductWizards.AberdeenSIPPEditIncomePaymentsPage import AberdeenSIPPEditIncomePaymentsPage
from TestPages.Wizards.ProductWizards.AbrdnJSIPPPaymentsInWizard import AbrdnJSIPPPaymentsInWizard
from TestPages.Wizards.ProductWizards.AbrdnSIPPUpdateAllowanceDetailsPage import AbrdnSIPPUpdateAllowanceDetailsPage
from TestPages.Wizards.Transfers.SIPP.TaxWrapperAllocationWizard import TaxWrapperAllocationWizard


class MenuGroup(BaseTestObject):
    dropDownGroupLocator = ".//button[contains(@class, 'trigger')]"
    dropDownElementLocator = ".//span[text()='{0}']//parent::button"
    hyperLinkGroupLocator = ".//a[contains(@class, 'custom-item')]"
    hyperLinkElementLocator = ".//a[contains(@class, 'custom-item') and text()='{0}']"
    buttonGroupLocator = "//button[contains(@class, 'custom-item')]"

    # this is set in LayoverProduct
    menuGroupForProductName = None

    def __init__(self, webdriver, parentElement, parentMenu: str):
        self.parentMenu = parentMenu
        byValue = f".//h2[text()='{self.parentMenu}']//parent::div"
        super().__init__(webdriver, parentElement, By.XPATH, byValue)

    @property
    def availableMenus(self):
        self.waitForNumberOfMenuElements()
        dropdownMenuItems = self.element.find_elements(By.XPATH, MenuGroup.dropDownGroupLocator)
        hyperlinkMenuItems = self.element.find_elements(By.XPATH, MenuGroup.hyperLinkGroupLocator)
        buttonMenuItems = self.element.find_elements(By.XPATH, MenuGroup.buttonGroupLocator)
        return hyperlinkMenuItems + dropdownMenuItems + buttonMenuItems

    @property
    def availableMenusText(self):
        return [k.text for k in self.availableMenus]

    def getMenuDropdown(self, dropdownMenuName):
        return DropdownListbox(self.webdriver, self.parentElement,
                               By.XPATH,
                               self.dropDownElementLocator.format(dropdownMenuName),
                               (By.XPATH, "//a[@class='item']"))

    @retry(exceptions=(UIException), delay=2, tries=5)
    def waitForNumberOfMenuElements(self, numberOfExpectedMenuItems=1):
        """
        Waits for menu elements within a column.
        Menu Column context is described by self.element
        """
        self.waitForElement()
        dropdownMenuItems = self.element.find_elements(By.XPATH, MenuGroup.dropDownGroupLocator)
        hyperlinkMenuItems = self.element.find_elements(By.XPATH, MenuGroup.hyperLinkGroupLocator)

        if len(dropdownMenuItems) + len(hyperlinkMenuItems) < numberOfExpectedMenuItems:
            raise UIException()

    @retry(exceptions=(UIException), delay=2, tries=5)
    def verifyPresenceOfMenuItems(self, expectedMenuItems: list):
        self.waitForNumberOfMenuElements(len(expectedMenuItems))
        locators = ((By.XPATH, MenuGroup.dropDownGroupLocator), (By.XPATH, MenuGroup.hyperLinkGroupLocator))

        for expectedMenuItem in expectedMenuItems:
            valueWaiter = ExpectedConditions.text_to_be_present_in_any_of_locators(locators, expectedMenuItem)
            WebDriverWait(self.parentElement, 60).until(valueWaiter)
        PrintMessage(f"Verified presence of '{expectedMenuItems}'", inStepMessage=True)

    def verifyPresenceOfDropdownMenuItems(self, dropdownMenuName: str, expectedMenuItems: list):
        dropdown = self.getMenuDropdown(dropdownMenuName)
        dropdownOptions = dropdown.getAvailableOptionsAsText(expectedMenuItems[0])

        assert sorted(dropdownOptions) == sorted(expectedMenuItems), f"expected \n'{expectedMenuItems}', got \n'{dropdownOptions}'"

        PrintMessage(f"Verified presence of '{expectedMenuItems}' in '{dropdownMenuName}'", inStepMessage=True)

    def getPage(self, menuName: str, subMenuName: str = None):
        match self.parentMenu:
            case MenuConstants.ClientDetails:
                match menuName:
                    case MenuConstants.PersonalDetails:
                        return PersonalDetailsPageBase(self.webdriver).navigateToPersonalDetailsTab()
                    case MenuConstants.AccountDetails:
                        return AccountDetailsPage(self.webdriver)
                    case MenuConstants.AccountDetailsTrust:
                        return AccountDetailsPageTrust(self.webdriver)
                    case MenuConstants.InterestedParties:
                        return AccountsRolesTabPage(self.webdriver)
                    case MenuConstants.BankDetails:
                        return ClientDetailsBankDetailsPage(self.webdriver)
                    case MenuConstants.MIFIRDecisionMakers:
                        return ClientDetailsMIFIRDecisionMakersPage(self.webdriver)
                    case MenuConstants.CapitalGainsSettings:
                        return ClientDetailsCapitalGainsSettingsPage(self.webdriver)
                    case MenuConstants.SuspendedActivity:
                        return ClientDetailsSuspendedActivityPage(self.webdriver)
                    case MenuConstants.OrganisationPersonalDetails:
                        return OrganisationDetails(self.webdriver)
            case MenuConstants.Others:
                match menuName:
                    case MenuConstants.Authorisation:
                        match subMenuName:
                            case MenuConstants.AuthoriseProcesses:
                                return AuthoriseProcessesPage(self.webdriver)
                    case MenuConstants.TermsAndConditions:
                        match subMenuName:
                            case MenuConstants.Others_UpdateAdviser:
                                return UpdateAdviserFirmTermsPage(self.webdriver)
                            case MenuConstants.UpdateCustomerTerms:
                                return UpdateCustomerTermsPage(self.webdriver)
                            case MenuConstants.AuthoriseAdviserFirmTerms:
                                return AuthoriseAdviserFirmTermsPage(self.webdriver)
                            case MenuConstants.AuthoriseCustomerTerms:
                                return AuthoriseCustomerTermsPage(self.webdriver)
                            case MenuConstants.ViewAdviserFirmTermsHistory:
                                return AdviserFirmTermsHistoryPage(self.webdriver)
                            case MenuConstants.ViewCustomerTermsHistory:
                                return CustomerTermsHistoryPage(self.webdriver)
            case "Investments":
                match menuName:
                    case "Model portfolios":
                        match subMenuName:
                            case "New portfolio":
                                return ModelPortfoliosNewPortfolioPage(self.webdriver)
                            case "List/edit portfolio":
                                return ListEditPortfolioPage(self.webdriver)
                            case "Attach/remove clients":
                                return AttachRemoveClientsPage(self.webdriver)
                    case "Mandates":
                        match subMenuName:
                            case "Setup & search":
                                return SetupAndSearchPage(self.webdriver)
                            case "Search exclusion group":
                                return SearchExclusionGroupPage(self.webdriver)
                            case "Create exclusion group":
                                return CreateExclusionGroupPage(self.webdriver)
                            case "Audit history":
                                return AuditHistoryPage(self.webdriver)
                    case MenuConstants.TARGET_ALLOCATION:
                        return TargetAllocationPage(self.webdriver)
                    case MenuConstants.REBALANCE:
                        return HoldingsExternalAssetsWizardPage(self.webdriver)
            case "Client activity":
                match menuName:
                    case MenuConstants.AddNewClient:
                        return AddNewClientWizard(self.webdriver)
                    case MenuConstants.FindAClient:
                        return ClientsPage(self.webdriver)
            case MenuConstants.ADMINISTER_ACCOUNTS:
                match menuName:
                    case MenuConstants.AGGREGATED_REPORTING:
                        return AdministerAccountsAggregatedReportingPage(self.webdriver)
                    case MenuConstants.AddEditFamilyDiscounts:
                        return AdministerAccountsCreateEditLinksPage(self.webdriver)
                    case MenuConstants.FAMILY_LINKED_ACCOUNTS:
                        return AdministerAccountsFamilyTermsLinkedAccountsPage(self.webdriver)
            case MenuConstants.Bulk:
                match menuName:
                    case MenuConstants.Sell:
                        return FindClientsForBulkTradePage(self.webdriver)
                    case MenuConstants.Switch:
                        return FindClientsForBulkTradePage(self.webdriver)
                    case MenuConstants.REBALANCE:
                        return FindClientsForBulkRebalancePage(self.webdriver)
            case MenuConstants.UsersAndAccess:
                match menuName:
                    case MenuConstants.AccessManagement:
                        match subMenuName:
                            case MenuConstants.UserSiteAccess:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.EditExistingAccountAccess:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.EditWrapProviderAccess:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.EditCompanyAccess:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.EditAdviserAccess:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.NewUsersEditCompanyAccessPage:
                                return EditCompanyAccess(self.webdriver)
                    case MenuConstants.UserManagement:
                        match subMenuName:
                            case MenuConstants.FindUser:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.NewUser:
                                return NewWebsiteUserPage(self.webdriver)
                            case MenuConstants.EditUser:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.SiteActivityLog:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.UserAccountActivity:
                                return FindWebsiteUsersPage(self.webdriver)
                            case MenuConstants.UsersByGroup:
                                return UsersByGroupPage(self.webdriver)
                    case MenuConstants.FirmConfiguration:
                        match subMenuName:
                            case MenuConstants.MIFIRDataCapture:
                                return MIFIRDataCapturePage(self.webdriver)
                            case MenuConstants.BulkClientMailingPreference:
                                return BulkClientMailingPreferencePage(self.webdriver)
            case MenuConstants.TRANSACTION_HISTORY:
                match menuName:
                    case MenuConstants.TRANSACTION_DETAILS:
                        match subMenuName:
                            case MenuConstants.CASH:
                                return AccountsTransactionsTabPage(self.webdriver)
            case MenuConstants.Transactions:
                match menuName:
                    case MenuConstants.TRANSACTION_HISTORY:
                        match subMenuName:
                            case MenuConstants.InvestmentTransactions:
                                return InvestmentTransactionPage(self.webdriver)

                    case MenuConstants.DistributionSchedules:
                        match subMenuName:
                            case MenuConstants.FindDistribution:
                                return FindDistributionsPage(self.webdriver)
                            case MenuConstants.DistributionDetails:
                                return FindDistributionsPage(self.webdriver)
                            case MenuConstants.QualifyingHoldings:
                                return FindDistributionsPage(self.webdriver)

                    case MenuConstants.CorporateActions:
                        match subMenuName:
                            case MenuConstants.FindCorporateActions:
                                return CorporateActionsPage(self.webdriver)
                            case MenuConstants.Detail:
                                return CorporateActionsPage(self.webdriver)
                            case MenuConstants.QualifyingHoldings:
                                return CorporateActionsPage(self.webdriver)
                            case MenuConstants.TaxReclaimPosting:
                                return TaxReclaimPostingPage(self.webdriver)

            case MenuConstants.Reporting:
                match menuName:
                    case MenuConstants.AdviserReports:
                        return AdviserReportGenerationPage(self.webdriver)
                    case MenuConstants.RemuneraionStatement:
                        return RemunerationStatementPage(self.webdriver)
                    case MenuConstants.BulkValuations:
                        return BulkValuationsPage(self.webdriver)
                    case MenuConstants.LEGACY_CLIENT_REPORTS:
                        return LegacyClientReportingPage(self.webdriver)

            case MenuConstants.Orders:
                match menuName:
                    case MenuConstants.DealsSwitches:
                        return DealReviewOrdersPage(self.webdriver)
                    case MenuConstants.Conversions:
                        return ConversionsPage(self.webdriver)
                    case MenuConstants.TRANSFERS_REREGISTRATIONS:
                        return TransfersAndReregistrationsPage(self.webdriver)
                    case MenuConstants.ORDERS_ON_HOLD:
                        return OrdersOnHoldPage(self.webdriver)
                    case MenuConstants.ORDER_COMPLETION:
                        return OrderCompletionPage(self.webdriver)

            case MenuConstants.Tracking:
                match menuName:
                    case MenuConstants.Orders:
                        match subMenuName:
                            case MenuConstants.Processes:
                                return ProcessesPage(self.webdriver)
                            case MenuConstants.Paymentswithdrawals:
                                return PaymentAndWithdrawlPage(self.webdriver)
                            case MenuConstants.TRANSFERS_REREGISTRATIONS:
                                return TrackOrdersTransfersAndreregistrationsPage(self.webdriver)
                            case MenuConstants.DealsSwitches:
                                return DealsAndSwitchesPage(self.webdriver)
                            case MenuConstants.MPSmigrationstatus:
                                return MPSmigrationstatusPage(self.webdriver)
                            case MenuConstants.InsuredFundDealsSwitches:
                                return InsuredFundDealsAndSwitchesPage(self.webdriver)

            case MenuConstants.AccountRestrictions:
                match menuName:
                    case MenuConstants.SuspendedActivityConfiguration:
                        return SuspendedActivityConfigurationPage(self.webdriver)
                    case MenuConstants.SuspendedReasonAuthorisation:
                        return SuspendedReasonAuthorisationPage(self.webdriver)

            case MenuConstants.Transfers:
                match menuName:
                    case MenuConstants.TransfersOff:
                        return TransfersOffPage(self.webdriver)
                    case MenuConstants.PostTransferDistribution:
                        return PostTransferDistributionPage(self.webdriver)

            case MenuConstants.PAYMENTS:
                match self.menuGroupForProductName:
                    case MenuConstants.ISAStocksAndShares:
                        match menuName:
                            case MenuConstants.ADD_REGULAR_PAYMENT:
                                return ISAStocksAndSharesRegularPaymentInPage(self.webdriver)
                            case MenuConstants.EDIT_REGULAR_PAYMENT:
                                return ISAEditRegularPaymentInPage(self.webdriver)

                    case MenuConstants.PERSONAL_PORTFOLIO | MenuConstants.PERSONAL_PORTFOLIO_002:
                        match menuName:
                            case MenuConstants.ADD_REGULAR_PAYMENT:
                                return PersonalPortfolioRegularPaymentInPage(self.webdriver)
                            case MenuConstants.EDIT_REGULAR_PAYMENT:
                                return PPEditRegularPaymentInPage(self.webdriver)

                    case MenuConstants.CASH_ACCOUNT:
                        match menuName:
                            case MenuConstants.ADD_REGULAR_PAYMENT:
                                return CashAccountRegularPaymentInBasePage(self.webdriver)
                            case MenuConstants.EDIT_REGULAR_PAYMENT:
                                return CashAccountRegularPaymentInBasePage(self.webdriver)

                    case MenuConstants.ABERDEEN_JSIPP:
                        match menuName:
                            case MenuConstants.ADD_REGULAR_PAYMENT:
                                return AbrdnJSIPPPaymentsInWizard(self.webdriver)
                            case MenuConstants.EDIT_REGULAR_PAYMENT:
                                return AbrdnJSIPPPaymentsInWizard(self.webdriver)

                match menuName:
                    case MenuConstants.EXISTING_CLIENT_NEW_BUSINESS:
                        return TaxWrapperAllocationWizard(self.webdriver)

            case MenuConstants.ISAManagement:
                match menuName:
                    case MenuConstants.TaxReclaim:
                        return TaxReclaimPage(self.webdriver)
                    case MenuConstants.ConsolTaxCertificate:
                        return ConsolidatedTaxCertificatePage(self.webdriver)
                    case MenuConstants.FilterTaxCertifcate:
                        return FilterTaxCertificatePage(self.webdriver)
                    case MenuConstants.VoidAndRepair:
                        return CashStockMovementPage(self.webdriver)

            case MenuConstants.SpecialTerms:
                match menuName:
                    case MenuConstants.ManageSchedules:
                        return ManageSchedulesPage(self.webdriver)
                    case MenuConstants.DiscretionaryInvestmentManagementFee:
                        return DiscretionaryInvestmentManagementFeePage(self.webdriver)

            case MenuConstants.IssueLogAdminMenu:
                match menuName:
                    case MenuConstants.LogIssue:
                        return IssueManagementLogIssuePage(self.webdriver)
                    case MenuConstants.ManageIssueLog:
                        return IssueManagementManageIssueLogPage(self.webdriver)
                    case MenuConstants.ViewProjects:
                        return ViewProjectsPage(self.webdriver)
                    case MenuConstants.AddProject:
                        return IssueManagementAddProjectPage(self.webdriver)

            case MenuConstants.Configuration:
                match menuName:
                    case MenuConstants.BulkClientMailingPreference:
                        return BulkClientMailingPreferencePage(self.webdriver)
                    case MenuConstants.CustomerMerge:
                        return CustomerMergePage(self.webdriver)

            case MenuConstants.MIAndReports:
                match menuName:
                    case MenuConstants.ManagementInfo:
                        match subMenuName:
                            case MenuConstants.ManagementInfoReports:
                                return ManagementInfoReportsPage(self.webdriver)
                            case MenuConstants.InlandRevenueReports:
                                return InlandRevenueReportsPage(self.webdriver)
                            case MenuConstants.EFMOpenLinesEnquiry:
                                return EFMOpenLinesEnquiryPage(self.webdriver)
                            case MenuConstants.EditTimeLimit:
                                return EditTimeLimitPage(self.webdriver)
                            case MenuConstants.AuthoriseTimeLimit:
                                return AuthoriseTimeLimitPage(self.webdriver)
                            case MenuConstants.TimeLimitHistory:
                                return TimeLimitHistoryPage(self.webdriver)

            case MenuConstants.PlatformSetUp:
                match menuName:
                    case MenuConstants.Network:
                        match subMenuName:
                            case MenuConstants.NetworkWizardSetup:
                                return NetworkWizardSetupPage(self.webdriver)
                            case MenuConstants.NetworkWizardInProgress:
                                return SearchCriteriaPage(self.webdriver)
                            case MenuConstants.NetworkWizardHistory:
                                return SearchCriteriaPage(self.webdriver)
                    case MenuConstants.Firms:
                        match subMenuName:
                            case MenuConstants.CompanyWizardSetup:
                                return CompanyWizardSetupPage(self.webdriver)
                            case MenuConstants.CompanyWizardInProgress:
                                return SearchCriteriaPage(self.webdriver)
                            case MenuConstants.CompanyWizardHistory:
                                return SearchCriteriaPage(self.webdriver)

            case MenuConstants.CASH:
                match menuName:
                    case MenuConstants.CHAPSSTPLimit:
                        return CHAPSSTPLimitedPage(self.webdriver)
                    case MenuConstants.UnmatchedItems:
                        match subMenuName:
                            case MenuConstants.UnmatchedExpectations:
                                return UnmatchedExpectationsPage(self.webdriver)
                            case MenuConstants.UnmatchedTransfers:
                                return UnmatchedTransfersPage(self.webdriver)
                    case MenuConstants.MatchedItems:
                        match subMenuName:
                            case MenuConstants.MatchedExpectations:
                                return MatchedExpectationsPage(self.webdriver)
                    case MenuConstants.ChequeProcessing:
                        match subMenuName:
                            case MenuConstants.ChequeIDCapture:
                                return ChequeIDCapturePage(self.webdriver)
                            case MenuConstants.ChequeIDReceipt:
                                return ChequeIDReceiptPage(self.webdriver)
                            case MenuConstants.ChequeStatus:
                                return ChequeStatusPage(self.webdriver)
                            case MenuConstants.AuthoriseChequeStatus:
                                return AuthoriseChequeStatusPage(self.webdriver)
                    case MenuConstants.Reports:
                        return ReportsPage(self.webdriver)
                    case MenuConstants.ManualCashAdjustments:
                        match subMenuName:
                            case MenuConstants.ManualCashAdjustments:
                                return ManualCashAdjustmentsPage(self.webdriver)
                            case MenuConstants.AuthoriseManualCashAdjustments:
                                return ManualCashAdjustmentAuthorisePage(self.webdriver)
                    case MenuConstants.AuthoriseWithdrawals:
                        return AuthoriseWithdrawalsPage(self.webdriver)
                    case MenuConstants.EndOfDayProcessing:
                        return EndOfDayProcessingPage(self.webdriver)
                    case MenuConstants.CHAPS:
                        return CHAPSPage(self.webdriver)
                    case MenuConstants.ResidualCashPaymentOut:
                        return ResidualCashPaymentsOutPage(self.webdriver)
                    case MenuConstants.DirectDebitFailures:
                        match subMenuName:
                            case MenuConstants.UnmatchedDirectDebitFailures:
                                return UnmatchedDirectDebitFailuresPage(self.webdriver)
                            case MenuConstants.MatchedDirectDebitFailures:
                                return MatchedDirectDebitFailuresPage(self.webdriver)
                            case MenuConstants.AuthoriseDirectDebitFailures:
                                return AuthoriseDirectDebitFailuresPage(self.webdriver)
                    case MenuConstants.BankRec:
                        match subMenuName:
                            case MenuConstants.Reports:
                                return ReportsPage(self.webdriver)
                    case MenuConstants.CASH_MANAGEMENT_ADMINISTRATION_CHARGE:
                        return CashManagementAdministrationChargePage(self.webdriver)
                    case MenuConstants.AUTHORISE_CASH_MANAGEMENT_ADMINISTRATION_CHARGE:
                        return AuthoriseCashManagementAdministrationChargePage(self.webdriver)

            case MenuConstants.AuthorisationsAndCorrections:
                match menuName:
                    case MenuConstants.Authorisation:
                        match subMenuName:
                            case MenuConstants.AuthoriseProcesses:
                                return AuthoriseProcessesPage(self.webdriver)
                            case MenuConstants.AuthoriseBankAccounts:
                                return AuthoriseBankAccountsPage(self.webdriver)
                            case MenuConstants.AuthoriseDocumentation:
                                return AuthoriseDocumentationPage(self.webdriver)
                            case MenuConstants.AuthoriseCompletePrices:
                                return AuthoriseCompletePricesPage(self.webdriver)
                            case MenuConstants.CompletePricesForBonds:
                                return CompletePricesForBondsPage(self.webdriver)
                            case MenuConstants.AuthoriseReregLetter:
                                return AuthoriseReregLetterPage(self.webdriver)
                            case MenuConstants.AuthoriseSavingsDirectProcesses:
                                return AuthoriseSavingsDirectProcessesPage(self.webdriver)
                    case MenuConstants.ErrorCorrections:
                        match subMenuName:
                            case MenuConstants.Request:
                                return RequestCorrectionPage(self.webdriver)
                            case MenuConstants.Authorise:
                                return AuthoriseCorrectionPage(self.webdriver)
                            case MenuConstants.History:
                                return HistoryPage(self.webdriver)
                            case MenuConstants.Reports:
                                return ReportsPage(self.webdriver)
                            case MenuConstants.AmendCompanyAddress:
                                return AmendCompanyAddressPage(self.webdriver)
                match menuName:
                    case MenuConstants.AuthoriseBwaReferrals:
                        return AuthoriseBWAReferralsPage(self.webdriver)

            case MenuConstants.OtherServices:
                match menuName:
                    case MenuConstants.NonTriggerWizards:
                        match subMenuName:
                            case MenuConstants.NewDealAndSwitch:
                                return AccountSearchPage(self.webdriver)
                            case MenuConstants.NewTransferAndRereg:
                                return AccountSearchPage(self.webdriver)
                match menuName:
                    case MenuConstants.ConversionsForReRegistration:
                        return ConversionForReregistrationPage(self.webdriver)
                match menuName:
                    case MenuConstants.Funding:
                        match subMenuName:
                            case MenuConstants.RequestFunding:
                                return RequestFundingPage(self.webdriver)
                            case MenuConstants.AuthoriseFunding:
                                return AuthoriseFundingPage(self.webdriver)
                            case MenuConstants.FundingHistory:
                                return FundingHistoryPage(self.webdriver)
                match menuName:
                    case MenuConstants.TestSoapRequest:
                        return TestSoapRequestPage(self.webdriver)
                    case MenuConstants.Services:
                        match subMenuName:
                            case MenuConstants.ServiceList:
                                return ServiceListPage(self.webdriver)
                            case MenuConstants.IncompleteWizards:
                                return IncompleteWizardsPage(self.webdriver)
                            case MenuConstants.ShadowingLog:
                                return ShadowingLogPage(self.webdriver)
                    case MenuConstants.Enquiries:
                        match subMenuName:
                            case MenuConstants.BatchQueries:
                                return BatchQueriesPage(self.webdriver)
                            case MenuConstants.OrderStatusQueries:
                                return OrderStatusQueriesPage(self.webdriver)
                match menuName:
                    case MenuConstants.ManualPlacement:
                        return ManualPlacementPage(self.webdriver)
                    case MenuConstants.HistoricStreamWorkflow:
                        return HistoricStreamWorkflowPage(self.webdriver)

            case MenuConstants.Charges:
                match menuName:
                    case MenuConstants.MaintainAdviserCharging:
                        return MaintainAdviserChargingWizard(self.webdriver)
                    case MenuConstants.AdviserPayments:
                        return AdviserPaymentsPage(self.webdriver)

            case MenuConstants.Adviser:
                match menuName:
                    case MenuConstants.NewAdviser:
                        return NewAdviserPage(self.webdriver)
                    case MenuConstants.FindAdviser:
                        return FindAdviserPage(self.webdriver)
                    case MenuConstants.ChangeOfAdviser:
                        return ChangeOfAdviserPage(self.webdriver)

            case MenuConstants.MoneyOut:
                match menuName:
                    case MenuConstants.Withdrawals:
                        return CreateOrdersWithdrawalsPage(self.webdriver)
                    case MenuConstants.MONEY_OUT_PP_TO_STOCKS_AND_SHARES_ISA:
                        return PersonalPortfolioToSharesAndStocksISA(self.webdriver)

            case MenuConstants.TOOLS:
                match menuName:
                    case MenuConstants.CAPITAL_GAINS_SCENARIO_TOOL:
                        return CapitalGainsScenarioToolPage(self.webdriver)

            case MenuConstants.ProductActions:
                from TestPages.Menu.LayoverProduct import LayoverProduct
                match menuName:
                    case productName if productName in [MenuConstants.ISAStocksAndShares, MenuConstants.ABERDEEN_JSIPP, MenuConstants.CASH_ACCOUNT] or MenuConstants.PERSONAL_PORTFOLIO in menuName:
                        layoverProduct = LayoverProduct(self.webdriver)
                        layoverProduct.productName = menuName
                        return layoverProduct

            case MenuConstants.Trading:
                match menuName:
                    case MenuConstants.Buy:
                        return PPBuyInvestmentsOrderSetupPage(self.webdriver)
                    case MenuConstants.Sell:
                        return PPSellInvestmentsOrderSetupPage(self.webdriver)
                    case MenuConstants.Switch:
                        return PPSSwitchInvestmentsOrderSetupPage(self.webdriver)
                    case MenuConstants.ADVANCED_ORDERS:
                        return QuoteAndDealPage(self.webdriver)

            case MenuConstants.ManagePortfolioService:
                match menuName:
                    case MenuConstants.MigrateToMPS:
                        return MigrateToMPSPage(self.webdriver)
                    case MenuConstants.MigrateFromMPS:
                        return MigrateFromMPSPage(self.webdriver)

            case MenuConstants.DRAWDOWN:
                match menuName:
                    case MenuConstants.UPDATE_ALLOWANCE_DETAILS:
                        return AbrdnSIPPUpdateAllowanceDetailsPage(self.webdriver)
                    case MenuConstants.EDIT_INCOME_PAYMENTS:
                        return AberdeenSIPPEditIncomePaymentsPage(self.webdriver)

            case MenuConstants.INSTRUMENTS:
                match menuName:
                    case MenuConstants.VALUATION_UPDATE:
                        return ValuationUpdatePage(self.webdriver)
                    case MenuConstants.APPLY_INCOME:
                        return ApplyIncomePage(self.webdriver)
                    case MenuConstants.VALUATION_AUTHORISATION:
                        return ValuationAuthorisationPage(self.webdriver)
                    case MenuConstants.MAINTAIN_MANAGER:
                        return MaintainManagerPage(self.webdriver)
                    case MenuConstants.CREATE_MANAGER:
                        return CreateManagerPage(self.webdriver)
                    case MenuConstants.MANAGER_AUTHORISATION:
                        return AuthoriseManagerPage(self.webdriver)
                    case MenuConstants.INSTRUMENT_AUTHORISATION:
                        return InstrumentAuthorisationPage(self.webdriver)
                    case MenuConstants.MAINTAIN_INSTRUMENT:
                        return MaintainInstrumentPage(self.webdriver)
                    case MenuConstants.CREATE_INSTRUMENT:
                        return CreateInstrumentPage(self.webdriver)

            case MenuConstants.INSURED_FUNDS:
                match menuName:
                    case MenuConstants.DEFERRED_TRADES:
                        return DeferredTradesPage(self.webdriver)

    @retry(exceptions=(UIException), delay=2, tries=3)
    def selectMenuItem(self,
                       menuName: str,
                       subMenuName=None,
                       menuPageToOpen: str = None,
                       comparisonOperator: operator = operator.eq):
        if (subMenuName):
            dropdown = self.getMenuDropdown(menuName)
            dropdown.selectOption(subMenuName)
            subMenuName = subMenuName if not menuPageToOpen else menuPageToOpen
            PrintMessage(f"Selected '{menuName} > {subMenuName}' option", inStepMessage=True)
        else:
            # Work around dynamically set product name i.e. Personal Portfolio (-002)
            menuItems = [k for k in self.availableMenus if comparisonOperator(k.text.lower(), menuName.lower())]
            if menuItems:
                menuItems[0].click()
                PrintMessage(f"Selected '{menuName}' option", inStepMessage=True)
                menuName = menuName if not menuPageToOpen else menuPageToOpen
            else:
                raise UIException(f"Not found '{menuName}' option. Available menus: {[k.text for k in self.availableMenus]}")

        return self.getPage(menuName, subMenuName)
