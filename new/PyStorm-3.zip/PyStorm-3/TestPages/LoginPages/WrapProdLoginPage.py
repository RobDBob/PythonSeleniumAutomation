from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.Unipass.UnipassLoginPage import UnipassLoginPage
from TestPages.WebDriver import ExpectedConditions as EC


class WrapProdLoginPage(BasePage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.ID, "frmlogin"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def navigate(self):
        url = self.testContext.getSetting(ConfigOptions.SLWRAP_SITE_URL)
        self.webdriver.get(url)

    def navigateToUnipassLogin(self):
        self.adviserLoginButton.click()
        return UnipassLoginPage(self.webdriver)

    @property
    def adviserLoginButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Adviser login']")
