from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestHelpers.DocumentDownloader import DocumentDownloader
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class NoChangeToolPage(BasePage):
    def __init__(self, webdriver):
        super().__init__(webdriver)
        self._documentDownloader = DocumentDownloader(self.webdriver, self.testContext)
        self._documentDownloader.HREF_LOCATOR = (By.XPATH, "//a[contains(@class,'download-button')]")

    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.NoChangeTool)

    def waitForDownloadButton(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//a[contains(@class,'download-button')]"))
        WebDriverWait(self.webdriver, 120).until(waitCondition)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[@class='user-name']")

    @property
    def accountIDLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class='account-id']")

    @property
    def createdDateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Created:']//parent::dt//following-sibling::dd")

    @property
    def wrapperLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Wrapper:']//parent::dt//following-sibling::dd")
