ABERDEEN_WILL_BE_INFORMED = "Aberdeen will be informed of any updates you made and will make any required updates to their records within 5 working days."
ACCOUNT_PENDING_AUTHORISATION_MESSAGE = "NOTE: There are updates to restrictions on this account pending authorisation"
ADDITIONAL_FEES_MAY_BE_INCURRED = "Addition fees may be incurred if this Asset is an off platform DFM or if your Pension holds a Drawdown arrangement"
AUTHORISE_CASH_ENTRIES_CONFIRMATION = "Are you sure you wish to Authorise/Reject these cash entries?"
ARE_YOU_SURE_YOU_WANT_TO_REMOVE_THIS_INVESTMENT = "Are you sure you want to remove this investment? Doing so may alter your model portfolio selections."
FATCA_CRS_BUSINESS_TYPE_TOOL_TIP_CONTENT = (
    "Under UK legislation we are required to collect certain tax information about the type of business that invests with us"
    " and possibly report some of that information to HMRC who in turn may share that information with other tax authorities"
    " around the world as appropriate. The Foreign Account Tax Compliance Act (‘’FATCA’’) was introduced by the U.S."
    " government in 2010. The UK adopted the frame work into UK legislation with an effective date of 1 July 2014."
    " FATCA requires us as platform provider to undertake specified due diligence, reporting and oversight obligations to detect and deter U.S. tax evasion."
    " The Common Reporting Standard (‘’CRS’’) was introduced by the OECD and implemented into UK law with an effective date of 1 January 2016."
    " Broadly similar to FATCA, the legislation requires us as platform provider to undertake essentially the same due diligence,"
    " reporting and oversight obligations to detect and deter tax evasion."
    " Please note that we are unable to provide tax advice in respect of the business type or questions on tax residency in respect of the business."
    " In case of any additional questions we would refer you to your tax advisor and/or the HMRC guidance available online.")
MINIMUM_AGE_WARNING_MESSAGE = ("If you are opening a Discounted Gift Plan, the minimum age of a Settlor on this type of Trust is 50 years old. "
                               "Additionally, the maximum age is 6 months before the Individuals 90th birthday.")
MINIMUM_REQUIRED_ONE_BENEFICIARY = "For new trusts where trust category is Absolute or Flexible a minimum of 1 beneficiary is required."
REMOVE_BENEFICIARY_WARNING = "At least 1 Beneficiary required for the trust account."
TRUST_MEMBERS_EXPLAINED = ("It is advised that the number of Trustees is greater than the number of Settlors.\nWhere Trust Type is "
                           "Existing, then a Settlor will not be required.\nMinimum age of a Settlor for a Discounted Gift Plan is 50 years "
                           "old, and max age is 6 months prior to 90th Birthday.\nA beneficiary is not required to be entered here if the "
                           "intended Trust Category will be Discretionary.\nClose")
ADD_MORE_TRUST_MEMBERS_MESSAGE = ("For new trusts where trust category is Absolute or Flexible a minimum of 1 beneficiary is required.\n"
                                  "It is advised that the number of Trustees is greater than the number of Settlors.\n"
                                  "Do you wish to add more Trust members?")
TRUST_NEW_OR_EXISTING_TOOL_TIP_CONTENT = ("A new trust is a trust that is created as part of the opening of a trust wrap account."
                                          " An existing trust is a trust which already exists at the time the trust wrap account is opened.")
LEI_TOOL_TIP_CONTENT = ("LEI means Legal Entity Identifier. It is a code unique to a legal entity or structure and required for transaction reporting purposes."
                        "Please see the FCA website for detail.")
MIFIR_DECISION_MAKERS_STATIC_MESSAGE = ("Use this page to capture any decision maker(s) representing the asset owners.\nDecision"
                                        " maker can then be selected when buying or selling a reportable instrument\nin accordance"
                                        " with MiFIR or a discretionary investment model.")
DECISION_MAKER_LEGAL_MESSAGE = (
    "The decision maker field is used where someone has a legal power of representation to act on behalf"
    " of the customer such as a Power of Attorney, Court appointed guardian or third party with a legally binding mandate."
    " This does not include executors or personal representatives of the deceased customer - in that case the customer is"
    " the buyer/seller and there is no decision maker.")
DISQUALIFYING_PENSION_CREDIT_MESSAGE = (
    "The disqualifying pension credit will be held under a separate header account."
    " Please note you will only be able to capture a single transfer as part of this application,"
    " if there are further transfers which are not subject to disqualifying pension credit or further single or regular payments in are required,"
    " or you wish to make a drawdown request as part of this application, please contact us on 0345 279 1001.")
YOU_MUST_ENTER_ADDRESS_LINE1 = "You must enter address line 1."
YOU_MUST_ENTER_ADDRESS_LINE2 = "You must enter address line 2."
YOU_MUST_ENTER_A_POSTCODE = "You must enter a postcode."
YOU_MUST_ENTER_RESIDENTIAL_ADDRESS = "You must enter residential address"
BUY_ACCOUNT_RESTRICTION_WARNING_MESSAGE = "An account with suspended or restricted activities cannot setup buy investments"
NO_NATIONAL_IDENTIFIER_DECISION_MAKER = ("No national identifier provided for the primary nationality."
                                         " Customer will be restricted trading in the exchange traded instruments")
DECLARATION_PART_A = ("This functionality is for migrating managed portfolios.  Migrating assets in different proportions to the"
                      " target allocation of the managed portfolio, may result in assets being rebalanced by the Investment Manager.")
DECLARATION_PART_B = ("I confirm that the chosen Discretionary Investment Manager has the authority to manage investments on behalf"
                      " of my client.This functionality is for migrating assets into managed portfolios. Migrating assets in different"
                      " proportions to the target allocation of the managed portfolio may result in assets being rebalanced by the Investment Manager."
                      "I also confirm that all provided book costs on Wrap are correct, and understand that once migrated to the Investment hub they"
                      " cannot be changed.")
DRAWDOWN_PRICE_LOCK_YES_ALERT_MESSAGE = ("Applying the Drawdown Price Lock means the platform charge for the Aberdeen SIPP "
                                         "won’t go up as money is taken out of the pension and the value is reduced")
QUANTITY_OF_UNITS_ALERT_MESSAGE = "You must enter a quantity of units greater than 0 to migrate to MPS portfolio"
REQUIRED_AGREEMENT_ALERT_MESSAGE = ("You must confirm that you hold evidence of the required agreement with the chosen Discretionary Investment Manager,"
                                    " and that all provided book costs on Wrap are correct.")
MIGRATE_FROM_MPS_DISCLAIMER = ("This functionality is for migrating assets out of the Managed Portfolio to the Wrap platform."
                               " Any assets that are not tradable on Wrap will be sold to cash.")
ALL_DATA_VALIDATED = "All data entered has been successfully validated."
TRUST_PROCESS_SUCCESSFULL = "Trust Process Updated Successfully"
ACCOUNT_RESTRICTION_UPDATE_SUCCESSFULL = "Account Restriction Update Process updated successfully"
NO_RESULTS_HAVE_BEEN_FOUND = "No results have been found for the entered criteria."
ENTER_THE_SEARCH_TERMS = "Enter the search terms below to find available trading account details and then click search."
ORDER_CANNOT_PLACED_DUE_TO_INSUFFICIENT_CASH = "Order cannot be placed due to Insufficient Cash!"
PLEASE_BE_AWARE = "Please be aware that your selection of assets may affect how early we can pay your client’s Pension Commencement Lump Sum (PCLS) and income"
PLEASE_FILL_IN_REGISTERED_AND_CORRESPONDANCE_ADDRESS = "Please fill in registered and correspondence address"
PLEASE_SELECT_EMPLOYMENT_STATUS = "Please select employment status"
PLEASE_SELECT_EMPLOYMENT_ROLE = "Please select employment role"
PLEASE_SELECT_OCCUPATION_INDUSTRY = "Please select occupation industry"
PLEASE_SELECT_SOURCE_OF_WEALTH_PRIMARY = "Please select source of wealth (Primary)"
PLEASE_SELECT_COUNTRY_OF_ORIGIN_PRIMARY = "Please select country of origin (Primary)"
CORRECTION_BATCH_CREATED_AND_VALIDATED_SUCCESSFULLY = "Correction Batch Created and Validated Successfully."
BATCH_AUTHORISED_SUCCESSFULLY_FOR_PROCESSING = "Batches authorised successfully for processing"
TRUST_MEMBER_IS_NOT_A_UK_RESIDENT = "Trust member is not a U.K. resident."
TAX_ID_NUMBER_CODIGO_DE_IDENTIFICATION_FISCAL = "Tax ID number (Código de identificación fiscal)"
YOU_CANNOT_ADD_BENEFICIARIES_AFTER_NEW_BUSINESS_WHERE_TRUST_CATEGORY_ABSOLUTE = ("You cannot add Beneficiaries after New Business where"
                                                                                 "Trust category = Absolute.")
PLEASE_NOTE_THAT_THE_CASH_DEPOSITS_AND_RATES = (
    "Please note that the cash deposits and rates offered are subject to change and the rates are not guaranteed"
    " until the funds reach the deposit taker. Cash deposits may be withdrawn at any time, if this happens and you"
    " have already placed an instruction to invest in a cash deposit with Bondsmith we will notify you and request"
    " alternative instructions. When selecting to invest in cash deposits please ensure you understand how they are protected."
    " Further information on this can be found in the FSCS information sheet or on the FSCS website.")
AER_STANDS_FOR_ANNUAL_EQUIVALENT_RATE = ("*AER stands for Annual Equivalent Rate. The AER illustrates what the interest rate would be "
                                         "if interest was paid and compounded once each year. It helps you compare interest rates across different products. "
                                         "Note: As part of our range of deposit takers, we have Sharia products which offer an expected profit rate, rather "
                                         "than interest on their savings products, in order to comply with Sharia banking principles")
CONFIRMATION_MESSAGE = (
    "I/ we have seen the appropriate documentation confirming the appointment of the Trustees to the Trust;\nall trustees of the Trust are "
    "recorded on the platform;\nthe above named Trustees have been advised that identify verification checks have been carried out to "
    "comply with the Money Laundering, Terrorist Financing and Transfer of Funds (Information on the Payer) Regulations 2017;\nthe "
    "information in relation to the Trustees which I have provided to Aberdeen was obtained by me;\nthe evidence I have obtained to verify "
    "the identity of the Trustees meets the standard evidence set out within the Guidance for the UK Financial Sector issued "
    "by JMLSG; or (ii) exceeds the standard evidence, in which case any further verification evidence taken are provided to Aberdeen;\nI will "
    "retain the above mentioned evidence and provide it to Aberdeen immediately upon request;\nI have not used the source of funds as evidence "
    "to verify the identity of the Trustees; and any follow-up action required regarding the tax residency self-certification of the Trustees "
    "has been completed (where applicable).\nImportant note: You must not add the Trustee to the platform if you cannot verify the Trustee's "
    "identity.")
YOU_MUST_ADD_A_NEW_TRUSTEE_BEFORE_REMOVING_SOLE_TRUSTEE = "You must add a new trustee before removing sole Trustee."
BEFORE_YOU_REMOVE_THIS_TRUSTEE = "Before you remove this Trustee, you must select another address for correspondence to go to."
NO_CASH_ENTRIES_FOR_THIS_ACCOUNT = "No cash entries have been raised for this account."
YOU_HAVE_NOT_SELECTED_ANY_PROCESS_TO_BE_AUTHORISED = "You have not selected any processes to be authorised."
SUBMITTED_THE_DOCUMENTS_TO_YOUR_CLIENT_FOR_E_SIGNATURE = "You have successfully submitted the documents to your client for e-signature."
YOU_CANNOT_AUTHORISE = "You have not selected any processes to be authorised.\nYou cannot authorise the request you posted"
THE_ESG_HUB_PROVIDES_INFORMATION = ("The ESG Hub provides information on your client’s portfolio for specific ESG themes. "
                                    "You can select from a number of themes and align these with your client’s ESG preferences. "
                                    "These can then be saved for analysis and populated in a report to share with your client. "
                                    "Your client’s preferences can be easily customised to allow you to tailor the information displayed to meet their needs.")
ADD_ONE_OFF_WITHDRAWAL = ("For the purposes of this What If illustration, the maximum estimated withdrawal includes any single payments and transfers."
                          " Withdrawals are assumed to be taken proportionally.")
WOULD_YOU_LIKETO_INCLUDE_OTHER_PRODUC_TONGOING_ADVISERCHARGING_IN_THE_ILLUSTRATION = ("Would you like to include other product "
                                                                                      "Ongoing Adviser Charging in the illustration?")
WORKFLOW_AND_NOTIFICATIONS_TEXT = ("Workflow and notifications allow you to manage your firms workflow and view activity specific to you."
                                   " A variety of filters can be set up to suit different needs across both"
                                   " Workflow and Notifications and help manage the information you see.")
INVESTMENT_SELECTION_PAGE_EXPECTED_TOOL_TIP_TEXT = ("Selecting Use Target Allocation, will input the clients current"
                                                    " target allocation into the IST section, with percentage allocation against each instrument.")
QUICK_SEARCH_TEXT = ("Search for a client or account quickly using first name(s),"
                     " surname, organisation or account number from anywhere in the platform using this search bar.")
PLEASE_MAKE_A_CONTRIBUTION_ERROR_MESSAGE = ("Please make a contribution to this product wrapper to continue."
                                            " To remove this product type, please navigate back to the wrapper selection step")
PLATFORM_NAVIGATION_CLIENTS = ("Clients - An advanced search which allows you to search by clients, consolidated or organisation accounts."
                               " You can search by more criteria here too, i.e. all clients with specific products or who have active regular payments.")
PENSION_CARRY_FORWARD_CALCULATOR_CONTENT = (
    "This calculator works out how much pension annual allowance"
    " your client has available for a tax year (including any unused allowance carried forward from earlier years)."
    " This will help you work out how much can be paid into your client's pension without triggering an annual allowance tax charge.")
MYFOLIO_LOOKTHROUGH_CONTENT = ("The MyFolio Lookthrough Tool has been designed to enable you to access performance"
                               ", the latest fund updates and commentary quickly and easily,"
                               " with options for flexible fund charting and creating customised client reports.")
MENU_SYSTEM_TEXT = ("The platform menu system is dynamic and provides access to tasks,"
                    " information and transactional activities within context of the position you are on the platform.")
FAVOURITES_TEXT = ("Create a list of your favourite and most used documents "
                   "by selecting the star icon next to a document name."
                   " Quickly and easily view your favourites shortlist by selecting this button.")
CAPPED_DRAWDOWN_CALCULATOR_CONTENT = ("This calculator helps you work out the maximum income"
                                      " your client could take from their pension pot if they"
                                      " started capped drawdown income review, now."
                                      " This is not a quote and the actual maximum permitted income amount may be different to the figure shown.")
CAPTIAL_GAIN_SCENARIO_TOOL_CONTENT = ("Allow you to calculate gains and loss on sales of Personal Portfolio"
                                      " investments, model scenarios and assess the impact of different withdrawal strategies.")
BULKREBALANCE_WARNING_MESSAGE_1MINIMUM_INVESTMENT_LIMITS_MAY_APPLY = ("Minimum investment limits may apply to some investment options."
                                                                      " These limits must be met or the instructions will fail.")
BULKREBALANCE_WARNING_MESSAGE_3PLEASE_REMEMBER_THAT_YOU_ARE_REQUIRED = ("Please remember that you are required to provide your client "
                                                                        "with the relevant information relating to this transaction, including the "
                                                                        "relevant SID(s), KID(s) and KIID(s), and that they have had "
                                                                        "a reasonable opportunity to read this information.")
BULKREBALANCE_WARNING_MESSAGE_4FOR_ISA_AND_PERSONAL_PORTFOLIO = ("For ISA and Personal Portfolio you may in some scenarios need "
                                                                 "to provide your client with a copy of pre-sales disclosure of "
                                                                 "expected cost and charges. If the client specific Charges "
                                                                 "Information Document (CID) is not available, a generic CID can be found here.")
MODEL_PORTFOLIO_CONFIRMATION_MESSAGE = ("Confirming the changes you have made to this Model"
                                        "Portfolio will automatically update all Client’s Target Asset Allocation Page for each product attached to "
                                        "the Model Portfolio. Please press the ‘Confirm’ Button to confirm saving the changes you have made, or press "
                                        "the ‘Cancel’ to return without saving the changes to the Model Portfolio.")
ORDER_VALUE_GREATER_THAN = "Order values greater than or equal to 95% have been amended to sell all units"
REVIEW_RECOMMENDED_REBALANCING = ("Review the recommended rebalancing transactions below. If you would like to change your client's target allocation, "
                                  "please use the Target Allocation screen.")
STATUS_CHANGE_CONFIRMATION_LABEL = "Status change(s) successful."
THERE_IS_CURRENTLY_NO_ACTIVE_ISA_ACCOUNT = "There is currently no active ISA account. Please create one before continuing with the PP to S&S ISA Application."
IMPORTANT_INFORMATION_MESSAGE = ("Important information\n\nIf any or all arrangements are unavailable to convert,"
                                 "the unavailability reason is detailed below and will need to be addressed or completed before conversion can take place."
                                 "The link below provides additional information on converting to flexible drawdown.")
WHERE_THE_INCOME_IS_ON_TARGET_BASIS = "Where the income is on a target basis, information must be provided to the user that " \
    "any income entered from an arrangement here will:"
YOU_CAN_CHANGE_YOUR_PASSWORD = "You can change your password online through our secure services with Okta."
FOLLOWING_BWA_REFERRALS_HAVE_BEEN_AUTHORISED = "Following bwa referrals have been authorised:"
ITFLS_DOCUMENTS_DECLARATIONS_MESSAGE = ("I will ensure that my client will meet the eligibility criteria of any investment held in their account as"
                                        " described in the relevant investment documentation.")
THIS_WILL_REMOVE_THIS_TRANSACTION_MESSAGE = ("This will remove this transaction from the matching screens. Any associated payments must be manually"
                                             " completed. This action cannot be reversed.")
CASH_MANAGEMENT_CHARGE_UPDATE_SUCCESSFULL = "Successfully updated 1 rows."
BENEFICIARIES_TOOL_TIP_MESSAGE = ("This is a summary of the primary beneficiaries who have been nominated by the scheme member. "
                                  "Where an Aberdeen SIPP Death Benefits Nomination form or other scheme member instruction has been received by us, "
                                  "we will use this form or instruction alongside the information shown here to decide who should "
                                  "receive death benefits from the Aberdeen SIPP.")
NO_BENEFICIARIES_SET_UP_FOR_PENSION = "No beneficiaries are currently set up for the pension."
BENEFICIARIES_NOMINATION_FORM = "Any completed Aberdeen SIPP Death Benefits Nomination form or other scheme member instructions can be viewed in the Document Library."
EDIT_BENEFICIARIES_CHARITY_POPUP_TEXT_MESSAGE = "If a charity is being nominated, please include the registered charity number alongside the name of the charity."
EDIT_BENEFICIARIES_NOMINATION_FORM__POPUP_TEXT_MESSAGE = ("If you are updating existing primary beneficiaries online,please review any associated Death Benefit"
                                                          "Nomination form saved in the document library to check if these instructions also need to be revised"
                                                          "to reflect your client’s current wishes.")
MAXUMUM_AMOUNT_OF_THREE_PAYMENTS_FOR_CLIENT_PAYMENT_TYPE_IS_EXCEEDED = "Maximum amount of three payments for Client payment type is exceeded"
DRAWDOWN_DETAILS_ERROR_MESSAGE = ("Tailored Drawdown cannot be selected because the Aberdeen SIPP holds non-compatible assets."
                                  " Please review and amend your client's investments if you wish to proceed.")
FCA_PERMISSION_ERROR_MESSAGE = "Unable to process application at this time due to insufficient FCA permissions"
FCA_PERMISSION_WARNING_MESSAGE = ("Unable to process application at this time due to insufficient FCA permissions."
                                  " (FCA permission not authorised or pension transfer permission not held)")
