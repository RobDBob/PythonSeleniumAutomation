from selenium.webdriver.common.by import By
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button


class BrewinAdvisorPage(ClientsPage):
    @property
    def menuButton(self):
        return Button(self.webdriver, self.webdriver, By.CLASS_NAME, "custom-navigation-trigger")

    @property
    def newClient(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='main-cta']")

    @property
    def workflowTab(self):
        return Button(self.webdriver, self.webdriver, By.ID, "tab-0")

    def wait(self):
        self.newClient.waitForText("New client")
