from enum import Enum


class ClientTabEnum(Enum):
    Summary = 1
    Investments = 2
    Performance = 3
    Insights = 4
    Transactions = 5
    Activity = 6
    Documents = 7
    Roles = 8
    ESG = 9
