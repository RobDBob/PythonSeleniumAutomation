from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class BusinessManagementPage(PlatformPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.ID, "Firm"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def network(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Network']")

    @property
    def networkField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "Network")

    @property
    def firm(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Firm']")

    @property
    def firmField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "Firm")

    @property
    def updateButton(self):
        return Button(self.webdriver, self.webdriver, By.CLASS_NAME, "btn.secondary")
