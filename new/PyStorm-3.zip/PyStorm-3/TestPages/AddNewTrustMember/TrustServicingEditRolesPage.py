from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB


class TrustServicingEditRolesPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TRUST_SERVICING_EDIT_ROLES)

    def navigateToTrustServicingPageFromEditRolesPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.cancelButton.click()
        return TrustServicingPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']//h1")

    @property
    def trustMemberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Trust member']")

    @property
    def trustMemberNameLabel(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='content']")

    @property
    def individualTrusteeCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Individual trustee']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def beneficiaryCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Beneficiary']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Save']")
