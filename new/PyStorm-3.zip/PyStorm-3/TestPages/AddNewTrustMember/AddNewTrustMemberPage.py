from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.TrustCorporateMembersRow import TrustCorporateMembersRow
from TestPages.PageObjects.BaseObjects.Table.Rows.TrustIndividualMembersRow import TrustIndividualMembersRow
from TestPages.PageObjects.ClientDetails.TrustServicingDetailsPage import TrustServicingDetailsPage
from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
from TestPages.Wizards.AddNewClientTrustMemberWizard import AddNewClientTrustMemberWizard


class AddNewTrustMemberPage(AddNewClientTrustMemberWizard):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ADD_NEW_TRUST_MEMBERS)

    def submitAndNavigateToTrustServicingPage(self):
        self.submitButton.click()
        return TrustServicingPage(self.webdriver)

    def submitAndNavigateToDetailsTrustServicingPage(self):
        self.submitButton.click()
        return TrustServicingDetailsPage(self.webdriver)

    def setWithTrustMemberData(self, testData: dict):
        self.addNewCustomers(testData.get("AddNewTrustMember", []))

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def trustNameSubTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Trust Name']")

    @property
    def trustEntityNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Name')]//following-sibling::p[contains(text(),'Trust')]")

    @property
    def existingTrustMembersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Existing trust members']")

    @property
    def individualMembersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Individual members']")

    @property
    def corporateMembersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Corporate members']")

    @property
    def confirmationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'I/ we confirm that')]//preceding-sibling::h2[text()='Confirmation']")

    @property
    def confirmationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'I/ we confirm that')]//following-sibling::ol")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Submit']")

    @property
    def trustIndividualMembersTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "(//table[@class='data-table'])[1]")
        resultTable.rowType = TrustIndividualMembersRow
        resultTable.headerCellLocator = (By.XPATH, ".//tr[@class='sub-head']//th//span")
        return resultTable

    @property
    def trustCorporateMembersTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "(//table[@class='data-table'])[2]")
        resultTable.rowType = TrustCorporateMembersRow
        resultTable.headerCellLocator = (By.XPATH, ".//tr[@class='sub-head']//th//span")
        return resultTable
