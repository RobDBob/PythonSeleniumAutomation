from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class AddAdditionalBeneficiaryWarningPopUpPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WARNING)

    def navigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.okButton.click()
        return TrustServicingPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Warning']")

    @property
    def popUpMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'You cannot add Beneficiaries')]")

    @property
    def okButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='OK']")
