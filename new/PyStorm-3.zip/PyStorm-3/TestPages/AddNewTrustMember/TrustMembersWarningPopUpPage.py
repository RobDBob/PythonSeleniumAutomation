from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class TrustMembersWarningPopUpPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WARNING)

    def navigateToRolesTab(self):
        from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
        self.okButton.click()
        return AccountsRolesTabPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']//h1")

    @property
    def youMustAddMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'You must add a new trustee')]")

    @property
    def beforeYouRemoveMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Before you remove this Trustee')]")

    @property
    def okButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='OK']")
