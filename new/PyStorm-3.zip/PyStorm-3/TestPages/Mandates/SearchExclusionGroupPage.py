from selenium.webdriver.common.by import By
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Labels import Label


class SearchExclusionGroupPage(ClientsPage):
    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    def wait(self):
        self.pageTitle.waitForText("Search Exclusion Group")
