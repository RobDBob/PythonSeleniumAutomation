from selenium.webdriver.common.by import By
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Labels import Label


class SetupAndSearchPage(ClientsPage):
    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    def wait(self):
        self.pageTitle.waitForText("Mandate Search")
