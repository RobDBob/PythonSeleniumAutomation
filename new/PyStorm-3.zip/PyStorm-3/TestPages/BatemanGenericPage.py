from selenium.webdriver.common.by import By
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.Okta.OktaLoginPage import OktaLoginPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class BatemanGenericPage(BasePage):
    def navigate(self):
        url = self.testContext.getSetting(ConfigOptions.BATEMAN_GENERIC_URL)
        self.webdriver.get(url)

    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.WELCOME_TO_THE_BATEMAN_ASSET_MANAGEENT_PLATFORM)

    def navigateToOktaLoginPage(self):
        self.clientLoginButton.click(jsClick=True)
        return OktaLoginPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def clientLoginButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='imgCustomer']")
