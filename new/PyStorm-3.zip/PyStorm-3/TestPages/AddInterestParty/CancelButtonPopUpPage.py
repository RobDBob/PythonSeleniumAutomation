from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class CancelButtonPopUpPage(BaseTestObject):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.DO_YOU_WANT_TO_CANCEL)

    def navigateToRolesTabPageFromCancelYesButton(self):
        from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
        self.yesButton.click()
        return AccountsRolesTabPage(self.parentElement)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']//h1")

    @property
    def popUpMessage(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//p[contains(text(),'If you cancel, you lose the')]")

    @property
    def areYouSureCancelMessage(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//p[text()='Are you sure you want to cancel?']")

    @property
    def yesButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Yes']")

    @property
    def noButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='No']")
