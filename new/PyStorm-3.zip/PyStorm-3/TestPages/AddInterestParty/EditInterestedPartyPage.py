from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class EditInterestedPartyPage(BasePage):
    ERROR_MESSAGE_ELEMENT_LOCATOR = (By.XPATH, "//div[@class='inline-error-message error']")

    def wait(self):
        self.pageTitle.waitForText(PageEnums.EDIT_INTERESTED_PARTY)

    def navigateToRolesTabPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
        self.submitButton.click()
        return AccountsRolesTabPage(self.webdriver)

    def navigateToCancelPopUpPage(self):
        from TestPages.AddInterestParty.CancelButtonPopUpPage import CancelButtonPopUpPage
        self.cancelButton.click()
        return CancelButtonPopUpPage(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']")

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cancel']")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Submit']")

    @property
    def titleDropdown(self):
        titleDropDownLocator = "//label[text()='Title']//parent::div//following-sibling::div//select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, titleDropDownLocator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def firstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']//parent::div//following-sibling::div//input")

    @property
    def surNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']//parent::div//following-sibling::div//input")

    @property
    def enterAddressManuallyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Or enter address manually']")

    @property
    def addressLine1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 1']/parent::div/following-sibling::div/input")

    @property
    def addressLine2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 2']/parent::div/following-sibling::div/input")

    @property
    def addressLine3EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 3']/parent::div/following-sibling::div/input")

    @property
    def countryDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "(//label[text()='Country']/parent::div/following-sibling::div/select)[1]",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def residentialAddressLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//b[text()='Residential address']")

    @property
    def residentialAddressInfoLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='address-info']")

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='control-label']//label[text()='Title']")

    @property
    def surNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='control-label']//label[text()='Surname']")

    @property
    def addressLineOneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='control-label']//label[text()='Address line 1']")

    @property
    def addressLineTwoLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='control-label']//label[text()='Address line 2']")

    @property
    def postCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='control-label']//label[text()='Postcode']")

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Postcode']/parent::div/following-sibling::div/input")
