import operator
import re
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import getFakeUKAddress
from TestPages import DataEnums, PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.SmartSearchEdit import SmartSearchEdit
from TestPages.PageObjects.BaseObjects.Table.ExistingCustomerTable import ExistingCustomerTable, ExistingCustomerTableRow
from TestPages.WebDriver import ExpectedConditions as EC
from TestPages.Wizards.NewClient.NationalitySetterCommon import NationalitySetterCommon


class AddInterestedPartyPage(BasePage, NationalitySetterCommon):
    ADDRESS_VALIDATION_ERROR_MESSAGE_LOCATOR = (By.XPATH, "//p[@class='error-message undefined']")
    ERROR_MESSAGE_LOCATOR = (By.XPATH, "//div[@class='inline-error-message error']")

    def _getNationalitySectionElement(self, index):
        locator = (By.XPATH, "//h2[text()='Client details']/parent::div//label[text()='Country of nationality']//ancestor::div[@class='row']/parent::div")
        valueWaiter = EC.presence_of_all_elements_located(locator, expectedElementsCount=index, compareOperator=operator.gt)
        WebDriverWait(self.webdriver, 30).until(valueWaiter)
        sections = self.webdriver.find_elements(*locator)
        return sections[index]

    def _getCountryOfNationalityDropdown(self, index):
        sectionElement = self._getNationalitySectionElement(index)
        dropdown = DropdownListbox(self.webdriver,
                                   sectionElement,
                                   By.XPATH,
                                   ".//label[text()='Country of nationality']/parent::div/following-sibling::div/select",
                                   (By.XPATH, ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    def _getPrimaryCitzenshipButtonYes(self, index):
        sectionElement = self._getNationalitySectionElement(index)
        return Button(self.webdriver, sectionElement, By.XPATH, ".//span[text()='Yes']")

    def _getPrimaryCitzenshipButtonNo(self, index):
        sectionElement = self._getNationalitySectionElement(index)
        return Button(self.webdriver, sectionElement, By.XPATH, ".//span[text()='No']")

    def getCountryOfNationalityCount(self):
        return self.webdriver.find_elements(By.XPATH, "//label[text()='Country of nationality']/parent::div/following-sibling::div/select")

    def wait(self):
        self.pageTitle.waitForText(PageEnums.AddInterestedParty)
        self.pageSubTitle.waitForText(PageEnums.CLIENT_DETAILS)

    def navigateToRolesTabPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
        self.submitButton.click()
        return AccountsRolesTabPage(self.webdriver)

    @retry(exceptions=(TimeoutException, UIException), tries=3, delay=3)
    def checkAndRefreshRolesDropdownIfNoOptionsAvailable(self, accountIdCheckBox, requiredOption):
        """
        Checks if required option is available in roles dropdown.
        If not available, refreshes the dropdown by unchecking and rechecking the account checkbox.
        """
        # Retrieve all available options from the roles dropdown
        options = self.rolesDropdown.getAvailableOptionsAsText()

        # Use requiredOption if provided, otherwise default to THIRD_PARTY_PAYER (last appearing option)
        dropdownOption = requiredOption if requiredOption else PageEnums.THIRD_PARTY_PAYER

        # Check if the required option exists in the available dropdown options
        if dropdownOption in options:
            PrintMessage(f"Roles dropdown options available: {options}", inStepMessage=True)
        else:
            # If required option is not available, refresh the dropdown by toggling the account checkbox
            PrintMessage("No options available in roles dropdown. Unchecking and rechecking account checkbox.", inStepMessage=True)
            # Uncheck and check the account checkbox to refresh options
            accountIdCheckBox.click()
            accountIdCheckBox.click()

    def selectAccountCheckBox(self, accountID, rolesDropdown=True, expectedOption=False):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//span[@class='label']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        accountIdCheckBox = self.webdriver.find_element(
            By.XPATH, f"//span[@class='label' and contains(text(),'{accountID}')]")
        accountIdCheckBox.click()
        if rolesDropdown:
            self.checkAndRefreshRolesDropdownIfNoOptionsAvailable(accountIdCheckBox, expectedOption)

    def navigateToCancelPopUpPage(self):
        from TestPages.AddInterestParty.CancelButtonPopUpPage import CancelButtonPopUpPage
        self.cancelButton.click()
        return CancelButtonPopUpPage(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']")

    def getErrorMessages(self):
        return [k.text for k in self.webdriver.find_elements(By.XPATH, "//div[@class='inline-error-message error']")]

    def getAddressValidationErrorMessages(self):
        return [k.text for k in self.webdriver.find_elements(By.XPATH, "//p[@class='error-message undefined']")]

    def selectJointAccountCheckBox(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//span[@class='label']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        accountCheckBoxElements = self.webdriver.find_elements(
            By.XPATH, "//h2[text()='Client details']//following-sibling::fieldset//div//label//span[@class='label']")
        jointAccountSearch = '&amp;'
        foundJointAccount = 0
        for element in accountCheckBoxElements:
            text = element.text
            if re.search(jointAccountSearch, text):
                Button(self.webdriver, self.webdriver, element).click()
                foundJointAccount = 1
            else:
                pass
        if foundJointAccount == 0:
            PrintMessage("Unable to find joint account")

    def waitForValidationErrors(self, validationErrors):
        PrintMessage(f'Waiting for validation error {validationErrors}...')
        waitCondition = EC.text_to_be_present_in_any_of_elements(
            (By.XPATH, "//div[@class='inline-error-message error']"), validationErrors)
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def isRadioButtonChecked(self, button: Button):
        return button.find_element(By.XPATH, ".//preceding-sibling::input").get_attribute('checked')

    def setAddInterestedPartyData(self, interestedPartyData, interestedPartyRoleType=PageEnums.LEGAL_REPRESENTATIVE_OR_EXECUTOR, readOnlyAccess=PageEnums.NO):
        address = getFakeUKAddress()
        self.newRadioButton.click()
        self.titleDropdown.selectOption(PageEnums.MR)
        self.firstNameEditField.enterValue(interestedPartyData[DataEnums.ADD_INTERESTED_PARTY_FIRST_NAME])
        self.surNameEditField.enterValue(interestedPartyData[DataEnums.ADD_INTERESTED_PARTY_SURNAME])
        # The below codes checks the Interested Party Role and acts accordingly
        if interestedPartyRoleType == PageEnums.THIRD_PARTY_PAYER:
            self.dateOfBirthDatePicker.specify_date(interestedPartyData[DataEnums.DOB])
        if interestedPartyRoleType in [PageEnums.LEGAL_REPRESENTATIVE_OR_EXECUTOR, PageEnums.ACCOUNT_ACCESS, PageEnums.POWER_OF_ATTORNEY]:
            self.dateOfBirthDatePicker.specify_date(interestedPartyData[DataEnums.DOB])
            if readOnlyAccess == PageEnums.YES:
                self.readOnlyAccessYesRadioButton.click()
            else:
                self.readOnlyAccessNoRadioButton.click()
        self.enterAddressManuallyButton.click()
        self.addressLine1EditField.enterValue(address["AddressLine1"])
        self.addressLine2EditField.enterValue(address["AddressLine2"])
        self.postCodeEditField.enterValue(address["PostCode"])
        if interestedPartyData.get("Nationalities", None):
            self.setWithNationalityData(interestedPartyData['Nationalities'])
        if interestedPartyData.get("NationalInsuranceNumber", None):
            self.nationalInsuranceNumberEditField.enterValue(interestedPartyData['NationalInsuranceNumber'])
        if interestedPartyData.get("NationalPassportNumber", None):
            self.nationalPassportNumberEditField.enterValue(interestedPartyData['NationalPassportNumber'])

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cancel']")

    @property
    def pageSubTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Client details']")

    @property
    def accountCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "(//h2[text()='Client details']//parent::div//div//label)[1]")

    @property
    def accountCustomerNameAndAccountNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h2[text()='Client details']//parent::div//div//span[@class='label'])[1]")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Submit']")

    @property
    def clientDetailsEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Client details']")

    @property
    def rolesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Role']")

    @property
    def rolesDropdown(self):
        locator = "//label[text()='Role']//parent::div//following-sibling::div//select"
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def pleaseSelectOptionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//option[text()='Please select']")

    @property
    def newRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='New']//parent::label")

    @property
    def existingRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Existing']//parent::label")

    @property
    def titleDropdown(self):
        titleDropDownLocator = "//label[text()='Title']//parent::div//following-sibling::div//select"
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver, By.XPATH, titleDropDownLocator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def firstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']//parent::div//following-sibling::div//input")

    @property
    def surNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']//parent::div//following-sibling::div//input")

    @property
    def dateOfBirthDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']//parent::div//following-sibling::div")

    @property
    def enterAddressManuallyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Or enter address manually']")

    @property
    def addressLine1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 1']/parent::div/following-sibling::div/input")

    @property
    def addressLine2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 2']/parent::div/following-sibling::div/input")

    @property
    def addressLine3EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Address line 3']/parent::div/following-sibling::div/input")

    @property
    def countryDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "(//label[text()='Country']/parent::div/following-sibling::div/select)[1]",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def countryOfNationalityLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Country of nationality']")

    @property
    def countryOfNationalityDropdown(self):
        return self._getCountryOfNationalityDropdown(0)

    @property
    def clientPrimaryCitizenshipLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Client primary citizenship']")

    @property
    def clientPrimaryCitizenshipYesRadioButton(self):
        return self._getPrimaryCitzenshipButtonYes(0)

    @property
    def clientPrimaryCitizenshipNoRadioButton(self):
        return self._getPrimaryCitzenshipButtonNo(0)

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Postcode']/parent::div/following-sibling::div/input")

    @property
    def legalRepresentativeExecutorOptionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//option[text()='Legal representative/Executor']")

    @property
    def thirdPartyPayerOptionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//option[text()='Third party payer']")

    @property
    def readOnlyAccessLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Read only access']")

    @property
    def readOnlyAccessYesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Read only access']//parent::div/parent::div/following-sibling::div//label//input//following-sibling::span[text()='Yes']")

    @property
    def readOnlyAccessNoRadioButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "//legend[text()='Read only access']//parent::div/parent::div/following-sibling::div//label//input//following-sibling::span[text()='No']")

    @property
    def readOnlyAccessYesRadioButtonNotPreselected(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Yes']//parent::label")

    @property
    def readOnlyAccessNoRadioButtonNotPreselected(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='No']//parent::label")

    @property
    def nationalInsuranceNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='National Insurance Number']//parent::div//following-sibling::div/input")

    @property
    def iDontOwnThisIdentifierCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'own this identifier')]")

    @property
    def residentialAddressLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//b[text()='Residential address']")

    @property
    def phoneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Phone']")

    @property
    def phoneHintLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Phone']//following-sibling::p")

    @property
    def countryLandlineNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h3[text()='Phone']//following::div//label[text()='Country'])[1]")

    @property
    def countryLandlineNumberDropdown(self):
        dropDownListBox = DropdownListbox(self.webdriver,
                                          self.webdriver,
                                          By.XPATH,
                                          "(//label[text()='Country']//parent::div//following-sibling::div/select)[2]",
                                          (By.TAG_NAME,
                                           'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def landlineNumberOptionalLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Landline number (optional)']")

    @property
    def landlineNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Landline number (optional)']//parent::div//following-sibling::div/input")

    @property
    def countryMobileNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h3[text()='Phone']//following::div//label[text()='Country'])[2]")

    @property
    def countryMobileNumberDropdown(self):
        dropDownListBox = DropdownListbox(self.webdriver,
                                          self.webdriver,
                                          By.XPATH,
                                          "(//label[text()='Country']//parent::div//following-sibling::div/select)[3]",
                                          (By.TAG_NAME,
                                           'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def mobileNumberOptionalLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Mobile number (optional)']")

    @property
    def mobileNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Mobile number (optional)']//parent::div//following-sibling::div/input")

    @property
    def residentialAddressHeadedWithStartTypingAddressLabel(self):
        return EditField(self.webdriver,
                         self.webdriver,
                         By.XPATH,
                         "//label[text()='Residential address']/parent::div/following-sibling::div//input[@placeholder='Start typing address or postcode...']")

    @property
    def residentialAddressPOBoxesFinancialAdviserAddressesLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Residential address']//parent::div//parent::div//parent::div//p[contains(text(),'PO boxes /')]")

    @property
    def letterOfAuthorityOptionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//option[text()='Letter of authority']")

    @property
    def residentialAddressSearchBox(self):
        smartSearch = SmartSearchEdit(self.webdriver,
                                      self.webdriver, By.XPATH, "//label[text()='Residential address']//parent::div//following-sibling::div")
        smartSearch.searchResultToSelectLocator = (
            By.XPATH, ".//ul[@id='ui-id-1']/li/div[text()='{0}']")
        return smartSearch

    @property
    def residentialAddressInfoLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='address-info']")

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Title']")

    @property
    def firstNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']")

    @property
    def surnameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']")

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']")

    @property
    def searchForCustomerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Search for customer']")

    @property
    def searchForCustomerField(self):
        smartSearch = SmartSearchEdit(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Search for customer']/following-sibling::div")
        smartSearch.searchResultToSelectLocator = (By.XPATH, ".//input[text()='{0}']")
        return smartSearch

    @property
    def addAnotherNationalityButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Add another nationality']")

    @property
    def countryOfNationalitySecondDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "(//label[text()='Country of nationality']/parent::div/following-sibling::div/select)[2]",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def nationalPassportNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Passport')]")

    @property
    def nationalPassportNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Passport')]//parent::div//following-sibling::div//input")

    @property
    def nationalInsuranceNumberWarningLabel(self):
        return Label(self.webdriver,
                     self.webdriver,
                     By.XPATH,
                     "//label[text()='National Insurance Number']//parent::div//following-sibling::div//div//p[text()='Please enter']")

    @property
    def nationalPassportNumberWarningLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Passport')]//parent::div//following-sibling::div//div//p[text()='Please enter']")

    @property
    def clientPrimaryCitizenshipWarningLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client primary citizenship']//ancestor::fieldset//div//p[text()='Please select']")

    @property
    def nationalIdentificationNumberWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH,
                     "//label[contains(text(),'National Identification Number')]//parent::div//following-sibling::div//child::div//p[text()='Please enter']")

    @property
    def iDontOwnThisIdentifierOneCheckBox(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//span[contains(text(),'own this identifier')])[1]")

    @property
    def iDontOwnThisIdentifierTwoCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "(//span[contains(text(),'own this identifier')])[2]")

    @property
    def clientPrimaryCitizenshipNo2RadioButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "(//legend[text()='Client primary citizenship']//parent::div/parent::div/following-sibling::div//label//span[text()='No'])[2]")

    @property
    def existingCustomerTable(self):
        resultTable = ExistingCustomerTable(
            self.webdriver,
            self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.rowType = ExistingCustomerTableRow
        resultTable.headerCellLocator = (
            By.XPATH, "//tr[@class='sub-head']//th//span")
        return resultTable

    @property
    def searchForCustomerEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Search for customer']/following-sibling::div")

    @property
    def noResultsDataLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'No results')]")

    @property
    def searchForCustomerMagnifyingGlassButton(self):
        return Button(self.webdriver, self.webdriver, By.CLASS_NAME, "search-icon")

    @property
    def dateOfBirthDate(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']//parent::div//following-sibling::div/div/input")

    @property
    def personalIdentificationCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Personal')]")

    @property
    def personalIdentificationCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Personal')]//parent::div//following-sibling::div//input")

    @property
    def nationalIdentificationNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'National Identification Number')]")

    @property
    def nationalIdentificationNumberEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'National Identification Number')]//parent::div//following-sibling::div//input")
