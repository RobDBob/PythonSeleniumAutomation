from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class RemoveInterestedPartyPopupPage(BaseTestObject):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ARE_YOU_SURE_YOU_WANT_TO_DELETE)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//p[text()='Are you sure you want to delete?']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Cancel']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Delete']")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//div[@class='header']//button[@class='close-btn']")
