from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class BatemanConfigSitePage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WhatDoYouWantToSearchFor)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'What do you')]")

    @property
    def menuButton(self):
        return Button(self.webdriver, self.webdriver, By.CLASS_NAME, "custom-navigation-trigger")

    @property
    def newClientButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='main-cta']")
