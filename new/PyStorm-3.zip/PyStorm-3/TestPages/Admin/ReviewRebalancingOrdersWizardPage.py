from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.RebalanceWizardBasePage import RebalanceWizardBasePage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ReviewRebalancingOrdersInvestmentsTableRow import ReviewRebalancingOrdersInvestmentsTableRow


class ReviewRebalancingOrdersWizardPage(RebalanceWizardBasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.REVIEW_REBALANCING_ORDERS)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def reviewRebalancingOrdersInvestmentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h1//following-sibling::table[@class='data-table']")
        table.rowType = ReviewRebalancingOrdersInvestmentsTableRow
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        table.rowLocator = (By.XPATH, ".//tr[@class='sub-head']")
        return table
