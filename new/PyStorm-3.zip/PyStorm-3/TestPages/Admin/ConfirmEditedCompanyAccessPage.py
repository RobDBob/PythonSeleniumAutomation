from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ConfirmEditedCompanyAccessPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.EDIT_COMPANY_ACCESS)
        self.readWriteMessageLabel.waitForElement()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Edit Company Access')]")

    @property
    def readWriteMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div//p[contains(text(),'Read/Write Company level access to FSAGKU')]")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btnConfirm' and contains(text(),'Confirm')]")

    @property
    def securityAccessConfirmationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Security access for this user has been updated.')]")
