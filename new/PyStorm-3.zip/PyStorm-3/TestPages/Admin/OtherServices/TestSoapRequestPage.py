from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.TestSoapRequestResultsRow import TestSoapRequestResultsRow


class TestSoapRequestPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TestSoapRequest)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def contentSearchEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "reqstringsearch")

    @property
    def requestFromHoursDropDown(self):
        dropdownBox = DropdownListbox(self.webdriver, self.webdriver, By.CSS_SELECTOR, "select[name='searchFromHour']", (By.XPATH, ".//option[@value]"))
        dropdownBox.checkAriaState = False
        return dropdownBox

    @property
    def requestFromMinutesDropDown(self):
        dropdownBox = DropdownListbox(self.webdriver, self.webdriver, By.CSS_SELECTOR, "select[name='searchFromMin']", (By.XPATH, ".//option[@value]"))
        dropdownBox.checkAriaState = False
        return dropdownBox

    @property
    def goButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='action-button']")

    @property
    def resultsTable(self) -> GenericTable:
        table = GenericTable(self.webdriver, self.webdriver, By.CSS_SELECTOR, "table[class='data-table']")
        table.headerCellLocator = (By.XPATH, ".//th[@class]")
        table.rowType = TestSoapRequestResultsRow
        return table
