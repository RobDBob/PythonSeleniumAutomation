from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class OrderCompletionPage(PlatformPage):
    def wait(self):
        self.externalOrderCompletionLabel.waitForText(PageEnums.EXTERNAL_ORDER_COMPLETION)

    @property
    def externalOrderCompletionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'External Order Completion')]")

    @property
    def searchFilterLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Search filter')]")

    @property
    def managerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Manager:')]")

    @property
    def managerDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Manager:')]//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def ciAccountIdLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ClAccountID:')]")

    @property
    def batchIdLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'BatchID:')]")

    @property
    def ciAccountIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='claccountid']")

    @property
    def batchIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='batchid']")

    @property
    def orderIdLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'OrderID:')]")

    @property
    def orderIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='orderid']")

    @property
    def partnerRefLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner Ref:')]")

    @property
    def partnerRefEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='externalId']")

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Amount (£):')]")

    @property
    def amountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='orderValue']")

    @property
    def dateCreatedLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Date Created:')]")

    @property
    def dateCreatedEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='dateCreated']")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Search']")
