from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Labels import Label


class ViewProjectsPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ProjectSummary)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
