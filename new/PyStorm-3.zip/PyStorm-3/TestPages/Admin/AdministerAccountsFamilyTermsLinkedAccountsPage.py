from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.AdministerAccountsCreateEditLinksPage import AdministerAccountsCreateEditLinksPage
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.FamilyTermsLinkedAccountsRow import FamilyTermsLinkedAccountsRow


class AdministerAccountsFamilyTermsLinkedAccountsPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ADMINISTER_ACCOUNTS_FAMILY_LINKED_ACCOUNTS)

    @retry(TimeoutException, tries=5)
    def navigateToAdminAccountsCreateEditLinksPageViaLastRow(self):
        currentUrl = self.webdriver.current_url
        lastRow: FamilyTermsLinkedAccountsRow = self.familyTermsLinkedAccountTable.getLastRow()
        lastRow.linkIdButton.click()
        self.waitForURLChangeFromCurrent(currentUrl)
        return AdministerAccountsCreateEditLinksPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def adviserFirmDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='adviserFirm']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def familyTermsLinkedAccountTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.rowType = FamilyTermsLinkedAccountsRow
        resultTable.headerCellLocator = (By.XPATH, ".//tr//th")
        resultTable.paginationLocator = (By.XPATH, "//div[@class='pagenation-container']//select")
        resultTable.waitForDataToRender()
        return resultTable
