from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.RebalanceWizardBasePage import RebalanceWizardBasePage
from TestPages.Admin.RebalanceWizardPage import RebalanceWizardPage
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Labels import Label


class HoldingsExternalAssetsWizardPage(RebalanceWizardBasePage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.HOLDINGS_EXTERNAL_ASSETS)

    def navigateToRebalancePage(self):
        self.nextStepButton.click()
        return RebalanceWizardPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[@class='PageHeading']")

    @property
    def thereAreNoExternalAssetHoldingsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'There are no external asset holdings on record for this client')]")
