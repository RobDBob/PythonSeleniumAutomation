from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import LongPageEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseAccountRestrictionUpdateProcesses import AuthoriseAccountRestrictionUpdateProcesses
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseBWAAuthorisationsRow import AuthoriseBWAAuthorisationsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseClientTrustProcessRow import AuthoriseClientTrustProcessesRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseFlagForApprovalActivitiesRow import AuthoriseFlagForApprovalActivitiesRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseTrustProcessesRow import AuthoriseTrustProcessesRow
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class AuthoriseProcessesPage(PlatformPage):
    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    def wait(self):
        self.pageTitle.waitForText("Authorise Process")
        self.waitSpinner()
        self.webdriver.waitForAPIRequestToFinish("customizelogo/get?isAdmin=true")

    @retry(exceptions=TimeoutException, delay=15, tries=4)
    def processAndWait(self, processAction, expectedMessage):
        PrintMessage(f"processAndWait > authorise process action: '{processAction}'", inStepMessage=True)
        if processAction == PageEnums.AUTHORISE:
            self.authoriseButton.click(jsClick=True)
        elif processAction == PageEnums.REJECT:
            self.rejectButton.click(jsClick=True)
        else:
            raise UIException(f"Wrong process action used: '{processAction}' expected '{PageEnums.AUTHORISE, PageEnums.REJECT}'")

        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='warning-message']"), expectedMessage)
        WebDriverWait(self.webdriver, 60).until(waitcondition, message=f"Failed to verify the message: '{expectedMessage}'")

    @retry(exceptions=UIException, delay=20, tries=4)
    def getTableRow(self, table: GenericTable, accountNumber):
        """
        Returns last matched row under assumption its the newest
        """
        PrintMessage(f"getRow > attempt to retrieve row for account number: '{accountNumber}'", inStepMessage=True)
        self.reload()
        row = table.getRow(columnName=PageEnums.ACCOUNT_CODE, text=accountNumber, reverseOrder=True)
        if row is None:
            raise UIException(f"Failed to find row from '{type(table)}' table for account number: '{accountNumber}'")
        return row

    def authoriseAccountInTrustProcesses(self, accountNumber):
        PrintMessage(f"Authorising account in trust processes table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseTrustProcessesRow = self.authoriseTrustProcessesTable.getRow(columnName=PageEnums.ACCOUNT_CODE, text=accountNumber)
        row.authoriseCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.AUTHORISE, LongPageEnums.TRUST_PROCESS_SUCCESSFULL)

    def authoriseBWAAuthorisations(self, accountNumber):
        PrintMessage(f"Authorising account in BWA Authorisations table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseBWAAuthorisationsRow = self.authoriseBWAAuthorisationsTable.getRow(columnName=PageEnums.AccountNumber, text=accountNumber)
        row.authoriseCheckBox.selectCheckBoxAndWait()
        self.confirmButton.click()
        self.bwaAuthorisationLabel.waitForText(LongPageEnums.FOLLOWING_BWA_REFERRALS_HAVE_BEEN_AUTHORISED)

    @retry(exceptions=UIException, delay=10, tries=12)
    def authoriseAccountRestrictionUpdateProcesses(self, accountNumber):
        PrintMessage(f"Authorising Account Restriction Update Process for: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseAccountRestrictionUpdateProcesses = self.getTableRow(self.authoriseAccountRestrictionUpdateProcessesTable, accountNumber)
        row.authoriseCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.AUTHORISE, LongPageEnums.ACCOUNT_RESTRICTION_UPDATE_SUCCESSFULL)

    def rejectAccountRestrictionUpdateProcesses(self, accountNumber):
        PrintMessage(f"Rejecting Account Restriction Update Process for: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseAccountRestrictionUpdateProcesses = self.getTableRow(self.authoriseAccountRestrictionUpdateProcessesTable, accountNumber)
        row.rejectCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.REJECT, LongPageEnums.ACCOUNT_RESTRICTION_UPDATE_SUCCESSFULL)

    def authoriseCustomerTrustProcesses(self, accountNumber, providedMessage=None):
        PrintMessage(f"Authorise account in customer trust processes table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseClientTrustProcessesRow = self.getTableRow(self.authoriseCustomerTrustProcessesTable, accountNumber)
        rowId = row.idLabel.text
        messageToVerify = providedMessage if providedMessage else f"Trust Process (request: {rowId})Updated Successfully "
        row.authoriseCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.AUTHORISE, messageToVerify)

    def rejectCustomerTrustProcesses(self, accountNumber):
        PrintMessage(f"Reject account in customer trust processes table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseClientTrustProcessesRow = self.getTableRow(self.authoriseCustomerTrustProcessesTable, accountNumber)
        rowId = row.idLabel.text
        messageToVerify = f"Trust Process (request: {rowId})Updated Successfully "
        row.rejectCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.REJECT, messageToVerify)

    def authoriseFlagForApprovalActivitiesProcesses(self, accountNumber):
        PrintMessage(f"Authorise Flag for Approval activities processes table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseFlagForApprovalActivitiesRow = self.getTableRow(self.authoriseFlagForApprovalActivitiesTable, accountNumber)
        requestId = row.requestIdLabel.text
        messageToVerify = f"F4A Process (request: {requestId})Updated Successfully "
        row.authoriseCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.AUTHORISE, messageToVerify)

    def rejectFlagForApprovalActivitiesProcesses(self, accountNumber):
        PrintMessage(f"Reject Flag for Approval activities processes table: '{accountNumber}'", inStepMessage=True)
        row: AuthoriseFlagForApprovalActivitiesRow = self.getTableRow(self.authoriseFlagForApprovalActivitiesTable, accountNumber)
        requestId = row.requestIdLabel.text
        messageToVerify = f"F4A Process (request: {requestId})Updated Successfully "
        row.rejectCheckBox.selectCheckBoxAndWait()
        self.processAndWait(PageEnums.REJECT, messageToVerify)

    @property
    def youCannotAuthoriseProcessToolTipLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@id = 'ToolTipFloatAlert']")

    @property
    def bwaAuthorisationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Following bwa referrals have been authorised:')]")

    @property
    def rejectButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Reject']")

    @property
    def authoriseButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Authorise']")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Confirm']")

    @property
    def authoriseTrustProcessesTable(self):
        table = GenericTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h2[text()='Authorise Trust Processes']/parent::div/following-sibling::div[position()=1]/table")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableHead')]")
        table.rowType = AuthoriseTrustProcessesRow
        return table

    @property
    def authoriseCustomerTrustProcessesTable(self):
        table = GenericTable(self.webdriver,
                             self.webdriver,
                             By.XPATH,
                             "//h2[text()='Authorise Customer Trust Processes']/parent::div/following-sibling::div[position()=1]/table")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableHead')]")
        table.rowType = AuthoriseClientTrustProcessesRow
        return table

    @property
    def authoriseAccountRestrictionUpdateProcessesTable(self):
        table = GenericTable(self.webdriver,
                             self.webdriver,
                             By.XPATH,
                             "//h2[text()='Authorise Account Restriction Update Processes']/parent::div/following-sibling::div[position()=1]/table")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableHead')]")
        table.rowType = AuthoriseAccountRestrictionUpdateProcesses
        return table

    @property
    def authoriseFlagForApprovalActivitiesTable(self):
        table = GenericTable(self.webdriver,
                             self.webdriver,
                             By.XPATH,
                             "//h2[text()='Authorise Flag for Approval activities']/parent::div/following-sibling::div[position()=1]/table")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableHead')]")
        table.rowType = AuthoriseFlagForApprovalActivitiesRow
        return table

    @property
    def authoriseBWAAuthorisationsTable(self):
        table = GenericTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//table[@class='data-table']")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[@scope='col']")
        table.rowType = AuthoriseBWAAuthorisationsRow
        return table
