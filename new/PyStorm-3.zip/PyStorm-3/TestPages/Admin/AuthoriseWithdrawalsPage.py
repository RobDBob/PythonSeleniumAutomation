from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import LongPageEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseWithdrawalsRow import AuthoriseWithdrawalsRow
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class AuthoriseWithdrawalsPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CashAuthoriseWithdrawals)

    def authoriseWithdrawal(self, rowToAuthorise: AuthoriseWithdrawalsRow):
        rowId = rowToAuthorise.idLabel.text
        rowToAuthorise.authoriseCheckBox.selectCheckBoxAndWait(jsClick=True)
        self.authoriseButton.click()

        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='Exclamation']"), LongPageEnums.AUTHORISE_CASH_ENTRIES_CONFIRMATION)
        WebDriverWait(self.webdriver, 60).until(waitcondition)

        self.authoriseYesButton.jsClick()

        expectedMessage = f"The following withdrawals have been authorised: {rowId}"
        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='warning-message']"), expectedMessage)
        WebDriverWait(self.webdriver, 60).until(waitcondition)

    def rejectWithdrawal(self, rowToAuthorise: AuthoriseWithdrawalsRow):
        rowId = rowToAuthorise.idLabel.text
        rowToAuthorise.rejectCheckBox.selectCheckBoxAndWait(jsClick=True)
        self.authoriseButton.click()

        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='Exclamation']"), LongPageEnums.AUTHORISE_CASH_ENTRIES_CONFIRMATION)
        WebDriverWait(self.webdriver, 60).until(waitcondition)

        self.authoriseYesButton.jsClick()

        expectedMessage = PageEnums.THE_FOLLOWING_WITHDRAWALS_HAVE_BEEN_REJECTED.format(rowId)
        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='warning-message']"), expectedMessage)
        WebDriverWait(self.webdriver, 60).until(waitcondition)

    def authoriseWithdrawalViaWithdrawalId(self, withdrawalId):
        PrintMessage(f"Authorising Withdrawal with ID: '{withdrawalId}'")
        row: AuthoriseWithdrawalsRow = self.authoriseWithdrawalsTable.getRow(columnName="id", text=withdrawalId)
        self.authoriseWithdrawal(row)

    def rejectWithdrawalViaWithdrawalId(self, withdrawalId):
        PrintMessage(f"Rejecting Withdrawal with ID: '{withdrawalId}'")
        row: AuthoriseWithdrawalsRow = self.authoriseWithdrawalsTable.getRow(columnName="id", text=withdrawalId)
        self.rejectWithdrawal(row)

    def authoriseWithdrawalViaAccountNumber(self, accountNumber):
        PrintMessage(f"Authorising Withdrawal with Account number: '{accountNumber}'")
        row: AuthoriseWithdrawalsRow = self.authoriseWithdrawalsTable.getRow(columnName=PageEnums.ACCOUNT, text=accountNumber)
        self.authoriseWithdrawal(row)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def companyDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.ID, "company", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account:']")

    @property
    def accountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account:']//following-sibling::div/input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Search']")

    @property
    def withdrawalsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Withdrawals']")

    @property
    def authoriseButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "btnAuthoriseCash")

    @property
    def authoriseYesButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "btnYesReject")

    @property
    def authoriseNoButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "btnNoReject")

    @property
    def authoriseWithdrawalsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Withdrawals']//following-sibling::div//table[@class='data-table']")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableSubHead')]")
        table.waitForDataToRender()
        table.rowType = AuthoriseWithdrawalsRow
        return table
