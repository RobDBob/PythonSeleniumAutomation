from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PlatformPage import PlatformPage


class RebalanceWizardBasePage(PlatformPage):

    @property
    def nextStepButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Next step']")
