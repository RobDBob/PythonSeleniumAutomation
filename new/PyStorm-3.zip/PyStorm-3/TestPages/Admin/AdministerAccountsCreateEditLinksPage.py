from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.AdministerAccountsCreateEditLinksFindClientPage import AdministerAccountsCreateEditLinksFindClientPage
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AdministerAccountsCreateAndEditLinksRow import AdministerAccountsCreateAndEditLinksRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AdministerAccountsCreateEditLinksFindClientRow import AdministerAccountsCreateEditLinksFindClientRow


class AdministerAccountsCreateEditLinksPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AdministerAccountsCreateEditLinks)

    def navigateToFindClientPage(self):
        self.findClientButton.click()
        return AdministerAccountsCreateEditLinksFindClientPage(self.webdriver)

    def selectAccountCodeInFindClientsPage(self, accountId):
        with self.navigateToFindClientPage() as findClientPage:
            resultTable = findClientPage.findClient(accountNumber=accountId)
            firstRow: AdministerAccountsCreateEditLinksFindClientRow = resultTable.getFirstRow()
            firstRow.accountCodeHyperlinkButton.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Number')]//following-sibling::input")

    @property
    def useThisPageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Use this page to')]")

    @property
    def findClientButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Find Client')]")

    @property
    def addButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Add']")

    @property
    def administerAccountsCreateAndEditLinksTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.rowType = AdministerAccountsCreateAndEditLinksRow
        resultTable.headerSectionLocator = (By.XPATH, ".//thead//tr")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.waitForDataToRender()
        return resultTable

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()=' Cancel']")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Confirm')]")
