from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class ListEditPortfolioConfirmationPage(ClientsPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.LISTEDIT_PORTFOLIO)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='ContentPlaceHolder_ModelPortfolioSearch_ConfirmButtonBottom']")
