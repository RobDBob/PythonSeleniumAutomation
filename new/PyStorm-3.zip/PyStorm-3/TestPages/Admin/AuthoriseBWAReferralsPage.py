from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.AuthoriseProcessesPage import AuthoriseProcessesPage
from TestPages.PageObjects.BaseObjects.Labels import Label


class AuthoriseBWAReferralsPage(AuthoriseProcessesPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.BWAAuthorisaion)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
