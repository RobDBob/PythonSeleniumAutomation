from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.LinkedSubClAccountIDPage import LinkedSubClAccountIDPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class RequestCorrectionSubmitPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.RequestCorrection)

    def submitCorrectionBatch(self):
        from TestPages.Admin.RequestCorrection.RequestCorrectionPage import RequestCorrectionPage
        self.submitButton.click()
        return RequestCorrectionPage(self.webdriver)

    def navigateToLinkedSubClAccountIDPage(self):
        self.findButton.click()
        return LinkedSubClAccountIDPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def correctionDetailReclaim(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Reclaim']")

    @property
    def advisorChargeAdjustmentAmountEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "acaa")

    @property
    def chargeTypeDropdown(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.ID, "chargetype", optionsLocator=(By.CSS_SELECTOR, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def notesEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "notes")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Submit']")

    @property
    def findButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Find')]")
