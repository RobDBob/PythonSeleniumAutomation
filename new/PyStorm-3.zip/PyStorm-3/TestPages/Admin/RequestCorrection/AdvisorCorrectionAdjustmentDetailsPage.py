from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseCorrectionAdjustmentDetailsRow import AuthoriseCorrectionAdjustmentDetailsRow
from TestPages.Support.NewTabPage import NewTabPage


class AdvisorCorrectionAdjustmentDetailsPage(NewTabPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AuthoriseCorrectionAdjustmentDetails)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def advisorCorrectionAdjustmentDetailsTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.rowType = AuthoriseCorrectionAdjustmentDetailsRow
        return resultTable
