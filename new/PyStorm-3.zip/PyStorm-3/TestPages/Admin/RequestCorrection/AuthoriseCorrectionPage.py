from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.Admin.RequestCorrection.AdvisorCorrectionAdjustmentDetailsPage import AdvisorCorrectionAdjustmentDetailsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseCorrectionRow import AuthoriseCorrectionRow
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class AuthoriseCorrectionPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AuthoriseCorrection)

    def openDetailsForFirstRow(self):
        firstRow: AuthoriseCorrectionRow = self.authoriseCorrectionsTable.getFirstRow()
        firstRow.detailButton.click()
        return AdvisorCorrectionAdjustmentDetailsPage(self.webdriver)

    # pylint: disable=W0622
    def authoriseAndConfirm(self, id):
        PrintMessage(f"Authorising correction with id: '{id}'")

        row: AuthoriseCorrectionRow = self.authoriseCorrectionsTable.getRow(columnName="ID", text=id)
        row.authoriseCheckBox.click()
        self.confirmButton.click()

        waitCondition = EC.presence_of_element_located((By.XPATH, "//a[@class='button' and contains(text(), 'Back')]"))
        WebDriverWait(self.webdriver, 30).until(waitCondition)

        self.confirmButton.click()

        waitForWarning = "Batches authorised successfully for processing"
        waitCondition = EC.text_to_be_present_in_element((By.XPATH, "//p[@class='warning-message']"), waitForWarning)
        WebDriverWait(self.webdriver, 30).until(waitCondition)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def authoriseCorrectionsTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table data-heavy-table']")
        resultTable.rowType = AuthoriseCorrectionRow
        resultTable.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableSubHead')]")
        return resultTable

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(), 'Confirm')]")

    @property
    def authoriseSuccessWarningMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class='warning-message']")
