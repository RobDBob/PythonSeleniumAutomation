from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.Admin.FindClientPage import FindClientPage
from TestPages.Admin.RequestCorrection.RequestCorrectionSubmitPage import RequestCorrectionSubmitPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class RequestCorrectionPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.RequestCorrection)

    def selectCorrectionType(self, correctionType):
        Button(self.webdriver, self.webdriver, By.XPATH, f"//span[text()='{correctionType}']/parent::div//input//following-sibling::span[text()='Select']").jsClick()

    def navigateToFindClientPage(self):
        self.accountIdFindButton.click()
        return FindClientPage(self.webdriver)

    # Removing expectedAccountId=None as it's causing pylint error
    def navigateToRequestCorrectionSubmitPage(self):
        self.nextButton.click()
        return RequestCorrectionSubmitPage(self.webdriver)

    def setAccountId(self, accountId):
        PrintMessage(f"RequestCorrectionPage > Account setting for '{accountId}'")

        with self.navigateToFindClientPage() as findClientPage:
            findClientPage.findAndSelectLastClient(accountId)

        waitCondition = EC.text_value_in_attribute_in_element(self.accoundIdEdit.element, "value", accountId)
        WebDriverWait(self.webdriver, 10).until(waitCondition, f"Expected to have account number filled in: {accountId}")

    @property
    def correctionReasonDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.ID, "reasonacaa", optionsLocator=(By.CSS_SELECTOR, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accoundIdEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "Searchclaccountid")

    @property
    def accountIdFindButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "ClAccountIDLink")

    @property
    def nextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Next']")

    @property
    def correctionReasonEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "UserNote")

    @property
    def wizardSubmittedMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='warning-message']//p")
