import operator
from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.TargetInvestmentSelectionFundAllocationRow import TargetInvestmentSelectionFundAllocationRow
from TestPages.Trackingorders.InvestmentSelectionToolPage import InvestmentSelectionToolPage
from TestPages.Wizards.NewClient.OldWizardBase import OldWizardBase


class TargetAllocationPage(OldWizardBase):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TARGET_ALLOCATION)

    def navigateToInvestmentSelectionToolPage(self):
        self.addFundButton.click()
        return InvestmentSelectionToolPage(self.webdriver)

    def setInvestment(self, fundCode, dataLabel):
        with self.navigateToInvestmentSelectionToolPage() as investmentSelectionToolPage:
            investmentSelectionToolPage.selectInvestmentProduct(fundCode, dataLabel)

    def allocateTargetFund(self, allocationData: list):
        for allocation in allocationData:
            if allocation.get(DataEnums.INVESTMENT_CODE, None):
                allocationName = allocation[DataEnums.INVESTMENT_CODE]
            else:
                allocationName = allocation[DataEnums.INVESTMENT_NAME]
            row: TargetInvestmentSelectionFundAllocationRow = self.targetAllocationTable.getRow(columnName=PageEnums.ASSET_CLASS,
                                                                                                value=allocationName,
                                                                                                comparisonOperator=operator.contains)
            row.allocationPercentageEditField.send_keys(allocation[DataEnums.INVESTMENT_VALUE])

    def removeFund(self, columValue):
        row: TargetInvestmentSelectionFundAllocationRow = self.targetAllocationTable.getRow(columnName=PageEnums.ASSET_CLASS,
                                                                                            value=columValue,
                                                                                            comparisonOperator=operator.contains)
        row.selectCheckBox.jsClick()
        self.removeButton.jsClick()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def selectViewDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[contains(text(),'Select')]//following-sibling::div//select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def editButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Edit')]")

    @property
    def modelPortfolioDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Model Portfolio']//following-sibling::select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def addFundButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Add fund']")

    @property
    def targetAllocationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class]")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowLocator = (By.XPATH, ".//tr[contains(@class,'sub-head') or contains(@id,'tr') and not(@style='display:none')]")
        table.rowType = TargetInvestmentSelectionFundAllocationRow
        return table

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def removeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Remove')]")
