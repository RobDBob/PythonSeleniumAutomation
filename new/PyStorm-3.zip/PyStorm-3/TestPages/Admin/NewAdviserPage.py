from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.AdminPage import AdminPage
from TestPages.PageObjects.BaseObjects.Labels import Label


class NewAdviserPage(AdminPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.NEW_ADVISER)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
