from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.AdminPage import AdminPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.FindAdvisorResultRow import FindAdvisorResultRow
from TestPages.Support.NewTabPage import NewTabPage
from TestPages.WebDriver import ExpectedConditions as EC


class FindAdviserPage(AdminPage, NewTabPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.FIND_ADVISER)

    def selectAdvisorCode(self, testData):
        self.companyDropdown.selectOption(testData[DataEnums.COMPANY])
        self.searchButton.click()

        advisorResultRow: FindAdvisorResultRow = self.findAdvisorResultTable.getRow(columnName=PageEnums.ADVISER_CODE, text=testData[DataEnums.ADVISOR_CODE])
        advisorCode = advisorResultRow.addAdvisorCodeLinkButton.text
        advisorResultRow.addAdvisorCodeLinkButton.click()
        PrintMessage(f"Advisor Code '{advisorCode}' selected", inStepMessage=True)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def companyDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.ID, "searchcompany", optionsLocator=(By.XPATH, ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "btnSearch")

    @property
    def findAdvisorResultTable(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//a[@id='btnSearch']//following-sibling::h4"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.rowLocator = (By.XPATH, ".//tr")
        resultTable.rowType = FindAdvisorResultRow
        return resultTable
