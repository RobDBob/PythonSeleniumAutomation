from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CashManagementAdministrationChargeRow import CashManagementAdministrationChargeRow
from TestPages.PlatformPage import PlatformPage


class CashManagementAdministrationChargePage(PlatformPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.CASH_MANAGEMENT_ADMINISTRATION_CHARGE)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def cashManagementAdministrationChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Cash Management Administration Charge']")

    @property
    def successMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'Update has been submitted')]")

    @property
    def errorMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'There are pending requests waiting)]")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Submit')]")

    @property
    def backToTopHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")

    @property
    def cashManagementAdministrationChargeTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = CashManagementAdministrationChargeRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.waitForDataToRender()
        return table
