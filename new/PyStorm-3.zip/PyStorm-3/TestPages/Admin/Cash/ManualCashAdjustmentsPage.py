from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.Admin.FindClientPage import FindClientPage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.FindClientsResultRow import FindClientsResultRow
from TestPages.WebDriver import ExpectedConditions as EC


class ManualCashAdjustmentsPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ManualCashAdjustments)

    def navigateToFindClient(self):
        self.findButton.click()
        return FindClientPage(self.webdriver)

    def setAccountId(self, accountId):
        with self.navigateToFindClient() as findClientPage:
            resultTable = findClientPage.findClient(accountNumber=accountId)
            lastRow: FindClientsResultRow = resultTable.getLastRow()
            subAccountSelected = lastRow.accountNumberLabel.text
            lastRow.accountNumberLabel.click()
        return subAccountSelected

    def performCashAdjustments(self, amount, narration, warningMessage):
        PrintMessage("Attempting to fill manual cash adjustments details", inStepMessage=True)
        self.amountEditField.enterValue(amount)
        self.narrationEditField.enterValue(narration)
        self.placeButton.click()
        waitCondition = EC.presence_of_element_located((By.XPATH, "//p[contains(text(),'Your Manual Cash Adjustment is now awaiting Authorisation')]"))
        WebDriverWait(self.webdriver, 60).until(waitCondition, f"Expected to have warning message as: {warningMessage}")

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def toClientAccountLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label Label' and contains(text(),'To client account:')]//parent::div//input[@id='toclientaccountnum']")

    @property
    def findButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btnFindToClient' and contains(text(),'Find')]")

    @property
    def getDateFromAsAtLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label Label' and contains(text(),'As At:')]//parent::div//input[@id='asAtDate']")

    @property
    def getCurrencyOptionLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label Label' and contains(text(),'Currency:')]//parent::div//select[@id='adjustmentcurrency']//option")

    @property
    def amountEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label Label' and contains(text(),'Amount:')]//parent::div//input[@id='amount']")

    @property
    def narrationEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label Label' and contains(text(),'Narration:')]//parent::div//input[@id='narration']")

    @property
    def placeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='js-place-button' and contains(text(),'Place')]")

    @property
    def warningMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class='warning-message']")
