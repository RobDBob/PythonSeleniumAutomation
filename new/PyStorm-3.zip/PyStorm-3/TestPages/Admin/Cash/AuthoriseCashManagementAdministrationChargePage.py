from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseCashManagementAdministrationChargeRow import AuthoriseCashManagementAdministrationChargeRow
from TestPages.PlatformPage import PlatformPage


class AuthoriseCashManagementAdministrationChargePage(PlatformPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.AUTHORISE_CASH_MANAGEMENT_ADMINISTRATION_CHARGE)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def authoriseCashManagementAdministrationChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Authorise Cash Management Administration Charge']")

    @property
    def successMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'Successfully updated')]")

    @property
    def noRecordsFoundMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'No records found')]")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def backToTopHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")

    @property
    def cashManagementAdministrationChargeTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = AuthoriseCashManagementAdministrationChargeRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.waitForDataToRender()
        return table
