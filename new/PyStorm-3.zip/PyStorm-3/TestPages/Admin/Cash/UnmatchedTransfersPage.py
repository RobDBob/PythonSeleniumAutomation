from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.Cash.UnmatchedExpectationsPage import UnmatchedExpectationsPage
from TestPages.PageObjects.BaseObjects.Labels import Label


class UnmatchedTransfersPage(UnmatchedExpectationsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.UnmatchedTransfers)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
