import operator
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.CashMatchingTransactionTable import CashMatchingBankTransactionTableRow
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CashMatchingChequeTransactionTableRow import CashMatchingChequeTransactionTableRow
from TestPages.PageObjects.BaseObjects.Table.Rows.CashMatchingExpectationRow import CashMatchingExpectationTableRow
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class UnmatchedExpectationsPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.UnmatchedExpectations)

    def waitForPageToLoad(self):
        self.bankTransactionsSearchButton.waitForElement()
        self.cashExpectationsSearchButton.waitForElement()
        self.cashExpectationsTablePagination.waitForDropdown()
        self.bankTransactionTablePagination.waitForDropdown()
        self.saveButton.waitForElement()

    def _waitForTableFeedbackToComplete(self, tableId: str):
        waitCondition = EC.attribute_present_in_element((By.ID, f"{tableId}Feedback"), "style")
        try:
            WebDriverWait(self.webdriver, timeout=3).until_not(waitCondition)
        except TimeoutException:
            pass
        WebDriverWait(self.webdriver, timeout=90).until(waitCondition)

    @retry(exceptions=TimeoutException, tries=3)
    def _searchAndWait(self, searchButton: Button, table: GenericTable):
        searchButton.click()
        searchButton.waitForElementToCeaseExist()
        self._waitForTableFeedbackToComplete(table.element.get_attribute("id"))
        table.waitForDataToRender()

    def performCashMatchingProcess(self, reconciliationName, ammountToMatch, accountToMatch):
        PrintMessage(f">>> performCashMatchingProcess for reconciliation: '{reconciliationName}', amount: '{ammountToMatch}' and the account: '{accountToMatch}'",
                     inStepMessage=True)
        self.reconciliationName.selectOption(reconciliationName)
        self.waitForPageToLoad()
        self.minAmount.enterValue(ammountToMatch)
        self.maxAmount.enterValue(ammountToMatch)

        if reconciliationName == PageEnums.INWARD_CHEQUES:
            self._searchAndWait(self.bankTransactionsSearchButton, self.bankTransactionsChequeAmountTable)
            firstRow: CashMatchingChequeTransactionTableRow = self.bankTransactionsChequeAmountTable.getFirstRow()
        else:
            self._searchAndWait(self.bankTransactionsSearchButton, self.bankTransactionsAmountTable)
            firstRow: CashMatchingBankTransactionTableRow = self.bankTransactionsAmountTable.getFirstRow()
        if firstRow is None:
            raise UIException("No bank transactions available in Unmatched expectations. Update test data!")

        firstRow.unmatchedItemsCheckBox.click()

        self.clAccountID.enterValue(accountToMatch)
        self._searchAndWait(self.cashExpectationsSearchButton, self.cashExpectationsTable)

        matchingRow: CashMatchingExpectationTableRow
        for matchingRow in self.cashExpectationsTable.getRows(columnName="ClAccountID", text=accountToMatch, comparisonOperator=operator.contains):
            matchingRow.matchedItemsCheckBox.click()
        self.saveButton.click()
        self.updateSuccessfulMsg.waitForElement()

        PrintMessage(f">>> performCashMatchingProcess for the account: '{accountToMatch}' - DONE", inStepMessage=True)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def reconciliationName(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Reconciliation Name: ']/parent::div//select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def minAmount(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@name='Table1FromMatch']")

    @property
    def maxAmount(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@name='Table1ToMatch']")

    @property
    def bankTransactionsSearchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@id='tdtable1SearchButton']")

    @property
    def clAccountID(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@name='Table2ClAccountID']")

    @property
    def cashExpectationsSearchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@id='tdtable2SearchButton']")

    @property
    def bankTransactionsAmountTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, "tdtable1")
        table.rowLocator = (By.XPATH, ".//tr[contains(@id,'trtable') and not(@style)]")
        table.rowType = CashMatchingBankTransactionTableRow
        return table

    @property
    def cashExpectationsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, "tdtable2")
        table.rowLocator = (By.XPATH, ".//tr[contains(@id,'trtable') and not(@style)]")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class,'TableHead')]")
        table.rowType = CashMatchingExpectationTableRow
        return table

    @property
    def bankTransactionsChequeAmountTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, "tdtable1")
        table.rowLocator = (By.XPATH, ".//tr[contains(@id,'trtable') and not(@style)]")
        table.rowType = CashMatchingChequeTransactionTableRow
        return table

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Save']")

    @property
    def updateSuccessfulMsg(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Update successful.')]")

    @property
    def unmatchedItemsText(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4//div[@id='divtable2countdisplay']")

    @property
    def cashExpectationsTablePagination(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='selPageJump2']")

    @property
    def bankTransactionTablePagination(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='selPageJump1']")

    @property
    def showDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Show ']")
