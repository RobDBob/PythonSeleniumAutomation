from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Support.NewTabPage import NewTabPage


class ShowDetailPopUpTransactionDetailsPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.TRANSACTION_DETAIL)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='closeButton']")

    @property
    def removeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Remove')]")

    @property
    def removeThisTransactionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//strong[contains(text(),'This will remove this transaction')]")
