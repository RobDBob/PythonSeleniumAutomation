from selenium.webdriver.common.by import By
from TestPages import DataEnums, LongPageEnums, PageEnums
from TestPages.Admin.ListEditPortfolioConfirmationPage import ListEditPortfolioConfirmationPage
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AdviserPortfolioDetailsRow import AdviserPortfolioDetailsRow
from TestPages.PageObjects.BaseObjects.Table.TaxWrapperDetailsTable import TaxWrapperDetailsTable


class ListEditPortfolioPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.LISTEDIT_PORTFOLIO)

    def navigateToListEditPortfolioConfirmationPage(self):
        self.continueButton.jsClick()
        return ListEditPortfolioConfirmationPage(self.webdriver)

    def searchModelPortfolio(self, testData):
        self.modelPortfolioDropdown.selectOption(testData[DataEnums.MODEL_PORTFOLIO])
        self.includeInactiveDropdown.selectOption(PageEnums.YES)
        self.taxWrapperDetailsTable.selectTaxWrapperCheckBox(testData.get(DataEnums.TAX_WRAPPER)).jsClick()
        self.portfolioSearchButton.click()
        return self.advisorPortfolioDetailsTable.getFirstRow()

    def changeStatusForModelPortfolio(self, modelPortfolioRow: AdviserPortfolioDetailsRow, isActive):
        if isActive == PageEnums.NO:
            modelPortfolioRow.inActiveStatusRadioButton.jsClick()
        else:
            modelPortfolioRow.activeStatusRadioButton.jsClick()
        listEditPortfolioConfirmationPage: ListEditPortfolioConfirmationPage = self.navigateToListEditPortfolioConfirmationPage()
        listEditPortfolioConfirmationPage.confirmButton.click()
        self.statusChangeConfirmationMessageLabel.waitForText(LongPageEnums.STATUS_CHANGE_CONFIRMATION_LABEL)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def companyDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//span[text()='Company']//parent::label//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def modelPortfolioDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Model portfolio')]//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def profileDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Profile')]//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def includeInactiveDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Include inactive')]//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def portfolioSearchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Search']")

    @property
    def continueButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Continue']")

    @property
    def statusChangeConfirmationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioSearch_UserErrorMessage']")

    @property
    def advisorPortfolioDetailsTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_ModelPortfolioSearch_SearchResultsGrid")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.rowLocator = (By.XPATH, ".//tr[contains(@class,'body-split odd last')]")
        resultTable.rowType = AdviserPortfolioDetailsRow
        return resultTable

    @property
    def taxWrapperDetailsTable(self):
        return TaxWrapperDetailsTable(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_ModelPortfolioSearch_ProductDataGrid")
