from datetime import datetime
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.TaxWrapperDetailsTable import TaxWrapperDetailsTable
from TestPages.Trackingorders.InvestmentSelectionToolPage import InvestmentSelectionToolPage


class ModelPortfolioSummaryPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.MODEL_PORTFOLIO_LISTEDIT_PORTFOLIO)

    def navigateToInvestmentSelectionToolPage(self):
        self.addFundButton.click()
        return InvestmentSelectionToolPage(self.webdriver)

    def setInvestment(self, fundCode):
        self.removeAllFundsButton.click()
        with self.navigateToInvestmentSelectionToolPage() as investmentSelectionToolPage:
            investmentSelectionToolPage.selectFundForModelPortfolio(fundCode)

    def setAllocationPercentageforFund(self, fundCode, fundAllocationPercentage):
        PrintMessage("Attempting to update the allocation percentage for the selected Fund", inStepMessage=True)
        actualAllocaionEditField = EditField(self.webdriver, self.webdriver, By.XPATH,
                                             f"//span[text()='{fundCode}']//parent::td//parent::tr//following-sibling::td[@class='text-right']//input")
        if actualAllocaionEditField.exists():
            actualAllocaionEditField.enterValue(fundAllocationPercentage)
            self.continueButton.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def companyDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//span[text()='Company']//parent::label//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def profileDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Profile')]//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def profileNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Portfolio name']//parent::div//input")

    @property
    def createdDateLabel(self):
        dateFormat = "%d/%m/%Y"
        dateLabel = Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetailControl_DateCreatedField']")
        return datetime.strptime(dateLabel.text, dateFormat).date()

    @property
    def lastUpdatedDateLabel(self):
        dateFormat = "%d/%m/%Y"
        dateLabel = Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetailControl_LastUpdatedLabel']")
        return datetime.strptime(dateLabel.text, dateFormat).date()

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetailControl_StatusCurrentLabel']")

    @property
    def numberOfClientsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetailControl_NumberOfClientsLabel']")

    @property
    def assetAllocationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Asset allocation')]")

    @property
    def addFundButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='button mr-10' and contains(text(),'Add fund')]")

    @property
    def removeAllFundsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='button' and contains(text(),'Remove all funds ')]")

    @property
    def continueButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='button' and contains(text(),'Continue')]")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='action-button' and contains(text(),'Confirm')]")

    @property
    def modelPortfolioAddFundConfirmationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetail_ROControl_ConfirmationStaticMessage']")

    @property
    def modelPortfolioAddFundUserMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//span[@id='ContentPlaceHolder_ModelPortfolioDetailControl_UserMessageTextBox']")

    @property
    def overseasEquitiesTargetValueEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//span[text()='Overseas Equities']//parent::td//parent::tr//following-sibling::td[@class='text-right']//input")

    @property
    def taxWrapperDetailsTable(self):
        return TaxWrapperDetailsTable(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_ModelPortfolioSearch_ProductDataGrid")
