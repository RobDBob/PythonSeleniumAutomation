from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class BulkClientMailingPreferencePage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.BulkClientMailingPreference)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
