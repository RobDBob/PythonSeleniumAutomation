from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class CreateManagerPage(PlatformPage):
    def wait(self):
        self.managerDetailsLabel.waitForText(PageEnums.MANAGER_DETAILS)

    @property
    def managerDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Manager details')]")

    @property
    def managerNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Manager Name')]//following-sibling::div//input")

    @property
    def groupNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Group Name')]//following-sibling::div//input")

    @property
    def fundWebsiteEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Fund Website')]//following-sibling::div//input")

    @property
    def countryDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Country')]//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def address1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Address 1')]//following-sibling::div//input[@name='address1']")

    @property
    def address2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Address 1')]//following-sibling::div//input[@name='address1']")

    @property
    def address3EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Address 3')]//following-sibling::div//input[@name='address3']")

    @property
    def address4EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Address 4')]//following-sibling::div//input[@name='address4']")

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Postcode')]//following-sibling::div//input")

    @property
    def bankAccountDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Bank Account details')]")

    @property
    def sortCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Sort Code')]//following-sibling::div//input")

    @property
    def accountNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Account Number')]//following-sibling::div//input")

    @property
    def bankAccountNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Bank Account Name')]//following-sibling::div//input")

    @property
    def bankNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Bank Name')]//following-sibling::div//input")

    @property
    def bankAddress1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Bank Address 1')]//following-sibling::div//input")

    @property
    def bankAddress2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Bank Address 2')]//following-sibling::div//input")

    @property
    def bankPostcodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Bank Postcode')]//following-sibling::div//input")
