from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ValuationAuthorisationPage(PlatformPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.AUTHORISE_VALUATION_UPDATES)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def authoriseValuationUpdatesSubHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Authorise Valuation Updates')]")

    @property
    def filterLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Filter')]")

    @property
    def accountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account')]")

    @property
    def accountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account')]//parent::div//input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")

    @property
    def thereAreNoUpdatesPendingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'There are no updates pending authorisation')]")
