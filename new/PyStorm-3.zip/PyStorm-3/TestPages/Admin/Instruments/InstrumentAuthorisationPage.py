from retry import retry
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.InstrumentAuthorisationRow import InstrumentAuthorisationRow
from TestPages.PlatformPage import PlatformPage


class InstrumentAuthorisationPage(PlatformPage):
    def wait(self):
        self.authoriseExternalInstrumentsLabel.waitForText(PageEnums.AUTHORISE_EXTERNAL_INSTRUMENTS)
        self.newClientButton.waitForElement()

    def getInstrumentRow(self, instrumentName):
        PrintMessage(f"getRow > attempt to retrieve row for instrumentName: '{instrumentName}'", inStepMessage=True)
        row: InstrumentAuthorisationRow = self.instrumentAuthorisationTable.getRow(columnName=PageEnums.INSTRUMENT_NAME,
                                                                                   value=instrumentName)
        return row

    @retry(exceptions=UIException, delay=10, tries=2)
    def verifyInstrumentDisplayed(self, instrumentName):
        row: InstrumentAuthorisationRow = self.getInstrumentRow(instrumentName)
        if row is None:
            raise UIException(f"Instrument '{instrumentName}' not found in the Instrument Authorisation Table")
        PrintMessage(f"Instrument '{instrumentName}' found in the Instrument Authorisation Table", inStepMessage=True)

    def authoriseInstrument(self, instrumentName):
        row: InstrumentAuthorisationRow = self.getInstrumentRow(instrumentName)
        row.authoriseCheckBox.click()
        self.saveButton.click()
        row: InstrumentAuthorisationRow = self.getInstrumentRow(instrumentName)
        if row is not None:
            raise UIException(f"Instrument authorisation failed'{instrumentName}'")
        PrintMessage(f"Instrument '{instrumentName}' authorised successfully", inStepMessage=True)

    @property
    def authoriseExternalInstrumentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Authorise External Instruments')]")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def backToTopHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")

    @property
    def instrumentAuthorisationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = InstrumentAuthorisationRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
