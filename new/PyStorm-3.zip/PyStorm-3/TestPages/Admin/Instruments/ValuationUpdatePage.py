from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ValuationUpdatePage(PlatformPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.VALUATION_UPDATES)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3")

    @property
    def externalManagerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Manager')]")

    @property
    def externalManagerEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Manager')]//following-sibling::div//select")

    @property
    def externalAssetLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset')]")

    @property
    def externalAssetEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset')]//following-sibling::div//select")

    @property
    def partnerReferenceLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner reference')]")

    @property
    def partnerReferenceEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner reference')]//following-sibling::div//input")

    @property
    def clientAccountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Client Account')]")

    @property
    def clientAccountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Client Account')]//following-sibling::div//input")

    @property
    def sedolLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Sedol')]")

    @property
    def sedolEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Sedol')]//following-sibling::div//input")

    @property
    def iSINLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ISIN')]")

    @property
    def iSINEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ISIN')]//following-sibling::div//input")

    @property
    def citiCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Citi code')]")

    @property
    def citiCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Citi code')]//following-sibling::div//input")

    @property
    def niNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'NI Number')]")

    @property
    def niNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'NI Number')]//following-sibling::div//input")

    @property
    def findButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Find')]")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")
