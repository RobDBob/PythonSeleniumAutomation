from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class MaintainInstrumentPage(PlatformPage):
    def wait(self):
        self.searchCriteriaLabel.waitForText(PageEnums.SearchCriteria)
        self.newClientButton.waitForElement()

    @property
    def searchCriteriaLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Search Criteria')]")

    @property
    def externalManagerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Manager')]")

    @property
    def externalAssetTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Type')]")

    @property
    def externalAssetDisplayNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Display Name')]")

    @property
    def externalAssetCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Code')]")

    @property
    def cIAccountIdLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ClAccountId')]")

    @property
    def partnerReferenceLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner Reference')]")

    @property
    def sedolLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'SEDOL')]")

    @property
    def isinLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ISIN')]")

    @property
    def citiCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Citi Code')]")

    @property
    def externalManagerDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'External Manager')]//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def externalAssetTypeDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'External Asset Type')]//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def externalAssetDisplayNameDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'External Asset Display Name')]//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def externalAssetCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Code')]//following-sibling::div/input")

    @property
    def cIAccountIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ClAccountId')]//following-sibling::div/input")

    @property
    def partnerReferenceEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner Reference')]//following-sibling::div/input")

    @property
    def sedolEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'SEDOL')]//following-sibling::div/input")

    @property
    def isinEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ISIN')]//following-sibling::div/input")

    @property
    def citiCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Citi Code')]//following-sibling::div/input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")

    @property
    def backToTopHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")
