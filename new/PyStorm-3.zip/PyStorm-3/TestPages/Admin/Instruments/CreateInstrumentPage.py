from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isFollowingSiblingInputCheckedCB
from TestPages.PlatformPage import PlatformPage


class CreateInstrumentPage(PlatformPage):
    def wait(self):
        self.wrapProviderLabel.waitForText(PageEnums.WRAP_PROVIDER)
        self.newClientButton.waitForElement()

    def setOuterRingInstrumentData(self, instrumentData: dict):
        # Wrap Provider
        if instrumentData.get(DataEnums.WRAP_PROVIDER, ""):
            self.wrapProviderDropdown.selectOption(instrumentData.get(DataEnums.WRAP_PROVIDER))

        # Investment Details
        if instrumentData.get(DataEnums.INVESTMENT_MANAGER, ""):
            self.managerDropdown.selectOption(instrumentData.get(DataEnums.INVESTMENT_MANAGER))
        if instrumentData.get(DataEnums.INSTRUMENT_TYPE, ""):
            self.instrumentTypeDropdown.selectOption(instrumentData.get(DataEnums.INSTRUMENT_TYPE))
        if instrumentData.get(DataEnums.DISPLAY_NAME):
            self.displayNameEditField.clearEnterValue(instrumentData.get(DataEnums.DISPLAY_NAME))
        if instrumentData.get(DataEnums.PARTNER_REFERENCE, ""):
            self.partnerReferenceEditField.clearEnterValue(instrumentData.get(DataEnums.PARTNER_REFERENCE))
        if instrumentData.get(DataEnums.MINIMUM_INVESTMENT_VALUE, ""):
            self.minimumInitialInvestmentEditField.clearEnterValue(instrumentData.get(DataEnums.MINIMUM_INVESTMENT_VALUE))
        if instrumentData.get(DataEnums.MAXIMUM_INVESTMENT_VALUE, ""):
            self.maxmumInitialInvestmentEditField.clearEnterValue(instrumentData.get(DataEnums.MAXIMUM_INVESTMENT_VALUE))
        if instrumentData.get(DataEnums.MINIMUM_SUBSEQUENT_INVESTMENT, ""):
            self.minimumSubsequentInvestmentEditField.clearEnterValue(instrumentData.get(DataEnums.MINIMUM_SUBSEQUENT_INVESTMENT))
        if instrumentData.get(DataEnums.SELL_AMOUNT, ""):
            self.minimumSellAmountEditField.clearEnterValue(instrumentData.get(DataEnums.SELL_AMOUNT))

        # Asset Manager Charges
        if instrumentData.get(DataEnums.ASSET_MANAGER_CHARGE, ""):
            self.externalAssetManagerInitialChargeEditField.clearEnterValue(instrumentData.get(DataEnums.ASSET_MANAGER_CHARGE))
        if instrumentData.get(DataEnums.ASSET_MANAGER_AMC, ""):
            self.externalAssetManagerAmcEditField.clearEnterValue(instrumentData.get(DataEnums.ASSET_MANAGER_AMC))
        if instrumentData.get(DataEnums.TRANSFERRABLE, ""):
            if instrumentData.get(DataEnums.TRANSFERRABLE) == PageEnums.YES:
                self.transferrableCheckbox.selectCheckBoxAndWait()
        if instrumentData.get(DataEnums.MATURITY_DATE, ""):
            self.maturityDateDatePicker.specify_date(instrumentData.get(DataEnums.MATURITY_DATE))
        if instrumentData.get(DataEnums.CLOSING_DATE, ""):
            self.closingDateApplicationDatePicker.specify_date(instrumentData.get(DataEnums.CLOSING_DATE))

        # Income Details
        if instrumentData.get(DataEnums.INTEREST_PAID, ""):
            self.canInterestBePaidOutDropdown.selectOption(instrumentData.get(DataEnums.INTEREST_PAID))
        if instrumentData.get(DataEnums.VALUATION_EXPECTATION_FREQUENCY, ""):
            self.valuationExpectationFrequencyDropdown.selectOption(instrumentData.get(DataEnums.VALUATION_EXPECTATION_FREQUENCY))
        if instrumentData.get(DataEnums.PENALTIES_RESTRICTIONS, ""):
            self.penaltiesRestrictionsEditField.clearEnterValue(instrumentData.get(DataEnums.PENALTIES_RESTRICTIONS))
        if instrumentData.get(DataEnums.TRADEABILITY, ""):
            self.tradeabilityDropdown.selectOption(instrumentData.get(DataEnums.TRADEABILITY))
        if instrumentData.get(DataEnums.TRADE_INSTRUCTION_METHOD, ""):
            self.externalManagerTradeInstructionMethodEditField.clearEnterValue(instrumentData.get(DataEnums.TRADE_INSTRUCTION_METHOD))
        if instrumentData.get(DataEnums.SELL_ONLY, ""):
            if instrumentData.get(DataEnums.SELL_ONLY) == PageEnums.YES:
                self.sellOnlyCheckbox.selectCheckBoxAndWait()
        if instrumentData.get(DataEnums.DRAWDOWN_PERMITTABLE, ""):
            if instrumentData.get(DataEnums.DRAWDOWN_PERMITTABLE) == PageEnums.YES:
                self.drawdownPermittableCheckbox.selectCheckBoxAndWait()

        # Fund Manager Contact Details
        if instrumentData.get(DataEnums.FUND_MANAGER_NAME, ""):
            self.fundManagerNameEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_NAME))
        if instrumentData.get(DataEnums.FUND_MANAGER_CONTACT_NAME, ""):
            self.fundManagerContactNameEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_CONTACT_NAME))
        if instrumentData.get(DataEnums.FUND_MANAGER_EMAIL, ""):
            self.fundManagerEmailEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_EMAIL))
        if instrumentData.get(DataEnums.FUND_MANAGER_PHONE_NO, ""):
            self.fundManagerPhoneEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_PHONE_NO))
        if instrumentData.get(DataEnums.FUND_MANAGER_PORTAL_DETAILS, ""):
            self.fundManagerPortalDetailsEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_PORTAL_DETAILS))
        if instrumentData.get(DataEnums.FUND_MANAGER_PASSWORD, ""):
            self.fundManagerPasswordEditField.clearEnterValue(instrumentData.get(DataEnums.FUND_MANAGER_PASSWORD))

        # Growth Rates
        if instrumentData.get(DataEnums.GROWTH_HIGH_RATE, ""):
            self.highEditField.clearEnterValue(instrumentData.get(DataEnums.GROWTH_HIGH_RATE))
        if instrumentData.get(DataEnums.GROWTH_MEDIUM_RATE, ""):
            self.mediumEditField.clearEnterValue(instrumentData.get(DataEnums.GROWTH_MEDIUM_RATE))
        if instrumentData.get(DataEnums.GROWTH_LOW_RATE, ""):
            self.lowEditField.clearEnterValue(instrumentData.get(DataEnums.GROWTH_LOW_RATE))

        # Bank Details
        if instrumentData.get(DataEnums.BANK_ACCOUNTS, ""):
            self.bankAccountToUseDropdown.selectOption(instrumentData.get(DataEnums.BANK_ACCOUNTS))

        # Permissions Details
        if instrumentData.get(DataEnums.PERMISSION_AVAILABLE_TO, ""):
            self.availableToDropdown.selectOption(instrumentData.get(DataEnums.PERMISSION_AVAILABLE_TO))

        # Administrator Contact Details
        if instrumentData.get(DataEnums.ADMINISTRATOR_NAME, ""):
            self.administratorNameEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_NAME))
        if instrumentData.get(DataEnums.ADMINISTRATOR_CONTACT_NAME, ""):
            self.administratorContactNameEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_CONTACT_NAME))
        if instrumentData.get(DataEnums.ADMINISTRATOR_EMAIL, ""):
            self.administratorEmailEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_EMAIL))
        if instrumentData.get(DataEnums.ADMINISTRATOR_PHONE_NO, ""):
            self.administratorPhoneEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_PHONE_NO))
        if instrumentData.get(DataEnums.ADMINISTRATOR_PORTAL_DETAILS, ""):
            self.administratorPortalDetailsEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_PORTAL_DETAILS))
        if instrumentData.get(DataEnums.ADMINISTRATOR_PASSWORD, ""):
            self.administratorPasswordEditField.clearEnterValue(instrumentData.get(DataEnums.ADMINISTRATOR_PASSWORD))

        # click Save
        self.saveButton.click()
        self.successMessageLabel.waitForElement()

    @property
    def successMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Investment created with reference')]")

    @property
    def wrapProviderLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Wrap Provider')]")

    @property
    def youDoNotHavePermissionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'You do not have permission')]")

    @property
    def investmentDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Investment Details')]")

    @property
    def managerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='fundmanagerid' and contains(text(),'Manager')]")

    @property
    def instrumentTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Instrument Type')]")

    @property
    def displayNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Display Name')]")

    @property
    def partnerReferenceLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner reference')]")

    @property
    def minimumInitialInvestmentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum initial investment')]")

    @property
    def maxmumInitialInvestmentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Maximum initial investment')]")

    @property
    def minimumSubsequentInvestmentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum subsequent investment')]")

    @property
    def minimumSellAmountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum sell amount')]")

    @property
    def maturityDateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Maturity Date')]")

    @property
    def closingDateApplicationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Closing Date for application')]")

    @property
    def externalAssetManagerInitialChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Manager Initial Charge')]")

    @property
    def externalAssetManagerAmcLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Manager AMC')]")

    @property
    def platformProviderAdministratorInitialChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Platform Provider Administrator Initial Charge')]")

    @property
    def platformProviderAdministratorOngoingChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Platform Provider Administrator Ongoing Charge')]")

    @property
    def transferrableLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Transferrable')]")

    @property
    def regularIncomeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Regular Income')]")

    @property
    def otherIncomeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Other Income')]")

    @property
    def canInterestBePaidOutLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Can interest be paid out')]")

    @property
    def valuationExpectationFrequencyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Valuation Expectation Frequency')]")

    @property
    def penaltiesRestrictionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Penalties Restrictions')]")

    @property
    def tradeabilityLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Tradeability')]")

    @property
    def externalManagerTradeInstructionMethodLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Manager Trade Instruction Method')]")

    @property
    def sellOnlyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'sell only')]")

    @property
    def drawdownPermittableLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Drawdown permittable')]")

    @property
    def fundManagerContactDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Fund Manager: Contact Details')]")

    @property
    def fundManagerNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMName' and contains(text(),'Name')]")

    @property
    def fundManagerContactNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMContactName' and contains(text(),'Contact Name')]")

    @property
    def fundManagerEmailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMEmail' and contains(text(),'Email')]")

    @property
    def fundManagerPhoneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMPhone' and contains(text(),'Phone number')]")

    @property
    def fundManagerPortalDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMPortal' and contains(text(),'Portal Details')]")

    @property
    def fundManagerPasswordLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMPassword' and contains(text(),'Passwords for Valuations')]")

    @property
    def administratorContactDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Administrator: Contact Details')]")

    @property
    def administratorNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminName' and contains(text(),'Name')]")

    @property
    def administratorContactNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminContactName' and contains(text(),'Contact Name')]")

    @property
    def administratorEmailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminEmail' and contains(text(),'Email')]")

    @property
    def administratorPhoneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminPhone' and contains(text(),'Phone number')]")

    @property
    def administratorPortalDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminPortal' and contains(text(),'Portal Details')]")

    @property
    def administratorPasswordLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminPassword' and contains(text(),'Passwords for Valuations')]")

    @property
    def growthRatesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Growth Rates')]")

    @property
    def highLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'High')]")

    @property
    def mediumLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Medium')]")

    @property
    def lowLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Low')]")

    @property
    def bankDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Bank Details')]")

    @property
    def bankAccountToUseLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Bank account to use')]")

    @property
    def permissionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Permissions')]")

    @property
    def availableToLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Available to')]")

    @property
    def displayNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Display Name')]//following-sibling::div/input")

    @property
    def partnerReferenceEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Partner reference')]//following-sibling::div/input")

    @property
    def minimumInitialInvestmentEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum initial investment')]//following-sibling::div/input")

    @property
    def maxmumInitialInvestmentEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Maximum initial investment')]//following-sibling::div/input")

    @property
    def minimumSubsequentInvestmentEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum subsequent investment')]//following-sibling::div/input")

    @property
    def minimumSellAmountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Minimum sell amount')]//following-sibling::div/input")

    @property
    def externalAssetManagerInitialChargeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Manager Initial Charge')]//following-sibling::div/div/input")

    @property
    def externalAssetManagerAmcEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Asset Manager AMC')]//following-sibling::div/div/input")

    @property
    def platformProviderAdministratorInitialChargeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Administrator Initial Charge')]//following-sibling::div/div/input")

    @property
    def platformProviderAdministratorOngoingChargeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Administrator Ongoing Charge')]//following-sibling::div/div/input")

    @property
    def penaltiesRestrictionsEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Penalties Restrictions')]//following-sibling::div/div/input")

    @property
    def externalManagerTradeInstructionMethodEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'External Manager Trade Instruction Method')]//following-sibling::div/input")

    @property
    def fundManagerNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMName' and contains(text(),'Name')]//following-sibling::div/input")

    @property
    def fundManagerContactNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMContactName' and contains(text(),'Contact Name')]//following-sibling::div/input")

    @property
    def fundManagerEmailEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMEmail' and contains(text(),'Email')]//following-sibling::div/input")

    @property
    def fundManagerPhoneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMPhone' and contains(text(),'Phone number')]//following-sibling::div/input")

    @property
    def fundManagerPortalDetailsEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='FMPortal' and contains(text(),'Portal Details')]//following-sibling::div/input")

    @property
    def fundManagerPasswordEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@for='FMPassword' and contains(text(),'Passwords for Valuations')]//following-sibling::div/input")

    @property
    def administratorNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminName' and contains(text(),'Name')]//following-sibling::div/input")

    @property
    def administratorContactNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminContactName' and contains(text(),'Contact Name')]//following-sibling::div/input")

    @property
    def administratorEmailEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminEmail' and contains(text(),'Email')]//following-sibling::div/input")

    @property
    def administratorPhoneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminPhone' and contains(text(),'Phone number')]//following-sibling::div/input")

    @property
    def administratorPortalDetailsEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[@for='AdminPortal' and contains(text(),'Portal Details')]//following-sibling::div/input")

    @property
    def administratorPasswordEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@for='AdminPassword' and contains(text(),'Passwords for Valuations')]//following-sibling::div/input")

    @property
    def highEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'High')]//following-sibling::div/input")

    @property
    def mediumEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Medium')]//following-sibling::div/input")

    @property
    def lowEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Low')]//following-sibling::div/input")

    @property
    def transferrableCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Transferrable')]")
        checkbox.isCheckedFuncCB = isFollowingSiblingInputCheckedCB
        return checkbox

    @property
    def sellOnlyCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'sell only')]")
        checkbox.isCheckedFuncCB = isFollowingSiblingInputCheckedCB
        return checkbox

    @property
    def drawdownPermittableCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Drawdown permittable')]")
        checkbox.isCheckedFuncCB = isFollowingSiblingInputCheckedCB
        return checkbox

    @property
    def managerDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[@for='fundmanagerid']//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def instrumentTypeDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Instrument Type')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def regularIncomeDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//span[contains(text(),'Regular Income')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def otherIncomeDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//span[contains(text(),'Other Income')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def canInterestBePaidOutDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//span[contains(text(),'Can interest be paid out')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def valuationExpectationFrequencyDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Valuation Expectation Frequency')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def tradeabilityDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Tradeability')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def wrapProviderDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//h2[contains(text(),'Wrap Provider')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def availableToDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Available to')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def bankAccountToUseDropdown(self):
        dropdown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Bank account to use')]//parent::div//following-sibling::div//select",
                                   (By.XPATH,
                                    ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def backToTopHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")

    @property
    def maturityDateDatePicker(self):
        return DatePicker(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Maturity Date')]//parent::div//following-sibling::div[contains(@class,'controls-text')]")

    @property
    def closingDateApplicationDatePicker(self):
        return DatePicker(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Closing Date for application')]//parent::div//following-sibling::div[contains(@class,'controls-text')]")
