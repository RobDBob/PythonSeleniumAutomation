from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ClientAccountExpectationsRow import ClientAccountExpectationsRow
from TestPages.PlatformPage import PlatformPage


class ApplyIncomePage(PlatformPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.APPLY_INCOME)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def clientAccountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Client Account')]")

    @property
    def clientAccountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Client Account')]//following-sibling::div//input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")

    @property
    def clientAccountExpectationsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Client account expectations to be generated')]")

    @property
    def clientAccountExpectationsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table data-table']//parent::div[@class='panel-body']")
        table.rowType = ClientAccountExpectationsRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
