from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class IssueManagementLogIssuePage(PlatformPage):
    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    def wait(self):
        self.pageTitle.waitForText(PageEnums.LogIssuePage)
