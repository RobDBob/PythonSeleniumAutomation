from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.ConfirmEditedCompanyAccessPage import ConfirmEditedCompanyAccessPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CompanyAccessLevelTableRow import CompanyAccessLevelTableRow
from TestPages.PlatformPage import PlatformPage


class EditCompanyAccess(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.EDIT_COMPANY_ACCESS)

    def clickSaveAndNavigateToConfirmPage(self):
        self.saveButton.jsClick()
        return ConfirmEditedCompanyAccessPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Edit Company Access')]")

    @property
    def companyAccessLabelTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.headerCellLocator = (By.XPATH, ".//th[@class='TableHead LAlign']")
        table.rowType = CompanyAccessLevelTableRow
        table.paginationLocator = (By.XPATH, "//div[@class='pagenation-container']//select")
        return table

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btnSaveCompanyLevel' and contains(text(),'Save')]")
