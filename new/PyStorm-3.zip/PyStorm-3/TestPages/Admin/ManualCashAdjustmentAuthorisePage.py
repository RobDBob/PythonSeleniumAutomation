from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseManualCashAdjustmentsRow import AuthoriseManualCashAdjustmentsRow
from TestPages.PlatformPage import PlatformPage


class ManualCashAdjustmentAuthorisePage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AuthoriseManualCashAdjustments)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='action-button' and contains(text(),'Confirm')]")

    @property
    def yesToProcessManualCashAdjustmentsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='col-auto col-middle mb-10 Exclamation']//parent::div//a[@class='action-button']")

    @property
    def statusUpdatedWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class='warning-message']")

    @property
    def authoriseManualCashAdjustmentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table data-heavy-table']")
        table.rowType = AuthoriseManualCashAdjustmentsRow
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'TableSubHead')]")
        return table

    @property
    def rejectReasonEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//tr[@style='']//td[contains(text(),'Rejected reason')]//following-sibling::td/input")
