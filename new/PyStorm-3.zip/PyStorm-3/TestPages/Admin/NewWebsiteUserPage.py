from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PlatformPage import PlatformPage


class NewWebsiteUserPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.NewWebsiteUser)

    def setWithData(self, userData: dict):
        if userData.get(DataEnums.USER_IS, None):
            option = userData.get(DataEnums.USER_IS)
            match option:
                case PageEnums.ADVISER_USER:
                    self.anAdviserRadioButton.click()

        if userData.get(DataEnums.ADVISER_COMPANY, None):
            self.advisersCompanyDropdown.selectOption(userData.get(DataEnums.ADVISER_COMPANY))
        if userData.get(DataEnums.SITE_ACCESS, None):
            self.advisorSiteAccessDropdown.selectOption(userData.get(DataEnums.SITE_ACCESS))
        if userData.get(DataEnums.FIRST_NAME, None):
            self.firstNameEditField.enterValue(userData.get(DataEnums.FIRST_NAME))
        if userData.get(DataEnums.SURNAME, None):
            self.surNameEditField.enterValue(userData.get(DataEnums.SURNAME))
        if userData.get(DataEnums.PRIMARY_EMAIL_ID, None):
            self.primaryEmailAddressEditField.enterValue(userData.get(DataEnums.PRIMARY_EMAIL_ID))
        if userData.get(DataEnums.ADDRESS_LINE_1, None):
            self.addressLine1EditField.enterValue(userData.get(DataEnums.ADDRESS_LINE_1))
        if userData.get(DataEnums.POST_CODE, None):
            self.postCodeEditField.enterValue(userData.get(DataEnums.POST_CODE))
        if userData.get(DataEnums.COUNTRY, None):
            self.countryDropdown.selectOption(userData.get(DataEnums.COUNTRY))
        self.saveButton.click()
        self.userSavedMessageLabel.waitForText(PageEnums.THIS_USER_HAS_BEEN_SAVED)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def userIsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'User is:')]")

    @property
    def userSavedMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'This user has been saved')]")

    @property
    def anAdviserRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'User is:')]//following-sibling::div//span[contains(text(),'an adviser')]")

    @property
    def slStaffRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'User is:')]//following-sibling::div//span[contains(text(),'SL staff')]")

    @property
    def thirdPartyRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'User is:')]//following-sibling::div//span[contains(text(),'Third party')]")

    @property
    def accessInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(), 'Access Information')]")

    @property
    def advisorSiteAccessDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//div[@id='AdvisorAccess']//label[contains(text(), 'Site Access:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def personalInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(), 'Personal Information')]")

    @property
    def titleEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Title:')]//following-sibling::input")

    @property
    def firstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'First Name:')]//following-sibling::input")

    @property
    def initialsEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Initials:')]//following-sibling::input")

    @property
    def surNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Surname:')]//following-sibling::input")

    @property
    def salutationEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Salutation:')]//following-sibling::input")

    @property
    def primaryEmailAddressEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Primary Email Address:')]//following-sibling::input")

    @property
    def emailAddressEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Email Address:')]//following-sibling::input")

    @property
    def dateOfBirthEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Date of Birth:')]//following-sibling::input")

    @property
    def postalAddressInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(), 'Postal Address Information')]")

    @property
    def addressLine1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Address Line 1:')]//following-sibling::input")

    @property
    def addressLine2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Address Line 2:')]//following-sibling::input")

    @property
    def addressLine3EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Address Line 3:')]//following-sibling::input")

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'PostCode:')]//following-sibling::input")

    @property
    def countryDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'Country:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def contactInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(), 'Contact Information')]")

    @property
    def workPhoneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Work Phone:')]//following-sibling::input")

    @property
    def homePhoneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Home Phone:')]//following-sibling::input")

    @property
    def mobileEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Mobile:')]//following-sibling::input")

    @property
    def faxEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Fax:')]//following-sibling::input")

    @property
    def otherPhoneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Other Phone:')]//following-sibling::input")

    @property
    def otherInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(), 'Other Information')]")

    @property
    def advisersCompanyDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'Company:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def departmentEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Department:')]//following-sibling::input")

    @property
    def positionEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Position:')]//following-sibling::input")

    @property
    def hourlyRateEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Hourly Rate(£):')]//following-sibling::input")

    @property
    def notes1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Notes 1:')]//following-sibling::div")

    @property
    def notes2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'Notes 2:')]//following-sibling::div")

    @property
    def userCanAuthoriseBankAccountModificationsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(), 'User can authorise bank account modifications:')]")

    @property
    def suppressCorporateActionNotificationsDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'Suppress Corporate Action Notifications?:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def withdrawalsAuthorisationLevelDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'Withdrawals Authorisation Level:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def historyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(), 'History')]")

    @property
    def adviserSupportTeamDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(), 'Adviser Support Team:')]//following-sibling::select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def networkWizardSetupCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(), 'Network Wizard Set-up')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def companyWizardSetupCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(), 'Company Wizard Set-up')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def importantNotesCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(), 'Important Notes')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def outerRingReadWriteAccessCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(), 'Outer ring read write access')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def insuredFundReadWriteAccessCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(), 'Insured fund read write access')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def pleaseIndicateTaxWrappersLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//div[contains(text(), 'Please indicate the tax wrappers that you wish your client to be permissioned to')]")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")
