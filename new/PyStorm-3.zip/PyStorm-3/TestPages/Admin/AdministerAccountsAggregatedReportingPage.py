from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.FindClientPage import FindClientPage
from TestPages.ClientsPage import ClientsPage
from TestPages.ClientsTabs.SearchResults.AccountDetailsAccountInfoPage import AccountDetailsAccountInfoPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class AdministerAccountsAggregatedReportingPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AdministerAccountsAggregatedReporting)

    def navigateToFirstFindClient(self):
        self.findClientButton.click()
        return FindClientPage(self.webdriver)

    def navigateToSecondFindClient(self):
        self.findClient2Button.click()
        return FindClientPage(self.webdriver)

    def navigateToAccountDetailsAccountInfoPage(self):
        self.saveButton.click()
        return AccountDetailsAccountInfoPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def useThisPageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Use this page to create')]")

    @property
    def accountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Type: ')]")

    @property
    def accountTypeConsolidatedLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Account Type: ')]//following-sibling::p[contains(text(),'Consolidated')]")

    @property
    def baseCurrencyDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Base Currency')]//following-sibling::select",
                                   optionsLocator=(
                                       By.XPATH,
                                       ".//option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Name: ')]//following-sibling::input")

    @property
    def linkedAccountEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Linked Account: ')]//following-sibling::input[@id='SubClAccountID1']")

    @property
    def findClientButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[text()='Find Client'])[1]")

    @property
    def removeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[ text()='Remove'])[1]")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Save']")

    @property
    def linkedAccount2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Linked Account: ')]//following-sibling::input[@id='SubClAccountID2']")

    @property
    def findClient2Button(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[text()='Find Client'])[2]")

    @property
    def remove2Button(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[ text()='Remove'])[2]")

    @property
    def linkedAccount3EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Linked Account: ')]//following-sibling::input[@id='SubClAccountID3']")

    @property
    def findClient3Button(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[text()='Find Client'])[3]")

    @property
    def remove3Button(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//a[ text()='Remove'])[3]")
