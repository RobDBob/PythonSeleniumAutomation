from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class DeferredTradesPage(PlatformPage):
    def wait(self):
        self.searchCriteriaLabel.waitForText(PageEnums.SearchCriteria)

    @property
    def searchCriteriaLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Search Criteria')]")

    @property
    def instrumentCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'InstrumentCode:')]//following-sibling::div/input")

    @property
    def dateFromDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Date From:')]//following-sibling::div/a")

    @property
    def dateToDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Date To:')]//following-sibling::div/a")

    @property
    def clAccountIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'ClAccountId:')]//following-sibling::div/input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")
