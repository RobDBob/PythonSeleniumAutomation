from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.Admin.FindAdviserPage import FindAdviserPage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AdviserAccountSelectRow import AdviserAccountSelectRow
from TestPages.WebDriver import ExpectedConditions as EC


class ChangeOfAdviserConfirmPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CHANGE_OF_ADVISER)
        self.pageSubTitle.waitForText(PageEnums.SWITCH_THE_FOLLOWING_ACCOUNTS_TO_THE_ABOVE_ADVISER)

    def navigateToFindAdviserPage(self):
        self.findButton.click()
        return FindAdviserPage(self.webdriver)

    def selectAccountChargesAndConfirm(self, accountNumber):
        adviserAccountSelectRow: AdviserAccountSelectRow = self.adviserAccountSelectTable.getRow(columnName=PageEnums.ACCOUNT, value=accountNumber)
        adviserAccountSelectRow.accountSelectCheckBox.click()
        self.ongoingAdviserChargesRadioButton.jsClick()
        self.regularInitialAdviserChargesRadioButton.jsClick()
        self.outstandingBouncedChargesRadioButton.jsClick()
        self.confirmButton.click()
        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//div[@class='warning-message']/div"), "Update successful.")
        WebDriverWait(self.webdriver, 60).until(waitcondition)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Change of Adviser']")

    @property
    def pageSubTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Switch the following accounts to the above adviser:']")

    @property
    def findButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@id='ContentPlaceHolder_resultsSection']//parent::div/a[text()='Find']")

    @property
    def newAdviserEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "newAdvisorCode")

    @property
    def adviserAccountSelectTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_ClientSearchResults_ClientAccountSearchResults")
        resultTable.firstRowIsHeader = True
        resultTable.headerSectionLocator = (By.XPATH, ".//tbody/tr[@class='sub-head']")
        resultTable.headerCellLocator = (By.XPATH, ".//td[contains(@class,'TableSubHead')]")
        resultTable.rowLocator = (By.XPATH, ".//tr")
        resultTable.rowType = AdviserAccountSelectRow
        return resultTable

    @property
    def ongoingAdviserChargesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//input[@id='ContentPlaceHolder_ChargesSetting_OACTRANSFER']//following-sibling::span[@class='gfx']")

    @property
    def regularInitialAdviserChargesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//input[@id='ContentPlaceHolder_ChargesSetting_RIACTRANSFER']//following-sibling::span[@class='gfx']")

    @property
    def outstandingBouncedChargesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//input[@id='ContentPlaceHolder_ChargesSetting_OBCTRANSFER']//following-sibling::span[@class='gfx']")

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_confirmChangeOfAdvisor")
