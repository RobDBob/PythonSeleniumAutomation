from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AdviserFirmTermsRow import AdviserFirmTermsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.OuterRingChargesRow import OuterRingChargesRow
from TestPages.PageObjects.BaseObjects.Table.Rows.PlatformChargeRow import PlatformChargeRow
from TestPages.PageObjects.BaseObjects.Table.Rows.ProductAdministrationChargeRow import ProductAdministrationChargeRow


class UpdateAdviserFirmTermsPage(ClientsPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.UPDATE_ADVISER_FIRM_TERMS)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def adviserFirmLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Adviser Firm')]")

    @property
    def propositionLevelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Proposition Level')]")

    @property
    def adviserFirmDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@name='adviserFirmSelect']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def propositionLevelDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@name='servicePropositionSelect']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def adviserFirmTermsOverviewLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Adviser Firm Terms Overview')]")

    @property
    def adviserFirmTermsOverviewTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='js-termsTable data-table mb-40']")
        table.rowType = AdviserFirmTermsRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        return table

    @property
    def currentTermsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Current Terms:')]")

    @property
    def outerRingChargesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Outer Ring Charges')]")

    @property
    def outerRingChargesTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[contains(@class,'js-outerRingChargesTable')]")
        table.rowType = OuterRingChargesRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        return table

    @property
    def productAdministrationChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Product Administration Charge')]")

    @property
    def productAdministrationChargeTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[contains(@class,'js-productAdministrationChargeTable')]")
        table.rowType = ProductAdministrationChargeRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        return table

    @property
    def platformChargeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Platform Charge')]")

    @property
    def platformChargeTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[contains(@class,'js-platformChargeTable')]")
        table.rowType = PlatformChargeRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        return table

    @property
    def updateButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Update')]")

    @property
    def changeToStandardButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Change to Standard')]")
