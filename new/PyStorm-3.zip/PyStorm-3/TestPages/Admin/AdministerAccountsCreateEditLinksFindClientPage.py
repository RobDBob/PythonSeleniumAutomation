from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AdministerAccountsCreateEditLinksFindClientRow import AdministerAccountsCreateEditLinksFindClientRow
from TestPages.Support.NewTabPage import NewTabPage


class AdministerAccountsCreateEditLinksFindClientPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.FindClient)

    def findClient(self, accountNumber=None, accountName=None):
        if accountNumber:
            PrintMessage(f"Find client with account number: '{accountNumber}'.", inStepMessage=True)
            self.accountNumberEditField.send_keys(accountNumber)
        if accountName:
            PrintMessage(f"Find client with account name: '{accountName}'", inStepMessage=True)
            self.accountNameEditField.send_keys(accountName)
        self.searchButton.jsClick()
        return self.administerAccountsCreateAndEditLinksTable

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account Number']//following-sibling::div/input")

    @property
    def accountNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account Name']//following-sibling::div/input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")

    @property
    def clearButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Clear')]")

    @property
    def administerAccountsCreateAndEditLinksTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table detached']")
        resultTable.rowType = AdministerAccountsCreateEditLinksFindClientRow
        resultTable.headerSectionLocator = (By.XPATH, ".//thead//tr")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.waitForDataToRender()
        return resultTable
