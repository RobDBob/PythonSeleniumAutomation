from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.Admin.ReportRowWaiter import ReportRowWaiter
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.AdviserReportGenerationTable import AdviserReportGenerationTable, AdviserReportReportRow
from TestPages.PlatformPage import PlatformPage


class AdviserReportGenerationPage(PlatformPage, ReportRowWaiter):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AdviserManagementInfoReports)

    def selectAndCreateReport(self, testData: dict) -> AdviserReportReportRow:
        if testData.get(DataEnums.REPORTS, None):
            self.reportsDropdown.selectOption(testData[DataEnums.REPORTS])
        if testData.get(DataEnums.COMPANY, None):
            self.companyDropdown.selectOption(testData[DataEnums.COMPANY])
        self.createButton.click()
        firstRow: AdviserReportReportRow = self.reportTable.getFirstRow()
        currentMinute = datetime.now().minute
        self.waitForReportToAppear(currentMinute, dateTime=firstRow.requestDateTime, tableToSearch=self.reportTable)
        return firstRow

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def reportsDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='TaskID']", optionsLocator=(By.CSS_SELECTOR, "option[value]"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def companyDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='searchcompany']", optionsLocator=(By.CSS_SELECTOR, "option[value]"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def createButton(self):
        return Button(self.webdriver, self.webdriver, By.CSS_SELECTOR, "a[id='btnCreate']")

    @property
    def reportTable(self):
        return AdviserReportGenerationTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
