from retry import retry
from selenium.common.exceptions import NoSuchWindowException, TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.FindClientsResultRow import FindClientsResultRow
from TestPages.Support.NewTabPage import NewTabPage


class FindClientPage(NewTabPage):
    EXPECT_AUTO_CLOSE = True

    def wait(self):
        self.pageTitle.waitForText(PageEnums.FindClient)

    def selectCorrectionType(self, correctionType):
        Button(self.webdriver, self.webdriver, By.XPATH, f"//span[text()='{correctionType}']").click()

    def findClient(self, accountNumber=None, accountName=None):
        if accountNumber:
            PrintMessage(f"Find client with account number: '{accountNumber}'.", inStepMessage=True)
            self.accountNumberEdit.send_keys(accountNumber)
        if accountName:
            PrintMessage(f"Find client with account name: '{accountName}'", inStepMessage=True)
            self.accountNameEdit.send_keys(accountName)

        self.searchButton.jsClick()
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table detached']")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.rowLocator = (By.XPATH, ".//tr")
        resultTable.rowType = FindClientsResultRow
        resultTable.waitForDataToRender()
        return resultTable

    @retry(exceptions=TimeoutException, tries=3)
    def findAndSelectLastClient(self, accountId):
        resultTable = self.findClient(accountNumber=accountId)
        lastRow: FindClientsResultRow = resultTable.getLastRow()
        lastRow.accountCodeButton.click()
        try:
            lastRow.defaultWait = 10
            lastRow.waitForElementToCeaseExist()

        # work around issue where click is not registered on test server
        except NoSuchWindowException:
            pass

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountNumberEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "txtaccountnumber")

    @property
    def accountNameEdit(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "txtsearchkey")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='action-button pull-right']")

    @property
    def clearButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Clear']")

    @property
    def enterTheSearchTermsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Enter the search terms')]")
