from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.ClientsTabs.SearchResults.AccountsDocumentsTabPage import AccountsDocumentsTabPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class LegacyClientReportingPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.REPORTS_AND_REQUEST)

    def navigateToAccountsDocumentsTabPage(self):
        self.generateDocumentsButton.click()
        return AccountsDocumentsTabPage(self.webdriver)

    def setWithReportGenerationData(self, testData):
        match testData.get(DataEnums.REPORT_TYPE, None):
            case PageEnums.INDIVIDUAL:
                self.individualRadioButton.click()
        match testData.get(DataEnums.REPORT_FORMAT, None):
            case PageEnums.WORD:
                self.wordRadioButton.click()
        match testData.get(DataEnums.CONTENT_TYPE, None):
            case PageEnums.FULL:
                self.fullRadioButton.click()
        match testData.get(DataEnums.DISPLAY_VIEW, None):
            case PageEnums.BY_PRODUCT:
                self.byProductRadioButton.click()
        match testData.get(DataEnums.ACCOUNT_VIEW, None):
            case PageEnums.WRAP:
                self.wrapViewRadioButton.click()
        match testData.get(DataEnums.HEADER_ON_OR_OFF, None):
            case PageEnums.OFF:
                self.offHeaderRadioButton.click()
        match testData.get(DataEnums.ASSET_CLASS_DETAILS, None):
            case PageEnums.TIER_1:
                self.tier1RadioButton.click()
        match testData.get(DataEnums.REPORT_CONTENT, None):
            case PageEnums.CAPITAL_GAIN_REPORT:
                self.capitalGainReportCheckBox.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//form//h1")

    @property
    def individualRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Report Type']//following-sibling::div//span[text()='Individual']")

    @property
    def wordRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Report Format']//following-sibling::div//span[text()='Word']")

    @property
    def fullRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Content Type']//following-sibling::div//span[text()='Full']")

    @property
    def byProductRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Display View']//following-sibling::div//span[text()='By Product']")

    @property
    def wrapViewRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account View']//following-sibling::div//span[text()='Wrap View']")

    @property
    def offHeaderRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Header On/Off']//following-sibling::div//span[text()='Off']")

    @property
    def tier1RadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Asset Class Detail']//following-sibling::div//span[text()='Tier 1']")

    @property
    def capitalGainReportCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Capital Gains Report']")

    @property
    def generateDocumentsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Generate documents']")
