from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseManagerRow import AuthoriseManagerRow
from TestPages.PlatformPage import PlatformPage


class AuthoriseManagerPage(PlatformPage):
    def wait(self):
        self.authoriseManagerLabel.waitForText(PageEnums.AUTHORISE_MANAGER)

    @property
    def authoriseManagerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Authorise Manager')]")

    @property
    def noteYouCanNotAuthoriseLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'You can not authorise changes initiated by yourself')]")

    @property
    def authoriseManagerTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = AuthoriseManagerRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
