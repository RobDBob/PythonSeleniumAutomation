from retry import retry
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.DateMethods import getMinuteRange
from TestPages import PageEnums
from TestPages.BasePage import BasePage


class ReportRowWaiter(BasePage):
    @retry(exceptions=UIException, delay=15, tries=20)
    def waitForReportToAppear(self, currentMinute, dateTime=None, tableToSearch=None):
        PrintMessage(f"Wait for report to appear with '{PageEnums.Complete}' state.")

        dataRows = tableToSearch.dataRows
        tableToSearch.scrollToEndOfElement()

        if not dataRows:
            raise UIException("waitForReportToAppear > no data available")

        if dateTime.minute not in getMinuteRange(currentMinute, 4):
            raise UIException(f"waitForReportToAppear > report not ready, current minute: '{currentMinute}'; report minute: '{dateTime.minute}'")

        reportStatus = tableToSearch.getFirstRow().statusLabel.text
        PrintMessage(f"REPORT STATUS : {reportStatus}")
        if reportStatus != PageEnums.Complete:
            raise UIException(f"waitForReportToAppear > report not ready, current status: '{reportStatus}'; waiting for 'Complete'.")
