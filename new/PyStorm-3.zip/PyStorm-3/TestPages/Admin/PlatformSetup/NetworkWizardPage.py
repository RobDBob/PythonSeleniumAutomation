from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.Admin.PlatformSetup.NetworkWizardRemunerationAndValuationPage import NetworkWizardRemunerationAndValuationPage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class NetworkWizardPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.NETWORK_WIZARD)

    def clickNextAndNavigateToRemunerationAndValuationPage(self):
        self.nextButton.click()
        return NetworkWizardRemunerationAndValuationPage(self.webdriver)

    def setWithNetworkData(self, networkData: dict):
        if networkData.get(DataEnums.NETWORK_NAME, None):
            self.networkNameEditField.enterValue(networkData.get(DataEnums.NETWORK_NAME))
        if networkData.get(DataEnums.LINKED_SERVICE_PROVIDER, None):
            self.linkedServiceProviderDropdown.selectOption(networkData.get(DataEnums.LINKED_SERVICE_PROVIDER))
        if networkData.get(DataEnums.TRADING_REFERENCE, None):
            self.fcaTradingReferenceEditField.enterValue(networkData.get(DataEnums.TRADING_REFERENCE))
        if networkData.get(DataEnums.TRADING_STATUS, None):
            self.fcaTrainingStatusDropdown.selectOption(networkData.get(DataEnums.TRADING_STATUS))
        if networkData.get(DataEnums.ADDRESS_LINE_1, None):
            self.addressLine1EditField.enterValue(networkData.get(DataEnums.ADDRESS_LINE_1))
        if networkData.get(DataEnums.ADDRESS_LINE_2, None):
            self.addressLine2EditField.enterValue(networkData.get(DataEnums.ADDRESS_LINE_2))
        if networkData.get(DataEnums.POST_CODE, None):
            self.postCodeEditField.enterValue(networkData.get(DataEnums.POST_CODE))
        if networkData.get(DataEnums.COUNTRY, None):
            self.countryDropdown.selectOption(networkData.get(DataEnums.COUNTRY))
        if networkData.get(DataEnums.AREA_CODE, None):
            self.areaCodeEditField.enterValue(networkData.get(DataEnums.AREA_CODE))
        if networkData.get(DataEnums.NUMBER, None):
            self.numberEditField.enterValue(networkData.get(DataEnums.NUMBER))

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def networkNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'Network name')]//parent::div//following-sibling::div//input")

    @property
    def linkedServiceProviderDropdown(self):
        dropDown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Linked service provider')]//parent::div//following-sibling::div//select",
            optionsLocator=(
                By.TAG_NAME,
                "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def fcaTradingReferenceEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "//label[contains(text(),'FCA/Trading reference')]//parent::div//following-sibling::div//input")

    @property
    def fcaTrainingStatusDropdown(self):
        dropDown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'FCA/Trading status')]//parent::div//following-sibling::div//select",
            optionsLocator=(
                By.TAG_NAME,
                "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def addressLine1EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Address line 1')]//parent::div//following-sibling::div//input")

    @property
    def addressLine2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Address line 2')]//parent::div//following-sibling::div//input")

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Postcode')]//parent::div//following-sibling::div//input")

    @property
    def countryDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[contains(text(),'Country')]//parent::div//following-sibling::div//select", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def areaCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "(//label[contains(text(),'Area code')]//parent::div//following-sibling::div//input)[1]")

    @property
    def numberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH,
                         "(//label[contains(text(),'Number')]//parent::div//following-sibling::div//input)[1]")

    @property
    def nextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Remuneration and valuation']")
