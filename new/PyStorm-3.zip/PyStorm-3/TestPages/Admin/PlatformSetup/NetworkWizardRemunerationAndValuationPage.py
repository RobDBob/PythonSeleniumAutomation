from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.PlatformSetup.NetworkWizardValidateAndExecutePage import NetworkWizardValidateAndExecutePage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class NetworkWizardRemunerationAndValuationPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.REMUNERATION_AND_VALUATION)

    def clickNextAndNavigateToValidateAndExecutePage(self):
        self.nextButton.click()
        return NetworkWizardValidateAndExecutePage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def nextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Validate and execute']")
