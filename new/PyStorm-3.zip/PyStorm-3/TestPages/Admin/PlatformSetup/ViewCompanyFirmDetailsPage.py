from selenium.webdriver.common.by import By
from TestPages.Admin.PlatformSetup.ViewCompanyPage import ViewCompanyPage
from TestPages.Admin.PlatformSetup.ViewCompanyRemunerationAndValuationPage import ViewCompanyRemunerationAndValuationPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class ViewCompanyFirmDetailsPage(ViewCompanyPage):
    def navigateNextToRemunerationAndValuationPage(self):
        self.nextButton.click()
        return ViewCompanyRemunerationAndValuationPage(self.webdriver)

    @property
    def subTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div/b")

    @property
    def firmTypeValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Firm Type']/../following-sibling::dd")

    @property
    def isActiveValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Is Active?']/../following-sibling::dd")

    @property
    def fcaTrandingReferenceValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='FCA/Trading Reference']/../following-sibling::dd")

    @property
    def firmEmailAddressValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Email Address']/../following-sibling::dd")

    @property
    def nextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(@class, 'next-button')]")
