
from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class ViewCompanyPage(BasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.VIEW_COMPANY)

    def navigateBackToDashBoardPage(self):
        from TestPages.Admin.PlatformSetup.CompanyWizardSetupPage import CompanyWizardSetupPage
        self.backToDashboardLeftHandMenuButton.click()
        return CompanyWizardSetupPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def backToDashboardLeftHandMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Back to dashboard']")
