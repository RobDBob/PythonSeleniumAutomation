from selenium.webdriver.common.by import By
from TestPages.Admin.PlatformSetup.ViewCompanyPage import ViewCompanyPage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.BankDetailsRow import BankDetailsRow


class ViewCompanyRemunerationAndValuationPage(ViewCompanyPage):
    @property
    def subTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div/b")

    @property
    def generateEDIFileValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Generate EDI File']/../following-sibling::dd")

    @property
    def bankDetailsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody")
        table.rowLocator = (By.XPATH, ".//tr")
        table.rowType = BankDetailsRow
        return table
