from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.PlatformSetup.NetworkWizardPage import NetworkWizardPage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label


class NetworkWizardSetupPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.Network)

    def selectNetworkClickCreateAndNavigateToNetworkWizardPage(self):
        self.networkTypeDropdown.selectOption(PageEnums.Network)
        self.createButton.click()
        return NetworkWizardPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3")

    @property
    def networkTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Network type']//parent::div//following-sibling::div//select", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def createButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Create']")
