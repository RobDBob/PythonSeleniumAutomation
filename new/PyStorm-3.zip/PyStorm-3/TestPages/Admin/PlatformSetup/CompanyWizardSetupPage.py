from selenium.webdriver.common.by import By
from TestPages import DataEnums
from TestPages.Admin.PlatformSetup.SearchCriteriaPage import SearchCriteriaPage
from TestPages.Admin.PlatformSetup.ViewCompanyFirmDetailsPage import ViewCompanyFirmDetailsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CompanyWizardFirmSearchResultRow import CompanyWizardFirmSearchResultRow


class CompanyWizardSetupPage(SearchCriteriaPage):
    def searchAndNavigateToViewCompanyPage(self, **kwargs):
        if DataEnums.FIRM_ID in kwargs:
            self.firmIDEditField.enterValue(kwargs.get(DataEnums.FIRM_ID))

        if DataEnums.FIRM_NAME in kwargs:
            self.firmNameEditField.enterValue(kwargs.get(DataEnums.FIRM_NAME))

        self.searchButton.click()
        self.searchResultsTable.waitForDataToRender()

        firstRow: CompanyWizardFirmSearchResultRow = self.searchResultsTable.getFirstRow()
        firstRow.firmIDButton.click()

        Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(), 'View')]").click()

        return ViewCompanyFirmDetailsPage(self.webdriver)

    @property
    def firmIDEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Firm ID']/../following-sibling::div/input")

    @property
    def firmNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Firm name']/../following-sibling::div/input")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Search']")

    @property
    def searchResultsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody")
        table.rowLocator = (By.XPATH, ".//tr")
        table.rowType = CompanyWizardFirmSearchResultRow
        return table
