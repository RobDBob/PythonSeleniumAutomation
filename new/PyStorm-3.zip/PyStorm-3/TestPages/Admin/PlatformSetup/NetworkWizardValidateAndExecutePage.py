from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Admin.PlatformSetup.NetworkWizardSuccessPage import NetworkWizardSuccessPage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class NetworkWizardValidateAndExecutePage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.VALIDATE_AND_EXECUTE)

    def clickSubmitAndNavigateToSuccessPage(self):
        self.submitButton.click()
        return NetworkWizardSuccessPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3")

    @property
    def successMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class = 'success-message undefined']")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Submit']")
