from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.LinkedSubClAccountIDTableRow import LinkedSubClAccountIDTableRow
from TestPages.Support.NewTabPage import NewTabPage


class LinkedSubClAccountIDPage(NewTabPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.LINKED_SUB_CI_ACCOUNT_ID)

    def checkAllAccountCheckBoxes(self):
        row: LinkedSubClAccountIDTableRow
        for row in self.linkedSubClAccountIDTable.dataRows:
            row.webdriver = self.webdriver
            row.chooseCheckBox.jsClick()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def linkedSubClAccountIDTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.rowType = LinkedSubClAccountIDTableRow
        return resultTable

    @property
    def confirmButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Confirm')]")
