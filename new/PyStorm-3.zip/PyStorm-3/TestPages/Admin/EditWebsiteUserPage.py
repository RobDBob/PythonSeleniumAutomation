from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.Admin.NewWebsiteUserPage import NewWebsiteUserPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class EditWebsiteUserPage(NewWebsiteUserPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.EDIT_WEBSITE_USER)

    def setEditWebsiteUserData(self, userData: dict):
        if userData.get(DataEnums.SITE_ACCESS):
            self.siteAccessDropdown.selectOption(userData.get(DataEnums.SITE_ACCESS))
        if userData.get(DataEnums.FIRST_NAME):
            self.firstNameEditField.enterValue(userData.get(DataEnums.FIRST_NAME))
        if userData.get(DataEnums.LAST_NAME):
            self.surNameEditField.enterValue(userData.get(DataEnums.SURNAME))
        if userData.get(DataEnums.EMAIL_ADDRESS):
            self.primaryEmailAddressEditField.enterValue(userData.get(DataEnums.EMAIL_ADDRESS))
        if userData.get(DataEnums.ADDRESS_LINE_1):
            self.addressLineOneEditField.enterValue(userData.get(DataEnums.ADDRESS_LINE_1))
        if userData.get(DataEnums.POST_CODE):
            self.postCodeEditField.enterValue(userData.get(DataEnums.POST_CODE))
        if userData.get(DataEnums.COUNTRY):
            self.countryDropdown.selectOption(userData.get(DataEnums.COUNTRY))
        if userData.get(DataEnums.COMPANY):
            self.companyDropdown.selectOption(userData.get(DataEnums.COMPANY))
        self.saveButton.click()
        self.userSavedMessageLabel.waitForText(PageEnums.THIS_USER_HAS_BEEN_SAVED)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def siteAccessDropdown(self):
        locator = "//label[contains(text(), 'Site Access:')]//following-sibling::select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def saveButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Save')]")

    @property
    def userSavedMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'This user has')]")

    @property
    def firstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'First Name:')]//following-sibling::input")

    @property
    def surNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Surname:')]//following-sibling::input")

    @property
    def primaryEmailAddressEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Primary Email Address:')]//following-sibling::input")

    @property
    def addressLineOneEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Address Line 1:')]//following-sibling::input")

    @property
    def postCodeEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'PostCode:')]//following-sibling::input")

    @property
    def countryDropdown(self):
        locator = "//label[contains(text(),'Country:')]//following-sibling::select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def companyDropdown(self):
        locator = "//label[contains(text(),'Company:')]//following-sibling::select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def removeUnipassIdentifierButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH,
                      "//label[contains(text(),'Unipass Identifier:')]//following-sibling::div//span[contains(text(),'Remove Unipass Identifier:')]")

    @property
    def accessInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()=' Access Information']")

    @property
    def advisorUserRadioButtonChecked(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@name='isadvisor' and @checked]/following-sibling::span")

    @property
    def unipassIdentifierLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Unipass Identifier:')]/parent::*/div[@class='controls-value']")

    @property
    def removeUnipassIdentifierLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Remove Unipass Identifier:')]")

    @property
    def userId(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'User ID:')]//following-sibling::div")

    @property
    def advisorSiteAccessDropdown(self):
        dropDownListBox = DropdownListbox(self.webdriver,
                                          self.webdriver,
                                          By.XPATH,
                                          "//div[@id='AdvisorAccess']//label[contains(text(), 'Site Access:')]//following-sibling::select",
                                          (By.TAG_NAME,
                                           'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox
