from selenium.webdriver.common.by import By
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AccountRestrictionConfigFeeAndChargesRow import AccountRestrictionConfigFeeAndChargesRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AccountRestrictionConfigPaymentsRow import AccountRestrictionConfigPaymentsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.AccountRestrictionConfigTransactionalRow import AccountRestrictionConfigTransactionalRow
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PlatformPage import PlatformPage


class SuspendedActivityConfigurationPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AccountRestrictionConfiguration)

    def getFeeAndChargesSelectedRow(self, dataLabel) -> AccountRestrictionConfigFeeAndChargesRow:
        dataRows: list[AccountRestrictionConfigFeeAndChargesRow] = self.feesAndChargesTable.dataRows
        matchingRows = [k for k in dataRows if dataLabel == k.feePostingLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def getPaymentsSelectedRow(self, dataLabel) -> AccountRestrictionConfigPaymentsRow:
        dataRows = self.paymentsTable.dataRows
        matchingRows = [k for k in dataRows if dataLabel == k.paymentTypeLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def getTransactionalSelectedRow(self, dataLabel) -> AccountRestrictionConfigTransactionalRow:
        dataRows = self.transactionalTable.dataRows
        matchingRows = [k for k in dataRows if dataLabel == k.transactionTypeLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def waitForMandatoryFieldValidationMessage(self, mandatoryFieldErrorMessage):
        self.mandatoryFieldValidationMessageLabel.waitForText(mandatoryFieldErrorMessage)

    def setWithRestrictionData(self, testData):
        if testData.get(DataEnums.REASON_FOR_SUSPENDING):
            self.reasonForSuspendingDropdown.selectOption(testData.get(DataEnums.REASON_FOR_SUSPENDING))

        self.editButton.jsClick()
        restrictionTypeData = testData.get(DataEnums.RESTRICTION_TYPE, [])

        for restrictionType in restrictionTypeData:
            match restrictionType:
                case DataEnums.DEPOSITS_FLAG_FOR_APPROVAL:
                    self.getPaymentsSelectedRow(PageEnums.DEPOSITS).flagForApprovalCheckBox.selectCheckBoxAndWait(jsClick=True)
                case DataEnums.FEE_POSTING:
                    self.getFeeAndChargesSelectedRow(PageEnums.FEE_POSTING).suspendedCheckBox.selectCheckBoxAndWait(jsClick=True)
                case DataEnums.WITHDRAWALS_FLAG_FOR_APPROVAL:
                    self.getPaymentsSelectedRow(PageEnums.WITHDRAWALS).flagForApprovalCheckBox.selectCheckBoxAndWait(jsClick=True)
        self.saveButton.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def reasonForSuspendingDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='restrictionReason']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def editButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Edit']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cancel']")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Save']")

    @property
    def feesAndChargesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Fees & Charges']")

    @property
    def paymentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Payments']")

    @property
    def transactionalLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transactional']")

    @property
    def feesAndChargesTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//td[text()='Fee Posting']/parent::tr/parent::tbody/parent::table")
        table.rowType = AccountRestrictionConfigFeeAndChargesRow
        return table

    @property
    def paymentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//td[text()='Withdrawals']/parent::tr/parent::tbody/parent::table")
        table.rowType = AccountRestrictionConfigPaymentsRow
        return table

    @property
    def transactionalTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//td[text()='Buys']/parent::tr/parent::tbody/parent::table")
        table.rowType = AccountRestrictionConfigTransactionalRow
        return table

    @property
    def untitledSectionTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = GenericBaseRow
        table.headerCellLocator = (By.XPATH, ".//th[text()]")
        return table

    @property
    def mandatoryFieldValidationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='plain-module']/p")

    @property
    def backToTop(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Back to top']")

    @property
    def restrictionMatrixChangeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Restriction matrix change has been sent to authorisation.')]")
