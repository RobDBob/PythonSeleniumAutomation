from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AccountRestrictionAuthorisationRow import AccountRestrictionAuthorisationRow
from TestPages.PlatformPage import PlatformPage


class SuspendedReasonAuthorisationPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AuthoriseRestrictionMatrixChange)

    def getAccountRestrictionAuthorisationSelectedRow(self, dataLabel) -> AccountRestrictionAuthorisationRow:
        dataRows: list[AccountRestrictionAuthorisationRow] = self.authoriseRestrictionAuthorisationTable.dataRows
        matchingRows = [k for k in dataRows if dataLabel in k.reasonNameLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def rejectAllRequests(self):
        cannotSelfAuthoriseLabel = (By.XPATH, "//p[text()='(note: You cannot authorise changes initiated by yourself)']")
        if not self.webdriver.find_elements(*cannotSelfAuthoriseLabel):
            return
        row: AccountRestrictionAuthorisationRow
        for row in self.authoriseRestrictionAuthorisationTable.dataRows:
            row.rejectCheckBox.jsClick()
        self.authoriseButton.click()
        self.authoriseButton.click()
        self.noChangesToAuthoriseLabel.waitForText(PageEnums.THERE_ARE_NO_CHANGES_TO_AUTHORISE)

    def authoriseAllRequests(self):
        cannotSelfAuthoriseLabel = (By.XPATH, "//p[text()='(note: You cannot authorise changes initiated by yourself)']")
        if not self.webdriver.find_elements(*cannotSelfAuthoriseLabel):
            return
        row: AccountRestrictionAuthorisationRow
        for row in self.authoriseRestrictionAuthorisationTable.dataRows:
            row.authoriseCheckBox.jsClick()
        self.authoriseButton.click()
        self.authoriseButton.click()
        self.noChangesToAuthoriseLabel.waitForText(PageEnums.THERE_ARE_NO_CHANGES_TO_AUTHORISE)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def areYouSureLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Are you sure you wish to Authorise/Reject these events?']")

    @property
    def authorisationCancelledLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Reason Matrix authorisation has been cancelled.']")

    @property
    def noChangesToAuthoriseLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='There are no changes to authorise.']")

    @property
    def youHaveNotSelectedAnyProcessesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='You have not selected any processes to be authorised.']")

    @property
    def authoriseButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Authorise')]")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Cancel')]")

    @property
    def backToTopButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Back to top')]")

    @property
    def authoriseRestrictionAuthorisationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.headerSectionLocator = (By.XPATH, ".//thead")
        table.headerCellLocator = (By.XPATH, ".//th[@class]")
        table.rowType = AccountRestrictionAuthorisationRow
        return table
