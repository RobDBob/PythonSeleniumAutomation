from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class RemunerationStatementPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.RemunerationStatementHistory)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")
