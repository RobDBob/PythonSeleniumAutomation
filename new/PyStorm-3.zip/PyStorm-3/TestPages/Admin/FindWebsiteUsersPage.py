from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.FindWebsiteUsersTableRow import FindWebsiteUsersTableRow
from TestPages.PlatformPage import PlatformPage


class FindWebsiteUsersPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.FindWebsiteUsers)

    def setWithData(self, userData: dict, userId=None):
        if userId:
            self.userIdEditField.enterValue(userId)
        if userData.get(DataEnums.FIRST_NAME):
            self.firstNameEditField.enterValue(userData.get(DataEnums.FIRST_NAME))
        if userData.get(DataEnums.LAST_NAME):
            self.lastNameEditField.enterValue(userData.get(DataEnums.LAST_NAME))
        if userData.get(DataEnums.EMAIL_ADDRESS):
            self.emailAddressEditField.enterValue(userData.get(DataEnums.EMAIL_ADDRESS))
        if userData.get(DataEnums.COMPANY):
            self.companyDropdown.selectOption(userData.get(DataEnums.COMPANY))
        if userData.get(DataEnums.USER_IS):
            self.selectUserAs(userData.get(DataEnums.USER_IS))
        if userData.get(DataEnums.USER_GROUP):
            self.userGroupDropdown.selectOption(userData.get(DataEnums.USER_GROUP))
        self.searchButton.click()

    def selectUserAs(self, userType: str):
        PrintMessage(f"Selecting User is : '{userType}'", inStepMessage=True)
        match userType:
            case PageEnums.END_CUSTOMER:
                self.endCustomerRadioButton.click()
            case PageEnums.ADVISER_USER:
                self.adviserUserRadioButton.click()
            case PageEnums.STAFF_USER:
                self.staffUserButton.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def emailAddressLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Email address:')]")

    @property
    def firstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'First Name:')]//parent::div//div//input")

    @property
    def lastNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Last name:')]//parent::div//div//input")

    @property
    def userIdEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'User ID:')]//parent::div//div//input")

    @property
    def emailAddressEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Email address:')]//parent::div//div//input")

    @property
    def adviserUserRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'an Adviser user')]")

    @property
    def endCustomerRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'an end customer')]")

    @property
    def staffUserButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'a Staff user')]")

    @property
    def companyDropdown(self):
        locator = "//label[contains(text(),'Company:')]//parent::div//select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def userGroupLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'User Group')]")

    @property
    def userGroupDropdown(self):
        locator = "//label[contains(text(),'User Group')]//parent::div//select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Search')]")

    @property
    def findWebsiteUserTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = FindWebsiteUsersTableRow
        return table
