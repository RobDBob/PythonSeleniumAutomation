from selenium.webdriver.common.by import By
from TestPages.Admin.ChangeOfAdviserConfirmPage import ChangeOfAdviserConfirmPage
from TestPages.ClientsPage import ClientsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class ChangeOfAdviserPage(ClientsPage):
    def wait(self):
        self.pageTitle.waitForText("Change of Adviser")

    def navigateToChangeOfAdviserConfirmPage(self):
        self.continueButton.click()
        return ChangeOfAdviserConfirmPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "searchClAccountId")

    @property
    def continueButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, 'ContentPlaceHolder_continueButton')
