from selenium.webdriver.common.by import By
from TestPages import LongPageEnums
from TestPages.Admin.RebalanceWizardBasePage import RebalanceWizardBasePage
from TestPages.Admin.ReviewRebalancingOrdersWizardPage import ReviewRebalancingOrdersWizardPage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.RebalanceTableRow import RebalanceProductsTableRow


class RebalanceWizardPage(RebalanceWizardBasePage):
    def wait(self):
        self.reviewTheRecommendedRebalancingTransactionsBelowLabel.waitForText(LongPageEnums.REVIEW_RECOMMENDED_REBALANCING)

    def navigateToReviewRebalancingOrdersPage(self):
        self.nextStepButton.click()
        return ReviewRebalancingOrdersWizardPage(self.webdriver)

    def getListOfTransactionTargetElementsForSpecificProduct(self, product) -> list[BaseTestObject]:
        """
        This method is created as part of a work around due to complex implementation of Rebalance Table
        This method returns the list of Transaction Target field elements for a specific product
        """
        elements = self.webdriver.find_elements(By.XPATH, f"//input[@class='target-input medium' and contains(@id,'{product}')]")
        return [BaseTestObject(self.webdriver, self.webdriver, element) for element in elements]

    # TODO: Rebalance Investment table need to be implemented in detail if more test scripts demand validation in Rebalance Table ,
    # currently the above work around is created to satisfy the requirement for TC C1541431

    @property
    def reviewTheRecommendedRebalancingTransactionsBelowLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Review the recommended rebalancing transactions below')]")

    @property
    def rebalanceProductsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table numeric-table data-heavy-table table-target-rebalance']")
        table.rowType = RebalanceProductsTableRow
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@class, 'body-split')]")
        table.rowLocator = (By.XPATH, ".//tr[@class='row-split']")
        return table
