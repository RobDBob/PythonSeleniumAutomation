from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.Admin.AuthoriseProcessesPage import AuthoriseProcessesPage
from TestPages.Admin.CashStockMovementPage import CashStockMovementPage
from TestPages.Admin.FindWebsiteUsersPage import FindWebsiteUsersPage
from TestPages.Menu import MenuConstants
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class AdminPage(PlatformPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.CLASS_NAME, 'admin-cards'))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def navigateToFindWebsiteUser(self):
        self.findUserButton.click()
        return FindWebsiteUsersPage(self.webdriver)

    def navigateToLogIssue(self):
        from TestPages.Admin.LogIssuePage import IssueManagementLogIssuePage
        self.logIssueButton.click()
        return IssueManagementLogIssuePage(self.webdriver)

    def navigateToManageIssues(self):
        from TestPages.Admin.ManageIssueLogPage import IssueManagementManageIssueLogPage
        self.manageIssuesButton.click()
        return IssueManagementManageIssueLogPage(self.webdriver)

    def navigateToProjectSummaryPage(self):
        from TestPages.Admin.ProjectSummaryPage import IssueManagementProjectSummaryPage
        self.viewProjectsButton.click()
        return IssueManagementProjectSummaryPage(self.webdriver)

    def navigateToAddProject(self):
        from TestPages.Admin.AddProjectPage import IssueManagementAddProjectPage
        self.addProjectButton.click()
        return IssueManagementAddProjectPage(self.webdriver)

    def navigateToAuthorisingBankAccounts(self):
        from TestPages.Admin.AuthoriseBankAccountsPage import AuthoriseBankAccountsPage
        self.authorisingBankAccountsButton.click()
        return AuthoriseBankAccountsPage(self.webdriver)

    def navigateToAuthoriseDocumentations(self):
        from TestPages.Admin.AuthoriseDocumentationPage import AuthoriseDocumentationPage
        self.authoriseDocumentationsButton.click()
        return AuthoriseDocumentationPage(self.webdriver)

    def navigateToErrorCorrectionRequest(self):
        from TestPages.Admin.RequestCorrection.RequestCorrectionPage import RequestCorrectionPage
        self.errorCorrectionRequestButton.click()
        return RequestCorrectionPage(self.webdriver)

    def navigateToErrorCorrectionAuthorise(self):
        from TestPages.Admin.RequestCorrection.AuthoriseCorrectionPage import AuthoriseCorrectionPage
        self.errorCorrectionAuthoriseButton.click()
        return AuthoriseCorrectionPage(self.webdriver)

    def navigateToCashStockMovement(self):
        self.voidAndRepairButton.click()
        return CashStockMovementPage(self.webdriver)

    def navigateToManualCashAdjustmentRequest(self):
        from TestPages.Admin.ManualCashAdjustmentRequestPage import ManualCashAdjustmentRequestPage
        self.manualCashAdjustmentRequestButton.click()
        return ManualCashAdjustmentRequestPage(self.webdriver)

    def navigateToManualCashAdjustmentAuthorise(self):
        from TestPages.Admin.ManualCashAdjustmentAuthorisePage import ManualCashAdjustmentAuthorisePage
        self.manualCashAdjustmentAuthoriseButton.click()
        return ManualCashAdjustmentAuthorisePage(self.webdriver)

    def navigateToAuthoriseWithdrawals(self):
        from TestPages.Admin.AuthoriseWithdrawalsPage import AuthoriseWithdrawalsPage
        self.authoriseWithdrawalsButton.click()
        return AuthoriseWithdrawalsPage(self.webdriver)

    def navigateToReports(self):
        from TestPages.Admin.ReportsPage import ReportsPage
        self.reportsButton.click()
        return ReportsPage(self.webdriver)

    def authoriseAccountRestrictionProcess(self, accountToAuthorise):
        authorisationPage: AuthoriseProcessesPage = self.openMainMenu().selectMenuItem(MenuConstants.AuthorisationsAndCorrections,
                                                                                       MenuConstants.Authorisation,
                                                                                       MenuConstants.AuthoriseProcesses)
        authorisationPage.authoriseAccountRestrictionUpdateProcesses(accountToAuthorise)

    @property
    def manageIssuesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Manage issues']")

    @property
    def findUserButton(self):
        return Button(self.webdriver, self.webdriver, By.CSS_SELECTOR, 'a[href="/Admin/Users/FindUsers.aspx"')

    @property
    def moreAdminActivityLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='More admin activity']")

    @property
    def moreAdminActivityContentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='All other admin activities can be accessed using the Menu.']")

    @property
    def issueManagementLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Issue management']")

    @property
    def logIssueButton(self):
        return Button(self.webdriver, self.webdriver, By.CSS_SELECTOR, 'a[href="/issues/logissue.aspx"')

    @property
    def viewProjectsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View projects']")

    @property
    def addProjectButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Add project']")

    @property
    def authorisingBankAccountsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Authorising bank accounts']")

    @property
    def errorCorrectionRequestButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Error correction: request']")

    @property
    def authoriseDocumentationsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Authorise documentations']")

    @property
    def errorCorrectionAuthoriseButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Error correction: authorise']")

    @property
    def voidAndRepairButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Void and repair']")

    @property
    def manualCashAdjustmentRequestButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Manual cash adjustment: request')]")

    @property
    def manualCashAdjustmentAuthoriseButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Manual cash adjustment: authorise')]")

    @property
    def authoriseWithdrawalsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Authorise withdrawals')]")

    @property
    def reportsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'Reports')]")
