from selenium.webdriver.common.by import By
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from TestPages.BasePage import BasePage
from TestPages.BrewinAdvisorPage import BrewinAdvisorPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField


class BrewinLoginPage(BasePage):
    @property
    def inputUserName(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "txtusername")

    @property
    def inputUserPassword(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "txtpassword")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "btnLogin")

    def navigate(self):
        url = self.testContext.getSetting(ConfigOptions.BREWIN_SITE_URL)
        self.webdriver.get(url)

    def wait(self):
        return

    def performLogin(self, userName, password):
        self.inputUserName.send_keys(userName)
        self.inputUserPassword.send_keys(password)
        self.submitButton.click()
        return BrewinAdvisorPage(self.webdriver)
