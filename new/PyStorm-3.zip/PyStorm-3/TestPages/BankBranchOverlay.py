from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class BankBranchOverlay(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.BankBranch)

    def getEditField(self, labelText):
        return EditField(self.webdriver, self.webdriver, By.XPATH, f"//label[text()='{labelText}']//ancestor::div[contains(@class,'form-group')]//input")

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[@id]")

    @property
    def bankNameEdit(self):
        return self.getEditField("Bank name")

    @property
    def addressLine1Edit(self):
        return self.getEditField("Address Line 1")

    @property
    def addressLine2Edit(self):
        return self.getEditField("Address Line 2")

    @property
    def addressLine3Edit(self):
        return self.getEditField("Address Line 3")

    @property
    def postCodeEdit(self):
        return self.getEditField("Address Line 3")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def continueButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Continue']")
