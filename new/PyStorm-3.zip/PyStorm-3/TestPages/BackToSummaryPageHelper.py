from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button


class BackToSummaryPageHelper(BasePage):
    def navigateBackToSummary(self, retry=False):
        from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage

        # attempt to work around blank screen errror
        self.wait()
        self.backToSummaryButton.jsClick()

        try:
            accountSummary = AccountSummaryTabPage(self.webdriver)
            accountSummary.wait()
        except TimeoutException:
            if not retry:
                PrintMessage("BLANK SCREEN ERROR: Go back to summary action!")
                self.webdriver.back()
                self.navigateBackToSummary(retry=True)
            raise
        return accountSummary

    @property
    def backToSummaryButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Back to summary']")
