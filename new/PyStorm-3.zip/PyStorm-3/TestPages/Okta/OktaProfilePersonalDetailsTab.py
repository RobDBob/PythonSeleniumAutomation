from selenium.webdriver.common.by import By
from TestPages.Okta.OktaProfileBasePage import OktaProfileBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class OktaProfilePersonalDetailsTab(OktaProfileBasePage):
    def wait(self):
        super().wait()
        self.waitForTabButtonToBeActive(self.personalDetailsTabButton)

    @property
    def accountHolderLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account holder']")

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Date of birth']")

    @property
    def nationalInsuranceNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='National insurance number']")

    @property
    def residentialAddressLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Residential address']")

    @property
    def correspondenceAddressLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Correspondence address']")

    @property
    def preferredEmailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Preferred email']")

    @property
    def contactUsLinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Contact us']")
