from selenium.webdriver.common.by import By
from TestPages.Okta.OktaProfileBasePage import OktaProfileBasePage
from TestPages.PageObjects.BaseObjects.Labels import Label


class OktaProfileAccountDetailsTab(OktaProfileBasePage):
    def wait(self):
        super().wait()
        self.waitForTabButtonToBeActive(self.accountDetailsTabButton)

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account name']")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account number']")

    @property
    def accountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account type']")

    @property
    def beneficiariesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Beneficiaries']")

    @property
    def adviserFirmLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Adviser firm']")

    @property
    def illustrationFolderIconLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='illustration folder']")

    @property
    def contactUsToChangeYourPersonalDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p/a[contains(text(), 'Contact us')]")

    @property
    def phoneIconLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[@class='phone']")
