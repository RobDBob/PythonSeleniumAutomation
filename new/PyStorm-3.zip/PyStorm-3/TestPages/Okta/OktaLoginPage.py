from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.BasePage import BasePage
from TestPages.Okta.OktaHomeForgotPasswordPage import OktaHomeForgotPasswordPage
from TestPages.Okta.OktaHomePage import OktaHomePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.WebDriver import ExpectedConditions as EC


class OktaLoginPage(BasePage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.ID, "okta-sign-in"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @retry(exceptions=TimeoutException, tries=2)
    def performLogin(self, username, password):
        self.emailEditField.enterValue(username)
        self.passwordEditField.enterValue(password)
        self.signInButton.jsClick()
        return OktaHomePage(self.webdriver)

    @retry(exceptions=TimeoutException, tries=5)
    def expandNeedHelpSingingSection(self):
        self.needHelpSigningInButton.click()

        waiter = EC.text_value_in_attribute_in_element(self.needHelpSigningInButton.element, "aria-expanded", "true")
        WebDriverWait(self.webdriver, 5).until(waiter)

    def navigateToForgotPasswordPage(self):
        self.expandNeedHelpSingingSection()
        self.forgotPasswordButton.click()
        return OktaHomeForgotPasswordPage(self.webdriver)

    @property
    def emailEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "okta-signin-username")

    @property
    def passwordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "okta-signin-password")

    @property
    def signInButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='o-form-button-bar']")

    @property
    def needHelpSigningInButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@data-se='needhelp']")

    @property
    def forgotPasswordButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@data-se='forgot-password']")
