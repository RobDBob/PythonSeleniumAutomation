from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class OktaProfileBasePage(OktaHomeBasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.YOUR_PROFILE)

    def waitForTabButtonToBeActive(self, tabButton: Button):
        waiter = EC.text_value_in_attribute_in_element(tabButton.element, "aria-selected", "true")
        WebDriverWait(self.webdriver, 10).until(waiter)

    def navigateToSecurityTab(self):
        from TestPages.Okta.OktaProfileSecurityDetailsTab import OktaProfileSecurityDetailsTab
        self.securityDetailsTabButton.click()
        return OktaProfileSecurityDetailsTab(self.webdriver)

    def navigateToAccountDetailsTab(self):
        from TestPages.Okta.OktaProfileAccountDetailsTab import OktaProfileAccountDetailsTab
        self.accountDetailsTabButton.click()
        return OktaProfileAccountDetailsTab(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def personalDetailsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "personalDetails")

    @property
    def accountDetailsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "accountDetails")

    @property
    def securityDetailsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "securityDetails")
