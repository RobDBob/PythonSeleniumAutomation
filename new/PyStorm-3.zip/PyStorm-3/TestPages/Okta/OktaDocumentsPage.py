from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable


class OktaDocumentsPage(OktaHomeBasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.YOUR_DOCUMENTS)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def literatureAndGuideLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def viewTheLatestTermsAndConditionLinkLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//a[contains(@id,'LiteratureAndGuides_View_YourDocumentsPage')]")

    @property
    def documentTypeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Select document types to view']")

    @property
    def dateDropdown(self):
        dropDownListBox = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                          "//label[text()='Date']//parent::div//following-sibling::div/select", (By.TAG_NAME, 'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def documentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//caption[text()='Documents']//parent::table")
        table.headerCellLocator = (By.XPATH, ".//th[contains(@class, 'table') and contains(@class, 'sort')]")
        return table
