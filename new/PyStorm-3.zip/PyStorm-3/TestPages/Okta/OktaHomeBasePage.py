from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class OktaHomeBasePage(BasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.YOUR_PORTFOLIO)

    def navigateToOktaProfilePage(self):
        from TestPages.Okta.OktaProfilePersonalDetailsTab import OktaProfilePersonalDetailsTab
        self.profileButton.click()
        return OktaProfilePersonalDetailsTab(self.webdriver)

    def navigateToOktaDocumentsPage(self):
        from TestPages.Okta.OktaDocumentsPage import OktaDocumentsPage
        self.documentsButton.click()
        return OktaDocumentsPage(self.webdriver)

    def navigateToOktaHelpPage(self):
        from TestPages.Okta.OktaHelpPage import OktaHelpPage
        self.helpButton.click()
        return OktaHelpPage(self.webdriver)

    @property
    def aberdeenLogoButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='layout-secured-logo']")

    @property
    def homeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='home']")

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def logoutButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Logout_MainNavigation")

    @property
    def lastLoginValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Last login:']//following-sibling::p")

    @property
    def profileButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Profile_MainNavigation")

    @property
    def contactUsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='contact-us']")

    @property
    def cookiePolicyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cookie policy']")

    @property
    def privacyPolicyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Privacy policy']")

    @property
    def legalInformationButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Legal information']")

    @property
    def accessibilityButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Accessibility']")

    @property
    def documentsButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Documents_MainNavigation")

    @property
    def helpButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Help_MainNavigation")

    @property
    def portFolioValueTodayLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Portfolio value today']")

    @property
    def changeInValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Change in value £']")

    @property
    def returnPercentageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Return %']")
