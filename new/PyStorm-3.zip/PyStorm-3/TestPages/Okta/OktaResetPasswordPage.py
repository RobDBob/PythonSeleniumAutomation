from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.Driver.PyStormDriver import PyStormDriver
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class OktaResetPasswordPage(BasePage):
    def __init__(self, webdriver: PyStormDriver, urlToNavigate: str):
        webdriver.get(urlToNavigate)
        super().__init__(webdriver)

    def wait(self):
        self.passwordRequirementsLabel.waitForText(PageEnums.PASSWORD_REQUIREMENTS)

    def setNewPassword(self, newPassword):
        self.newPasswordEditField.send_keys(newPassword)
        self.repeatPasswordEditField.send_keys(newPassword)
        self.resetPasswordButton.click()

        waiter = EC.visibility_of_element_located((By.XPATH, "//h1[@data-se='dashboard-my-apps-title']"))
        WebDriverWait(self.webdriver, 60).until(waiter)

    @property
    def passwordRequirementsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='password-requirements--header']")

    @property
    def newPasswordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@name='newPassword']")

    @property
    def repeatPasswordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@name='confirmPassword']")

    @property
    def resetPasswordButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@type='submit']")
