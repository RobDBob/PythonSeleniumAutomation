from retry import retry
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Support.NewTabPage import NewTabPage
from TestPages.WebDriver import ExpectedConditions as EC


class OktaHelpPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.WRAP_HELP)

    @retry(exceptions=TimeoutException, delay=2, tries=5)
    def checkIfCookiesBannerExistAndAcceptAll(self):
        try:
            # Wait up to 10 seconds for the banner to appear
            waitCondition = EC.presence_of_element_located((By.XPATH, "//div[contains(@id,'banner')]"))
            WebDriverWait(self.webdriver, self.SPINNER_TIME_OUT).until(waitCondition)

            acceptAllButton = self.webdriver.find_element(By.XPATH, "//button[text()='Accept All']")
            acceptAllButton.click()
        except (TimeoutException, NoSuchElementException):
            PrintMessage("Cookies banner or Accept All button not found, skipping acceptance.", inStepMessage=True)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def pageSubTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1//following-sibling::p")

    @property
    def lookingForHelpLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Looking for help')]")

    @property
    def footnoteLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Copyright © Aberdeen Group plc')]")

    @property
    def websiteProviderDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'Website provider details')]")

    @property
    def sidebarSectionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(@class,'sidebar-wrapper')]")
