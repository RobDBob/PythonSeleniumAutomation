from selenium.webdriver.common.by import By
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.OktaInvestmentHoldingsRow import OktaInvestmentHoldingsRow


class OktaPerformanceTab(OktaHomeBasePage):
    def wait(self):
        super().wait()
        self.oktaPerformanceTable.waitForElement()

    @property
    def chooseAccountViewDropdownListBox(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Account view']/../..//select[@class='form-input']",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def dateDropdownListBox(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Date']/../..//select[@class='form-input']",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def oktaPerformanceTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table table-transposed mt-20 mb-0']")
        table.rowType = OktaInvestmentHoldingsRow
        return table

    @property
    def columnsExplainedButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Columns explained']")

    @property
    def exportButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='export-btn']")
