from selenium.webdriver.common.by import By
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.OktaInvestmentHoldingsRow import OktaInvestmentHoldingsRow


class OktaInvestmentsTab(OktaHomeBasePage):
    def wait(self):
        super().wait()
        self.oktaInvestmentsTable.waitForElement()

    @property
    def chooseAccountViewDropdownListBox(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Account view']/../..//select[@class='form-input']",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def asAtDateDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='As at date']/..//following-sibling::div//input[@class='form-input']")

    @property
    def productViewLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Product view']")

    @property
    def assetViewLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Asset view']")

    @property
    def productAndAssetViewSwitchToggleButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='controls-checkbox']")

    @property
    def oktaInvestmentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table-expandable-new mt-20']")
        table.rowType = OktaInvestmentHoldingsRow
        return table

    @property
    def columnsExplainedButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Columns explained']")

    @property
    def exportButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='export-btn']")
