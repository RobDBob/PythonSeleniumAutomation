from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Support.NewTabPage import NewTabPage
from TestPages.WebDriver import ExpectedConditions as EC


class OktaEndUserSettingsPage(NewTabPage):
    def wait(self):
        iFrameElement = EC.presence_of_element_located((By.XPATH, "//iframe[@title='Settings frame']"))
        WebDriverWait(self.webdriver, 20).until(iFrameElement)

        self.webdriver.switch_to.frame(0)
        self.pageTitleLabel.waitForText(PageEnums.ACCOUNT)

    def editPersonalInformation(self, **kwargs):
        self.personalInformationEditButton.click()

        if kwargs.get(DataEnums.NEW_PRIMARY_EMAIL_ADDRESS):
            PrintMessage("OKTA > Security > Personal Information > change email to new", inStepMessage=True)
            self.primaryEmailAddressEditField.enterValue(kwargs.get(DataEnums.NEW_PRIMARY_EMAIL_ADDRESS))

        self.savePersonalInformationEditButton.click()
        self.personalInformationEditButton.waitForElement()

    def changePasswordAndConfirm(self, oldPassword, newPassword):
        PrintMessage("OKTA > Security > change password to new", inStepMessage=True)
        self.oldPasswordEditField.enterValue(oldPassword)
        self.newPasswordEditField.enterValue(newPassword)
        self.confirmPasswordEditField.enterValue(newPassword)
        self.changePasswordButton.click()

        passwordChangeConfirmation = EC.presence_of_element_located((By.XPATH, "//p[contains(@class, 'infobox-success') and @style='display: block;']"))
        WebDriverWait(self.webdriver, 20).until(passwordChangeConfirmation)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@id='user-profile']//h1")

    @property
    def personalInformationEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='person_info.edit_link']")

    @property
    def primaryEmailAddressEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='person_info.email']")

    @property
    def savePersonalInformationEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='person_info.button.submit']")

    @property
    def oldPasswordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='change_password.oldPassword']")

    @property
    def newPasswordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='change_password.newPassword']")

    @property
    def confirmPasswordEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='change_password.verifyPassword']")

    @property
    def changePasswordButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='change_password.button.submit']")
