from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label


class OktaHomeForgotPasswordPage(BasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.RESET_PASSWORD)

    @retry(exceptions=TimeoutException, tries=2)
    def requestPasswordReset(self, emailToRestorePassword):
        PrintMessage(f"Request password reset for login email: '{emailToRestorePassword}'", inStepMessage=True)
        self.emailEditField.enterValue(emailToRestorePassword)
        self.emailSentLabel.waitForText(PageEnums.EMAIL_SENT)
        self.emailSentMessageLabel.waitForText(emailToRestorePassword)
        self.backToSignInButton.click()

        from TestPages.Okta.OktaLoginPage import OktaLoginPage
        return OktaLoginPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def emailEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "account-recovery-username")

    @property
    def resetViaEmailButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@data-se='email-button']")

    @property
    def emailSentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[@data-se='o-form-head']")

    @property
    def emailSentMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@data-se='o-form-explain']")

    @property
    def backToSignInButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@data-se='back-button']")
