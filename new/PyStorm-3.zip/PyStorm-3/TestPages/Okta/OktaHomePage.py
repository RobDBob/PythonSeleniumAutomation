from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.Okta.OktaPerformanceTab import OktaPerformanceTab
from TestPages.Okta.OktaTransactionHistoryTab import OktaTransactionHistoryTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable


class OktaHomePage(OktaHomeBasePage):
    def wait(self):
        super().wait()
        self.valuationSummaryLabel.waitForText(PageEnums.VALUATION_SUMMARY)

    def navigateToInvestmentsTab(self):
        from TestPages.Okta.OktaInvestmentsTab import OktaInvestmentsTab
        self.investmentsTabButton.click()
        return OktaInvestmentsTab(self.webdriver)

    def navigateToInsightsTab(self):
        from TestPages.Okta.OktaInsightsTab import OktaInsightsTab
        self.insightsTabButton.click()
        return OktaInsightsTab(self.webdriver)

    def navigateToTransactionHistoryTab(self):
        self.transactionHistoryTabButton.click()
        return OktaTransactionHistoryTab(self.webdriver)

    def navigateToPerformanceTab(self):
        self.performanceTabButton.click()
        return OktaPerformanceTab(self.webdriver)

    @property
    def summaryTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Summary_TabNavigation")

    @property
    def investmentsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Investments_TabNavigation")

    @property
    def performanceTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Performance_TabNavigation")

    @property
    def insightsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "Insights_TabNavigation")

    @property
    def transactionHistoryTabButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "TransactionHistory_TabNavigation")

    @property
    def valuationSummaryLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Valuation summary']")

    @property
    def valuationSummaryTable(self):
        return GenericTable(self.webdriver, self.webdriver, By.XPATH, "//caption[text()='Valuation summary']//parent::table")

    @property
    def valuationSummaryChartButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h2[text()='Valuation summary']//parent::div//following-sibling::div//div[@class='valuation-summary-chart']")

    @property
    def productDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Product details']")

    @property
    def productDetailsLinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(@id,'ProductDetails_SummaryTab')]")

    @property
    def productDetailsHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(@class,'card-icon product-icon')]//following-sibling::p[contains(@class,'is-heading')]")
