from selenium.webdriver.common.by import By
from TestPages.Okta.OktaEndUserSettingsPage import OktaEndUserSettingsPage
from TestPages.Okta.OktaProfilePersonalDetailsTab import OktaProfileBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class OktaProfileSecurityDetailsTab(OktaProfileBasePage):
    def wait(self):
        super().wait()
        self.waitForTabButtonToBeActive(self.securityDetailsTabButton)

    def navigateToOktaEndUserSettingsPageViaChangePasswordButton(self):
        self.changePasswordButton.click()
        return OktaEndUserSettingsPage(self.webdriver)

    @property
    def changePasswordButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Change password']")

    @property
    def securityDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Security details']")

    @property
    def youCanChangeYourPasswordLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Security details']//following-sibling::p")
