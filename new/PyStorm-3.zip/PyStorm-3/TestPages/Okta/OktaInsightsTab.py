from selenium.webdriver.common.by import By
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.OktaInsightsAssetClassAllocationRow import OktaInsightsAssetClassAllocationRow
from TestPages.PageObjects.BaseObjects.Table.Rows.OktaInsightsGeographicAllocationRow import OktaInsightsGeographicAllocationRow


class OktaInsightsTab(OktaHomeBasePage):
    def wait(self):
        super().wait()
        self.oktaGeographicAllocationTable.waitForElement()

    @property
    def chooseAccountViewDropdownListBox(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Account view']/parent::div/following-sibling::div/select[@class='form-input']",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def asAtDateDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='As at date']/parent::div/following-sibling::div//input[@class='form-input']")

    @property
    def geographicAllocationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Geographic allocation']")

    @property
    def oktaGeographicAllocationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table table-transposed transposed-mb text-size-16']")
        table.rowType = OktaInsightsGeographicAllocationRow
        return table

    @property
    def viewFullDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='View full details']")

    @property
    def assetClassAllocationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Asset class allocation']")

    @property
    def assetClassAllocationChartLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='valuation-summary-chart']")

    @property
    def assetClassAllocationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table grey table-transposed text-size-16']")
        table.rowType = OktaInsightsAssetClassAllocationRow
        return table

    @property
    def sectorAllocationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Sector allocation']")

    @property
    def sectorAllocationChartLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='sector-chart-wrapper']")
