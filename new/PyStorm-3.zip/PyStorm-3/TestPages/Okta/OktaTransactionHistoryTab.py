from selenium.webdriver.common.by import By
from TestPages.Okta.OktaHomeBasePage import OktaHomeBasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable


class OktaTransactionHistoryTab(OktaHomeBasePage):
    def wait(self):
        super().wait()
        self.oktaTransactionTable.waitForElement()

    @property
    def cashButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='Cash_TransactionHistoryTab']")

    @property
    def investmentsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='Investments_TransactionHistoryTab']")

    @property
    def accountViewDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account view']//parent::div//following-sibling::div//select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def dateDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']//parent::div//following-sibling::div//select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def transactionTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Transaction type']//parent::div//following-sibling::div//select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def oktaTransactionTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='table table-transposed mt-20']")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def exportButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='export-btn']")
