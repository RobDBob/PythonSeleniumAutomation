from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.NotificationsPage import NotificationsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class DashboardPage(PlatformPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.ID, "Firm"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def verifyPresenceOfDashboardTabs(self, expectedTabs):
        PrintMessage(f"Attempting to locate dashboard tab {expectedTabs}...", inStepMessage=True)
        for expectedTab in expectedTabs:
            valueWaiter = EC.text_to_be_present_in_any_of_elements((By.CLASS_NAME, 'item'), expectedTab)
            WebDriverWait(self.webdriver, 60).until(valueWaiter)
        PrintMessage(f"Verified presence of '{expectedTabs}'", inStepMessage=True)

    def verifyPresenceOfDashboardSearchOptions(self, searchOptions):
        PrintMessage("Attempting to locate search options in dashboard tab {searchOptions}...", inStepMessage=True)
        for searchOption in searchOptions:
            valueWaiter = EC.text_to_be_present_in_any_of_elements((By.CLASS_NAME, 'anim-navigation-wrapper'), searchOption)
            WebDriverWait(self.webdriver, 60).until(valueWaiter)
        PrintMessage(f"Verified presence of '{searchOptions}'")

    def verifyPresenceOfDashboardSearchBoxes(self):
        PrintMessage('Attempting to locate search form objects...', inStepMessage=True)
        self.firmSearchEditField.exists()
        self.networkSearchEditField.exists()
        PrintMessage("Firm, Network and Icon located successfully.")

    def verifyHighlightedDashboardTabs(self, tabName):
        PrintMessage(f'Verifying highlighted tab in DashboardPage: {tabName} ...')
        waitCondition = EC.text_to_be_present_in_element((By.XPATH, "//button[@aria-selected='true' and text()='Workflow']"), tabName)
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def navigateToNotificationsTab(self):
        self.closeHintDialogIfPresent()
        self.notificationsButton.click()
        return NotificationsPage(self.webdriver)

    @property
    def networkSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "Network")

    @property
    def firmSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "Firm")

    @property
    def workflowButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Workflow')]")

    @property
    def notificationsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Notifications')]")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Search')]")

    @property
    def selectAdviserDropDownListbox(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@class='form-input']")

    @property
    def selectedDefaultWorkflowTab(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@aria-selected='true' and text()='Workflow']")

    @property
    def networkLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Network']")

    @property
    def firmLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Firm']")

    @property
    def assignAnAdviserLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Assign an adviser']")

    @property
    def assignAnAdviserSearchDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Assign an adviser']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown
