from selenium.webdriver.common.by import By
from CommonCode.TestHelpers.StringMethods import sortListOfDicts
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ESGPreferencesDetailedTableRow import ESGPreferencesDetailedTableRow
from TestPages.Support.NewTabPage import NewTabPage


class ESGPreferencesThemeDetailedPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.CLIENT_PREFERENCES)
        self.themeTitleLabel.waitForText(self.themeTitleLabel)
        self.esgPreferencesDetailedTable.waitForElement()

    def getAllPreferencesPageInvestmentDetails(self) -> list[dict]:
        allInvestments = []
        k: ESGPreferencesDetailedTableRow
        for k in self.esgPreferencesDetailedTable.dataRows:
            preferencesInvestmentDetail = {
                PageEnums.INVESTMENTS: k.assetLabel.text,
                PageEnums.ALLOCATION: k.weighingPercentageLabel.text,
                PageEnums.MARKET_VALUE2: k.valueLabel.text
            }
            allInvestments.append(preferencesInvestmentDetail)
        return sortListOfDicts(allInvestments, PageEnums.INVESTMENTS)

    @property
    def selectedAccountDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@data-testid='account-selector']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def themeTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='theme-title']")

    @property
    def whyThisMattersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Why this matters']")

    @property
    def keyFactsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Key Facts']")

    @property
    def dataCoverageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Data coverage']")

    @property
    def didYouKnowLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Did you know?']")

    @property
    def benchMarkLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[class='benchmark-percent']")

    @property
    def esgPreferencesDetailedTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='fnz-table table']")
        table.rowType = ESGPreferencesDetailedTableRow
        table.dataLocator = (By.XPATH, ".//tbody//parent::table")
        table.rowLocator = (By.XPATH, ".//tbody//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def navigateBackToPreferencesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//a[@href='/adviser/preferences/overview' and text()='Preferences']")
