from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ESG.ESGPreferencesThemeDetailedPage import ESGPreferencesThemeDetailedPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Support.NewTabPage import NewTabPage
from TestPages.WebDriver import ExpectedConditions as EC
from TestPages.WebDriver.ObjProduction import manufacture


class ESGPreferencesPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.CLIENT_PREFERENCES)

    def getThemeRagStatusList(self) -> list:
        """Returns a list of dictionaries, where each dictionary contains the theme and its RAG status (visible or not)."""

        waitCondition = EC.presence_of_element_located((By.XPATH, "//li[@class='theme-item selected']/div"))
        WebDriverWait(self.webdriver, 120).until(waitCondition)
        self.setPreferencesButton.click(jsClick=True)
        themesSelectedCheckboxes = [themeSelectedCheckbox.text for themeSelectedCheckbox in self.themeSelectedCheckboxes]
        self.setPreferencesApplyButton.click()
        themeListDisplayed = self.webdriver.find_elements(By.XPATH, "//li[@class='theme-item selected']/div")
        themeListInPreferencesPage = {
            k.find_element(By.XPATH, ".//div[@class='theme-title']").text: k.find_element(By.XPATH,
                                                                                          ".//div[@title='ESG insights relative to comparison index']").is_displayed()
            for k in themeListDisplayed}
        themeRagStatusList = []
        for theme in themesSelectedCheckboxes:
            if theme in themeListInPreferencesPage:
                ragStatus = themeListInPreferencesPage[theme]
                PrintMessage(f"Theme {theme} found in selected themes and its Rag Status is : {ragStatus}")
                themeRagStatusList.append({PageEnums.THEME: theme, PageEnums.RAG_STATUS: ragStatus})
            else:
                PrintMessage(f"Theme {theme} not found in selected themes.")
                themeRagStatusList.append({PageEnums.THEME: theme, PageEnums.RAG_STATUS: False})
        return themeRagStatusList

    def clickFindOutMoreButton(self, theme: str):
        """click on Find out more button based on theme preferences"""
        if theme == PageEnums.CORPORATE_GOVERNANCE_PREFERENCE:
            self.findOutMoreCorporateGovernanceButton.click()
        elif theme == PageEnums.RECYCLING_PREFERENCE:
            self.findOutMoreRecyclingButton.click()
        return ESGPreferencesThemeDetailedPage(self.webdriver)

    def getAllThemesDisplayedText(self):
        elements = manufacture(Label, self.webdriver, self.webdriver, By.XPATH, ".//div[@class='theme-title']")
        return [element.text for element in elements if element.text]

    def uncheckThemesCheckboxes(self):
        """Unchecks all currently selected theme checkboxes."""
        self.setPreferencesButton.click(jsClick=True)
        for checkbox in self.themeSelectedCheckboxes:
            checkbox.click()
        self.setPreferencesApplyButton.click()

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def setPreferencesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Set preferences']")

    @property
    def selectPreferencesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[@class='card-title no-border mb-0']")

    @property
    def esgThemesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='btn btn-expand-collapse']")

    @property
    def findOutMoreCorporateGovernanceButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(@href,'/adviser/preferences/corporate-governance')]")

    @property
    def findOutMoreRecyclingButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(@href,'/adviser/preferences/recycling')]")

    @property
    def setPreferencesApplyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='btn btn-primary']")

    @property
    def themeSelectedCheckboxes(self):
        return manufacture(CheckBox, self.webdriver, self.webdriver, By.XPATH,
                           "//input[@class='cb-input' and @checked]/following-sibling::span[@class='cb-label']")
