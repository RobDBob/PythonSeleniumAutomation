from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.WebDriver import ExpectedConditions as EC


class ESGOverviewSetPreferencesPopUpPage(BasePage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@class='card-title']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def exitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Exit']")

    @property
    def nextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Next']")

    @property
    def backButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Back']")

    @property
    def climateChangeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Climate change']")

    @property
    def waterSecurityLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Water security']")

    @property
    def wasteLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Waste']")

    @property
    def womenInLeadershipLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Women in leadership']")

    @property
    def deforestationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Deforestation']")

    @property
    def humanRightsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Human rights']")

    @property
    def corporateGovernanceLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Corporate governance']")

    @property
    def recyclingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Recycling']")

    @property
    def airPollutionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Air pollution']")

    @property
    def applyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Apply']")

    @property
    def climateChangeCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Climate change']/preceding-sibling::span[@class='cb-design']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox
