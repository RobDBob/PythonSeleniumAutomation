from retry import retry
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import sortListOfDicts
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ESGHoldingsDetailedTableRow import ESGHoldingsDetailedTableRow
from TestPages.Support.NewTabPage import NewTabPage


class ESGHoldingsPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.HOLDINGS)
        self.refreshUntilHoldingsPageDetailsLoaded()

    # Holdings page requires multiple refresh sometimes to get the required items loaded , this methods created as work around for this issue
    @retry(exceptions=(UIException), delay=3, tries=8)
    def refreshUntilHoldingsPageDetailsLoaded(self):
        if len(self.webdriver.find_elements(By.XPATH, "//label[text()='Select account level']")) == 0:
            self.webdriver.refresh()
            raise UIException("Holdings Page not loaded successfully")

    def getAllHoldingsPageInvestments(self) -> list:
        investments = [k.assetLabel.text for k in self.esgHoldingsDetailedTable.dataRows]
        PrintMessage(f"Found investments holdings: '{investments}'")
        return investments

    def getAllHoldingsPageInvestmentDetails(self) -> list[dict]:
        allInvestments = []
        k: ESGHoldingsDetailedTableRow
        for k in self.esgHoldingsDetailedTable.dataRows:
            holdingInvestmentDetail = {PageEnums.INVESTMENTS: k.assetLabel.text,
                                       PageEnums.ALLOCATION: k.percentageWeightingLabel.text,
                                       PageEnums.MARKET_VALUE2: k.valueGBPLabel.text}
            allInvestments.append(holdingInvestmentDetail)
        return sortListOfDicts(allInvestments, PageEnums.INVESTMENTS)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def selectAccountLevelDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@data-testid='account-selector']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def esgHoldingsDetailedTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='fnz-table table table-detailed']")
        table.rowType = ESGHoldingsDetailedTableRow
        table.dataLocator = (By.XPATH, ".//tbody//parent::table")
        table.rowLocator = (By.XPATH, ".//tbody//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
