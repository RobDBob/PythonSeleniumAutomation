from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ESGCompaniesDetailedTableRow import ESGCompaniesDetailedTableRow
from TestPages.Support.NewTabPage import NewTabPage


class ESGCompaniesPage(NewTabPage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.COMPANIES)
        self.esgCompaniesTable.waitForElement()

    def getTotalCompaniesDisplayedCount(self) -> int:
        companies = []
        k: ESGCompaniesDetailedTableRow
        for k in self.esgCompaniesTable.dataRows:
            companies.append(k.companiesLabel)
        return len(companies)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def selectAccountLevelDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@data-testid='account-selector']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def esgCompaniesTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='fnz-table table table-detailed']")
        table.rowType = ESGCompaniesDetailedTableRow
        table.dataLocator = (By.XPATH, ".//tbody")
        table.rowLocator = (By.XPATH, ".//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
