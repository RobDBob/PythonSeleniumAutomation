from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ESG.ESGCompaniesPage import ESGCompaniesPage
from TestPages.ESG.ESGHoldingsPage import ESGHoldingsPage
from TestPages.ESG.ESGOverviewSetPreferencesPopUpPage import ESGOverviewSetPreferencesPopUpPage
from TestPages.ESG.ESGPreferencesPage import ESGPreferencesPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Support.NewTabPage import NewTabPage


class ESGOverviewPage(NewTabPage):
    def wait(self):
        self.webdriver.refresh()
        self.pageTitleLabel.waitForText(PageEnums.RESPONSIBLE_SUSTAINABLE_INVESTING)

    def clickViewHoldingsButtonAndNavigateToHoldingsPage(self):
        self.viewHoldingsButton.click()
        return ESGHoldingsPage(self.webdriver)

    def clickViewCompaniesButtonAndNavigateToCompaniesPage(self):
        self.viewCompaniesButton.click()
        return ESGCompaniesPage(self.webdriver)

    def clickViewPreferencesAndNavigateToPreferencesPageButton(self):
        self.viewPreferencesButton.click()
        return ESGPreferencesPage(self.webdriver)

    def clickPreferencesTabAndNavigateToPreferencesPage(self):
        self.preferencesTabButton.click()
        return ESGPreferencesPage(self.webdriver)

    def navigateToSetPreferencesPopUpPage(self):
        self.setPreferencesButton.click(jsClick=True)
        return ESGOverviewSetPreferencesPopUpPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def whatIsESGTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='What is ESG?']")

    @property
    def importantInformationTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Important information']")

    @property
    def accountNameTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Account name:']")

    @property
    def esgThemesTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='ESG themes']")

    @property
    def clientPreferencesTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Client preferences']")

    @property
    def holdingsTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Holdings']")

    @property
    def viewHoldingsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View holdings']")

    @property
    def viewPreferencesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View preferences']")

    @property
    def preferencesTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Preferences']")

    @property
    def companiesTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'Companies')]")

    @property
    def viewCompaniesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[contains(text(),'View companies')]")

    @property
    def reportingTileLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Reporting']")

    @property
    def setPreferencesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Set preferences']")
