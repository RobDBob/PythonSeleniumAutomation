from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class NotificationsPage(PlatformPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//button[contains(text(),'Notifications')]"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def notificationsMessage(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='notification-message undefined']")

    @property
    def feesAndChargesBox(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Fees and Charges')]")

    @property
    def tradingAndTransferBox(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Trading and transfer')]")

    @property
    def moreSavedFiltersButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'More saved filters')]")

    @property
    def createFilterBox(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Create filter')]")

    @property
    def allNotificationsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'All notifications')]")

    @property
    def followUpButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Follow up')]")

    @property
    def notificationsExplainedLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Notifications explained')]")

    @property
    def configureNotificationsLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Configure notifications')]")

    @property
    def defaultNotificationsWarningMessage(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'There are currently no notifications.')]")
