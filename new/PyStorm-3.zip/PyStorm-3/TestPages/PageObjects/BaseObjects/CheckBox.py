import logging
from typing import Callable
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.Driver.PyStormElement import PyStormElement
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.StateCallbacks import defaultIsCheckedCB


class CheckBox(BaseTestObject):
    isCheckedFuncCB: Callable[['CheckBox', 'PyStormDriver'], bool]

    def __init__(self, webdriver, parentElement, *args):
        super().__init__(webdriver, parentElement, *args)
        self.isCheckedFuncCB = defaultIsCheckedCB

    @retry(exceptions=(TimeoutException, UIException), delay=2, tries=2)
    def waitForChecked(self, isChecked=True):
        """
        Waits and checks if element is checked.
        Cannot use Expected Conditions here as passing in property getter passes its value not the function itself

        :param self: Description
        :param isChecked: Description
        """
        PrintMessage(f"Checkbox Waiter --- waiting for state to be: '{isChecked}'",
                     inStepMessage=True,
                     level=logging.DEBUG)
        if self.isChecked == isChecked:
            return
        raise UIException(f"Failed to action checkbox, expected outcome isChecked:'{isChecked}'")

    @retry(exceptions=(TimeoutException, UIException), delay=5, tries=5, backoff=2)
    def selectCheckBoxAndWait(self, newState=True, jsClick=False):
        PrintMessage(f"selectCheckBoxAndWait new state: '{newState}', actual: '{self.isChecked}', jsClick: '{jsClick}'",
                     inStepMessage=True,
                     level=logging.DEBUG)
        if self.isChecked == newState:
            return

        self.click(jsClick=jsClick)
        self.waitForChecked(newState)

    @property
    def isChecked(self):
        """
        Used in radio buttons
        """
        # pylint: disable = too-many-function-args
        self.waitForElement()
        return self.isCheckedFuncCB(self, self.webdriver)

    @property
    def isInputDisabled(self):
        self.waitForElement()
        return bool(self.inputTypeElement.get_attribute('disabled'))

    @property
    def inputTypeElement(self) -> PyStormElement:
        """
        input type element for checkbox - it holds checked property
        Returns the input element that is either a preceding or following sibling of the current element.
        """
        return self.element.find_element(By.XPATH, ".//preceding-sibling::input | .//following-sibling::input")
