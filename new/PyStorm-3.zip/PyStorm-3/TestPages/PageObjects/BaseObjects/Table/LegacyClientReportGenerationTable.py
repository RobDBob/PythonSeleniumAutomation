from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class LegacyClientReportGenerationRow(GenericBaseRow):
    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//td[6]")

    @property
    def dateTimeStamp(self):
        """
        Code assumes date format in Request Time column unchanged and as: 17/05/2024 18:14:23
        """
        dateTimeFormat = "%d/%m/%Y %H:%M:%S"
        dateLabel = Label(self.webdriver, self.parentElement, By.XPATH, ".//td[5]")
        dateTimeStamp = datetime.strptime(dateLabel.text, dateTimeFormat)
        return dateTimeStamp

    @property
    def downloadButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, ".//td[8]")


class LegacyClientReportGenerationTable(GenericTable):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")
    headerCellLocator = (By.XPATH, ".//th")

    @property
    def header(self):
        headerElement = self.element.find_element(*self.headerLocator)
        return LegacyClientReportGenerationRow(self.webdriver, self.webdriver, headerElement)

    @property
    def dataRows(self) -> list[LegacyClientReportGenerationRow]:
        dataHolder = self.element.find_element(*self.dataLocator)
        elements = dataHolder.find_elements(*self.rowLocator)
        return [LegacyClientReportGenerationRow(self.webdriver, self.webdriver, k) for k in elements]
