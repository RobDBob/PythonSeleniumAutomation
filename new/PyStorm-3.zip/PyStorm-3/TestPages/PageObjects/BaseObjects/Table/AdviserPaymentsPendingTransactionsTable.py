import logging
from datetime import datetime
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserPendingTransactionsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def product(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def typeOfPayment(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def dateDue(self):
        dateFormat = "%d/%m/%Y"
        return datetime.strptime(self.getCell(index=3).text, dateFormat).date()

    @property
    def expectedAdviserPaymentLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.getCell(index=7), By.XPATH, "//a[text() ='Cancel']")


class AdviserPendingTransactionsTable(GenericTable):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")
    rowType = AdviserPendingTransactionsRow
    firstRowIsHeader = True

    def selectAdviserPayment(self, expectedAdviserPaymentLabel, typeOfPayment) -> AdviserPendingTransactionsRow:
        PrintMessage(f"Selecting expected adviser amount row : '{expectedAdviserPaymentLabel}'")
        matchingRows = [k for k in self.dataRows if expectedAdviserPaymentLabel in k.product.text and typeOfPayment in k.typeOfPayment.text]
        if matchingRows:
            PrintMessage(f"selectAdviserPayment > '{matchingRows[0].text}'", level=logging.DEBUG)
            return matchingRows[0]
        return None
