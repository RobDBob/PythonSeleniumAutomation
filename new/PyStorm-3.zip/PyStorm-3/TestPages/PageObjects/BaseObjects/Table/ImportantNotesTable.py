from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class ImportantNotesTable(BaseTestObject):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)
