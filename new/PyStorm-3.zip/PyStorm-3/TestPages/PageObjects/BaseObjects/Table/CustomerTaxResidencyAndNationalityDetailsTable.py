from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions


class CustomerTaxResidencyAndNationalityDetailsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def editButton(self):
        return Button(self.webdriver, self.getCell(8), By.XPATH, ".//button[@title='Edit']")

    @property
    def countryNameLabel(self):
        return Label(self.webdriver, self.getCell(0), By.XPATH, ".//span")

    @property
    def clientNationalityLabel(self):
        return Label(self.webdriver, self.getCell(1), By.XPATH, ".//span")

    @property
    def clientTaxResidentLabel(self):
        return Label(self.webdriver, self.getCell(2), By.XPATH, ".//span")

    @property
    def primaryCitizenshipLabel(self):
        return Label(self.webdriver, self.getCell(3), By.XPATH, ".//span")

    @property
    def nationalityIdentifierLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def nationalityIdentifierTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def taxIdentificationNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))

    @property
    def taxIdentificationNumberTypeLabel(self):
        return Label(self.webdriver, self.getCell(7), By.XPATH, ".//span")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.getCell(8), By.XPATH, ".//button[@title='Delete']")


class CustomerTaxResidencyAndNationalityDetailsTable(GenericTable):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[CustomerTaxResidencyAndNationalityDetailsRow]:
        """
        Either
        Rows can be found - rows exist, then wait for ID property to show up
        Rows cannot be found:
             - rows do not exist
             - rows failed to load in time
        """
        dataHolder = self.element.find_element(*self.dataLocator)

        valueWaiter = ExpectedConditions.attribute_present_in_one_of_elements(self.rowLocator, "id")
        WebDriverWait(dataHolder, 10).until(valueWaiter)

        return [CustomerTaxResidencyAndNationalityDetailsRow(self.webdriver, dataHolder, By.XPATH,
                                                             f".//tr[@id='{k.get_attribute('id')}']") for k in dataHolder.find_elements(*self.rowLocator)]
