from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.BulkClientsAccountTableRow import BulkClientsAccountTableRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class BulkRebalanceConfirmationTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[BulkClientsAccountTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [BulkClientsAccountTableRow(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]

    @property
    def listOfClients(self):
        return BulkClientsAccountTableRow(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table table-grid-view']//tbody//tr")
