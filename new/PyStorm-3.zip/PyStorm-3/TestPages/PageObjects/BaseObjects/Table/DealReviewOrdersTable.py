import operator
from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class DealReviewDataRow(GenericBaseRow):
    dateTimeFormat = "%d/%m/%Y %H:%M:%S"
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToCancelOrderPage(self):
        from TestPages.Trackingorders.CancelOrderPage import CancelOrderPage
        self.batchIDButton.click()
        return CancelOrderPage(self.webdriver)

    @property
    def wholeNumberLabel(self):
        """
        Whole text found is something similar to:   'Batchnumber xxxx  '  and so, value after string splitting is at 1th index
        [batchNUmber, orderNumber]
        """
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def orderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=3))

    @property
    def orderStatusLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=5))

    @property
    def currencyLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=6))

    @property
    def netConsidValue(self):
        return float(self.getCell(index=7).text)

    @property
    def dateCreated(self):
        return datetime.strptime(self.getCell(index=8).text, self.dateTimeFormat)

    @property
    def history(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//a[@class='inline-link' and text()='H']")

    @property
    def batchIDButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//a[contains(@href,'javascript:lnkEdit_Click')]")

    @property
    def batchNumberText(self):
        return self.wholeNumberLabel.text.split(".")[0]

    @property
    def orderIdText(self):
        return self.wholeNumberLabel.text.split(".")[1]

    @property
    def batchTotal(self):
        """
        Whole text found is something similar to: '  Batch total 100.00' and so, value after string splitting is at 4th index
        """
        batchElementLabel = Label(self.webdriver, self.element, By.XPATH, ".//following-sibling::tr[contains(@class,'sub-total')]")
        if batchElementLabel.text:
            pair = batchElementLabel.text.split(" ")
            if pair:
                return pair[4]
        return None


class DealReviewOrdersTable(GenericTable):
    rowType = DealReviewDataRow
    rowLocator = (By.XPATH, ".//tr[contains(@class, 'RowOut')]")
    headerCellLocator = (By.XPATH, ".//th")

    def getAllRowsWithBatchNumber(self, batchNumber):
        return self.getRows(propertyName="wholeNumberLabel",
                            text=batchNumber,
                            comparisonOperator=operator.contains)
