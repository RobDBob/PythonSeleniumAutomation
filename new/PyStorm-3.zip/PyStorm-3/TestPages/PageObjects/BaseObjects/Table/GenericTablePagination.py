from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox


class GenericTablePagination(DropdownListbox):
    def __init__(self, webdriver, parentElement, paginationLocator):
        if paginationLocator:
            super().__init__(webdriver, parentElement, *paginationLocator)
        self.checkAriaState = False
        self.optionsLocator = (By.TAG_NAME, 'option')

    def navigateToNextPage(self):
        """
        Clicks on the next page button.
        """
        PrintMessage(f"Current page is: '{self.selectedOption}'. Clicking on next page button.")
        try:
            nextPageNumber = self.getNextPageNumber()
            if nextPageNumber:
                self.selectOption(nextPageNumber)
            else:
                return False
        except UIException as e:
            PrintMessage(f"Failed to navigate to next page: {e}")
            return False
        return True

    def getNextPageNumber(self):
        """
        Returns the next page number.
        """
        if self.selectedOption:
            currentPageNumber = int(self.selectedOption)
            return str(currentPageNumber + 1)
        raise UIException("Current page number is not set.")

    def selectPage(self, pageNumber):
        """
        Selects the page number from the dropdown.
        """
        PrintMessage(f"Current page is: '{self.selectedOption}'.Selecting page number: '{pageNumber}'")
        self.selectOption(str(pageNumber))
