from datetime import datetime
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class ClientActivityTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")
    dateFormat = "%d/%m/%Y"

    def getData(self, index):
        allElements = self.element.find_elements(*self.CELL_LOCATOR)
        if len(allElements) > index:
            return allElements[index]
        return None

    @property
    def dateStartedDate(self):
        return datetime.strptime(Label(self.webdriver, self.parentElement, self.getCell(index=0)).text, self.dateFormat).date()

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def activityTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def referenceNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def adviserLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))

    @property
    def createdByLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=7))

    @property
    def lastUpdateDate(self):
        return datetime.strptime(Label(self.webdriver, self.parentElement, self.getCell(index=8)).text, self.dateFormat).date()

    @property
    def actionButton(self):
        return Button(self.webdriver, self.getCell(9), By.XPATH, ".//button[@title='Quick actions menu']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.getCell(10), By.XPATH, ".//button[@title='Delete']")


class ClientActivityTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    rowLocator = (By.XPATH, ".//tr[@id]")

    def getNewlyCreatedRow(self, timestamp):
        foundRows = [k for k in self.dataRows if k.lastUpdate >= timestamp.date()]
        if foundRows:
            PrintMessage(f"Found activity row current with last update date: '{foundRows[0].lastUpdate}'")
            return foundRows[0]
        PrintMessage(f"Failed to find result with current date-time: '{timestamp}', found other '{len(self.dataRows)}' items not matching criteria.")
        return None

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[ClientActivityTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        rows = self.element.find_elements(*self.rowLocator)
        return [ClientActivityTableRow(self.webdriver, self.element, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]
