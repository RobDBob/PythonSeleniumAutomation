from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class DetailsCorporateMemberRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToRemoveCorporateMembersPopUpPage(self):
        from TestPages.ClientsTabs.SearchResults.RemoveCorporateTrusteePopUpPage import RemoveCorporateTrusteePopUpPage
        self.removeButton.jsClick()
        return RemoveCorporateTrusteePopUpPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(0))

    @property
    def noResultsLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//div[contains(text(),'No results')]")

    @property
    def companyNameButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, ".//a[@class='hpyerlink']")

    @property
    def companyTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(2))

    @property
    def removeButton(self):
        return Button(self.webdriver, self.getCell(3), By.XPATH, ".//span[text()='Remove']")
