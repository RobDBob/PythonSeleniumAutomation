from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class MaintainManagerRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def dateStartedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def managerNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def createdByLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def authorisedByLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def lastUpdatedDateLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))
