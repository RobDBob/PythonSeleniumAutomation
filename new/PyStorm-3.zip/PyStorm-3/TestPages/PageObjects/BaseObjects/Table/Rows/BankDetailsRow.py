from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class BankDetailsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def accountReferenceLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(0))
