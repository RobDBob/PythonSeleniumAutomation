from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseFlagForApprovalActivitiesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[contains(@class, TableData)]")

    @property
    def requestIdLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def processLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def accountCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def restrictionReasonLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, self.getCell(index=6))
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        return checkbox

    @property
    def rejectCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, self.getCell(index=7))
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        return checkbox
