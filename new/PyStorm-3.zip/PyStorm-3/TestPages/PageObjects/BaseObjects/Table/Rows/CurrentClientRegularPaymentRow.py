from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CurrentClientRegularPaymentRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def subAccountLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(index=0))

    @property
    def methodLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(index=1))

    @property
    def instructionsLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(index=2))

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(index=3))

    @property
    def selectPaymentCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(index=4), By.XPATH, ".//span")
