from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB, isInputChildDisabledCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseCashManagementAdministrationChargeRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def productLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def PropositionLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def oldRateLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def newRateLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=4), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox

    @property
    def rejectCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=5), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox
