from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class PlatformChargeRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def lowerBandLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def upperBandLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def abrdnSIPPPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def sippercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def juniorSippPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def offshoreBondPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def onshoreBondPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(6))

    @property
    def cashIsaPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(7))

    @property
    def isaAndStocksPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(8))

    @property
    def personalPortfolioPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(9))

    @property
    def cashAccountPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(10))
