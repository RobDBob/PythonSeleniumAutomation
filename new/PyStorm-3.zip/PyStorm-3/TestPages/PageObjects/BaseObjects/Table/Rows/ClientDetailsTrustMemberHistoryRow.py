from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ClientDetailsTrustMemberHistoryRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def changeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(0))

    @property
    def updatedByLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(1))

    @property
    def authorisedByLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(3))

    @property
    def authorisedTimeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(4))
