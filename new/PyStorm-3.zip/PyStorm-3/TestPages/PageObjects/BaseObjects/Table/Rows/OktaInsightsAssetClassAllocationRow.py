from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class OktaInsightsAssetClassAllocationRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def assetClassLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def allocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))
