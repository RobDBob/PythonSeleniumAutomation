from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CurrentRegularPaymentInstructionsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToCancelFutureRegularPaymentPopupPage(self):
        from TestPages.ClientsTabs.SearchResults.FutureRegularPaymentPopupPage import FutureRegularPaymentPopupPage
        self.cancelButton.click()
        return FutureRegularPaymentPopupPage(self.webdriver)

    @property
    def payerLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def taxReliefLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def frequencyLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def paidFromLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def nextPaymentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def finalPaymentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(6))

    @property
    def indexationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(8))

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.getCell(8), By.XPATH, "//button[text()='Cancel']")
