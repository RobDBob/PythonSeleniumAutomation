from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB, isInputChildDisabledCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InstrumentAuthorisationRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def instrumentNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def instrumentDetailsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def modifedByLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def dateModifiedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=4), By.XPATH, ".//input[contains(@name,'authorise')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox

    @property
    def rejectCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=5), By.XPATH, ".//input[contains(@name,'reject')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox
