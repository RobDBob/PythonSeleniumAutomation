from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InvestmentSelectionFundAllocationRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[not(@style='display:none;')]")
    XPATH_SKIP_HIDDEN = "not(contains(@id, 'XXX')) and not(@type='hidden') and not(contains(@style, 'display: none;'))]"

    @property
    def fundNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def ppAllocationPercentageEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, f".//input[contains(@id, 'Personal_Portfolio') and {self.XPATH_SKIP_HIDDEN}")

    @property
    def sippAllocationPercentageEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, f".//input[contains(@id, 'SIPPWeighting') and {self.XPATH_SKIP_HIDDEN}")

    @property
    def onshoreBondAllocationPercentageEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, f".//input[contains(@id, 'Onshore_Bond') and {self.XPATH_SKIP_HIDDEN}")

    @property
    def offshoreBondAllocationPercentageEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, f".//input[contains(@id, 'Offshore_Bond') and {self.XPATH_SKIP_HIDDEN}")
