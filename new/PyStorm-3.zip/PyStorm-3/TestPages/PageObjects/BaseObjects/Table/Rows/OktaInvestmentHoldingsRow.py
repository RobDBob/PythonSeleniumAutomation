from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class OktaInvestmentHoldingsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[@class]")

    @property
    def investmentsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def allocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))

    @property
    def quantityLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=2))

    @property
    def unitCostLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=3))

    @property
    def unitPriceLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=4))

    @property
    def totalCostLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=5))

    @property
    def marketValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=6))

    @property
    def differenceLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=7))
