from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CompletedInstructionsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def payerLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def singlePaymentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def singleTaxReliefLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def regularPaymentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def regularTaxReliefLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def totalLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))
