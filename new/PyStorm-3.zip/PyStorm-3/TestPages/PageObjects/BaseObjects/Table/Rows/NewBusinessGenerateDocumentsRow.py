from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class NewBusinessGenerateDocumentsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[not(@style='display:none;')]")

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def statusLabel(self):
        return Button(self.webdriver, self.element, self.getCell(2))
