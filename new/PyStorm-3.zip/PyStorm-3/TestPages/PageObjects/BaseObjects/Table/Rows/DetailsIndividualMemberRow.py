from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class DetailsIndividualMemberRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToRemoveIndividualMembersPopUpPage(self):
        from TestPages.ClientsTabs.SearchResults.RemoveCorporateTrusteePopUpPage import RemoveCorporateTrusteePopUpPage
        self.removeIndividualMemberButton.jsClick()
        return RemoveCorporateTrusteePopUpPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def nameLinkButton(self):
        return Button(self.webdriver, self.getCell(2), By.XPATH, "//a[@class='hpyerlink']")

    @property
    def genderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def shareOfTrustLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def editRolesButton(self):
        return Button(self.webdriver, self.getCell(6), By.XPATH, ".//button[@title='Edit']")

    @property
    def removeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(7))

    @property
    def removeIndividualMemberButton(self):
        return Button(self.webdriver, self.getCell(7), By.XPATH, ".//span[text()='Remove']")

    @property
    def noResultsLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//div[contains(text(),'No results have been found for the entered criteria.')]")
