from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CurrentRegularWithdrawalInstructionsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def amountText(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0)).text

    @property
    def frequencyText(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1)).text

    @property
    def payerText(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2)).text

    @property
    def nextWithdrawal(self):
        dateFormat = "%d/%m/%Y"
        return datetime.strptime(self.getCell(index=3).text, dateFormat).date()
