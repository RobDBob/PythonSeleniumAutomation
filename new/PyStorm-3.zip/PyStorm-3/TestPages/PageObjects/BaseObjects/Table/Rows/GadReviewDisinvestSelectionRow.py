from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class GadReviewDisinvestSelectionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def investmentsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def existingAllocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def newAllocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))
