from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ESGPreferencesDetailedTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def assetLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def valueLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def weighingPercentageLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))
