from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AccountRestrictionConfigPaymentsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def suspendedActivityLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def flagForApprovalLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def paymentTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def suspendedActivityCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=1), By.XPATH, ".//span")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def flagForApprovalCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=2), By.XPATH, ".//span")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox
