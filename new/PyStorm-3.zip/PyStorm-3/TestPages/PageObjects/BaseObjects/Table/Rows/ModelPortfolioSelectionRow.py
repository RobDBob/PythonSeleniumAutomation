from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ModelPortfolioSelectionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//th[@colspan]")

    @property
    def newOnshorebondDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@id,'Onshore_Bond')]",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def newOffshorebondDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@id,'Offshore_Bond')]",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown
