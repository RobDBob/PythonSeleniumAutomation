from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserAccountSelectRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def accountLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def adviserNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def adviserCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def agencyCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def companyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def accountSelectCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(index=6), By.XPATH, "//div[@class='square-checkbox label-sr-only']")
