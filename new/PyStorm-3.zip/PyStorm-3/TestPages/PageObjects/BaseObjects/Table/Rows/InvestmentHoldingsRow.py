from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InvestmentHoldingsRow(GenericBaseRow):
    THOUSAND_SEPARATOR = ','
    CELL_LOCATOR = (By.XPATH, ".//td[@class]")
    HEADER_INDICES = {}

    def getDynamicIndex(self, columnName):
        return self.HEADER_INDICES.get(columnName)

    @property
    def investmentsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def allocationPercentageLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.ALLOCATION)))

    @property
    def targetAllocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.TARGET_ALLOCATION)))

    @property
    def fundCodeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.FUND_CODE)))

    @property
    def quantityLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.Quantity)))

    @property
    def locationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.LOCATION)))

    @property
    def unitCosLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.UNIT_COST)))

    @property
    def unitPriceLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.UNIT_PRICE)))

    @property
    def totalCostLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.TOTAL_COST)))

    @property
    def marketLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.MARKET_VALUE2)))

    @property
    def differenceLabel(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.DIFFERENCE)))

    @property
    def modelPortFolioExpandToggleButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//button[contains(@class, 'row-toggle')]")

    @property
    def investmentUnitPriceValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=3))

    @property
    def differenceValue(self):
        return Label(self.webdriver, self.element, self.getCell(self.getDynamicIndex(PageEnums.DIFFERENCE))).text

    @property
    def investmentTotalCostValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=5))
