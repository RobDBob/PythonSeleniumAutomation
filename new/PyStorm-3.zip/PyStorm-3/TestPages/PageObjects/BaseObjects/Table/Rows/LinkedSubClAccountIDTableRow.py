from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class LinkedSubClAccountIDTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[@class]")

    @property
    def consolidatedClAccountIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def linkedSubClAccountIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))

    @property
    def chooseCheckBox(self):
        return CheckBox(self.webdriver,
                        self.element,
                        By.XPATH,
                        ".//label[@class='controls-checkbox']/span[@class='label']")
