from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CompanyWizardFirmSearchResultRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def firmIDButton(self):
        return Button(self.webdriver, self.parentElement, self.getCell(0))

    @property
    def fcaTradingReferenceLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(3))

    @property
    def fcaTradingStatusLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(4))
