from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserFirmTermsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def termsIdButton(self):
        return Button(self.webdriver, self.element, self.getCell(0))

    @property
    def termsTypeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def fromDateLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def toDateLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def numbersOfCustomersLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))
