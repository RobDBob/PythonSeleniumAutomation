from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class OuterRingChargesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def initialAdministrationChargeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def investmentManagerChargeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def yearlyAdministrationChargeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def yearlyDrawdownChargeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))
