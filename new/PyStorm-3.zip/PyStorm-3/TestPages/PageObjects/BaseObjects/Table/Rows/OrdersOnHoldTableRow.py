from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class OrdersOnHoldTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def checkReleaseHoldCheckBoxEnabled(self):
        return self.releaseHoldCheckBox.element.is_enabled()

    @property
    def clAccountIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def releaseHoldCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(index=9), By.XPATH, ".//input")

    @property
    def cancelCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(index=10), By.XPATH, ".//input")
