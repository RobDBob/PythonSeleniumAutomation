from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB, isInputChildDisabledCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseBWAAuthorisationsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[contains(@class, TableData)]")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=9), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox

    @property
    def rejectCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=10), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox
