from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB, isInputChildDisabledCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdministerAccountsCreateAndEditLinksRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def removeCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=3), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox
