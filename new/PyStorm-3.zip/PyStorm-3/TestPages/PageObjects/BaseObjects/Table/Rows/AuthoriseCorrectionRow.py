from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseCorrectionRow(GenericBaseRow):
    @property
    def id(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def accountId(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def detailButton(self):
        return Button(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def authoriseCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, By.XPATH, ".//input[@class='authenticate']//ancestor::div[@class='square-checkbox label-sr-only']")

    @property
    def rejectCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, By.XPATH, ".//input[@class='reject']//ancestor::div[@class='square-checkbox label-sr-only']")
