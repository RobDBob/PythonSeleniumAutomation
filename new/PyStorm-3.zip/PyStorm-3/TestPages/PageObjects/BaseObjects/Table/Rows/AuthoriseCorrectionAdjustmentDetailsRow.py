from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseCorrectionAdjustmentDetailsRow(GenericBaseRow):
    @property
    def clientAccountIdLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def productTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def correctionTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def correctionDescriptionReasonLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def advisorChargeAdjustmentAmountLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def processingResultsLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))
