from selenium.webdriver.common.by import By
from TestPages.AddInterestParty.EditInterestedPartyPage import EditInterestedPartyPage
from TestPages.AddInterestParty.RemoveInterestedPartyPopupPage import RemoveInterestedPartyPopupPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.ClientDetails.PersonalDetailsPage import PersonalDetailsPage


class AddInterestedPartyRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToPersonalDetailsPage(self):
        self.editButton.click()
        return PersonalDetailsPage(self.parentElement)

    def navigateToEditInterestedPartyPage(self):
        self.editButton.click()
        return EditInterestedPartyPage(self.parentElement)

    def navigateToRemovePopUpPage(self, expectedInterestedPartyName):
        if self.nameLabel.text == expectedInterestedPartyName:
            self.removeButton.jsClick()
            return RemoveInterestedPartyPopupPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

        print(f"The expected name '{expectedInterestedPartyName}' is not present in the table.")
        return None

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def accountRoleLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def onlineAccessLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def editButton(self):
        cellElement = self.getCell(4)
        return Button(self.webdriver, cellElement, By.XPATH, ".//button[@title='Edit']")

    @property
    def removeButton(self):
        cellElement = self.getCell(5)
        return Button(self.webdriver, cellElement, By.XPATH, ".//button[@class='remove-button label-sr-only']//span")

    @property
    def noResultsFoundLabel(self):
        return Label(self.webdriver, self.getCell(index=0), By.XPATH, ".//div[contains(text(),'No results')]")

    @property
    def onlineAccessToggleButton(self):
        cellElement = self.getCell(3)
        return Button(self.webdriver, cellElement, By.XPATH, "//fieldset[@class='radio-toggle']")
