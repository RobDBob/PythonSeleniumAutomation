from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class EditBeneficiaryRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[@class='cell-left']")

    @property
    def typeLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(0))

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(1))

    @property
    def relationshipLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(2))

    @property
    def proportionLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(3))

    @property
    def lastUpdatedLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(4))

    @property
    def editButton(self):
        return Button(self.webdriver, self.webdriver, self.getCell(5))

    @property
    def removeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Delete']/preceding-sibling::span")
