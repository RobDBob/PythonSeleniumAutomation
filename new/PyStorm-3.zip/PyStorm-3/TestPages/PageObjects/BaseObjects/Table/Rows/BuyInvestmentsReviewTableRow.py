from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class BuyInvestmentsReviewTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def investmentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def buyValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def buyQuantityLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def limitPriceLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))
