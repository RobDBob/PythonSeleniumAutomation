from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseManagerRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def managerNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def managerDetailsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def modifiedByLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def dateModifiedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def authoriseLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def rejectLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))
