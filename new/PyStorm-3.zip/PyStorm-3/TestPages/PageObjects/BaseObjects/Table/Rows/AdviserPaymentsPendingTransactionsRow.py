from datetime import datetime
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserPaymentsPendingTransactionsRow(GenericBaseRow):
    @property
    def product(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def typeOfPayment(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def dateDue(self):
        dateFormat = "%d/%m/%Y"
        return datetime.strptime(self.getCell(index=3).text, dateFormat).date()

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.element, self.getCell(index=7))
