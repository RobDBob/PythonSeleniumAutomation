from selenium.webdriver.common.by import By
from TestPages.Admin.EditWebsiteUserPage import EditWebsiteUserPage
from TestPages.BatemanConfigSitePage import BatemanConfigSitePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class FindWebsiteUsersTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToBatemanConfigSite(self, webdriver) -> BatemanConfigSitePage:
        self.viewButton.click()
        return BatemanConfigSitePage(webdriver)

    def navigateToEditWebsiteUserPage(self, webdriver) -> EditWebsiteUserPage:
        self.userNameButton.jsClick()
        return EditWebsiteUserPage(webdriver)

    @property
    def viewButton(self):
        return Button(self.webdriver, self.getCell(4), By.XPATH, ".//a[text()='view']")

    @property
    def userNameButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, ".//a")
