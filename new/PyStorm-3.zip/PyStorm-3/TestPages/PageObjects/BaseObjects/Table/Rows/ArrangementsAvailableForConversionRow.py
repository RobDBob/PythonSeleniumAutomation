from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isInputChildCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ArrangementsAvailableForConversionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def arrangementIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def postRetirementArrangementValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def gadMaximumLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def preADayPortionLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def inheritedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def convertCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//label[@class='controls-checkbox']")
        checkbox.isCheckedFuncCB = isInputChildCheckedCB
        return checkbox
