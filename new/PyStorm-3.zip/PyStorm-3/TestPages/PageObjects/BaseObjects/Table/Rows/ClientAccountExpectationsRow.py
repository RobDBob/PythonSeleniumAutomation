from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ClientAccountExpectationsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def clAccountIdLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def accountHolderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def investmentNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def externalFundManagerLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))
