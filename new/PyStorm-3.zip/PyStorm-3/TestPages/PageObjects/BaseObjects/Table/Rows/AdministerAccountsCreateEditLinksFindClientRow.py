from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdministerAccountsCreateEditLinksFindClientRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def accountCodeHyperlinkButton(self):
        return Button(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def searchKeyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def productTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def clientNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def companyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def niNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))

    @property
    def accountDescLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=7))

    @property
    def adviserLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=8))
