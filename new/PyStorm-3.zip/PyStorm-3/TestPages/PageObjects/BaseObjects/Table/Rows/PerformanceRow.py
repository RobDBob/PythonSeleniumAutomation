from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class PerformanceRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def investmentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def openingValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))

    @property
    def buysLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=2))

    @property
    def sellsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=3))

    @property
    def releasedGainLossLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=4))

    @property
    def unreleasedGainLossLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=5))

    @property
    def incomeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=6))

    @property
    def gainLossLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=7))

    @property
    def returnPercentLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=8))

    @property
    def closingValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=9))
