from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.SearchResults.TrustRequiredOneBeneficiaryWarningPage import TrustRequiredOneBeneficiaryWarningPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdditionalBeneficiariesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToTrustRequiredOneBeneficiaryWarningPage(self):
        self.removeButton.jsClick()
        return TrustRequiredOneBeneficiaryWarningPage(self.webdriver)

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def noResultsFoundLabel(self):
        return Label(self.webdriver, self.getCell(index=0), By.XPATH, "//div[contains(text(),'No results')]")

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def genderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def shareOfTrustLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def removeButton(self):
        return Button(self.webdriver, self.getCell(6), By.XPATH, ".//span[text()='Remove']")

    @property
    def editButton(self):
        return Button(self.webdriver, self.getCell(7), By.XPATH, ".//button[@title='Edit']")
