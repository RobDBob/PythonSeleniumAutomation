from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AccountRestrictionConfigFeeAndChargesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def suspendedLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def feePostingLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def suspendedCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, By.XPATH, ".//input[@id='PostFee']//following-sibling::span")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox
