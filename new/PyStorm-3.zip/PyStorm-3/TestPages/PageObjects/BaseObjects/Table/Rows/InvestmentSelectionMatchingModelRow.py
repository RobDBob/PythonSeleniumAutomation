from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InvestmentSelectionMatchingModelRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def mpsCompanyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def mpsMpDescriptionLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def addButton(self):
        return Button(self.webdriver, self.getCell(index=6), By.XPATH, "./a")
