from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.SearchResults.DepositInformationPage import DepositInformationPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CashDepositSelectionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToDepositInformationPage(self):
        self.providerLinkButton.click()
        return DepositInformationPage(self.parentElement)

    @property
    def providerLinkButton(self):
        return Button(self.webdriver, self.getCell(0), By.XPATH, ".//a[@class='hyperlink']")

    @property
    def typeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def aerGrossLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def termOrNoticeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def minOpeningAmountLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def interestPaidLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def selectButton(self):
        return Button(self.webdriver, self.getCell(6), By.XPATH, ".//span[@class='label']")
