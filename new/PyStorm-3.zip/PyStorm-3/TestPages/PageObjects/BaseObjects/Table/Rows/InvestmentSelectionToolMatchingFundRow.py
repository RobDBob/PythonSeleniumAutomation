from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InvestmentSelectionToolMatchingFundRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def addButton(self):
        return Button(self.webdriver, self.getCell(index=13), By.XPATH, "//a[contains(@id,'addButtonOverview')]")

    @property
    def addFundButton(self):
        cellElement = self.getCell(14)
        return Button(self.webdriver, cellElement, By.XPATH, "//a[contains(text(),'Add')]")
