from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class DealReviewOrdersRow(GenericBaseRow):
    @property
    def batchIDButton(self):
        return Button(self.webdriver, self.element, By.XPATH, "//tbody[@class='body-split']//a[contains(@href,'javascript:lnkEdit_Click')]")
