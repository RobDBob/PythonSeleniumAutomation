from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.ProductWizards.InvestmentInformationPopUpPage import InvestmentInformationPopUpPage


class OffPlatformFundSelectionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def selectFundAndNavigateToInvestmentInformationPopUp(self):
        self.selectButton.click(jsClick=True)
        return InvestmentInformationPopUpPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

    @property
    def fundNameLabel(self):
        return Label(self.webdriver, self.getCell(0), By.XPATH, "//a[@class='hyperlink']")

    @property
    def selectButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, "//a/span")
