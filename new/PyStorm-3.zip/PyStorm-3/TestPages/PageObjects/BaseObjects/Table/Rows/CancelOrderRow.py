from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CancelOrderRow(GenericBaseRow):
    @property
    def cancelCheckBox(self):
        return CheckBox(self.webdriver, self.element, By.XPATH, ".//input[@type='checkbox' and not(@disabled)]")
