from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.Trackingorders.InvestmentSelectionToolPage import InvestmentSelectionToolPage


class DealPlaceOrderBuyTradesInvestmentDetailsTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToInvestmentSelectionToolPage(self):
        self.findButton.click()
        return InvestmentSelectionToolPage(self.webdriver)

    @property
    def findButton(self):
        return Button(self.webdriver, self.getCell(0), By.XPATH, ".//a[text()='Find']")
