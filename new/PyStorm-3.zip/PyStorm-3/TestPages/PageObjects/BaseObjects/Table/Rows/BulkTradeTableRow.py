from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class BulkTradeTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def selectCheckBox(self):
        return CheckBox(self.webdriver, self.element, By.XPATH, ".//input[@type='checkbox']")

    @property
    def accountIdLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))
