from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ESignatureTermsAndConditionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def fileNameLabel(self):
        return Label(self.webdriver, self.webdriver, self.getCell(0))

    @property
    def selectToBeESignedCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(1), By.XPATH, ".//span")
