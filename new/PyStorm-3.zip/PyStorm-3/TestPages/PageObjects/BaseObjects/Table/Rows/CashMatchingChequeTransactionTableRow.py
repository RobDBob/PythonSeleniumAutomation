from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CashMatchingChequeTransactionTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def unmatchedItemsCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, self.getCell(8))
