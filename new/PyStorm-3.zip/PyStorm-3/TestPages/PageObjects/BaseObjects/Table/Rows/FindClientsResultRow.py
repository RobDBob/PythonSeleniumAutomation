from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class FindClientsResultRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def accountCodeButton(self):
        return Button(self.webdriver, self.getCell(index=0), By.XPATH, ".//a")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.getCell(0), By.XPATH, "//a[@class='share']")

    @property
    def searchKeyButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, "(//a[@class='share'])[2]")
