from selenium.webdriver.common.by import By
from TestPages.AddNewTrustMember.TrustServicingEditRolesPage import TrustServicingEditRolesPage
from TestPages.ClientsTabs.SearchResults.RemoveTrustMemberPage import RemoveTrustMemberPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.ClientDetails.PersonalDetailsPage import PersonalDetailsPage


class IndividualMembersRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToPersonalDetailsPage(self):
        self.nameLinkButton.click()
        return PersonalDetailsPage(self.parentElement)

    def navigateToTrustServicingEditRolesPage(self):
        self.editRolesButton.click()
        return TrustServicingEditRolesPage(self.webdriver)

    def clickRemoveAndNavigateToRemoveTrustMemberPage(self):
        self.removeButton.jsClick()
        return RemoveTrustMemberPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def nameLinkButton(self):
        return Button(self.webdriver, self.getCell(2), By.XPATH, "//a[@class='hpyerlink']")

    @property
    def genderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def shareOfTrustLabel(self):
        return Label(self.webdriver, self.element, self.getCell(5))

    @property
    def editRolesButton(self):
        return Button(self.webdriver, self.getCell(6), By.XPATH, ".//button[@title='Edit']")

    @property
    def removeLabel(self):
        return Label(self.webdriver, self.element, self.getCell(7))

    @property
    def removeButton(self):
        return Button(self.webdriver, self.getCell(8), By.XPATH, ".//span[text()='Remove']")
