from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CashMatchingExpectationTableRow(GenericBaseRow):
    @property
    def matchedItemsCheckBox(self):
        return Button(self.webdriver, self.webdriver, self.getCell(0))
