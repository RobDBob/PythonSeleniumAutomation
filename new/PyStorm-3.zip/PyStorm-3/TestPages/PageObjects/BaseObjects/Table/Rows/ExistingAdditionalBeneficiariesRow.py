from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ExistingAdditionalBeneficiariesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def titleLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def genderLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))

    @property
    def noResultsLabel(self):
        return Label(self.webdriver, self.getCell(index=0), By.XPATH, ".//div[contains(text(),'No results')]")
