from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class FamilyTermsLinkedAccountsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def linkIdButton(self):
        return Button(self.webdriver, self.getCell(index=0), By.XPATH, "./a")

    @property
    def dateCreatedLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def adviserLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))
