from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class MigrateToMPSSubAccountHoldingsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")
    
    @property
    def valueAvailableLabel(self):
        return self.getCell(1).text