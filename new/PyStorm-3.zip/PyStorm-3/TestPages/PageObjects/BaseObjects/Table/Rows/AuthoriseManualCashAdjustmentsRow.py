from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseManualCashAdjustmentsRow(GenericBaseRow):
    @property
    def authoriseCheckBox(self):
        return Button(self.webdriver, self.webdriver, self.getCell(8))

    @property
    def rejectCheckBox(self):
        return Button(self.webdriver, self.webdriver, self.getCell(9))
