from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class PaymentsTransactionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def typeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def productsLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def frequencyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def methodLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def dateCreatedLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def dateCreatedDate(self):
        return datetime.strptime(Label(self.webdriver, self.parentElement, self.getCell(index=4)).text, "%d/%m/%Y").date()

    @property
    def instructionLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.getCell(8), By.XPATH, ".//a[text()='Cancel']")

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.getCell(5), By.XPATH, ".//span[@class='text']")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=7))
