from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.SearchResults.TrustMemberHistoryPage import TrustMemberHistoryPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.ClientDetails.TrustOrganisationCompanyDetailsPage import TrustOrganisationCompanyDetailsPage


class CorporateMemberRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    def navigateToTrustMemberHistoryPage(self):
        self.historyLinkButton.click()
        return TrustMemberHistoryPage(self.parentElement)

    def clickRemoveAndNavigateToRemoveTrustMemberPage(self):
        from TestPages.ClientsTabs.SearchResults.RemoveTrustMemberPage import RemoveTrustMemberPage
        self.removeButton.jsClick()
        return RemoveTrustMemberPage(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']")

    def navigateTrustOrganisationCompanyDetailsPage(self):
        self.companyNameLabel.click()
        return TrustOrganisationCompanyDetailsPage(self.parentElement)

    @property
    def roleLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(0))

    @property
    def companyNameLabel(self):
        return Label(self.webdriver, self.getCell(1), By.XPATH, "//a[@class='hpyerlink']")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(3))

    @property
    def historyLinkButton(self):
        return Button(self.webdriver, self.getCell(4), By.XPATH, ".//a[text()='History']")

    @property
    def removeButton(self):
        return Button(self.webdriver, self.getCell(5), By.XPATH, ".//button")

    @property
    def removeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(3))
