from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class OrdersTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def orderIdLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def batchIdLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def clAccountIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def dateLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))
