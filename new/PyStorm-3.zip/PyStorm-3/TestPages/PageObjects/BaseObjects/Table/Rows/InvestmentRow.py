from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class InvestmentRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def arrangementQuantityEditField(self):
        return EditField(self.webdriver, self.getCell(2), By.XPATH, ".//input[contains(@id,'Quantity')]")

    @property
    def arrangementGroup1EditField(self):
        return EditField(self.webdriver, self.getCell(4), By.XPATH, ".//input[contains(@id,'G1Quantity')]")
