from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CompanyAccessLevelTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def readWriteAccessCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(4), By.XPATH, ".//input[contains(@id,'companyrw')]//following-sibling::span")
