from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ExpectedSinglePaymentsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def payerLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def amountLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def taxReliefLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def frequencyLabel(self):
        return Label(self.webdriver, self.element, self.getCell(3))

    @property
    def paidFromLabel(self):
        return Label(self.webdriver, self.element, self.getCell(4))
