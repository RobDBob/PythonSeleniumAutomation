from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CurrentAvailableLocalToolTipTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def itemNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def itemValueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))
