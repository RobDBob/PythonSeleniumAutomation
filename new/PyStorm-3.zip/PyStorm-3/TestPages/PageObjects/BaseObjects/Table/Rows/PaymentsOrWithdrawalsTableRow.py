from datetime import datetime
from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.Withdrawals.WithdrawalsSummaryPage import WithdrawalsSummaryPage


class PaymentsOrWithdrawalsTableRow(BaseTestObject):
    def navigateToWithdrawalSummary(self):
        self.summaryButton.click()
        return WithdrawalsSummaryPage(self.webdriver)

    @property
    def entryIDButton(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'txtEntry')]")

    @property
    def entryIDValueLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'txtEntry')]/a")

    @property
    def productName(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'txtAccountName')]")

    @property
    def frequency(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class='TableData CAlign' and contains(@id,'txtMethod')]")

    @property
    def method(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class='TableData LAlign' and contains(@id,'txtMethod')]")

    @property
    def dateCreated(self):
        return datetime.strptime(Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'txtDateCreated')]").text, "%d-%b-%y %I:%M %p")

    @property
    def amount(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'txtAmount')]")

    @property
    def instruction(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'tdInstruction')]")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[contains(@id,'tdStatus')]")

    @property
    def narration(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[18]")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//td/a[text()='Cancel']")

    @property
    def summaryButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//td/a[text()='Summary']")
