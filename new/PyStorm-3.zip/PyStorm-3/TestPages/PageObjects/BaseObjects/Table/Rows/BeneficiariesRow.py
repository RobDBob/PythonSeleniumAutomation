from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class BeneficiariesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[@class='cell-left']")

    @property
    def nameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(0))

    @property
    def proportionLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(1))
