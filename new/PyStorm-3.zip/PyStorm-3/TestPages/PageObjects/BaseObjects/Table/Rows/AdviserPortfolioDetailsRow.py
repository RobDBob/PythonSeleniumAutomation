from datetime import datetime
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.Admin.ModelPortfolioSummaryPage import ModelPortfolioSummaryPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserPortfolioDetailsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")
    dateFormat = "%d/%m/%Y"

    def navigateToModelPortfolioSummaryPage(self, modelPortfolioName):
        if self.modelPortfolioNameLinkButton.text == modelPortfolioName:
            PrintMessage(f"The selected Model Portfolio '{modelPortfolioName}' is present in the table.")
            self.modelPortfolioNameLinkButton.jsClick()
            return ModelPortfolioSummaryPage(self.webdriver)
        PrintMessage(f"The selected Model Portfolio '{modelPortfolioName}' is not present in the table.")
        return None

    @property
    def modelPortfolioNameLinkButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, ".//a[@class='url-link inline-link']")

    @property
    def taxWrapperLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=2))

    @property
    def activeStatusRadioButton(self):
        return Button(self.webdriver, self.getCell(3), By.XPATH, "//input[@value='ActiveCheckBox']/following-sibling::span")

    @property
    def inActiveStatusRadioButton(self):
        return Button(self.webdriver, self.getCell(4), By.XPATH, "//input[@value='InActiveCheckBox']/following-sibling::span")

    @property
    def activeStatusLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=5))

    @property
    def createdDate(self):
        dateFormat = "%d/%m/%Y"
        dateLabel = Label(self.webdriver, self.element, self.getCell(index=6))
        return datetime.strptime(dateLabel.text, dateFormat).date()

    @property
    def lastUpdatedDate(self):
        dateFormat = "%d/%m/%Y"
        dateLabel = Label(self.webdriver, self.element, self.getCell(index=7))
        return datetime.strptime(dateLabel.text, dateFormat).date()

    @property
    def numberOfClientsAttachedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=8))
