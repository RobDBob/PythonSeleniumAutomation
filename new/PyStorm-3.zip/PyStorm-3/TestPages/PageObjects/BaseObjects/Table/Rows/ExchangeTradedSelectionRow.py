from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ExchangeTradedSelectionRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def selectButton(self):
        cellElement = self.getCell(2)
        return Button(self.webdriver, cellElement, By.XPATH, ".//a/span")
