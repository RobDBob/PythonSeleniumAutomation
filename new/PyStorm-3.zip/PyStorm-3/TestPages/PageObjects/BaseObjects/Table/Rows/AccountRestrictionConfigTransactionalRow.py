from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AccountRestrictionConfigTransactionalRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def suspendedLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def transactionTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def suspendedCheckBox(self):
        return CheckBox(self.webdriver, self.getCell(index=1), By.XPATH, ".//span")
