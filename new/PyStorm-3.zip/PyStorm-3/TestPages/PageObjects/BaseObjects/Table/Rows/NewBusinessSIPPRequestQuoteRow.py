from datetime import datetime
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.Wizards.NewClient.QuoteSummaryIllustrationsPage import QuoteSummaryIllustrationsPage


class NewBusinessSIPPRequestQuoteRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[@class]")

    def _waitForNewTabToOpen(self, preClickWindowHandles):
        if len(self.webdriver.window_handles) == len(preClickWindowHandles):
            raise UIException("New tab did not open yet")

    @retry(exceptions=(UIException, TimeoutException), delay=1, tries=2)
    def clickLinkButtonAndNavigateToIllustrationsPage(self):
        preClickWindowHandles = self.webdriver.window_handles
        self.linkCompleteButton.click()
        self._waitForNewTabToOpen(preClickWindowHandles)
        return QuoteSummaryIllustrationsPage(self.webdriver)

    @property
    def dateTime(self):
        dateFormat = "%d/%m/%Y %H:%M:%S"
        return datetime.strptime(self.getCell(index=1).text, dateFormat)

    @property
    def commentsLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def linkCompleteButton(self):
        return Button(self.webdriver, self.getCell(3), By.XPATH, ".//a[@href]")

    @property
    def runningButton(self):
        return Button(self.webdriver, self.element, self.getCell(3))
