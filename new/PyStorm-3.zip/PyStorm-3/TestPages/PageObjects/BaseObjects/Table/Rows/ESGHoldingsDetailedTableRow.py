from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ESGHoldingsDetailedTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def assetLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def valueGBPLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def percentageWeightingLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def carbonEmissionsLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))

    @property
    def waterUsageLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def wasteToLandfillLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=6))

    @property
    def averageFemaleDirectorsLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=7))

    @property
    def deforestationLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=8))

    @property
    def humanRightsControversiesLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=9))

    @property
    def corporateGovernanceLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=10))

    @property
    def recyclingLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=11))

    @property
    def airPollutionLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=12))
