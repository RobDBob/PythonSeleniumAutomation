from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ArrangementRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def arrangementLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def allocationLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def valueLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))
