from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseTrustProcessesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[contains(@class, TableData)]")

    @property
    def processTypeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def accountCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.element, self.getCell(index=4))
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        return checkbox

    @property
    def rejectCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, self.getCell(index=5))
