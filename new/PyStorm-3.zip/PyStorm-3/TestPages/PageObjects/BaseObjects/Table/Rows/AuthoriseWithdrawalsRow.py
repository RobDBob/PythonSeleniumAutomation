from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isInputChildCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseWithdrawalsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[contains(@class, TableData)]")

    @property
    def idLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=11))

    @property
    def authoriseCheckBox(self):
        checkBox = CheckBox(self.webdriver, self.getCell(index=12), By.XPATH, ".//label[@for]")
        checkBox.isCheckedFuncCB = isInputChildCheckedCB
        return checkBox

    @property
    def rejectCheckBox(self):
        checkBox = CheckBox(self.webdriver, self.getCell(index=13), By.XPATH, ".//label[@for]")
        checkBox.isCheckedFuncCB = isInputChildCheckedCB
        return checkBox
