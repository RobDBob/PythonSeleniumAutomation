from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AccountRestrictionAuthorisationRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def reasonNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def authoriseCheckBox(self):
        return CheckBox(self.webdriver, self.element, By.XPATH, ".//input[contains(@id,'authorise')]//following-sibling::span")

    @property
    def rejectCheckBox(self):
        return CheckBox(self.webdriver, self.element, By.XPATH, ".//input[contains(@id,'reject')]//following-sibling::span")
