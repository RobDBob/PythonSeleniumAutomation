from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isCSSCheckedCB, isInputChildDisabledCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AuthoriseAccountRestrictionUpdateProcesses(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td[contains(@class, TableData)]")

    @property
    def accountCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=5))

    @property
    def authoriseCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=7), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox

    @property
    def rejectCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.getCell(index=8), By.XPATH, ".//div[contains(@class,'square-checkbox')]")
        checkbox.isCheckedFuncCB = isCSSCheckedCB
        checkbox.isDisabledFuncCB = isInputChildDisabledCB
        return checkbox
