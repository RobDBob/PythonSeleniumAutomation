from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class MigrateFromMPSSubAccountHoldingsRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def expandButton(self):
        cellElement = self.getCell(0)
        return Button(self.webdriver, cellElement, By.XPATH, ".//a")
