from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class FindAdvisorResultRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def advisorNameLabel(self):
        cellElement = self.getCell(index=0)
        return Label(self.webdriver, self.webdriver, cellElement)

    @property
    def addAdvisorCodeLinkButton(self):
        return Button(self.webdriver, self.getCell(1), By.XPATH, "//a[@class='inline-link']")

    @property
    def companyAdvisorCodeLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def companyLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=3))

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=4))
