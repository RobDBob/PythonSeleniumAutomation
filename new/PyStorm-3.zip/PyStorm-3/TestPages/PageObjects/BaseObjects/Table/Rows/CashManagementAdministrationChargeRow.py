from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CashManagementAdministrationChargeRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def productLabel(self):
        return Label(self.webdriver, self.element, self.getCell(0))

    @property
    def propositionLabel(self):
        return Label(self.webdriver, self.element, self.getCell(1))

    @property
    def currentRateLabel(self):
        return Label(self.webdriver, self.element, self.getCell(2))

    @property
    def newRateEditField(self):
        return EditField(self.webdriver, self.getCell(3), By.XPATH, ".//input[@type='text']")

    @property
    def actionEditButton(self):
        return Button(self.webdriver, self.getCell(4), By.XPATH, ".//span[contains(text(),'Edit')]")

    @property
    def actionCancelButton(self):
        return Button(self.webdriver, self.getCell(4), By.XPATH, ".//span[contains(text(),'Cancel')]")
