from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AddNewClientClientMatchesRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def customerIDLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=0))

    @property
    def firstNamesLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=1))

    @property
    def surNameLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=2))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=3))

    @property
    def dateCreatedLabel(self):
        return Label(self.webdriver, self.element, self.getCell(index=4))

    @property
    def goToClientButton(self):
        return Button(self.webdriver, self.element, By.XPATH, "//a[text()='Go to client']")

    @property
    def useThisClientButton(self):
        return Button(self.webdriver, self.element, By.XPATH, "//a[text()='Use this client']")
