from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.BulkClientsAccountTableRow import BulkClientsAccountTableRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class BulkRebalanceRegularInvestmentTabTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[BulkClientsAccountTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [BulkClientsAccountTableRow(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]

    @property
    def titleOfBulkRebalanceRegularInvestmentClientsAccountTable(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Clients with Regular Investments')]")

    @property
    def clientsTableTitleAccountName(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Account Name']")

    @property
    def clientsTableTitleAccountID(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Account ID']")

    @property
    def clientsTableTitleProduct(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Product']")

    @property
    def clientsTableTitleModelPortfolio(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Model Portfolio']")

    @property
    def clientsTableTitleQuantity(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Quantity']")

    @property
    def clientsTableTitleMarketValue(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[contains(text(),'Market Value')]")

    @property
    def clientsTableTitleRegularPayment(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Regular Payment']")

    @property
    def clientsTableTitleNextContributionDate(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[text()='Next Contribution Date']")

    @property
    def clientsTableDetailLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, ".//a[@class='inline-link']")
