from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableFooter import TableFooter
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions


class InvestmentAllocationBaseRow(GenericBaseRow):
    # Single slash due to .//td will return nested tds
    CELL_LOCATOR = (By.XPATH, "./td")

    @retry(exceptions=TimeoutException, delay=2, tries=5)
    def setAllocationForFieldName(self, columnIndex, allocationValue):
        """
        Allocation fields can be any of or all at once: ["Single %", "Client Regular %", "Party Regular %"]
        """
        allocationEditField = EditField(self.webdriver, self.getCell(columnIndex), By.XPATH, ".//input[@type='text']")
        allocationEditField.enterValueAndWait(allocationValue)

    @retry(exceptions=TimeoutException, delay=2, tries=5)
    def setAllocationForFieldNameWithLimit(self, allocationValue, limitValue, expiryDate):
        """
        Allocation details requires extra fields Limit and Expiry date when Limit radio button is clicked, This method ensures the extra values are added
        """
        self.limitRadioButton.click()
        self.allocationEditField.enterValueAndWait(allocationValue)
        self.limitEditField.enterValueAndWait(limitValue)
        self.expiryDateDatePicker.specify_date(expiryDate)

    @property
    def investmentHyperlink(self):
        """
        If Cash, then label
        If anything else, then hyperlink
        """
        cellElement = self.getCell(0)
        return Button(self.webdriver, cellElement, By.XPATH, ".//a[@class='hyperlink']")

    @property
    def investmentText(self):
        """
        If Cash, then label
        If anything else, then hyperlink
        """
        return self.getCell(0).text

    @property
    def investmentCode(self):
        """
        If Cash, then label
        If anything else, then hyperlink
        """
        return self.getCell(0).find_element(By.XPATH, './/p[@class]').text

    @property
    def availableUnits(self):
        cellElement = self.getCell(1)
        return float((cellElement.find_element(By.XPATH, ".//span")).text)

    @property
    def marketValueLabel(self):
        return self.getCell(2).text

    @property
    def orderValueLabel(self):
        return Label(self.webdriver, self.getCell(3), By.XPATH, ".//input[@type='text']")

    @property
    def allocationEditField(self):
        return EditField(self.webdriver, self.getCell(1), By.XPATH, ".//input[@type='text']")

    @property
    def protectFromAutoDisInvestmentBuyInvestmentCheckbox(self):
        """
        Property that returns Protect from auto-disinvestment checkbox for Off Platforms funds in Buy Investment page
        """
        checkBox = CheckBox(self.webdriver, self.getCell(3), By.XPATH, ".//input[@type='checkbox']/following-sibling::span")
        checkBox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkBox

    @property
    def limitRadioButton(self):
        """
        Limit Radio Button, click on this radio button will enable limitEditField and expiryDateDatePicker fields
        """
        return Button(self.webdriver, self.getCell(0), By.XPATH, ".//span[text()='Limit']")

    @property
    def protectFromAutoDisinvestmentNewBusinessCheckbox(self):
        """
        Property that returns Protect from auto-disinvestment checkbox for Off Platforms funds in new business investment page
        """
        return CheckBox(self.webdriver, self.getCell(2), By.XPATH, ".//input[@type='checkbox']/following-sibling::span")

    @property
    def limitEditField(self):
        """
        Limit EditField is used to enter the limit value and is used only when the Limit radio button is clicked
        """
        return EditField(self.webdriver, self.getCell(2), By.XPATH, ".//input[@type='text']")

    @property
    def expiryDateDatePicker(self):
        """
        Expiry DatePicker is used to enter the expiry date value  and is used only when the Limit radio button is clicked
        """
        return DatePicker(self.webdriver, self.getCell(3), By.XPATH, ".//span[@title='Date selector']//parent::div")


class SwitchFromInvestmentAllocationRow(InvestmentAllocationBaseRow):
    @property
    def orderValueEditField(self):
        return EditField(self.webdriver, self.getCell(3), By.XPATH, ".//input[@type='text']")

    @property
    def orderUnitEditField(self):
        return EditField(self.webdriver, self.getCell(4), By.XPATH, ".//input[@type='text']")

    @property
    def allocationEditField(self):
        return EditField(self.webdriver, self.getCell(5), By.XPATH, ".//input[@type='text']")

    @property
    def switchAll(self):
        cellElement = self.getCell(7)
        return CheckBox(self.webdriver, cellElement, By.XPATH, ".//input[@type='checkbox']/following-sibling::span")

    @property
    def protectFromAutoDisinvestment(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, ".//tr/td[8]//input/following-sibling::span")


class SwitchToInvestmentAllocationRow(InvestmentAllocationBaseRow):
    @property
    def allocationEditField(self):
        return EditField(self.webdriver, self.getCell(1), By.XPATH, ".//input[@type='text']")

    @property
    def actionDeleteButton(self):
        return Button(self.webdriver, self.getCell(2), By.XPATH, ".//button")

    @property
    def protectFromAutoDisinvestment(self):
        cellElement = self.getCell(5)
        return CheckBox(self.webdriver, cellElement, By.XPATH, ".//input[@type='checkbox']")


class SellInvestmentAllocationRow(InvestmentAllocationBaseRow):
    @property
    def allocationEditField(self):
        cellElement = self.getCell(3)
        return EditField(self.webdriver, cellElement, By.XPATH, ".//input[@type='text']")

    @property
    def sellAllCheckBox(self):
        cellElement = self.getCell(4)
        return CheckBox(self.webdriver, cellElement, By.XPATH, ".//input[@type='checkbox']")


class AssestsToBeReregisteredAllocationRow(InvestmentAllocationBaseRow):
    @property
    def investmentText(self):
        """
        If Cash, then label
        If anything else, then hyperlink
        """
        return self.getCell(1).text

    @property
    def orderQuantity(self):
        cellElement = self.getCell(2)
        return EditField(self.webdriver, cellElement, By.XPATH, ".//input[@type='text']")


class InvestmentAllocationTable(BaseTestObject):
    HEADER_LOCATOR = (By.XPATH, ".//thead")
    FOOTER_LOCATOR = (By.XPATH, ".//tfoot")
    DATA_LOCATOR = (By.XPATH, ".//tbody")
    ROW_LOCATOR = (By.XPATH, ".//tr")
    rowType = InvestmentAllocationBaseRow

    def getInvestmentAllocationRow(self, investmentName) -> InvestmentAllocationBaseRow:
        PrintMessage(f"Selecting investment row : '{investmentName}'")
        matchingRows = [k for k in self.dataRows if investmentName in k.investmentText]
        if matchingRows:
            return matchingRows[0]
        return None

    def getInvestmentAllocationRows(self, investmentName) -> list[InvestmentAllocationBaseRow]:
        """
        Method used to get the list of rows with same investment (if any), created as part of a validation for test C1521899
        """
        matchingRows = [k for k in self.dataRows if investmentName in k.investmentText]
        if matchingRows:
            return matchingRows
        return []

    def setInvestmentAllocations(self, allocationsData: list):
        for allocationData in allocationsData:
            self.setInvestmentAllocation(allocationData)

    @retry(exceptions=UIException, tries=4)
    def setInvestmentAllocation(self, allocationData: dict):
        """
        Method performs:
         - a lookup for data row for specified fundName (FundName & FundCode)
         - checks which of the investment types to use i.e. [Allocation, Single, Regular, ThirdParty] (AllocationFieldName)
         - inserts allocation value (Allocation)
        """
        # TODO: check tests execute
        investmentName: str = allocationData[DataEnums.INVESTMENT_NAME]
        if investmentName.lower() == PageEnums.GBPCASH.lower():
            investmentName = DataEnums.CASH

        # work around issue on test server where interaction starts before all columns are rendered
        if len(self.header.headers) < 3:
            raise UIException("Expecting more than two columns investment allocation table ")

        matchingColumnHeaders = [k for k in self.header.headers if allocationData[DataEnums.ALLOCATION_FIELD_NAME] in k]

        if matchingColumnHeaders:
            matchingColumnIndex = self.header.headers.index(matchingColumnHeaders[0])
            matchingRows = [k for k in self.dataRows if investmentName.lower() in k.investmentText.lower()]

            if matchingRows:
                matchingRow: InvestmentAllocationBaseRow = matchingRows[0]

                if allocationData.get(DataEnums.PROTECT_FROM_AUTO_DISINVESTMENT):
                    matchingRow.protectFromAutoDisinvestmentNewBusinessCheckbox.click(jsClick=True)

                if allocationData.get(DataEnums.LIMIT):
                    matchingRow.setAllocationForFieldNameWithLimit(allocationData[DataEnums.ALLOCATION_PERCENTAGE],
                                                                   allocationData[DataEnums.LIMIT_VALUE], allocationData[DataEnums.EXPIRY_DATE])
                else:
                    matchingRow.setAllocationForFieldName(matchingColumnIndex, allocationData[DataEnums.ALLOCATION_PERCENTAGE])
            else:
                raise UIException(f"Expected InvestmentName: '{investmentName}' not found on allocation table")
        else:
            PrintMessage(f"Allocation type: '{allocationData[DataEnums.ALLOCATION_FIELD_NAME]}' not present in current headers: '{self.header.headers}'")

    def getAllInvestmentsAndSingleAllocations(self) -> dict:
        """
        This method returns a dict containing the Investment Hyperlink text + Investment code as key and single allocation as value
        """
        investmentDetails = {}

        k: InvestmentAllocationBaseRow
        for k in self.dataRows:
            investmentDetails[k.investmentText] = k.allocationEditField.value
        return investmentDetails

    def getAllInvestmentHyperlinkTextAndSingleAllocations(self) -> list[dict]:
        """
        This method returns a list of Dict containing the Investment Hyperlink text as key and single allocation as value
        """
        investmentDetails = []

        k: InvestmentAllocationBaseRow
        for k in self.dataRows:
            investmentDetails.append({
                DataEnums.INVESTMENT_NAME: k.investmentHyperlink.text,
                DataEnums.ALLOCATION_PERCENTAGE: int(k.allocationEditField.value)
            })
        return investmentDetails

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.HEADER_LOCATOR)

    @property
    def footer(self):
        return TableFooter(self.webdriver, self.element, *self.FOOTER_LOCATOR)

    @property
    @retry(exceptions=TimeoutException, delay=2, tries=3)
    def dataRows(self) -> list:
        """
        Either
        Rows can be found - rows exist, then wait for ID property to show up
        Rows cannot be found:
             - rows do not exist
             - rows failed to load in time
        """
        dataHolder = self.element.find_element(*self.DATA_LOCATOR)

        valueWaiter = ExpectedConditions.attribute_present_in_one_of_elements(self.ROW_LOCATOR, "id")
        WebDriverWait(dataHolder, 10).until(valueWaiter)

        return [self.rowType(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']")
                for k in dataHolder.find_elements(*self.ROW_LOCATOR)]
