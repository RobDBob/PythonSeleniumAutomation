from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class ExistingJointCustomerTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def clientNameLabel(self):
        cellElement = self.getCell(index=0)
        return Label(self.webdriver, self.webdriver, cellElement)

    @property
    def addClientLinkButton(self):
        cellElement = self.getCell(3)
        return Button(self.webdriver, cellElement, By.XPATH, "//button[@class='secondary-add-button']//span")


class ExistingJointCustomerTable(GenericTable):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    rowLocator = (By.XPATH, ".//tr[@id]")

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[ExistingJointCustomerTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        rows = self.element.find_elements(*self.rowLocator)
        return [ExistingJointCustomerTableRow(self.webdriver, self.element, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]
