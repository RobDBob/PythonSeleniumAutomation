import operator
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.InvestmentHoldingsRow import InvestmentHoldingsRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class InvestmentHoldingsTable(GenericTable):
    rowType = InvestmentHoldingsRow
    headerLocator = (By.XPATH, "//thead")
    dataLocator = None
    rowLocator = (By.XPATH, ".//tr[@class='']")
    SUB_INVESTMENT = (By.XPATH, ".//tr[@class='sub-investment']")
    MODEL_PORTFOLIO_LOCATOR = (By.XPATH, ".//tr[not(@class)]")

    def getInvestmentRow(self, investmentName, comparisonOperator: operator = operator.eq) -> InvestmentHoldingsRow:
        matchingInvestments = [k for k in self.dataRows if comparisonOperator(k.investmentsLabel.text, investmentName)]
        if matchingInvestments:
            return matchingInvestments[0]
        return None

    def getAllInvestments(self) -> list:
        investmentsList = [k.investmentsLabel.text for k in self.dataRows]
        PrintMessage(f"Found investments : '{investmentsList}'")
        return investmentsList

    def getModelPortFolios(self) -> list:
        """
        Fetches the model portfolios and performs a click on the toggle button to display the list of investments
          present under the model portfolios.
        """
        self.rowLocator = self.MODEL_PORTFOLIO_LOCATOR
        modelPortFolios = []
        for k in self.dataRows:
            modelPortFolios.append(k.investmentsLabel.text)
            k.modelPortFolioExpandToggleButton.click()
        PrintMessage(f"Found Model Portfolios : '{modelPortFolios}'")
        return modelPortFolios

    def getAllInvestmentsForModelPortFolios(self) -> list:
        """
        Method retrieves all investments associated with Model Portfolios from the table.
        """
        self.rowLocator = self.SUB_INVESTMENT
        modelPortFoliosInvestmentsList = [(k.investmentsLabel.text + " " + k.allocationPercentageLabel.text) for k in self.dataRows]
        return modelPortFoliosInvestmentsList

    def getInvestmentRowForModelPortfolio(self, investmentName, comparisonOperator: operator = operator.eq) -> InvestmentHoldingsRow:
        """
        This method retrieves a row by matching the combined investment name and allocation.
        This is necessary because model portfolios can contain duplicate investment names,
        and only the first match would be returned otherwise, making subsequent values unreachable.
        """
        matchingInvestments = [k for k in self.dataRows if comparisonOperator((k.investmentsLabel.text + " " + k.allocationPercentageLabel.text), investmentName)]
        if matchingInvestments:
            return matchingInvestments[0]
        return None

    @property
    def productNameLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//span[contains(@class, 'product-name')]")

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//span[@class='account']")

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)
