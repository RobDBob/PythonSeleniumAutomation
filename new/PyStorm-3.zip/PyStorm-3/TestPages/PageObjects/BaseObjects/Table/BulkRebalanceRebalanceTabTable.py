from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Table.BulkClientsAccountTableRow import BulkClientsAccountTableRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class BulkRebalanceRebalanceTabTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[BulkClientsAccountTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [BulkClientsAccountTableRow(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]

    @property
    def listOfClients(self):
        return BulkClientsAccountTableRow(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']//tbody//tr")

    @property
    def rebalanceTabTableTitleAccountName(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//*[text()='Account Name']")

    @property
    def rebalanceTabTableTitleAccountID(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//*[text()='Account ID']")

    @property
    def rebalanceTabTableTitleProduct(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//*[text()='Product']")

    @property
    def rebalanceTabTableTitleModelPortfolio(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//*[text()='Model Portfolio']")

    @property
    def rebalanceTabTableTitleMarketValue(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//tr[@class='sub-head']//th[text()='Market Value']")

    @property
    def rebalanceTabTableTitleDiscretionary(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "(//th[contains(text(),'Discretionary')])[1]")

    @property
    def rebalanceTabTableTitleDiscretionaryRadioButton(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "(//th[contains(text(),'Discretionary')])[1]//input")

    @property
    def rebalanceTabTableTitleNonDiscretionary(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[contains(text(),'Non-Discretionary')]")

    @property
    def rebalanceTabTableTitleNonDiscretionaryRadioButton(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[contains(text(),'Non-Discretionary')]//input")

    @property
    def rebalanceTabTableTitleExecutionOnly(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[contains(text(),'Execution Only')]")

    @property
    def rebalanceTabTableTitleExecutionOnlyRadioButton(self):
        return TableHeader(self.webdriver, self.webdriver, By.XPATH, "//th[contains(text(),'Execution Only')]//input")

    @property
    def openOrdersclientsTableDetailLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//td[@class='align']//a")
