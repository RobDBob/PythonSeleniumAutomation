from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.BulkClientsAccountTableRow import BulkClientsAccountTableRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions as EC


class BulkTradeTabClientsAccountsTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def bulkTradeClientTableHeaders(self):
        valueWaiter = EC.visibility_of_all_elements_located((By.XPATH, "//tr[contains(@class,'sub-head')]//th"))
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        clientTableHeaders = self.webdriver.find_elements(By.XPATH, "//tr[contains(@class,'sub-head')]//th")
        return [k.text for k in clientTableHeaders]

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[BulkClientsAccountTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [BulkClientsAccountTableRow(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]

    @property
    def titleOfClientsTable(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Clients']")
