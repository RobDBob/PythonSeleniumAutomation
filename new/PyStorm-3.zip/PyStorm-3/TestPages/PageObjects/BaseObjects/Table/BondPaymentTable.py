import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.WebDriver import ExpectedConditions as EC

STYLE_HIDDEN = "display: none;"


class SinglePaymentDetailRow(BaseTestObject):
    @property
    def sourceDropdown(self):
        return DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@name, 'SingleSource')]",
                               optionsLocator=(By.XPATH, ".//option[@value]"), checkAriaState=False)

    @property
    def methodDropdown(self):
        return DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@name, 'SingleMethod')]",
                               optionsLocator=(By.XPATH, ".//option[@value]"), checkAriaState=False)

    @property
    def cashAccountsDropdown(self):
        return DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@name, 'SingleAccountTransfer')]",
                               optionsLocator=(By.XPATH, ".//option[@value]"), checkAriaState=False)

    @property
    def accountDropdown(self):
        return DropdownListbox(self.webdriver,
                               self.element,
                               By.XPATH,
                               ".//select[contains(@name, 'SingleBankAccount')]",
                               optionsLocator=(
                                   By.XPATH,
                                   ".//option[@value]"),
                               checkAriaState=False)

    @property
    def dateDatePicker(self):
        return DatePicker(self.webdriver, self.element, By.XPATH, ".//input[contains(@name, 'SingleFirstDate')]/parent::div")


class RegularPaymentDetailRow(BaseTestObject):
    @property
    def sourceDropdown(self):
        return DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@name, 'RegularSource')]",
                               optionsLocator=(By.XPATH, ".//option[@value]"), checkAriaState=False)

    @property
    def methodDropdown(self):
        return DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[contains(@name, 'RegularMethod')]",
                               optionsLocator=(By.XPATH, ".//option[@value]"), checkAriaState=False)

    @property
    def accountDropdown(self):
        return DropdownListbox(self.webdriver,
                               self.element,
                               By.XPATH,
                               ".//select[contains(@name, 'RegularBankAccount')]",
                               optionsLocator=(
                                   By.XPATH,
                                   ".//option[@value]"),
                               checkAriaState=False)

    @property
    def startDateEditField(self):
        return DatePicker(self.webdriver, self.element, By.XPATH, ".//input[contains(@name, 'RegularFirstDate')]/parent::div")

    @property
    def finalDateEditField(self):
        return DatePicker(self.webdriver, self.element, By.XPATH, ".//input[contains(@name, 'RegularFinalDate')]/parent::div")

    @property
    def frequencyDropdown(self):
        return DropdownListbox(self.webdriver,
                               self.element,
                               By.XPATH,
                               ".//select[contains(@name, 'RegularFrequency')]",
                               optionsLocator=(
                                   By.XPATH,
                                   ".//option[@value]"),
                               checkAriaState=False)

    @property
    def continueDropdown(self):
        return DropdownListbox(self.webdriver,
                               self.element,
                               By.XPATH,
                               ".//select[contains(@name, 'RegularFinalDateType')]",
                               optionsLocator=(
                                   By.XPATH,
                                   ".//option[@value]"),
                               checkAriaState=False)

    @property
    def paymentsToIncreaseDropdown(self):
        return DropdownListbox(self.webdriver,
                               self.element,
                               By.XPATH,
                               ".//select[contains(@name, 'RegularPaymentIncreaseType')]",
                               optionsLocator=(
                                   By.XPATH,
                                   ".//option[@value]"),
                               checkAriaState=False)


class RegularPaymentHeadingRow(BaseTestObject):
    pass


class RegularPaymentRow(BaseTestObject):
    def expand(self) -> RegularPaymentDetailRow:
        styleAttribute = self.element.find_element(By.XPATH, ".//span[contains(@name, 'SingleShow')]").get_attribute("style")
        if styleAttribute is None or STYLE_HIDDEN not in styleAttribute:
            self.showDetailButton.click()

        waiter = EC.text_value_in_attribute_in_element(self.hideDetailButton.element, "style", STYLE_HIDDEN)
        WebDriverWait(self.parentElement, 30).until_not(waiter)
        return RegularPaymentDetailRow(self.webdriver, self.parentElement, By.ID, f"RegularDetailRow{self.rowNumber}")

    @property
    def amountEditField(self):
        return EditField(self.webdriver, self.element, By.ID, f"RegularSIPPAllocated{self.rowNumber}")

    @property
    def amountOnshoreBondEditField(self):
        return EditField(self.webdriver, self.element, By.ID, f"RegularOnshore_Bond1Allocated{self.rowNumber}")

    @property
    def amountOffshoreBondEditField(self):
        return EditField(self.webdriver, self.element, By.ID, f"RegularOffshore_Bond1Allocated{self.rowNumber}")

    @property
    def rowNumber(self):
        rowId = self.element.get_attribute("id")
        matchObject = re.search(r"(\d)", rowId)
        if matchObject:
            return matchObject.group(1)
        raise UIException(f"Failed to identify row number for rowId: '{rowId}'")

    @property
    def hideDetailButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//span[contains(@name, 'RegularHide')]")

    @property
    def showDetailButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//span[contains(@name, 'RegularShow')]")


class SinglePaymentRow(BaseTestObject):
    def expand(self) -> SinglePaymentDetailRow:
        styleAttribute = self.element.find_element(By.XPATH, ".//span[contains(@name, 'SingleShow')]").get_attribute("style")
        if styleAttribute is None or STYLE_HIDDEN not in styleAttribute:
            self.showDetailButton.click()

        waiter = EC.text_value_in_attribute_in_element(self.hideDetailButton.element, "style", STYLE_HIDDEN)
        WebDriverWait(self.parentElement, 30).until_not(waiter)
        return SinglePaymentDetailRow(self.webdriver, self.parentElement, By.ID, f"SingleDetailRow{self.rowNumber}")

    @property
    def amountOnshoreBondEditField(self):
        return EditField(self.webdriver, self.element, By.ID, f"SingleOnshore_Bond1Allocated{self.rowNumber}")

    @property
    def amountOffshoreBondEditField(self):
        return EditField(self.webdriver, self.element, By.ID, f"SingleOffshore_Bond1Allocated{self.rowNumber}")

    @property
    def amountSIPPEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, f"//td[@id='SingleSIPPInputAllocation{self.rowNumber}']//input")

    @property
    def rowNumber(self):
        rowId = self.element.get_attribute("id")
        matchObject = re.search(r"(\d)", rowId)
        if matchObject:
            return matchObject.group(1)
        raise UIException(f"Failed to identify row number for rowId: '{rowId}'")

    @property
    def hideDetailButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//span[contains(@name, 'SingleHide')]")

    @property
    def showDetailButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//span[contains(@name, 'SingleShow')]")


class BondPaymentTable(BaseTestObject):
    def getRegularPaymentRow(self, rowNumber) -> RegularPaymentRow:
        matchedRows = [k for k in self.dataRegularPaymentRegularRows if k.rowNumber == str(rowNumber)]
        if matchedRows:
            regularPaymentRow = matchedRows[0]
            if STYLE_HIDDEN in regularPaymentRow.get_attribute("style"):
                self.addAnotherRegularButton.click()
            return regularPaymentRow
        return None

    def getSinglePaymentRow(self, rowNumber) -> SinglePaymentRow:
        matchedRows = [k for k in self.dataSinglePaymentRegularRows if k.rowNumber == str(rowNumber)]
        if matchedRows:
            singlePaymentRow = matchedRows[0]
            if STYLE_HIDDEN in singlePaymentRow.get_attribute("style"):
                self.addAnotherSingleButton.click()
            return singlePaymentRow
        return None

    @property
    def addAnotherSingleButton(self):
        return Button(self.webdriver, self.element, By.ID, "AddAnotherSingle")

    @property
    def addAnotherRegularButton(self):
        return Button(self.webdriver, self.element, By.ID, "AddAnotherRegular")

    @property
    def dataSinglePaymentRegularRows(self) -> list[SinglePaymentRow]:
        allRows = self.element.find_elements(By.XPATH, ".//tbody[contains(@id, 'SingleRow')]")

        return [SinglePaymentRow(self.webdriver, self.parentElement, row) for row in allRows]

    @property
    def dataRegularPaymentRegularRows(self) -> list[RegularPaymentRow]:
        regularPaymentSection = self.element.find_element(By.XPATH, "//tbody[@id='hideRegularSection']")
        allRows = regularPaymentSection.find_elements(By.XPATH, ".//tr[contains(@id, 'RegularRow')]")

        return [RegularPaymentRow(self.webdriver, self.parentElement, row) for row in allRows]
