from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions as EC


class InvestmentsTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def investmentsTableHeaders(self):
        valueWaiter = EC.visibility_of_all_elements_located((By.XPATH, "//tr[contains(@class,'sub-head')]//th"))
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        clientTableHeaders = self.webdriver.find_elements(By.XPATH, "//tr[contains(@class,'sub-head')]//th")
        return [k.text for k in clientTableHeaders]

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)
