from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.EditField import EditField


class AllocationRow(BaseTestObject):
    pass


class RegularPaymentAllocationTable(BaseTestObject):
    @property
    def header(self):
        headerElement = self.element.find_element(By.XPATH, ".//thead")
        return AllocationRow(self.webdriver, headerElement, By.XPATH, ".//th")

    # pylint: disable=E1120
    @property
    def dataRows(self) -> list[AllocationRow]:
        dataHolder = self.element.find_element(By.XPATH, ".//tbody")
        elemements = dataHolder.find_elements(By.XPATH, ".//tr")
        return [AllocationRow(self.webdriver, self.webdriver, k) for k in elemements]

    @property
    def allocationTablePrePopulatedPercentageEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, "//div[contains(@class,'controls-percentage')]//input")

    @property
    def allocationTablePrePopulatedPercentageThirdPartyEditField(self):
        return EditField(self.webdriver, self.element, By.XPATH, "(//div[contains(@class,'controls-percentage')]//input)[2]")
