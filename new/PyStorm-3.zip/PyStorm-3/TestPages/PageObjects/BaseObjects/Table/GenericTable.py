import operator
from retry import retry
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject, PyStormElement
from TestPages.PageObjects.BaseObjects.Table import TableConst
from TestPages.PageObjects.BaseObjects.Table.GenericTablePagination import GenericTablePagination
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseAccountRestrictionUpdateProcesses import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableFooter import TableFooter
from TestPages.WebDriver import ExpectedConditions as EC

PARAM_COLUMN_NAME = "columnName"
PARAM_VALUE = "value"
PARAM_COMPARISON_OPERATOR = "comparisonOperator"
PARAM_USE_PAGINATION = "usePagination"
PARAM_ROW_FIELD_NAME = "rowFieldName"
PARAM_DATETIME_STAMP = "dateTimeStamp"
PARAM_REVERSE_ORDER = "reverseOrder"
PARAM_PROPERTY_NAME = "valuePropertyName"
PARAM_TEXT_PROPERTY_NAME = "textPropertyName"
PARAM_TABLE_FILTERS = "tableFilters"

ARG_DATE_CREATED = "dateCreated"


class TableFilter:
    def __init__(self,
                 columnName: str,
                 value: str,
                 cellValueComparisionType: operator = operator.eq):

        self.columnName = columnName
        self.value = value
        self.cellValueComparisionType = cellValueComparisionType

    def getPrintable(self):
        return f"{self.columnName}({self.cellValueComparisionType.__qualname__}) with {self.value}({self.cellValueComparisionType.__qualname__})"


class GenericTable(BaseTestObject):
    headerSectionLocator = (By.XPATH, ".//thead")
    headerCellLocator = (By.XPATH, ".//th[contains(@class, 'cell')]")
    dataLocator = (By.XPATH, ".//tbody")
    FOOTER_LOCATOR = (By.XPATH, ".//tfoot")
    rowLocator = (By.XPATH, ".//tr")
    rowType = None

    # to accommodate those tables where first row is header
    firstRowIsHeader = False

    # To handle the generic pagination
    paginationLocator = None

    def _getIndexFromColumn(self, **kwargs):
        columnName: str = kwargs.get(PARAM_COLUMN_NAME, "")
        comparisonOperator: operator = kwargs.get(PARAM_COMPARISON_OPERATOR, operator.eq)

        matchingColumns = [k for k in self.headers if comparisonOperator(k.lower(), columnName.lower())]
        if matchingColumns:
            return self.headers.index(matchingColumns[0])
        raise UIException(f"Column '{columnName}' not found.")

    def _getRowsMatchingColumnName(self, rows: list[GenericBaseRow], **kwargs):
        """
        Determine column index from column name
        return rows where value matches expected value in the Column
        """
        value: str = kwargs.get(PARAM_VALUE, "")
        comparisonOperator: operator = kwargs.get(PARAM_COMPARISON_OPERATOR, operator.eq)

        columnIndex = self._getIndexFromColumn(**kwargs)

        results = []
        dataRow: GenericBaseRow
        for dataRow in rows:
            cellElement: PyStormElement = dataRow.getCell(columnIndex)

            if cellElement and comparisonOperator(cellElement.text, value):
                results.append(dataRow)

        return results

    @retry(exceptions=(StaleElementReferenceException, UIException), delay=2, tries=5)
    def _getRowsByColumn(self, **kwargs):
        """
        kwarg args:
         - columnName: str,
         - value: str,
         - comparisonOperator i.e. operator.eq

        Method makes an attempt to find matching rows for provided parameters
        1. Find matching column in column headers
        2. Find row in data with matched value in expected column
        Default comparison is a full match
        Optionally can use operator.contains to perform less strict comparison

        If pagination is available and no matching rows are found, it will try to navigate to the next page
        """
        dataRows = self.dataRows
        orderByColumnName = kwargs.get("orderByColumnName")
        usePagination = kwargs.get(PARAM_USE_PAGINATION, False)

        if kwargs.get("reverseOrder"):
            # flips the order to find first match checking from the last
            dataRows.reverse()

        foundRows = self._getRowsMatchingColumnName(dataRows, **kwargs)

        # Use pagination if available
        if not foundRows and usePagination and self.paginationLocator:
            if self.paginationListbox.navigateToNextPage():
                return self._getRowsByColumn(**kwargs)  # olumnName, value, comparisonOperator, orderByColumnName=orderByColumnName, usePagination=usePagination)

        if orderByColumnName:
            sortByColumnIndex = self._getIndexFromColumn(**kwargs) if orderByColumnName else None
            if sortByColumnIndex:
                return sorted(foundRows, key=lambda x: x.getCell(sortByColumnIndex))
        return foundRows

    @retry(exceptions=(StaleElementReferenceException, UIException), delay=2, tries=5)
    def _getRowsByTableRowPropertyName(self, **kwargs):  # rowPropertyName, textToCompare, fieldTypeName, comparisonOperator=operator.eq, usePagination=False):
        """
        rowPropertyName - relates to field name in row class
        fieldTypeName - either text or value

        If pagination is available and no matching rows are found, it will try to navigate to the next page
        """
        rowPropertyName = kwargs.get("rowPropertyName")
        fieldTypeName = kwargs.get("fieldTypeName")

        comparisonOperator = kwargs.get(PARAM_COMPARISON_OPERATOR)
        textToCompare = kwargs.get(PARAM_VALUE)
        usePagination = kwargs.get(PARAM_USE_PAGINATION)

        foundRows = []
        for dataRow in self.dataRows:
            fieldObj = getattr(dataRow, rowPropertyName)
            if isinstance(fieldObj, BaseTestObject):
                fieldText = getattr(fieldObj, fieldTypeName)
                if fieldText and comparisonOperator(fieldText, textToCompare):
                    foundRows.append(dataRow)
            elif isinstance(fieldObj, str):
                if fieldObj and comparisonOperator(fieldObj, textToCompare):
                    foundRows.append(dataRow)

        # Use pagination if available
        if not foundRows and usePagination and self.paginationLocator:
            if self.paginationListbox.navigateToNextPage():
                return self._getRowsByTableRowPropertyName(**kwargs)

        if len(foundRows) == 0:
            PrintMessage(f"Row with value: '{textToCompare}' in field '{rowPropertyName}' not found.", inStepMessage=True)

        return foundRows

    def _getRowsByFilter(self, tableFilters: list[TableFilter], **_):
        """
        retrieves row by using filter containing multiple column names and values
        tableFilter: {ColumnName: A, value: B, ColumnNamecomparisonOperator: C, ColumnValuecomparisonOperator: D}

        TODO: to expand to work with row fields via Text or Value
        """
        rows = self.dataRows
        for tableFilter in tableFilters:
            rows = self._getRowsMatchingColumnName(rows,
                                                   columnName=tableFilter.columnName,
                                                   value=tableFilter.value,
                                                   comparisonOperator=tableFilter.cellValueComparisionType)

        return rows

    @retry(exceptions=TimeoutException, tries=10)
    def waitForDataToRender(self, expectedMinimumRowCount=1, message=""):
        """
        Waits for at least expectedMinimumRowCount to appear
        """
        message = message if message else f"Waiting for table to contain at least {expectedMinimumRowCount} data row."
        waitCondition = EC.presence_of_all_elements_located(self.rowLocator, expectedMinimumRowCount)
        WebDriverWait(self.dataHolder, timeout=5).until(waitCondition, message)

    def getRows(self, **kwargs):
        """
        Common method to ask table for a row

        using columnName / valuePropertyName / textPropertyName are mutually exclusive, each drives a different code execution path

        :param in kwargs:
         - columnName - name of the column to check
         - valuePropertyName - name of the row class property - value type check
         - textPropertyName - name of the row class property - text type check
         - value
         - usePagination

        :param kwargs: Description
        """
        if PARAM_COLUMN_NAME in kwargs:
            return self._getRowsByColumn(**kwargs)

        if PARAM_PROPERTY_NAME in kwargs:
            return self._getRowsByTableRowPropertyName(rowPropertyName=kwargs.pop(PARAM_PROPERTY_NAME), fieldTypeName=TableConst.TYPE_VALUE, **kwargs)

        if PARAM_TEXT_PROPERTY_NAME in kwargs:
            return self._getRowsByTableRowPropertyName(rowPropertyName=kwargs.pop(PARAM_TEXT_PROPERTY_NAME), fieldTypeName=TableConst.TYPE_TEXT, **kwargs)

        if PARAM_TABLE_FILTERS in kwargs:
            return self._getRowsByFilter(**kwargs)

        return []

    def getRow(self, **kwargs):
        rows = self.getRows(**kwargs)

        if rows:
            return rows[0]

        # If no rows found and PARAM_USE_PAGINATION is set then:
        if kwargs.get(PARAM_USE_PAGINATION) and self.paginationLocator:
            if self.paginationListbox.navigateToNextPage():
                return self.getRow(**kwargs)
        return None

    def getFirstRowIndex(self):
        """
        Method used to exclude header row in dataRows property
        """
        return 1 if self.firstRowIsHeader else 0

    def getPrintable(self):
        toPrint = []
        for row in self.dataRows:
            toPrint.append(row.text)

        import json
        return json.dumps(toPrint, indent=2)

    @retry(exceptions=UIException, delay=2, tries=5)
    def getHeaders(self, cleanHeaders=False) -> list:
        """
        Retrieves the table headers.

        cleanHeaders (bool): If True, returns only the text before any newline character in each header cell.
                            If False, returns the full text of each header cell.
        """
        headerSection = self.element.find_element(*self.headerSectionLocator)
        if headerSection:
            if cleanHeaders:
                return [k.text.split('\n')[0] for k in headerSection.find_elements(*self.headerCellLocator)]
            return [k.text for k in headerSection.find_elements(*self.headerCellLocator)]
        raise UIException(f"Table headers not found with locator: '{self.headerCellLocator}'")

    def getFirstRow(self):
        if self.dataRows:
            return self.dataRows[0]
        return None

    def getLastRow(self):
        if self.dataRows:
            return self.dataRows[-1]
        return None

    @retry(exceptions=(StaleElementReferenceException, UIException), delay=2, tries=5)
    def getNewlyCreatedRows(self, **kwargs):
        """
        returns newly created row under assumption row contains DateTime or Date field
        See example in DealReviewDataRow.dateCreated

        args:
        dateTimeStamp - can be either DATE or DATETIME depending on row data
        """
        rowFieldName = kwargs.get(PARAM_ROW_FIELD_NAME, ARG_DATE_CREATED)
        dateOrTimeStamp = kwargs.get(PARAM_DATETIME_STAMP, "")

        self.waitForDataToRender()

        foundRows = [k for k in self.dataRows if getattr(k, rowFieldName) >= dateOrTimeStamp]

        if foundRows:
            PrintMessage(f"Found search result with current date-time: '{getattr(foundRows[0], rowFieldName)}'", inStepMessage=True)
            return foundRows

        errMsg = f"""Failed to find result with current date-time: '{dateOrTimeStamp}',
        found other '{[getattr(k, rowFieldName) for k in self.dataRows]}' items not matching criteria."""
        raise UIException(errMsg)

    def getNewlyCreatedRow(self, **kwargs):
        """
        returns newly created row under assumption row contains DateTime or Date field
        See example in DealReviewDataRow.dateCreated

        args:
        dateTimeStamp - can be either DATE or DATETIME depending on row data
        rowFieldName - relates to name of the field in rowType class
        """
        self.waitForDataToRender()

        if kwargs.get(PARAM_DATETIME_STAMP):
            return next(iter(self.getNewlyCreatedRows(**kwargs)), None)

        return max(self.dataRows, key=lambda x: getattr(x, kwargs.get(PARAM_ROW_FIELD_NAME, ARG_DATE_CREATED)))

    @property
    def dataHolder(self):
        if self.element is None:
            return None
        return self.element.find_element(*self.dataLocator) if self.dataLocator else self.element

    @property
    def headers(self) -> list:
        return self.getHeaders(cleanHeaders=False)

    @property
    def dataRows(self):
        dataHolder = self.dataHolder
        if dataHolder is None:
            return []

        allRows = dataHolder.find_elements(*self.rowLocator)

        # pylint: disable = not-callable
        return [self.rowType(self.webdriver, self.parentElement, allRows[index]) for index in range(len(allRows)) if index >= self.getFirstRowIndex()]

    @property
    def headerIndices(self):
        """
        Return the header indices as a dictionary where key is the header name and value is its index.
        """
        if not self.headers:
            raise UIException("No headers found.")
        return {header: index for index, header in enumerate(self.headers)}

    @property
    def paginationListbox(self):
        """
        Returns the pagination listbox if it exists, otherwise returns None.
        """
        return GenericTablePagination(self.webdriver, self.element, self.paginationLocator)

    @property
    def footer(self):
        return TableFooter(self.webdriver, self.element, *self.FOOTER_LOCATOR)
