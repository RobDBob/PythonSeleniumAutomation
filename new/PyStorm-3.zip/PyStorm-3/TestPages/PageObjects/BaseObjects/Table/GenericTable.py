import operator
from retry import retry
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject, PyStormElement
from TestPages.PageObjects.BaseObjects.Table import TableConst
from TestPages.PageObjects.BaseObjects.Table.GenericTablePagination import GenericTablePagination
from TestPages.PageObjects.BaseObjects.Table.Rows.AuthoriseAccountRestrictionUpdateProcesses import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableFooter import TableFooter
from TestPages.WebDriver import ExpectedConditions as EC


class TableFilter:
    def __init__(self, **kwargs):

        self.columnName = kwargs.get(TableConst.PARAM_COLUMN_NAME)
        self.propertyName = kwargs.get(TableConst.PARAM_PROPERTY_NAME)
        self.value = kwargs.get(TableConst.PARAM_VALUE)
        self.text = kwargs.get(TableConst.PARAM_TEXT)
        self.cellValueComparisionType = kwargs.get(TableConst.PARAM_COMPARISON_OPERATOR, operator.eq)

    def getPrintable(self):
        return f"{self.columnName}({self.cellValueComparisionType.__qualname__}) with {self.value}({self.cellValueComparisionType.__qualname__})"


class GenericTable(BaseTestObject):
    headerSectionLocator = (By.XPATH, ".//thead")
    headerCellLocator = (By.XPATH, ".//th[contains(@class, 'cell')]")
    dataLocator = (By.XPATH, ".//tbody")
    FOOTER_LOCATOR = (By.XPATH, ".//tfoot")
    rowLocator = (By.XPATH, ".//tr")
    rowType = None

    # to accommodate those tables where first row is header
    firstRowIsHeader = False

    # To handle the generic pagination
    paginationLocator = None

    def _getIndexFromColumn(self, **kwargs):
        columnName: str = kwargs.get(TableConst.PARAM_COLUMN_NAME, "")
        comparisonOperator: operator = kwargs.get(TableConst.PARAM_COMPARISON_OPERATOR, operator.eq)

        matchingColumns = [k for k in self.headers if comparisonOperator(k.lower(), columnName.lower())]
        if matchingColumns:
            return self.headers.index(matchingColumns[0])
        raise UIException(f"Column '{columnName}' not found.")

    def _getRowsMatchingColumnName(self, dataRows: list[GenericBaseRow], **kwargs):
        """
        Determine column index from column name
        return rows where value matches expected value in the Column

        read text or value from passed arguments, text has precendence as its more common
        """
        textValueToCompare: str = kwargs.get(TableConst.PARAM_TEXT, kwargs.get(TableConst.PARAM_VALUE, ""))
        comparisonOperator: operator = kwargs.get(TableConst.PARAM_COMPARISON_OPERATOR, operator.eq)

        columnIndex = self._getIndexFromColumn(**kwargs)

        results = []
        dataRow: GenericBaseRow
        for dataRow in dataRows:
            cellElement: PyStormElement = dataRow.getCell(columnIndex)

            if cellElement and comparisonOperator(cellElement.text, textValueToCompare):
                results.append(dataRow)

        return results

    def _getRowsByColumn(self, dataRows, **kwargs):
        """
        kwarg args:
         - columnName: str,
         - value: str,
         - comparisonOperator i.e. operator.eq

        Method makes an attempt to find matching rows for provided parameters
        1. Find matching column in column headers
        2. Find row in data with matched value in expected column
        Default comparison is a full match
        Optionally can use operator.contains to perform less strict comparison

        """
        orderByColumnName = kwargs.get("orderByColumnName")

        if kwargs.get("reverseOrder"):
            # flips the order to find first match checking from the last
            dataRows.reverse()

        foundRows = self._getRowsMatchingColumnName(dataRows, **kwargs)

        if orderByColumnName:
            sortByColumnIndex = self._getIndexFromColumn(**kwargs) if orderByColumnName else None
            if sortByColumnIndex:
                return sorted(foundRows, key=lambda x: x.getCell(sortByColumnIndex))
        return foundRows

    def _getRowsByTablepropertyName(self, dataRows, **kwargs):
        """
        propertyName - relates to field name in row class
        fieldTypeName - either text or value

        """
        propertyName = kwargs.get(TableConst.PARAM_PROPERTY_NAME)
        fieldTypeName = TableConst.PARAM_TEXT if TableConst.PARAM_TEXT in kwargs else TableConst.PARAM_VALUE
        textToCompare = kwargs.get(TableConst.PARAM_TEXT, kwargs.get(TableConst.PARAM_VALUE, ""))

        comparisonOperator = kwargs.get(TableConst.PARAM_COMPARISON_OPERATOR, operator.eq)

        foundRows = []
        for dataRow in dataRows:
            fieldObj = getattr(dataRow, propertyName)
            if isinstance(fieldObj, BaseTestObject):
                fieldText = getattr(fieldObj, fieldTypeName)
                if fieldText and comparisonOperator(fieldText, textToCompare):
                    foundRows.append(dataRow)
            elif isinstance(fieldObj, str):
                if fieldObj and comparisonOperator(fieldObj, textToCompare):
                    foundRows.append(dataRow)

        if len(foundRows) == 0:
            PrintMessage(f"Row with value: '{textToCompare}' in field '{propertyName}' not found.", inStepMessage=True)

        return foundRows

    def _getRowsByFilter(self, dataRows, tableFilters: list[TableFilter], **_):
        """
        retrieves row by using filter containing multiple column names and values
        tableFilter: {ColumnName: A, value: B, ColumnNamecomparisonOperator: C, ColumnValuecomparisonOperator: D}

        TODO: to expand to work with row fields via Text or Value
        """
        for tableFilter in tableFilters:
            rows = self._getRowsMatchingColumnName(dataRows,
                                                   columnName=tableFilter.columnName,
                                                   text=tableFilter.text,
                                                   value=tableFilter.value,
                                                   comparisonOperator=tableFilter.cellValueComparisionType)

        return rows

    @retry(exceptions=TimeoutException, tries=10)
    def waitForDataToRender(self, expectedMinimumRowCount=1, message=""):
        """
        Waits for at least expectedMinimumRowCount to appear
        retry must stay as it refreshes data to check via self.dataLocator
        """
        message = message if message else f"Waiting for table to contain at least {expectedMinimumRowCount} data row."
        waitCondition = EC.presence_of_all_elements_located(self.rowLocator, expectedMinimumRowCount)
        WebDriverWait(self.dataHolder, timeout=5).until(waitCondition, message)

    @retry(exceptions=(StaleElementReferenceException, UIException), delay=2, tries=5)
    def getRows(self, **kwargs):
        """
        Common method to ask table for a row

        using columnName / valuePropertyName / textPropertyName are mutually exclusive, each drives a different code execution path

        :param in kwargs:
         - columnName - name of the column to check
         - valuePropertyName - name of the row class property - value type check
         - textPropertyName - name of the row class property - text type check
         - value

        :param kwargs: Description
        """
        dataRows = self.dataRows
        if TableConst.PARAM_COLUMN_NAME in kwargs:
            return self._getRowsByColumn(dataRows, **kwargs)

        if TableConst.PARAM_PROPERTY_NAME in kwargs:
            return self._getRowsByTablepropertyName(dataRows, **kwargs)

        if TableConst.PARAM_TABLE_FILTERS in kwargs:
            return self._getRowsByFilter(dataRows, **kwargs)

        return []

    def getRow(self, **kwargs):
        rows = self.getRows(**kwargs)

        if rows:
            return rows[0]

        # If no rows found and PARAM_USE_PAGINATION is set then:
        if kwargs.get(TableConst.PARAM_USE_PAGINATION) and self.paginationLocator:
            if self.paginationListbox.navigateToNextPage():
                return self.getRow(**kwargs)
        return None

    def getFirstRowIndex(self):
        """
        Method used to exclude header row in dataRows property
        """
        return 1 if self.firstRowIsHeader else 0

    def getPrintable(self):
        toPrint = []
        for row in self.dataRows:
            toPrint.append(row.text)

        import json
        return json.dumps(toPrint, indent=2)

    @retry(exceptions=UIException, delay=2, tries=5)
    def getHeaders(self, cleanHeaders=False) -> list:
        """
        Retrieves the table headers.

        cleanHeaders (bool): If True, returns only the text before any newline character in each header cell.
                            If False, returns the full text of each header cell.
        """
        headerSection = self.element.find_element(*self.headerSectionLocator)
        if headerSection:
            if cleanHeaders:
                return [k.text.split('\n')[0] for k in headerSection.find_elements(*self.headerCellLocator)]
            return [k.text for k in headerSection.find_elements(*self.headerCellLocator)]
        raise UIException(f"Table headers not found with locator: '{self.headerCellLocator}'")

    def getFirstRow(self):
        if self.dataRows:
            return self.dataRows[0]
        return None

    def getLastRow(self):
        if self.dataRows:
            return self.dataRows[-1]
        return None

    @retry(exceptions=(StaleElementReferenceException, UIException), delay=2, tries=5)
    def getNewlyCreatedRows(self, **kwargs):
        """
        returns newly created row under assumption row contains DateTime or Date field
        See example in DealReviewDataRow.dateCreated

        args:
        dateTimeStamp - can be either DATE or DATETIME depending on row data
        """
        propertyName = kwargs.get(TableConst.PARAM_PROPERTY_NAME, TableConst.ARG_DATE_CREATED)
        dateOrTimeStamp = kwargs.get(TableConst.PARAM_DATETIME_STAMP, "")

        self.waitForDataToRender()

        foundRows = [k for k in self.dataRows if getattr(k, propertyName) >= dateOrTimeStamp]

        if foundRows:
            PrintMessage(f"Found search result with current date-time: '{getattr(foundRows[0], propertyName)}'", inStepMessage=True)
            return foundRows

        errMsg = f"""Failed to find result with current date-time: '{dateOrTimeStamp}',
        found other '{[getattr(k, propertyName) for k in self.dataRows]}' items not matching criteria."""
        raise UIException(errMsg)

    def getNewlyCreatedRow(self, **kwargs):
        """
        returns newly created row under assumption row contains DateTime or Date field
        See example in DealReviewDataRow.dateCreated

        args:
        dateTimeStamp - can be either DATE or DATETIME depending on row data
        propertyName - relates to name of the field in rowType class
        """
        self.waitForDataToRender()

        if kwargs.get(TableConst.PARAM_DATETIME_STAMP):
            return next(iter(self.getNewlyCreatedRows(**kwargs)), None)

        return max(self.dataRows, key=lambda x: getattr(x, kwargs.get(TableConst.PARAM_PROPERTY_NAME,
                                                                      TableConst.ARG_DATE_CREATED)))

    @property
    def dataHolder(self):
        if self.element is None:
            return None
        return self.element.find_element(*self.dataLocator) if self.dataLocator else self.element

    @property
    def headers(self) -> list:
        return self.getHeaders(cleanHeaders=False)

    @property
    def dataRows(self):
        dataHolder = self.dataHolder
        if dataHolder is None:
            return []

        allRows = dataHolder.find_elements(*self.rowLocator)

        # pylint: disable = not-callable
        return [self.rowType(self.webdriver, self.parentElement, allRows[index]) for index in range(len(allRows)) if index >= self.getFirstRowIndex()]

    @property
    def headerIndices(self):
        """
        Return the header indices as a dictionary where key is the header name and value is its index.
        """
        if not self.headers:
            raise UIException("No headers found.")
        return {header: index for index, header in enumerate(self.headers)}

    @property
    def paginationListbox(self):
        """
        Returns the pagination listbox if it exists, otherwise returns None.
        """
        return GenericTablePagination(self.webdriver, self.element, self.paginationLocator)

    @property
    def footer(self):
        return TableFooter(self.webdriver, self.element, *self.FOOTER_LOCATOR)
