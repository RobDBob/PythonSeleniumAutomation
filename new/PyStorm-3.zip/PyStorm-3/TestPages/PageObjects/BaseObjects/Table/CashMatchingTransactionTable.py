from TestPages.Admin.Cash.ShowDetailPopUpTransactionDetailsPage import ShowDetailPopUpTransactionDetailsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class CashMatchingBankTransactionTableRow(GenericBaseRow):
    def navigateToTransactionDetailPage(self):
        self.showDetailsButton.click()
        return ShowDetailPopUpTransactionDetailsPage(self.webdriver)

    @property
    def showDetailsButton(self):
        return Button(self.webdriver, self.webdriver, self.getCell(1))

    @property
    def unmatchedItemsCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, self.getCell(6))
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox
