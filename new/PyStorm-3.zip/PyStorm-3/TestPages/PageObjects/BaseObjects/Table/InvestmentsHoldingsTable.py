from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.InvestmentHoldingsTable import InvestmentHoldingsTable
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class InvestmentsHoldingsTable(GenericTable):
    rowType = InvestmentHoldingsTable
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = None
    rowLocator = (By.XPATH, ".//tbody")

    def getCurrentInvestmentHoldings(self):
        return [(k.productNameLabel.text + " " + k.accountNameLabel.text) for k in self.dataRows]

    def getInvestmentHoldingsTableProductView(self, holdingsName) -> InvestmentHoldingsTable:
        """
        holdingsName: main holding name i.e. ['Personal Portfolio', 'Cash Account']
        """
        matchingData = [subTable for subTable in self.dataRows if holdingsName in (subTable.productNameLabel.text + " " + subTable.accountNameLabel.text)]
        if matchingData:
            return matchingData[0]
        PrintMessage(f"Investment holding not found: {holdingsName}")
        return None

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def offPlatformInvestmentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//tr[@class='product-heading sipp']//following-sibling::tr//span[@class='header opi']")
