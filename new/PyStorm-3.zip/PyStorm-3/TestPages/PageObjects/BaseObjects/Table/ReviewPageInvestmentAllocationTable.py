from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import compareText
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions


class ReviewPageInvestmentAllocationRow(BaseTestObject):
    @property
    def investmentName(self):
        """
        If Cash, then label
        If anything else, then hyperlink
        """
        cellLocator = (By.XPATH, ".//td")
        if self.element.find_elements(*cellLocator) and self.element.find_elements(*cellLocator)[0].text == "Cash":
            return Label(self.webdriver, self.element, *cellLocator)
        if self.element.find_elements(*cellLocator) and not self.element.find_elements(*cellLocator)[0].get_attribute("class") == "hyperlink":
            return Label(self.webdriver, self.element, *cellLocator)
        return Label(self.webdriver, self.element, By.XPATH, ".//a[@class='hyperlink']")

    @property
    def allocationPercentage(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class='cell-right']")

    @property
    def allocationSingleLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class='cell-right'][1]")

    @property
    def allocationRegularLabel(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class='cell-right'][2]")


class ReviewPageInvestmentAllocationTable(BaseTestObject):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def selectInvestment(self, investmentName):
        PrintMessage(f"Selecting investment row : '{investmentName}'")
        matchingRows = [k for k in self.dataRows if compareText(k.investmentName.text, investmentName)]
        if matchingRows:
            return matchingRows[0]
        return None

    def getAllInvestmentsDetails(self):
        return {k.investmentName.text: int(k.allocationPercentage.text) for k in self.dataRows}

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[ReviewPageInvestmentAllocationRow]:
        """
        Either
        Rows can be found - rows exist, then wait for ID property to show up
        Rows cannot be found:
             - rows do not exist
             - rows failed to load in time
        """
        dataHolder = self.element.find_element(*self.dataLocator)

        valueWaiter = ExpectedConditions.attribute_present_in_one_of_elements(self.rowLocator, "id")
        WebDriverWait(dataHolder, 10).until(valueWaiter)

        return [ReviewPageInvestmentAllocationRow(self.webdriver, dataHolder, By.XPATH,
                                                  f".//tr[@id='{k.get_attribute('id')}']") for k in dataHolder.find_elements(*self.rowLocator)]
