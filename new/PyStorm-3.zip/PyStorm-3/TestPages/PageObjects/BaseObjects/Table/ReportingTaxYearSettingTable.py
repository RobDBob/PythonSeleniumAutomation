from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class ReportingTaxYearSettingRow(BaseTestObject):
    @property
    def rowValue(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td/div")


class ReportingTaxYearSettingTable(BaseTestObject):
    headerLocator = (By.XPATH, ".//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[ReportingTaxYearSettingRow]:
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [ReportingTaxYearSettingRow(self.webdriver, dataHolder, By.XPATH, f".//tr[{k}]") for k in range(1, len(rows) + 1)]
