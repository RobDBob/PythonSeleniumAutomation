from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label


class BulkClientsAccountTableRow(BaseTestObject):
    @property
    def accountName(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//table[@class= 'data-table table-grid-view']//tr[1]//td[1]")

    @property
    def accountId(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//table[@class= 'data-table table-grid-view']//tr[1]//td[2]")

    @property
    def product(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Product']")

    @property
    def modelPortfolio(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Model Portfolio']")

    @property
    def quantity(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Quantity']")

    @property
    def marketValue(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Market Value (GBP)']")

    @property
    def estimatedSellValue(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Estimated Sell Value']")

    @property
    def discretionary(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Discretionary']")

    @property
    def nonDiscretionary(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Non-Discretionary']")

    @property
    def executionOnly(self):
        return Label(self.webdriver, self.element, By.XPATH, "//td[text()='Execution Only']")
