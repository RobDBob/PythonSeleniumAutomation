from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ParentOrLegalGuardianTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def clientNameLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=0))

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def assignedAdviserLabel(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=2))

    @property
    def addClientLinkButton(self):
        return Button(self.parentElement, self.parentElement, By.XPATH, ".//button[@class='secondary-add-button']//span")
