from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class IncomeRowEdit(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def productText(self):
        return self.getCell(index=0).text

    @property
    def incomeOptionText(self):
        return self.getCell(index=1).text


class ManageIncomeTable(BaseTestObject):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def getRowByProduct(self, productName) -> IncomeRowEdit:
        PrintMessage(f"ManageIncomeEditTable. Selecting '{productName}' by productName", inStepMessage=True)
        productToSelect = [k for k in self.dataRows if k.productText == productName]

        if productToSelect:
            return productToSelect[0]
        PrintMessage(f"SearchSummaryAccountTable. Product not found, available products to select are {[k.productText for k in self.dataRows]}", inStepMessage=True)
        return None

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[IncomeRowEdit]:
        dataHolder = self.element.find_element(*self.dataLocator)
        allRows = dataHolder.find_elements(*self.rowLocator)
        return [IncomeRowEdit(self.webdriver, self.parentElement, k) for k in allRows]
