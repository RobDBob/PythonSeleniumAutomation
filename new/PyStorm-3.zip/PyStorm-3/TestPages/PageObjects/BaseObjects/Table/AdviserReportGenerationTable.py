from datetime import datetime
from retry import retry
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class AdviserReportReportRow(GenericBaseRow):
    @property
    def reportLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//td[1]")

    @property
    def criteriaLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//td[2]")

    @property
    def requestDateTime(self):
        """
        Code assumes date format in Request Time column unchanged and as: 19-Jun-23 1:18 pm
        """
        dateTimeFormat = "%d-%b-%y %I:%M %p"
        dateLabel = Label(self.webdriver, self.parentElement, By.XPATH, ".//td[3]")
        dateTimeStamp = datetime.strptime(dateLabel.text, dateTimeFormat)
        return dateTimeStamp

    @property
    @retry(exceptions=UIException, delay=5, tries=2)
    def status(self):
        statusLabel = Label(self.webdriver, self.parentElement, By.XPATH, ".//td[4]")
        hyperlinkElements = statusLabel.find_elements(By.XPATH, ".//a")
        if hyperlinkElements:
            return hyperlinkElements[0]
        raise UIException("Report hyperlink not available")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, ".//td[4]")


class AdviserReportGenerationTable(GenericTable):
    @property
    def header(self):
        headerElement = self.element.find_element(By.XPATH, ".//thead")
        return AdviserReportReportRow(self.webdriver, self.webdriver, headerElement)

    @property
    def dataRows(self) -> list[AdviserReportReportRow]:
        dataHolder = self.element.find_element(By.XPATH, ".//tbody")
        elements = dataHolder.find_elements(By.XPATH, ".//tr")
        return [AdviserReportReportRow(self.webdriver, self.webdriver, k) for k in elements]
