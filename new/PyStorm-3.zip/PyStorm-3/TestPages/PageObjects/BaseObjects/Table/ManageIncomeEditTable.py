from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader


class IncomeRowEdit(BaseTestObject):
    @property
    def product(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td[@class]")

    @property
    def incomeOption(self):
        dropdown = DropdownListbox(self.webdriver, self.element, By.XPATH, ".//select[@id]", (By.XPATH, ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown


class ManageIncomeEditTable(BaseTestObject):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[IncomeRowEdit]:
        dataHolder = self.element.find_element(*self.dataLocator)
        allRows = dataHolder.find_elements(*self.rowLocator)
        return [IncomeRowEdit(self.webdriver, self.webdriver, k) for k in allRows if "none" not in k.get_attribute('style')]
