from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.BulkClientsAccountTableRow import BulkClientsAccountTableRow
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions as EC


class BulkConfirmationTabTable(BaseTestObject):
    headerLocator = (By.XPATH, "//tr[@class='sub-head']")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def bulkSellConfirmationClientTableHeaders(self):
        tableHeaderLocators = (By.XPATH, "//tr[contains(@class,'sub-head')]//td")
        valueWaiter = EC.visibility_of_all_elements_located(tableHeaderLocators)
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        clientTableHeaders = self.webdriver.find_elements(*tableHeaderLocators)
        return [k.text for k in clientTableHeaders]

    def bulkSwitchConfirmationClientsTableHeaders(self):
        tableHeaderLocators = (By.XPATH, "(//tr[contains(@class,'sub-head')])[2]//td")
        valueWaiter = EC.visibility_of_all_elements_located(tableHeaderLocators)
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        clientTableHeaders = self.webdriver.find_elements(*tableHeaderLocators)
        return [k.text for k in clientTableHeaders]

    def bulkSwitchTableHeaders(self):
        tableHeaderLocators = (By.XPATH, "//table[@class='data-table table-grid-view mb-30']//tr[@class='sub-head']//td")
        valueWaiter = EC.visibility_of_all_elements_located(tableHeaderLocators)
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        clientTableHeaders = self.webdriver.find_elements(*tableHeaderLocators)
        return [k.text for k in clientTableHeaders]

    @property
    def header(self):
        """
        Data header
        :return:
        """
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[BulkClientsAccountTableRow]:
        """
        Find all visible row elements
        Extract row ids
        Use rowIds to create list of row instances with identified locators
        Approach where row elements store locators instead of live element is preferable.
        """
        dataHolder = self.element.find_element(*self.dataLocator)
        rows = dataHolder.find_elements(*self.rowLocator)
        return [BulkClientsAccountTableRow(self.webdriver, dataHolder, By.XPATH, f".//tr[@id='{k.get_attribute('id')}']") for k in rows]

    @property
    def titleOfbulkSwitchTable(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[contains(text(),'Bulk Switch')]")

    @property
    def titleOfClientsTable(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Clients']")

    @property
    def discretionaryRadioButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//tr[@class='odd']//label)[1]")

    @property
    def nonDiscretionaryRadioButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//tr[@class='odd']//label)[2]")

    @property
    def executionOnlyRadioButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//tr[@class='odd']//label)[3]")
