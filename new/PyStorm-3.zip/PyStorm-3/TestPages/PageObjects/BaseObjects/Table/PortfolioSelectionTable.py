from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import compareText
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.TableHeader import TableHeader
from TestPages.WebDriver import ExpectedConditions


class PortfolioSelectionRow(BaseTestObject):
    @property
    def portfolioName(self):
        return Label(self.webdriver, self.element, By.XPATH, ".//td//td")

    @property
    def selectButton(self):
        return Button(self.webdriver, self.element, By.XPATH, ".//td/a/span")


class PortfolioSelectionTable(BaseTestObject):
    headerLocator = (By.XPATH, "//thead")
    dataLocator = (By.XPATH, ".//tbody")
    rowLocator = (By.XPATH, ".//tr")

    def selectPortfolio(self, portfolioName):
        PrintMessage(f"Selecting Portfolio row : '{portfolioName}'")
        matchingRows = [k for k in self.dataRows if compareText(k.portfolioName.text, portfolioName)]
        if matchingRows:
            matchingRows[0].selectButton.click()

    @property
    def header(self):
        return TableHeader(self.webdriver, self.element, *self.headerLocator)

    @property
    def dataRows(self) -> list[PortfolioSelectionRow]:
        """
        Either
        Rows can be found - rows exist, then wait for ID property to show up
        Rows cannot be found:
             - rows do not exist
             - rows failed to load in time
        """
        dataHolder = self.element.find_element(*self.dataLocator)

        valueWaiter = ExpectedConditions.attribute_present_in_one_of_elements(self.rowLocator, "id")
        WebDriverWait(dataHolder, 10).until(valueWaiter)

        return [PortfolioSelectionRow(self.webdriver,
                                      dataHolder,
                                      By.XPATH,
                                      f".//tr[@id='{k.get_attribute('id')}']") for k in dataHolder.find_elements(*self.rowLocator)]
