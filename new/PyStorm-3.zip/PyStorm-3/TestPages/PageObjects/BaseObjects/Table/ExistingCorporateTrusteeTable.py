from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow


class ExistingCorporateTrusteeTableRow(GenericBaseRow):
    CELL_LOCATOR = (By.XPATH, ".//td")

    @property
    def companyName(self):
        cellElement = self.getCell(index=0)
        return Label(self.webdriver, self.webdriver, cellElement)

    @property
    def companyType(self):
        return Label(self.webdriver, self.parentElement, self.getCell(index=1))

    @property
    def addClientLink(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[@class='secondary-add-button']//span")
