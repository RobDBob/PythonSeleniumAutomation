from selenium.webdriver.common.by import By
from CommonCode.Driver.PyStormElement import PyStormElement
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject


class Button(BaseTestObject):
    @property
    def isActive(self):
        """
        Some buttons when clicked, become active i.e. active class is added to element
        This property indicates if button was already clicked
        :return:
        """
        self.waitForElement()
        return 'active' in self.element.get_attribute('class')

    @property
    def isInputDisabled(self):
        self.waitForElement()
        return bool(self.inputTypeElement.get_attribute('disabled'))

    @property
    def inputTypeElement(self) -> PyStormElement:
        """
        input type element for RadioButton - it holds checked property
        Returns the input element that is child of the current element.
        """
        return self.element.find_element(By.XPATH, ".//input")
