from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button


class AdvisorSideMenu(BaseTestObject):
    def __init__(self, webdriver, parentElement):
        super().__init__(webdriver, parentElement, By.XPATH, "//ul[@class='main-items']")

    @property
    def dashboardButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, ".//button[text()='Dashboard']")

    @property
    def clientsButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, ".//button[text()='Clients']")

    @property
    def businessManagementButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, ".//button[text()='Business management']")

    @property
    def toolsAndLiteratureButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, ".//button[text()='Tools and literature']")

    @property
    def adminButton(self):
        return Button(self.webdriver, self.parentElement, By.CLASS_NAME, "item.admin")
