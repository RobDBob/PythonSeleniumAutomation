from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label


class ClientsAdvancedSearchTab(ClientsBaseTab):
    def wait(self):
        self.advancedQueryButton.waitForElement()

    @property
    def labelAdviser(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']")

    @property
    def adviserSearchDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']/parent::div/parent::div//select")

    @property
    def goButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='btn primary ' and text()='Go']")

    @property
    def advancedQueryButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@class='text']/parent::button")
