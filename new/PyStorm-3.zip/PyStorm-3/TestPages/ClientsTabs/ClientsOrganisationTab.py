from retry import retry
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ClientsTabs.OrganisationSearchCriteria import OrganisationSearchCriteria
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ClientsOrganisationTab(ClientsBaseTab):
    SEARCH_BUTTON_LOCATOR = "//button[@class='btn primary mb-0 ' and text()='Search']"
    SEARCH_BUTTON_BUSY_LOCATOR = "//button[@class='btn primary mb-0 is-busy']"

    def wait(self):
        self.waitTab(self.organisationButton)

    @retry(exceptions=NoSuchElementException, delay=2, tries=5)
    def _clickSearchAndWait(self):
        self.searchButton.click()

        try:
            # wait for element to be in busy state
            valueWaiter = EC.presence_of_element_located((By.XPATH, self.SEARCH_BUTTON_BUSY_LOCATOR))
            WebDriverWait(self.webdriver, 5).until(valueWaiter)
        except TimeoutException:
            pass

        # wait for element to be no longer in is-busy state
        valueWaiter = EC.presence_of_element_located((By.XPATH, self.SEARCH_BUTTON_LOCATOR))
        WebDriverWait(self.webdriver, 60).until(valueWaiter)

    def organisationSearchAndSelect(self,
                                    searchCriteria: OrganisationSearchCriteria,
                                    expectedPageToOpen=None):
        """
        searchCriteria: is an object with search criteria
        organisationName: expected item to be found and select
        expectedPageToOpen: In case there is other page after finding account expected to open i.e other than search summary
        """
        table: SearchResultsTable = self.getSearchTable(searchCriteria)
        foundRow = table.getRowByOrganisationName(searchCriteria.organisationName)

        if foundRow:
            foundRow.name.click()
            if expectedPageToOpen:
                return expectedPageToOpen(self.webdriver)
            from TestPages.ClientsTabs.SearchResults.AccountsActivityTabPage import AccountsActivityTabPage
            return AccountsActivityTabPage(self.webdriver)
        raise UIException(f"No results found for {searchCriteria.organisationName}")

    def getSearchTable(self, searchCriteria: OrganisationSearchCriteria):
        """
        This method works with assumption when only search result table needs to be return
        """
        if searchCriteria.network:
            self.networkSmartSearchEdit.enterValue(searchCriteria.network)
            PrintMessage(f"organisationSearch by searchCriteria.network: {searchCriteria.network}")
        if searchCriteria.company:
            self.companySmartSearchEdit.searchAndSelect(searchCriteria.company)
            PrintMessage(f"organisationSearch by searchCriteria.company: {searchCriteria.company}")
        if searchCriteria.organisationName:
            self.nameSearchEditField.enterValue(searchCriteria.organisationName)
            PrintMessage(f"organisationSearch by searchCriteria.organisationName: {searchCriteria.organisationName}")
        if searchCriteria.accountNumber:
            self.accountnumberSearchEditField.enterValue(searchCriteria.accountNumber)
            PrintMessage(f"organisationSearch by searchCriteria.accountNumber: {searchCriteria.accountNumber}")
        if searchCriteria.status:
            self.statusSearchDropdown.selectOption(searchCriteria.status)
            PrintMessage(f"organisationSearch by searchCriteria.status: {searchCriteria.status}")
        if searchCriteria.organisationType:
            self.organisationtypeSearchDropdown.selectOption(searchCriteria.organisationType)
            PrintMessage(f"organisationSearch by searchCriteria.organisationType: {searchCriteria.organisationType}")
        if searchCriteria.adviser:
            self.adviserSearchDropdown.selectOption(searchCriteria.adviser)
            PrintMessage(f"organisationSearch by searchCriteria.adviser: {searchCriteria.adviser}")

        self._clickSearchAndWait()
        return SearchResultsTable(self.webdriver, self.webdriver, By.CLASS_NAME, "ctable-scrollpane")

    @property
    def labelName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name']")

    @property
    def labelAccountNumber(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']")

    @property
    def labelStatus(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Status']")

    @property
    def labelAdviser(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']")

    @property
    def labelOrganisationType(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Organisation type']")

    @property
    def nameSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name']/parent::div/parent::div//input")

    @property
    def accountnumberSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']/parent::div/parent::div//input")

    @property
    def statusSearchDropdown(self):
        dropDown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Status']/parent::div/parent::div//select",
            optionsLocator=(
                By.TAG_NAME,
                "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def adviserSearchDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']/parent::div/parent::div//select")

    @property
    def organisationtypeSearchDropdown(self):
        locator = "//label[text()='Organisation type']/parent::div/parent::div//select"
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def searchButton(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//button[@class='btn primary mb-0 ' and text()='Search']")
