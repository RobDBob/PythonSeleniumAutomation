from enum import Enum


class CustomerStatus(Enum):
    All = 0
    Active = 2
    Prospect = 3
    Inactive = 4
    Deceased = 5


class AccountRole(Enum):
    All = 0
    Individual = 1
    Joint = 2
    Trustee = 30
    Setlor = 31
    Beneficiary = 32


class Adviser(Enum):
    All = 1


class OrganisationType(Enum):
    All = 1
    Trust = 2
    CorporateTrust = 3
    Company = 4
