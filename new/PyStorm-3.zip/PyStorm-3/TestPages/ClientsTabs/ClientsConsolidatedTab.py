from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable


class ClientsConsolidatedTab(ClientsBaseTab):
    def wait(self):
        self.waitTab(self.consolidatedButton)

    def enterConsolidatedAccountNumberAndSearch(self, accountNumber):
        self.accountNumberSearchEditField.enterValue(accountNumber)
        self.searchButton.click()
        return SearchResultsTable(self.webdriver, self.webdriver, By.CLASS_NAME, "ctable-scrollpane")

    def searchAndSelect(self, accountNumber):
        foundRow = None
        searchResultTable = self.enterConsolidatedAccountNumberAndSearch(accountNumber)
        foundRows = searchResultTable.dataRows
        if foundRows:  # method can be refined to add more validation for selection
            foundRow = foundRows[0]
        if foundRow is not None:
            foundRow.name.click()
        self.currentSelectedTabButton.waitForElement()
        return self.getCurrentTabPage()

    @property
    def labelName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name']")

    @property
    def labelAccountNumber(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']")

    @property
    def labelStatus(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Status']")

    @property
    def labelAdviser(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']")

    @property
    def nameSearchInput(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name']/parent::div/parent::div//input")

    @property
    def accountNumberSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']/parent::div/parent::div//input")

    @property
    def statusSearchDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "(//label[text()='Status']/parent::div/parent::div//select)",
                                   optionsLocator=(
                                       By.TAG_NAME,
                                       "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def adviserSearchDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "(//label[text()='Adviser']/parent::div/parent::div//select)",
                                   optionsLocator=(
                                       By.TAG_NAME,
                                       "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def searchButton(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//button[@class='btn primary mb-0 ' and text()='Search']")
