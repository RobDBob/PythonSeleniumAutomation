from datetime import date
from CommonCode.DictionaryCaseInsensitive import DictionaryCaseInsensitive
from TestPages import DataEnums
from TestPages.ClientsTabs.SearchCriteriaOptions import AccountRole, CustomerStatus


# pylint: disable=too-many-instance-attributes
# pylint: disable=too-many-function-args
# pylint: disable=line-too-long
class IndividualSearchCriteria:
    def __init__(self, data=None):
        self.dataDict = DictionaryCaseInsensitive()
        if not data:
            return

        for key in data:
            if DataEnums.ACCOUNT_ROLE.lower() == key.lower():
                self.accountRole = data[key]
            elif DataEnums.STATUS.lower() == key.lower():
                self.status = data[key]
            else:
                self.dataDict[key] = data[key]

    def getAPIQueryParamsAsString(self, currentPage=1, pageSize=40) -> str:
        """
        Returns a parametrized query string for API request
        """
        unformatted = "customerId={0}&customerStatus={1}&firstName={2}&lastName={3}&dateOfBirth={4}&taxIdentifier={5}&clAccountId={6}&customerRole={07}&entityId={8}&entityType={9}&visibleToAdviserId={10}&currentPage={11}&pageSize={12}"
        return unformatted.format("", self.statusValue, self.firstName, self.surname, self.dateOfBirth, "",
                                  self.accountNumber, self.accountRoleValue, "", "", "", currentPage, pageSize)

    def getPrintable(self):
        toPrint = {}
        for key in self.dataDict:
            value = self.dataDict.get(key)
            if value and isinstance(value, (str, int, float, dict, list)):
                toPrint[key] = value
            elif isinstance(value, date):
                toPrint[key] = str(value)
            elif value:
                toPrint[key] = value.name
        import json
        return json.dumps(toPrint, indent=2)

    def returnValue(self, key, defaultValue=""):
        if key in self.dataDict:
            return self.dataDict[key]
        return defaultValue

    @property
    def network(self):
        return self.returnValue(DataEnums.NETWORK)

    @property
    def company(self):
        return self.returnValue(DataEnums.COMPANY)

    @property
    def firstName(self):
        return self.returnValue(DataEnums.FIRST_NAME)

    @property
    def surname(self):
        return self.returnValue(DataEnums.SURNAME)

    @property
    def accountNumber(self):
        return self.returnValue(DataEnums.ACCOUNT_NUMBER)

    @property
    def adviser(self):
        return self.returnValue(DataEnums.ADVISER)

    @property
    def dateOfBirth(self):
        return self.returnValue(DataEnums.DOB)

    @property
    def accountRole(self):
        return self.returnValue(DataEnums.ACCOUNT_ROLE, AccountRole.Individual).name

    @property
    def status(self):
        return self.returnValue(DataEnums.STATUS, CustomerStatus.Active).name

    @property
    def accountRoleValue(self):
        return self.returnValue(DataEnums.ACCOUNT_ROLE, AccountRole.Individual).value

    @property
    def statusValue(self):
        return self.returnValue(DataEnums.STATUS, CustomerStatus.Active).value

# Setters

    @network.setter
    def network(self, newValue):
        self.dataDict[DataEnums.NETWORK] = newValue

    @company.setter
    def company(self, newValue):
        self.dataDict[DataEnums.COMPANY] = newValue

    @firstName.setter
    def firstName(self, newValue):
        self.dataDict[DataEnums.FIRST_NAME] = newValue

    @surname.setter
    def surname(self, newValue):
        self.dataDict[DataEnums.SURNAME] = newValue

    @accountNumber.setter
    def accountNumber(self, newValue):
        self.dataDict[DataEnums.ACCOUNT_NUMBER] = newValue

    @adviser.setter
    def adviser(self, newValue):
        self.dataDict[DataEnums.ADVISER] = newValue

    @dateOfBirth.setter
    def dateOfBirth(self, newValue):
        self.dataDict[DataEnums.DOB] = newValue

    @accountRole.setter
    def accountRole(self, newValue):
        valueToSet = None

        if isinstance(newValue, str):
            match newValue.lower():
                case "all":
                    valueToSet = AccountRole.All
                case "individual":
                    valueToSet = AccountRole.Individual
                case "joint":
                    valueToSet = AccountRole.Joint
                case "trustee":
                    valueToSet = AccountRole.Trustee
                case "setlor":
                    valueToSet = AccountRole.Setlor
                case "beneficiary":
                    valueToSet = AccountRole.Beneficiary
                case _:
                    valueToSet = AccountRole.Individual
        else:
            valueToSet = newValue

        self.dataDict[DataEnums.ACCOUNT_ROLE] = valueToSet

    @status.setter
    def status(self, newValue: CustomerStatus):
        valueToSet = None

        if isinstance(newValue, str):
            match newValue.lower():
                case "all":
                    valueToSet = CustomerStatus.All
                case "active":
                    valueToSet = CustomerStatus.Active
                case "deceased":
                    valueToSet = CustomerStatus.Deceased
                case _:
                    valueToSet = CustomerStatus.All
        else:
            valueToSet = newValue

        self.dataDict[DataEnums.STATUS] = valueToSet
