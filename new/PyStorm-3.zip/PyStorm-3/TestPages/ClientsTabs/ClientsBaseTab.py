from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.Enums.ClientTabEnum import ClientTabEnum
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.SmartSearchEdit import SmartSearchEdit
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class ClientsBaseTab(PlatformPage):
    def waitTab(self, buttonElement: Button):
        valueWaiter = EC.text_value_in_attribute_in_element(buttonElement.element, "class", "primary")
        WebDriverWait(self.webdriver, 30).until(valueWaiter)

    @retry(exceptions=(UIException, TimeoutException), delay=15, tries=5)
    def selectTabAndWait(self, tab: ClientTabEnum):
        allTabElements = self.webdriver.find_elements(By.XPATH, "//button[@role='tab']")
        matchingTabElements = [Button(self.webdriver, self.webdriver, k) for k in allTabElements if k.text == tab.name]
        if matchingTabElements:
            PrintMessage(f"Switching to {tab.name} Tab.", inStepMessage=True)
            matchingTabElements[0].click()
            valueWaiter = EC.text_value_in_attribute_in_element(matchingTabElements[0].element, "aria-selected", "true")
            WebDriverWait(self.webdriver, 30).until(valueWaiter)
        else:
            raise UIException(f"Expected tab: '{tab.name}' not found")

    def navigateToTab(self, tab: ClientTabEnum):
        self.closeHintDialogIfPresent()
        self.selectTabAndWait(tab)
        return self.getCurrentTabPage(tab.name)

    def navigateToClientsConsolidatedSearchPage(self):
        from TestPages.ClientsTabs.ClientsConsolidatedTab import ClientsConsolidatedTab
        self.consolidatedButton.click()
        return ClientsConsolidatedTab(self.webdriver)

    def navigateToClientsAdvancedSearchPage(self):
        from TestPages.ClientsTabs.ClientsAdvancedSearchTab import ClientsAdvancedSearchTab
        self.advancedsearchButton.click()
        return ClientsAdvancedSearchTab(self.webdriver)

    def navigateToIndividualTab(self):
        from TestPages.ClientsTabs.ClientsIndividualTab import ClientsIndividualTab
        self.navigateToClientsPage()
        self.clientsButton.click()
        return ClientsIndividualTab(self.webdriver)

    def navigateToOrganisationTab(self):
        from TestPages.ClientsTabs.ClientsOrganisationTab import ClientsOrganisationTab
        self.organisationButton.click()
        return ClientsOrganisationTab(self.webdriver)

    def getCurrentTabPage(self, tabName=None):
        if not tabName:
            tabName = self.currentSelectedTabButton.text

        match tabName:
            case ClientTabEnum.Summary.name:
                from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
                return AccountSummaryTabPage(self.webdriver)
            case ClientTabEnum.Investments.name:
                from TestPages.ClientsTabs.SearchResults.AccountsInvestmentsTabPage import AccountsInvestmentsTabPage
                return AccountsInvestmentsTabPage(self.webdriver)
            case ClientTabEnum.Performance.name:
                from TestPages.ClientsTabs.SearchResults.AccountsPerformanceTabPage import AccountsPerformanceTabPage
                return AccountsPerformanceTabPage(self.webdriver)
            case ClientTabEnum.Insights.name:
                from TestPages.ClientsTabs.SearchResults.AccountsInsightsTabPage import AccountsInsightsTabPage
                return AccountsInsightsTabPage(self.webdriver)
            case ClientTabEnum.Transactions.name:
                from TestPages.ClientsTabs.SearchResults.AccountsTransactionsTabPage import AccountsTransactionsTabPage
                return AccountsTransactionsTabPage(self.webdriver)
            case ClientTabEnum.Activity.name:
                from TestPages.ClientsTabs.SearchResults.AccountsActivityTabPage import AccountsActivityTabPage
                return AccountsActivityTabPage(self.webdriver)
            case ClientTabEnum.Documents.name:
                from TestPages.ClientsTabs.SearchResults.AccountsDocumentsTabPage import AccountsDocumentsTabPage
                return AccountsDocumentsTabPage(self.webdriver)
            case ClientTabEnum.Roles.name:
                from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
                return AccountsRolesTabPage(self.webdriver)
            case ClientTabEnum.ESG.name:
                from TestPages.ClientsTabs.SearchResults.AccountsESGTabPage import AccountsESGTabPage
                return AccountsESGTabPage(self.webdriver)
            case _:
                return None

    @property
    def currentSelectedTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@aria-selected='true']")

    @property
    def networkSmartSearchEdit(self):
        return SmartSearchEdit(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//div[@class='form-group search-form']//label[@for='Network']/parent::div/parent::div")

    @property
    def companySmartSearchEdit(self):
        smartSearch = SmartSearchEdit(self.webdriver, self.webdriver, By.XPATH,
                                      "//div[@class='form-group search-form']//label[@for='Company']/parent::div/parent::div")
        smartSearch.searchResultToSelectLocator = (By.XPATH, ".//li//div//button[text()='{0}']")
        return smartSearch

    @property
    def networkLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Network']")

    @property
    def companyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Company']")

    @property
    def clientsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(@class, 'square') and text()='Clients']")

    @property
    def consolidatedButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Consolidated']")

    @property
    def organisationButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Organisation']")

    @property
    def advancedsearchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Advanced search']")
