from TestPages.ClientsTabs.SearchCriteriaOptions import CustomerStatus, OrganisationType


# pylint: disable=R0902
class OrganisationSearchCriteria:
    network = ""
    company = ""
    organisationName = ""
    accountNumber = ""
    _status: CustomerStatus = None
    _organisationType: OrganisationType = None
    adviser = ""

    def __init__(self, data=None):
        if data:
            self.updateData(data)

    def updateData(self, incData: dict):
        self.network = incData.get("network", "")
        self.company = incData.get("company", "")
        self.organisationName = incData.get("organisationName", "")
        self.accountNumber = incData.get("accountNumber", "")
        self.status = incData.get("status", CustomerStatus.Active)
        self.organisationType = incData.get("organisationType", OrganisationType.Company)
        self.adviser = incData.get("adviser", "")

    @property
    def organisationType(self):
        return self._organisationType.name if self._organisationType else ""

    # pylint: disable=C0123
    @organisationType.setter
    def organisationType(self, newValue):
        if type(newValue) == OrganisationType:
            self._organisationType = newValue
        if type(newValue) == str:
            match newValue.lower():
                case "all":
                    self._organisationType = OrganisationType.All
                case "trust":
                    self._organisationType = OrganisationType.Trust
                case "corporatetrust":
                    self._organisationType = OrganisationType.CorporateTrust
                case "company":
                    self._organisationType = OrganisationType.Company

    @property
    def status(self):
        return self._status.name if self._status else ""

    @status.setter
    def status(self, newValue):
        if isinstance(newValue, CustomerStatus):
            self._status = newValue
        elif isinstance(newValue, str):
            match newValue.lower():
                case "all":
                    self._status = CustomerStatus.All
                case "active":
                    self._status = CustomerStatus.Active
                case "prospect":
                    self._status = CustomerStatus.Prospect
                case "inactive":
                    self._status = CustomerStatus.Inactive
