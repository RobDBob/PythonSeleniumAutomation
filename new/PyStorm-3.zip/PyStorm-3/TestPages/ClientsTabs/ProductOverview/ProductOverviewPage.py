from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ArrangementRow import ArrangementRow
from TestPages.PlatformPage import PlatformPage


class ProductOverviewPage(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.backToSummaryButton.waitForText(PageEnums.BackToSummary)
        self.closeHintDialogIfPresent()

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToProductInformationTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductInformationTab import ProductInformationTab
        self.productInformationTabButton.click()
        return ProductInformationTab(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToTransfersAndReregistrationPage(self):
        from TestPages.TransfersAndReregistrationsPage import TransfersAndReregistrationsPage
        self.pendingTransfer.click()
        return TransfersAndReregistrationsPage(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToProductPaymentInTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductPaymentInTab import ProductPaymentInTab
        self.paymentInTabButton.jsClick()
        return ProductPaymentInTab(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToProductValuationAndIncomeTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductValuationAndIncomeTab import ProductValuationAndIncomeTab
        self.valuationAndIncomeTabButton.jsClick()
        return ProductValuationAndIncomeTab(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=3)
    def navigateToProductWithdrawalsTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductWithdrawalsTab import ProductWithdrawalsTab
        self.withdrawalsTabButton.click()
        return ProductWithdrawalsTab(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToProductChargesTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductChargesTab import ProductChargesTab
        self.chargesTabButton.click()
        return ProductChargesTab(self.webdriver)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToProductDrawdownTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductDrawdownTab import ProductDrawdownTab
        self.drawdownTabButton.click()
        return ProductDrawdownTab(self.webdriver)

    def cancelActiveReularPaymentsAndNavigateToProductPaymentTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductPaymentInTab import ProductPaymentInTab
        self.cancelRegularPayment.click()
        self.cancelRegularPaymentYesButton.click()
        return ProductPaymentInTab(self.webdriver)

    @property
    def paymentInTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Payments in']")

    @property
    def valuationAndIncomeTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Valuation and income']")

    @property
    def withdrawalsTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Withdrawals']")

    @property
    def chargesTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Charges']")

    @property
    def productInformationTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Product information']")

    @property
    def cancelRegularPayment(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def cancelRegularPaymentYesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Yes']")

    @property
    def noRegularPaymentsAvailable(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='No regular payment(s) currently set up for this client']")

    @property
    def pendingTransfer(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transfers']//following-sibling::div//a[text()=' pending transfer']")

    @property
    def drawdownTabButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Drawdown']")

    @property
    def viewInvestmentsLinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View investments']")

    @property
    def arrangementTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table asset-class-table mb-0']")
        table.waitForDataToRender()
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.rowType = ArrangementRow
        return table

    @property
    def flexibleDrawdownTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//h3[text()='Flexible drawdown']//following-sibling::div//table[contains(@class,'table-subtle')]")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.waitForDataToRender()
        return table
