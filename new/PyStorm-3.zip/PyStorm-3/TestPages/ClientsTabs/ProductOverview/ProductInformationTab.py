from retry import retry
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ClientsTabs.ProductOverview.EditBeneficiariesPopupPage import EditBeneficiariesPopupPage
from TestPages.ClientsTabs.ProductOverview.EditProductStatusPopupPage import EditProductStatusPopupPage
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable, TableFilter
from TestPages.PageObjects.BaseObjects.Table.Rows.BeneficiariesRow import BeneficiariesRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ProductInformationTab(ProductOverviewPage):
    def wait(self):
        self.productInformationTabButton.waitForElement()
        waitCondition = EC.text_value_in_attribute_in_element(self.productInformationTabButton.element, "aria-selected", "true")
        WebDriverWait(self.webdriver, 10).until(waitCondition)
        self.productInformationLabel.waitForText(PageEnums.ProductInformationTitle)

    def navigateToManageIncomePage(self):
        from TestPages.ClientsTabs.ProductOverview.ManageIncomePage import ManageIncomePage
        self.viewOrEditIncomeButton.click()
        return ManageIncomePage(self.webdriver)

    def navigateToEditProductStatusPopupPage(self):
        self.editProductStatusButton.click(jsClick=True)
        return EditProductStatusPopupPage(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']")

    def navigateToEditBeneficiariesPopupPage(self):
        self.beneficiariesEditPencilButton.click()
        return EditBeneficiariesPopupPage(self.webdriver)

    def navigateToDocumentsTabPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountsDocumentsTabPage import AccountsDocumentsTabPage
        self.documentLibraryButton.click()
        return AccountsDocumentsTabPage(self.webdriver)

    @retry(exceptions=(UIException), delay=10, tries=4)
    def waitExpectedBeneficiaryRowToMatchFilter(self, tableRecordFilters: list[TableFilter]):
        """
        Returns row with expected state described in the filter
        """
        PrintMessage(f"Waiting for 'Expected Beneficiary' row to be in state: {[k.getPrintable() for k in tableRecordFilters]}", inStepMessage=True)
        matchingRow = self.beneficiariesTable.getRow(tableFilters=tableRecordFilters)

        if not matchingRow:
            raise UIException(f"waitForExpectedBeneficiaryRowToMatchFilter > Expected '{[k.getPrintable() for k in tableRecordFilters]}'")

    @property
    def beneficiariesTable(self):
        table = GenericTable(self.webdriver,
                             self.webdriver,
                             By.XPATH,
                             "//h2[text()='Beneficiaries']/parent::div/parent::div/following-sibling::div/div/div/table")
        table.rowType = BeneficiariesRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def documentLibraryButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Document library']")

    @property
    def beneficiariesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Beneficiaries']")

    @property
    def benficiariesLastEditedLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Beneficiaries']/parent::div/parent::div/following-sibling::div/p")

    @property
    def beneficiariesEditPencilButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit Beneficiaries']/preceding-sibling::span")

    @property
    def beneficiariesProportionTableLabel(self):
        return Label(self.webdriver,
                     self.webdriver,
                     By.XPATH,
                     "//div[text()='Any completed Aberdeen SIPP Death Benefits Nomination form or other scheme member instructions can be viewed in the']")

    @property
    def beneficiariesLastUpdatedSectionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Last updated : N/A']")

    @property
    def beneficiariesToolTipContentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Beneficiaries']/following-sibling::div/div/div[@class='tooltip-content-panel']")

    @property
    def beneficiariesToolTipButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Beneficiaries']/parent::div/div/button")

    @property
    def beneficiariesCurrentlyNoSetupLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='No beneficiaries are currently set up for the pension.']")

    @property
    def viewOrEditIncomeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='hyperlink' and text()='View or edit income']")

    @property
    def productInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def productInformationTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-subtle pt-10 pb-10']")

    @property
    def editProductInformationButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit product name']")

    @property
    def manageIncomeTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-subtle pt-10 pb-25']")

    @property
    def editProductStatusButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit Product Status']//parent::button")
