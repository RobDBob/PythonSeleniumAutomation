from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable, TableFilter
from TestPages.PageObjects.BaseObjects.Table.Rows.EditBeneficiaryRow import EditBeneficiaryRow


class EditBeneficiariesPopupPage(ProductOverviewPage):
    @retry(exceptions=(TimeoutException), delay=2, tries=2)
    def wait(self):
        self.editBeneficiariesLabel.waitForText(PageEnums.EDIT_BENEFICIARIES)

    def navigateToEditBeneficiaryRemovePopupPage(self, editBeneficiaryRow: EditBeneficiaryRow):
        from TestPages.ClientsTabs.ProductOverview.EditBeneficiariesRemoveRowPopupPage import EditBeneficiariesRemoveRowPopupPage
        editBeneficiaryRow.removeButton.jsClick()
        return EditBeneficiariesRemoveRowPopupPage(self.webdriver)

    def setEditBeneficiariesType(self, editBeneficiaryDatas: list):
        for editBeneficiaryData in editBeneficiaryDatas:
            if editBeneficiaryData.get(DataEnums.BENEFICIARY_TYPE, "") == PageEnums.INDIVIDUAL:
                self.setBeneficiaryTypeIndividual(editBeneficiaryData)

            elif editBeneficiaryData.get(DataEnums.BENEFICIARY_TYPE, "") == PageEnums.CHARITY:
                self.setBeneficiaryTypeCharity(editBeneficiaryData)

            elif editBeneficiaryData.get(DataEnums.BENEFICIARY_TYPE, "") == PageEnums.Trust:
                self.setBeneficiaryTypeTrust(editBeneficiaryData)
            self.editBeneficiariesTypeSaveButton.click()

    def setBeneficiaryTypeCharity(self, editBeneficiaryData: dict):
        if editBeneficiaryData.get(DataEnums.NAME_OF_ORGANIZATION, ""):
            self.editBeneficiariesCharityNameOfOrganizationEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.NAME_OF_ORGANIZATION))
        if editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE, ""):
            self.editBeneficiariesCharityProportionPercentageEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE))

    def setBeneficiaryTypeTrust(self, editBeneficiaryData: dict):
        if editBeneficiaryData.get(DataEnums.NAME_OF_TRUST, ""):
            self.editBeneficiariesTrustNameOfTrustEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.NAME_OF_TRUST))
        if editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE, ""):
            self.editBeneficiariesTrustProportionPercentageEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE))

    def setBeneficiaryTypeIndividual(self, editBeneficiaryData: dict):
        if editBeneficiaryData.get(DataEnums.TITLE, ""):
            self.editBeneficiariesIndividualTitleDropdown.selectOption(editBeneficiaryData.get(DataEnums.TITLE))
        if editBeneficiaryData.get(DataEnums.FIRST_NAME, ""):
            self.editBeneficiariesIndividualFirstNameEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.FIRST_NAME))
        if editBeneficiaryData.get(DataEnums.SURNAME, ""):
            self.editBeneficiariesIndividualSurNameEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.SURNAME))
        if editBeneficiaryData.get(DataEnums.DOB):
            self.editBeneficiariesIndividualdateOfBirthEditField.dateEdit.forceClearValue()
            self.editBeneficiariesIndividualdateOfBirthEditField.specify_date(editBeneficiaryData.get(DataEnums.DOB))
        if editBeneficiaryData.get(DataEnums.GENDER, "") == PageEnums.MALE:
            self.editBeneficiariesIndividualMaleRadioButton.click()
        elif editBeneficiaryData.get(DataEnums.GENDER, "") == PageEnums.FEMALE:
            self.editBeneficiariesIndividualFemaleRadioButton.click()
        if editBeneficiaryData.get(DataEnums.RELATIONSHIP, ""):
            self.editBeneficiariesIndividualRelationshipDropdown.selectOption(editBeneficiaryData.get(DataEnums.RELATIONSHIP))
        if editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE, ""):
            self.editBeneficiariesIndividualProportionPercentageEditField.clearEnterValue(editBeneficiaryData.get(DataEnums.PROPORTION_PERCENTAGE))

    def editBenficiaryIndividualCompleteSetUp(self, testData: list):
        self.editBeneficiariesAddNewButton.click()
        self.editBeneficiariesIndividualButton.click()
        self.setBeneficiaryTypeIndividual(testData[DataEnums.EDIT_BENEFICIARY][0])
        self.editBeneficiariesTypeSaveButton.click()
        self.editBeneficiariesSubmitButton.click()

    @retry(exceptions=(UIException), delay=10, tries=4)
    def waitExpectedEditBeneficiaryRowToMatchFilter(self, tableRecordFilters: list[TableFilter]):
        """
        Returns row with expected state described in the filter
        """
        PrintMessage(f"Waiting for 'Expected Beneficiary' row to be in state: {[k.getPrintable() for k in tableRecordFilters]}", inStepMessage=True)
        matchingRow = self.editBeneficiariesTable.getRow(tableFilters=tableRecordFilters)

        if not matchingRow:
            raise UIException(f"waitForExpectedBeneficiaryRowToMatchFilter > Expected '{[k.getPrintable() for k in tableRecordFilters]}'")

    @property
    def editBeneficiariesTable(self):
        table = GenericTable(self.webdriver,
                             self.webdriver,
                             By.XPATH,
                             "//h1[text()='Edit beneficiaries']/parent::div/following-sibling::div//table")
        table.rowType = EditBeneficiaryRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def editBeneficiariesIndividualButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Individual']/parent::label")

    @property
    def editBeneficiariesCharityButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Charity']/parent::label")

    @property
    def editBeneficiariesTrustButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Trust']/parent::label")

    @property
    def editBeneficiariesAddNewLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Add new']")

    @property
    def editBeneficiariesSubmitLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Submit']")

    @property
    def editBeneficiariesCancelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def editBeneficiariesAddNewButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Add new']")

    @property
    def editBeneficiariesSubmitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Submit']")

    @property
    def editBeneficiariesCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def editBeneficiariesPopUpTextLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//div[@class='content']/div)[1]")

    @property
    def editBeneficiariesIndividualTitleDropdown(self):
        locator = "//label[text()='Title']/parent::div/following-sibling::div/select"
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def editBeneficiariesIndividualFirstNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesIndividualSurNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesIndividualdateOfBirthEditField(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']//parent::div//following-sibling::div")

    @property
    def editBeneficiariesIndividualMaleRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Male']/parent::label")

    @property
    def editBeneficiariesIndividualFemaleRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Female']/parent::label")

    @property
    def editBeneficiariesIndividualRelationshipDropdown(self):
        locator = "//label[text()='Relationship']/parent::div/following-sibling::div/select"
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver, By.XPATH, locator, optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def editBeneficiariesIndividualProportionPercentageEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesTypeSaveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Save']")

    @property
    def editBeneficiariesTypeCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def editBeneficiariesTypeSubmitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Submit']")

    @property
    def editBeneficiariesIndividualTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Title']")

    @property
    def editBeneficiariesIndividualFirstNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']")

    @property
    def editBeneficiariesIndividualSurNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']")

    @property
    def editBeneficiariesIndividualDateOfBirthLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']")

    @property
    def editBeneficiariesIndividualGenderLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Gender']")

    @property
    def editBeneficiariesIndividualMaleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Male']")

    @property
    def editBeneficiariesIndividualFemaleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Female']")

    @property
    def editBeneficiariesIndividualRelationshipLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Relationship']")

    @property
    def editBeneficiariesIndividualProportionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']")

    @property
    def editBeneficiariesTableEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit']/parent::button")

    @property
    def editBeneficiariesTableDeleteButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Delete']/parent::button")

    @property
    def editBeneficiariesPercentageProportionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='The total proportion must be 100%']")

    @property
    def editBeneficiariesCharityNameOfOrganizationEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name of organization']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesCharityNameOfOrgainzationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name of organization']")

    @property
    def editBeneficiariesCharityProportionPercentageEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesCharityProportionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']")

    @property
    def editBeneficiariesTrustNameOfTrustEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name of Trust']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesTrustProportionPercentageEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']/parent::div/following-sibling::div/input")

    @property
    def editBeneficiariesTrustNameOfTrustLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Name of Trust']")

    @property
    def editBeneficiariesTrustProportionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Proportion (%)']")

    @property
    def editBeneficiariesTypeHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Type']")

    @property
    def editBeneficiariesNameHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Name']")

    @property
    def editBeneficiariesRelationShipHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Relationship']")

    @property
    def editBeneficiariesProportionHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Proportion']")

    @property
    def editBeneficiariesLastUpdatedHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Last updated']")

    @property
    def editBeneficiariesEditHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Edit']")

    @property
    def editBeneficiariesRemoveHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th/span[text()='Remove']")

    @property
    def editBeneficiariesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Edit beneficiaries']")

    @property
    def editBeneficiariesCharityPopupTextMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h1[text()='Edit beneficiaries']/parent::div/following-sibling::div/div/p)[1]")

    @property
    def editBeneficiariesNominationFormPopupTextMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h1[text()='Edit beneficiaries']/parent::div/following-sibling::div/div/p)[2]")

    @property
    def totalProportionPercentageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//td[text()='Total']/following-sibling::td//p")
