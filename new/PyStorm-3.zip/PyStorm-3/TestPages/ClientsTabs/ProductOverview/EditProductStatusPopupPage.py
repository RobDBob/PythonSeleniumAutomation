from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label


class EditProductStatusPopupPage(BaseTestObject):
    def wait(self):
        self.editProductstatusLabel.waitForText(PageEnums.EDIT_PRODUCT_STATUS)

    def setProductStatusAndReturnToBasePage(self, status):
        from TestPages.ClientsTabs.ProductOverview.ProductInformationTab import ProductInformationTab
        self.statusDropdown.selectOption(status)
        self.statusDropdown.waitForSelectedOption(status)
        self.applyButton.click(jsClick=True)
        return ProductInformationTab(self.webdriver)

    @property
    def editProductstatusLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']//h2")

    @property
    def statusDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.parentElement,
            By.XPATH,
            "//div[@class='inner']//label[text()='Status']//parent::div//following-sibling::div//select",
            (By.XPATH,
             ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def applyButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inner']//button[text()='Apply']")
