import random
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from TestPages import PageEnums
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.ManageIncomeEditTable import ManageIncomeEditTable
from TestPages.PageObjects.BaseObjects.Table.ManageIncomeTable import ManageIncomeTable


class ManageIncomePage(ProductOverviewPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ManageIncomeTitle)

    def modifyIncomeOfFirstRow(self):
        """
        Updates income settings of a first product to any other new value
        """
        self.edit.click()

        if not self.editIncomeTable.dataRows:
            raise UIException("No records found in ManageIncome page")

        selectedRow = self.editIncomeTable.dataRows[0]
        selectedRow.incomeOption.clickDropdown()
        avilableOptions = selectedRow.incomeOption.getAvailableOptionsAsText()
        currentIncomeOption = selectedRow.incomeOption.selectedOption
        # remove currently selected option from pool of options
        avilableOptions.pop(avilableOptions.index(currentIncomeOption))
        newOption = random.choice(avilableOptions)
        selectedRow.incomeOption.selectOption(newOption)

        changeRecord = {"ProductName": self.editIncomeTable.dataRows[0].product.text,
                        "PreviousIncomeOption": currentIncomeOption, "CurrentIncomeOption": newOption}

        self.save.click()

        # refresh browser as income table does not render after save
        self.webdriver.refresh()

        return changeRecord

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def edit(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@name='btnEdit']")

    @property
    def save(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@name='btnSave']")

    @property
    def editIncomeTable(self):
        return ManageIncomeEditTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")

    @property
    def incomeTable(self):
        return ManageIncomeTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
