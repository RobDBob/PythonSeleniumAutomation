from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ProductValuationAndIncomeTab(ProductOverviewPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//h2[text()='Valuation summary']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        self.valuationSummaryTable.waitForElement()

    @property
    def valuationSummaryLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Valuation summary']")

    @property
    def valuationSummaryChartTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='highcharts-container ml-auto mr-auto']")

    @property
    def valuationSummaryTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//table[@class='data-table asset-class-table mb-0']")
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def valuationDetailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Valuation detail']")

    @property
    def savingsPotTable(self):
        table = GenericTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "(//h3[text()='Savings pot']//following-sibling::div//table)[1]")
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def flexibleDrawdownTable(self):
        table = GenericTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h3[text()='Flexible drawdown']//following-sibling::div//table[@class='table-subtle table-first-last-cell-padding-reset']")
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def incomeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Income']")

    @property
    def incomePaymentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Income payments']")

    @property
    def incomePaymentsDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/..//following-sibling::div//select[@class='form-input']")

    @property
    def totalIncomePanelTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-total-income']")

    @property
    def nextIncomePaymentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Next income payment']")

    @property
    def nextIncomePaymentEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit next income payment']")

    @property
    def nextIncomePaymentTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//h3[text()='Next income payment']/../../..//following-sibling::div//table")
        table.headerSectionLocator = (By.XPATH, ".//tbody//tr")
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def viewBreakdownOfIncomeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View breakdown of income']")

    @property
    def cancelIncomePaymentButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel income payment']")
