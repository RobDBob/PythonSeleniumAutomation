from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class UpdatePensionProtectionDetailsPopupPage(ProductOverviewPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//h1"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def updatePensionProtectionDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Update Pension Protection Details']")

    @property
    def pensionProtectionDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Pension protection']")

    @property
    def popupPageFieldsetLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//fieldset[@class='' and not(@disabled)]")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='close-btn']")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Save']")
