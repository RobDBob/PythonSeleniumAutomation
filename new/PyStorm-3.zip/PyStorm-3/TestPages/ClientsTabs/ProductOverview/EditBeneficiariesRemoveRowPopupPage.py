from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ClientsTabs.ProductOverview.ProductInformationTab import ProductInformationTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class EditBeneficiariesRemoveRowPopupPage(ProductInformationTab):
    def wait(self):
        self.deleteBeneficiaryRowLabel.waitForText(PageEnums.ARE_YOU_SURE_WANT_TO_DELETE_THIS_BENEFICIARY)

    @property
    def deleteBeneficiaryRowLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Are you sure you want to delete this beneficiary?']")

    @property
    def deleteBeneficiaryButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Delete']")

    @property
    def deleteBeneficiaryCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")
