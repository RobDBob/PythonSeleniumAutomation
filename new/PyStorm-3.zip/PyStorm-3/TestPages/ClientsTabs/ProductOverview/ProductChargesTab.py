from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ProductChargesTab(ProductOverviewPage):
    def wait(self):
        self.chargesTabButton.click()
        waitCondition = EC.text_value_in_attribute_in_element(self.chargesTabButton.element, "aria-selected", "true")
        WebDriverWait(self.webdriver, 10).until(waitCondition)

        waitCondition = EC.presence_of_element_located((By.XPATH, "//h1[text()='Charges']"))
        WebDriverWait(self.webdriver, 10).until(waitCondition)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToMaintainAdviserChargingPage(self):
        from TestPages.Wizards.MaintainAdviserChargingWizard import MaintainAdviserChargingWizard
        self.editOngoingAdviserChargeButton.jsClick()
        return MaintainAdviserChargingWizard(self.webdriver)

    @property
    def chargesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Charges']")

    @property
    def chargeDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Charges details']")

    @property
    def chargesTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-subtle pt-0']")

    @property
    def editOngoingAdviserChargeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit ongoing adviser charge']")

    @property
    def viewChargesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='View charges']")

    @property
    def viewTermsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='View terms']")

    @property
    def portfolioManagerFeeTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-subtle row-higher']")

    @property
    def autoDisinvestmentStrategyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Auto-disinvestment strategy']")

    @property
    def autoDisinvestmentStrategyEditIconButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Edit'and not(@disabled)]")

    @property
    def autoDisinvestmentStrategyTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Auto-disinvestment strategy']//following-sibling::div[@class='panel-subtle']")

    @property
    def editStrategyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit account disinvestment strategy']")

    @property
    def drawdownPriceLockLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Drawdown Price Lock']")

    @property
    def drawdownPriceLockTable(self):
        return SearchResultsTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//table[@class='table-subtle table-first-last-cell-padding-reset has-first-cell-highlighted mb-15 row-higher']")

    @property
    def familyLinkingValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//th[text()='Family linking']//following-sibling::td")
