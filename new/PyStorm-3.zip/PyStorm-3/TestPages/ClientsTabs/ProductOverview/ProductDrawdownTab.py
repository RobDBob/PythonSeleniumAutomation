from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ProductDrawdownAndIncomeHistoryTableRow import ProductDrawdownAndIncomeHistoryTableRow
from TestPages.WebDriver import ExpectedConditions as EC


class ProductDrawdownTab(ProductOverviewPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//h2[text()='Allowance details']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @retry(exceptions=TimeoutException, delay=1, tries=2)
    def navigateToUpdatePensionProtectionDetailsPopupPage(self):
        from TestPages.ClientsTabs.ProductOverview.UpdatePensionProtectionDetailsPopupPage import UpdatePensionProtectionDetailsPopupPage
        self.protectionDetailsEditIconButton.click()
        return UpdatePensionProtectionDetailsPopupPage(self.webdriver)

    @property
    def allowanceDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Allowance details']")

    @property
    def drawdownTableLsaUsedDataLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th[text()='LSA Used']//parent::*//td")

    @property
    def drawdownTableLsdbaUsedDataLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//th[text()='LSDBA Used']//parent::*//td")

    @property
    def protectionDetailsEditIconButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='edit-circle-icon-button label-sr-only ml-5']")

    @property
    def updateAllowanceDetailsHyperlinkButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Update Allowance Details']")

    @property
    def regularDrawdownDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Regular drawdown details']")

    @property
    def regularDrawdownDetailsEditIconButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@title='Edit']")

    @property
    def activeTailoredDrawdownInstructionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Active tailored drawdown instructions']")

    @property
    def drawdownHistoryLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Drawdown history']")

    @property
    def dateDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/../..//select[@class='form-input']")

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Search']")

    @property
    def drawdownAndIncomeHistoryTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//table[@class='table-subtle table-first-last-cell-padding-reset data-table']")
        table.rowType = ProductDrawdownAndIncomeHistoryTableRow
        table.headerCellLocator = (By.XPATH, ".//th")
        return table
