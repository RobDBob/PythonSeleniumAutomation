from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.ClientsTabs.SearchResults.AccountsTransactionsTabPage import AccountsTransactionsTabPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable, TableFilter
from TestPages.PageObjects.BaseObjects.Table.Rows.CompletedInstructionsRow import CompletedInstructionsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.CurrentRegularPaymentInstructionsRow import CurrentRegularPaymentInstructionsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.ExpectedSinglePaymentsRow import ExpectedSinglePaymentsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.ExpectedTransfersRow import ExpectedTransfersRow
from TestPages.PageObjects.BaseObjects.Table.Rows.ProductTransfersInRow import ProductTransfersInRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.ProductWizards.ABERDEENJSIPPEditRegularPaymentInPage import ABERDEENJSIPPEditRegularPaymentInPage
from TestPages.ProductWizards.ABERDEENSIPPEditRegularPaymentInPage import ABERDEENSIPPEditRegularPaymentInPage
from TestPages.WebDriver import ExpectedConditions as EC
from TestPages.Wizards.ProductWizards.AbrdnSIPPPaymentsInWizard import AbrdnSIPPPaymentsInWizard


class ProductPaymentInTab(ProductOverviewPage):
    def wait(self):
        self.paymentInTabButton.click()
        waitCondition = EC.text_value_in_attribute_in_element(self.paymentInTabButton.element, "aria-selected", "true")
        WebDriverWait(self.webdriver, 10).until(waitCondition)

    @retry(exceptions=TimeoutException, delay=5, tries=2)
    def reloadPageAndWaitForTableToLoad(self):
        self.reload()
        self.expectedSinglePaymentsTable.waitForDataToRender()

    @retry(exceptions=TimeoutException, delay=5, tries=2)
    def reloadPageAndWaitForRegularPaymentInstructionsTableToLoad(self):
        self.reload()
        self.currentRegularPaymentInstructionsTable.waitForDataToRender()

    def navigateToAberdeenSIPPPaymentInPage(self):
        self.currentRegularPaymentsInstructionsEditIconButton.click()
        return AbrdnSIPPPaymentsInWizard(self.webdriver)

    def navigateToAberdeenSIPPEditRegularPaymentInPage(self):
        self.currentRegularPaymentsInstructionsEditIconButton.click()
        return ABERDEENSIPPEditRegularPaymentInPage(self.webdriver)

    def clickEditAndNavigateToAberdeenJSIPPEditRegularPaymentInPage(self):
        self.currentRegularPaymentsInstructionsEditIconButton.click()
        return ABERDEENJSIPPEditRegularPaymentInPage(self.webdriver)

    def navigateToTransactionTabPage(self):
        self.clickHereLink.click()
        return AccountsTransactionsTabPage(self.webdriver)

    @retry(exceptions=(UIException), delay=10, tries=4)
    def waitForExpectedTransfersRowToMatchFilter(self, tableRecordFilters: list[TableFilter]):
        """
        Returns row with expected state described in the filter
        """
        PrintMessage(f"Waiting for 'Expected Transfer' row to be in state: {[k.getPrintable() for k in tableRecordFilters]}", inStepMessage=True)
        matchingRow = self.expectedSinglePaymentsTable.getRow(tableFilters=tableRecordFilters)

        if matchingRow:
            return matchingRow

        raise UIException(f"waitForExpectedTransfersRowToMatchFilter > Expected '{[k.getPrintable() for k in tableRecordFilters]}'")

    @retry(exceptions=(UIException), delay=50, tries=4)
    def waitForCompletedTransfersRowToMatchFilter(self, tableRecordFilters: list[TableFilter]):
        """
        Returns row with expected state described in the filter
        """
        PrintMessage(f"Waiting for 'Completed Transfer' row to be in state: {[k.getPrintable() for k in tableRecordFilters]}", inStepMessage=True)
        self.reload()
        matchingRow = self.paymentInTransfersInTable.getRow(tableFilters=tableRecordFilters)

        if matchingRow:
            return matchingRow

        raise UIException(f"waitForCompletedTransfersRowToMatchFilter > Expected '{[k.getPrintable() for k in tableRecordFilters]}'")

    @property
    def activeInstructionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Active instructions']")

    @property
    def isaAllowanceTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel-subtle']")

    @property
    def viewAllISASubscriptionsLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View all ISA subscriptions']")

    @property
    def currentRegularPaymentInstructionsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//h3[text()='Current regular payment instructions']/parent::div/parent::div/parent::div//table")
        table.rowType = CurrentRegularPaymentInstructionsRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def expectedSinglePaymentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Expected single payment(s)']/parent::div/parent::div/parent::div//table")
        table.rowType = ExpectedSinglePaymentsRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def transfersTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transfers']/parent::*/parent::*")

    @property
    def completedInstructionsTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Completed instructions']")

    @property
    def dateListbox(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/parent::*/parent::*//select[@class='form-input']")

    @property
    def completedInstructionsGraphTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='highcharts-container instructions-column-chart-isa']")

    @property
    def completedInstructionsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//h3[text()='Regular and single payments']/following-sibling::div//div//table[contains(@class,'table-subtle')]")
        table.rowType = CompletedInstructionsRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def transfersCompletedInstructionsTable(self):
        return SearchResultsTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//table[@class='table-subtle table-first-last-cell-padding-reset mb-10 data-table']")

    @property
    def viewCompletedTransfersLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View completed transfers']")

    @property
    def clickHereLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='hyperlink' and text()='click here.']")

    @property
    def currentRegularPaymentsInstructionsEditIconButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@type='button' and @title='Edit']")

    @property
    def currentRegularPaymentsInstructionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Current regular payment instructions']")

    @property
    def currentRegularPaymentsInstructionsTableNoRegularPaymentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='No regular payment(s) currently set up for this client']")

    @property
    def expectedSinglePaymentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Expected single payment(s)']")

    @property
    def annualAllowanceLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Annual Allowance ']")

    @property
    def expectedTransfersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Expected transfers']")

    @property
    def exportToExcelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='excel-download']")

    @property
    def paymentsAndTaxReliefTable(self):
        return GenericTable(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            " //button[@class='excel-download']//following-sibling::div//table[@class='table-subtle table-first-last-cell-padding-reset data-table']")

    @property
    def transfersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transfers']")

    @property
    def toViewAllPaymentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'To view all payments')]")

    @property
    def expectedTransfersTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Expected transfers']/parent::div/parent::div//table")
        table.rowType = ExpectedTransfersRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table

    @property
    def paymentInTransfersInTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transfers']/following-sibling::div//div[contains(@class,'ctable')]//table")
        table.rowType = ProductTransfersInRow
        table.headerSectionLocator = (By.XPATH, ".//thead//tr")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.waitForDataToRender()
        return table
