from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CurrentRegularWithdrawalInstructionsRow import CurrentRegularWithdrawalInstructionsRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ProductWithdrawalsTab(ProductOverviewPage):
    def wait(self):
        self.withdrawalsTabButton.click()
        waitCondition = EC.text_value_in_attribute_in_element(self.withdrawalsTabButton.element, "aria-selected", "true")
        WebDriverWait(self.webdriver, 10).until(waitCondition)

    def selectProductOption(self, partialOptionName):
        """
        Method ensures that ui stays on withdrawal tab after changing product to new
        """
        offShoreBondOption = self.productDropdown.getOptionFromPartialText(partialOptionName)
        self.productDropdown.selectOption(offShoreBondOption)
        self.withdrawalsTabButton.click()

    @property
    def productDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.CSS_SELECTOR,
            "select[class='form-input']",
            optionsLocator=(
                By.XPATH,
                ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def currentRegularWithdrawalInstructionsTable(self):
        try:
            table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[contains(@class, 'data-table')]")
            table.rowType = CurrentRegularWithdrawalInstructionsRow
            return table
        except TimeoutException:
            sectionElemenet = self.webdriver.find_elements(By.XPATH, "//div[@class='d-flex f-direction-column']")[0]
            return Label(self.webdriver, sectionElemenet, By.XPATH, ".//span").text

    @property
    def expectedSingleWithdrawalTable(self):
        try:
            sectionElemenet = self.webdriver.find_elements(By.XPATH, "//div[@class='d-flex f-direction-column']")[1]
            return Label(self.webdriver, sectionElemenet, By.XPATH, ".//span")
        except TimeoutException:
            return SearchResultsTable(
                self.webdriver,
                self.webdriver,
                By.XPATH,
                "//div[@class='d-flex f-direction-column']//h3[text()='Expected single withdrawal']")

    @property
    def completedInstructionsTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='ctable-root is-scrollable']")

    @property
    def clickHereLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='hyperlink' and text()='click here']")
