from retry import retry
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ClientsTabs.IndividualSearchCriteria import IndividualSearchCriteria
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class ClientsIndividualTab(ClientsBaseTab):
    searchButtonLocator = "//button[@class='btn primary mb-0 ' and text()='Search']"
    searchButtonBusyLocator = "//button[@class='btn primary mb-0 is-busy']"

    def wait(self):
        self.waitTab(self.clientsButton)

    def verifyIndividualPageSearchOptions(self, expectedSearchOptions):
        PrintMessage("Attempting to locate Individual Page search options lables '{expectedSearchOptions}'", inStepMessage=True)
        for expectedLink in expectedSearchOptions:
            valueWaiter = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//*[@class='advanced-search mb-0']//*[@class='control-label']"), expectedLink)
            WebDriverWait(self.webdriver, 60).until(valueWaiter)
        PrintMessage(f"Verified presence of '{expectedSearchOptions}' lables")

    @retry(exceptions=NoSuchElementException, delay=2, tries=5)
    def _clickSearchAndWait(self):
        self.searchButton.click()

        try:
            # wait for element to be in busy state
            valueWaiter = EC.presence_of_element_located((By.XPATH, self.searchButtonBusyLocator))
            WebDriverWait(self.webdriver, 5).until(valueWaiter)
        except TimeoutException:
            pass

        # wait for element to be no longer in is-busy state
        valueWaiter = EC.presence_of_element_located((By.XPATH, self.searchButtonLocator))
        WebDriverWait(self.webdriver, 60).until(valueWaiter)

    def individualSearchAndSelect(self,
                                  searchCriteria: IndividualSearchCriteria,
                                  nameToSelect=None,
                                  expectedPageToOpen=None,
                                  nameComparisonOperator=str.__eq__):
        """
        searchCriteria: is an object with search criteria
        nameToSelect: expected item to be found and select
        expectedPageToOpen: In case there is other page after finding account expected to open i.e other than search summary
        nameComparisonOperator: type of comparison when selecting one of the search results, default is a full match
        """
        if searchCriteria.network:
            self.networkSmartSearchEdit.enterValue(searchCriteria.network)
        if searchCriteria.company:
            self.companySmartSearchEdit.searchAndSelect(searchCriteria.company)
        if searchCriteria.firstName:
            self.firstnameSearchEditField.enterValue(searchCriteria.firstName)
        if searchCriteria.surname:
            self.surnameSearchEditField.enterValue(searchCriteria.surname)
        if searchCriteria.accountNumber:
            self.accountnumberSearchEditField.enterValue(searchCriteria.accountNumber)
        if searchCriteria.status:
            self.statusSearchDropdown.selectOption(searchCriteria.status)
        if searchCriteria.adviser:
            self.adviserSearchDropdown.selectOption(searchCriteria.adviser)
        if searchCriteria.accountRole:
            self.accountroleSearchDropdown.selectOption(searchCriteria.accountRole)
        if searchCriteria.dateOfBirth:
            self.dateOfBirthSearchEditField.enterValue(searchCriteria.dateOfBirth)

        self._clickSearchAndWait()

        table = SearchResultsTable(self.webdriver, self.webdriver, By.CLASS_NAME, "ctable-scrollpane")

        if nameToSelect:
            foundRow = table.getActiveRowByName(nameToSelect, nameComparisonOperator)
        else:
            foundRow = table.getRowBySearchCriteria(searchCriteria, nameComparisonOperator)

        foundRow.name.click()
        if expectedPageToOpen:
            return expectedPageToOpen(self.webdriver)

        waitCondition = EC.presence_of_element_located((By.XPATH, "//button[@aria-selected='true']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        return self.getCurrentTabPage()

    def enterAccountNumberAndSearch(self, searchCriteria: IndividualSearchCriteria):
        self.accountnumberSearchEditField.enterValue(searchCriteria.accountNumber)
        self._clickSearchAndWait()
        return SearchResultsTable(self.webdriver, self.webdriver, By.CLASS_NAME, "ctable-scrollpane")

    @property
    def firstnameSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']/../..//input")

    @property
    def surnameSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']/../..//input")

    @property
    def accountnumberSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']/../..//input")

    @property
    def dateOfBirthSearchEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']/../..//input")

    @property
    def statusSearchDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Status']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def adviserSearchDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Adviser']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def accountroleSearchDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Account role']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def searchButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, self.searchButtonLocator)

    @property
    def firstNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='First name']")

    @property
    def surNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Surname']")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account number']")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Status']")

    @property
    def adviserLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Adviser']")

    @property
    def accountRoleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Account role']")

    @property
    def dateOfBirthLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date of birth']")

    @property
    def financialCrimeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(@class,'text-negative')]")
