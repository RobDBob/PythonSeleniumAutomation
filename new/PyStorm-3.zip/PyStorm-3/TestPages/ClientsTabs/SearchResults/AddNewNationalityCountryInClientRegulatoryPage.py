from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.ClientDetails.RegulatoryPage import RegulatoryPage
from TestPages.WebDriver import ExpectedConditions as EC


class AddNewNationalityCountryInClientRegulatoryPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CustomerTaxResidencyAndNationalityDetails)
        waitCondition = EC.presence_of_element_located(
            (By.XPATH, "//label[text()='Country name']//ancestor::div[@class='content']//preceding-sibling::div//h1"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def cancelAndNavigateToRegulatoryPage(self):
        self.cancelNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    def saveAndNavigateToRegulatoryPage(self):
        self.saveNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    def addAndNavigateToRegulatoryPage(self):
        self.addNationalityDetailsButton.waitForElement()
        self.addNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Country name']//ancestor::div[@class='content']//preceding-sibling::div//h1")

    @property
    def addCountryNameDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Country name']//parent::div//following-sibling::div//select",
                                   optionsLocator=(
                                       By.TAG_NAME,
                                       "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def clientTaxResidentYesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client tax resident']//ancestor::fieldset//span[text()='Yes']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def clientTaxResidentNoRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client tax resident']//ancestor::fieldset//span[text()='No']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def clientNationalityYesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client nationality']//ancestor::fieldset//span[text()='Yes']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def clientNationalityNoRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client nationality']//ancestor::fieldset//span[text()='No']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def primaryCitizenshipYesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Primary citizenship']//ancestor::fieldset//span[text()='Yes']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def primaryCitizenshipNoRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Primary citizenship']//ancestor::fieldset//span[text()='No']//ancestor::label[contains(@class,'pin-radio')]")

    @property
    def taxReferenceTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "(//select[@class='form-input'])[2]", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def taxIdentificationNumberEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Client tax resident']//ancestor::div//label[text()='Tax identification number']//parent::div//following-sibling::div//input")

    @property
    def nationalPassportNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='National Passport Number']//parent::div//following-sibling::div//input")

    @property
    def iDontOwnThisIdentifierCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "(//span[@class='label' and contains(text(),'own this identifier')])[1]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def secondIDontOwnThisIdentifierCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "(//span[@class='label' and contains(text(),'own this identifier')])[2]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def nationalIdentificationNumberEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='National Identification Number (PESEL)']//parent::div//following-sibling::div//input")

    @property
    def taxNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Tax Number')]//parent::div//following-sibling::div//input")

    @property
    def taxIdNumberEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Tax ID number')]//parent::div//following-sibling::div//input")

    @property
    def cancelNationalityDetailsButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "//h1[text()='Customer tax residency and nationality details']//parent::div//following-sibling::div//button[text()='Cancel']")

    @property
    def addNationalityDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Add']")

    @property
    def closeNationalityDetailsButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h1[text()='Customer tax residency and nationality details']//parent::div//button//span[text()='close']")

    @property
    def saveNationalityDetailsButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "//h1[text()='Customer tax residency and nationality details']//parent::div//following-sibling::div//div//button[text()='Save']")

    @property
    def addCountryNameWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Country name']//parent::div//following-sibling::div//div//p")

    @property
    def clientNationalityWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Client nationality']//ancestor::fieldset//div//p")

    @property
    def taxIdentificationNumberWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Tax identification number']//ancestor::div//div//p")

    @property
    def primaryCitizenshipWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Primary citizenship']//ancestor::fieldset//div//p")

    @property
    def clientTaxResidentWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Client tax resident']//ancestor::fieldset//div//p")

    @property
    def atLeastOneNationalityNeededOkButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//p[text()='Client must have at least one nationality']//parent::div//div//button[text()='OK']")

    @property
    def atLeastOneNationalityNeededLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='content']//p")
