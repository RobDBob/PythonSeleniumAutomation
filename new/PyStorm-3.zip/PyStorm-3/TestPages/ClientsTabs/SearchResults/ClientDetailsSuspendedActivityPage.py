from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, LongPageEnums, PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.SuspendedActivityFeesAndChargesRow import SuspendedActivityFeesAndChargesRow
from TestPages.PageObjects.BaseObjects.Table.Rows.SuspendedActivityPaymentsRow import SuspendedActivityPaymentsRow
from TestPages.PageObjects.BaseObjects.Table.Rows.UntitledAccountRestrictionRow import UntitledAccountRestrictionRow
from TestPages.PageObjects.BaseObjects.Table.SuspendedActivityPaymentsTable import SuspendedActivityPaymentsTable
from TestPages.PlatformPage import PlatformPage


class ClientDetailsSuspendedActivityPage(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ClientDetailsAccountRestrictions)

    def removeSuspensionRestriction(self, accountRestrictionName):
        styleHidden = "display: none;"

        self.untitledSectionTable.waitForDataToRender()
        row: UntitledAccountRestrictionRow = self.untitledSectionTable.getRow(columnName=PageEnums.SuspensionReason, value=accountRestrictionName)

        if row.removedButton.get_attribute("style") == styleHidden:
            return

        PrintMessage("Attempting to remove Account Restrictions", inStepMessage=True)
        row.removedButton.click()

        # button is redrawn after action so we need to re-fetch it
        row: UntitledAccountRestrictionRow = self.untitledSectionTable.getRow(columnName=PageEnums.SuspensionReason, value=accountRestrictionName)
        row.removedButton.waitForTextInAttribute(styleHidden, "style")

    def getPaymentsSelectedRow(self, dataLabel) -> SuspendedActivityPaymentsRow:
        matchingRows: list[SuspendedActivityPaymentsRow] = [k for k in self.paymentsTable.dataRows if dataLabel == k.withdrawalsLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def getFeeAndChargesSelectedRow(self, dataLabel) -> SuspendedActivityFeesAndChargesRow:
        matchingRows: list[SuspendedActivityFeesAndChargesRow] = [k for k in self.feesAndChargesTable.dataRows if dataLabel == k.feePostingLabel.text]
        if matchingRows:
            return matchingRows[0]
        return None

    def setWithRestrictionData(self, testData: dict):
        if testData.get(DataEnums.SELECT_VIEW, None):
            optionToSelect = self.selectViewDropdown.getOptionFromPartialText(testData.get(DataEnums.SELECT_VIEW))
            self.selectViewDropdown.selectOption(optionToSelect)

        self.editButton.jsClick()

        if testData.get(DataEnums.REASON_FOR_SUSPENDING, None):
            self.selectReasonForSuspendingDropdown.selectOption(testData.get(DataEnums.REASON_FOR_SUSPENDING))

        if testData.get(DataEnums.RESTRICTION_TYPE, []):
            restrictionTypeData = testData.get(DataEnums.RESTRICTION_TYPE, [])
            for data in restrictionTypeData:
                if data == DataEnums.DEPOSITS_FLAG_FOR_APPROVAL:
                    self.getPaymentsSelectedRow(PageEnums.DEPOSITS).flagForApprovalCheckBox.selectCheckBoxAndWait(jsClick=True)
                if data == DataEnums.FEE_POSTING:
                    self.getFeeAndChargesSelectedRow(PageEnums.FEE_POSTING).suspendedCheckBox.selectCheckBoxAndWait(jsClick=True)
                if data == DataEnums.WITHDRAWALS_FLAG_FOR_APPROVAL:
                    self.getPaymentsSelectedRow(PageEnums.WITHDRAWALS).flagForApprovalCheckBox.selectCheckBoxAndWait(jsClick=True)
        self.saveButton.click()

    def removeFirstRowIfExists(self):
        """
        Edit button won't be availalbe if there is pending authorisation
        """
        self.editButton.jsClick()

        matchingRow: UntitledAccountRestrictionRow = self.untitledSectionTable.getFirstRow()
        if not matchingRow.removedButton.exists():
            return
        PrintMessage("Attempting to remove Account Restrictions", inStepMessage=True)
        matchingRow.removedButton.click()

    @property
    def isAccountPendingAuthorisation(self):
        return LongPageEnums.ACCOUNT_PENDING_AUTHORISATION_MESSAGE in self.webdriver.find_element("xpath", "//form[text()]").text

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//form//h1")

    @property
    def wpNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3//span[contains(text(),'WP')]")

    @property
    def selectViewDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Select view']//following-sibling::div/select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def selectReasonForSuspendingDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='restrictionreason']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def editButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btnedit']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btncancel']")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='btnsave']")

    @property
    def feesAndChargesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Fees & Charges']")

    @property
    def feesAndChargesTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Fees & Charges']//following-sibling::div/table")
        table.rowType = SuspendedActivityFeesAndChargesRow
        return table

    @property
    def paymentsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Payments']")

    @property
    def paymentsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Payments']//following-sibling::div/table")
        table.rowType = SuspendedActivityPaymentsRow
        return table

    @property
    def transactionalLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transactional']")

    @property
    def transactionalTable(self):
        return SuspendedActivityPaymentsTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Transactional']//following-sibling::div/table")

    # Table representing the untitled section at the bottom of Client Details - Account Restrictions page
    @property
    def untitledSectionTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = UntitledAccountRestrictionRow
        table.headerCellLocator = (By.XPATH, ".//th[text()]")
        return table
