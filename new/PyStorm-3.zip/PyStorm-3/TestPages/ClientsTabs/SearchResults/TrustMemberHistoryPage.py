from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ClientDetailsTrustMemberHistoryRow import ClientDetailsTrustMemberHistoryRow


class TrustMemberHistoryPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TRUST_MEMBER_HISTORY)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "(//h1)[2]")

    @property
    def untitledTrustMemberTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH,
                             "//h1[text()='Client details - Trust member History']//parent::div//parent::div//table")
        table.headerCellLocator = (By.XPATH, ".//th//span")
        table.rowType = ClientDetailsTrustMemberHistoryRow
        return table
