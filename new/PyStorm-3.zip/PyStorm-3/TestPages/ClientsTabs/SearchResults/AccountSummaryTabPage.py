import operator
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import convertCurrencyInStringFormatToFloat, tryToInt
from TestPages import PageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ClientsTabs.ProductOverview.ProductOverviewPage import ProductOverviewPage
from TestPages.ClientsTabs.SearchResults.SearchResultsPage import SearchResultsPage
from TestPages.Enums.ClientTabEnum import ClientTabEnum
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.ProductAccountCardTableRow import ProductAccountCardTableRow
from TestPages.PageObjects.BaseObjects.Table.SearchSummaryAccountTable import SearchSummaryAccountTable
from TestPages.WebDriver import ExpectedConditions as EC


class AccountSummaryTabPage(ClientsBaseTab, SearchResultsPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//button[@aria-selected='true' and text()='Summary']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def getHeadAccountFor(self, productName):
        selectedProduct = self.accountsTable.selectProduct(productName)
        if selectedProduct:
            return selectedProduct.accountNumber.split("-")[0]
        return None

    def selectProductFromTable(self, productName):
        PrintMessage(f"Selecting product from Summary product table: '{productName}'", inStepMessage=True)
        summaryRow = self.accountsTable.selectProduct(productName)
        PrintMessage(f"Selected product with account number: '{summaryRow.accountNumber}'", inStepMessage=True)

        summaryRow.product.click()
        return ProductOverviewPage(self.webdriver)

    def verifyFinancialCrimeAccountRestrictionLabel(self, accountID):
        waitCondition = EC.text_to_be_present_in_any_of_elements((By.XPATH, "//p[contains(text(),'Financial Crime R.7')]"), accountID)
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def _getInvestmentHoldingsTable(self, holdingName):
        investmentsTab = self.navigateToTab(ClientTabEnum.Investments)
        investmentHolding = investmentsTab.investmentsTable.getInvestmentHoldingsTableProductView(holdingName)
        if investmentHolding:
            return investmentHolding
        PrintMessage(f"Investment holding: '{holdingName}' not found.", inStepMessage=True)
        return None

    def getProductNameFor(self, investmentName):
        investmentHolding = self._getInvestmentHoldingsTable(investmentName)
        if investmentHolding is None:
            raise UIException(f"No records for '{investmentName}' investment available")

        productName = investmentHolding.productNameLabel.text
        self.navigateToTab(ClientTabEnum.Summary)
        return productName

    def getInvestmentsTotalCostFor(self, investmentHolding, investmentName):
        """
        Get current total cost for given investment
        """
        investmentHolding = self._getInvestmentHoldingsTable(investmentHolding)

        totalCost = 0
        if investmentHolding:
            investmentRow = investmentHolding.getInvestmentRow(investmentName)
            if investmentRow:
                totalCost = investmentRow.investmentTotalCostValueLabel.convertCurrencyInStringFormatToFloat
        self.navigateToTab(ClientTabEnum.Summary)
        return totalCost

    def selectJointAccountsFromSummaryView(self, toSelect: bool = True):
        PrintMessage("Attempting to remove deselect Joint Accounts from summary view...", inStepMessage=True)
        self.totalClientViewExpandButton.waitForElement()
        self.totalClientViewExpandButton.jsClick()
        self.totalClientViewJointCheckbox.selectCheckBoxAndWait(toSelect, jsClick=True)
        self.totalClientViewApplyButton.jsClick()
        PrintMessage("Joint Accounts successfully removed from summary view.", inStepMessage=True)

    def selectProductFromSummaryView(self, toSelect: bool = True):
        PrintMessage("Attempting to remove PP and ISA from summary view...", inStepMessage=True)
        self.totalClientViewExpandButton.jsClick()
        self.isaTotalViewCheckbox.selectCheckBoxAndWait(toSelect, jsClick=True)
        self.ppTotalViewCheckbox.selectCheckBoxAndWait(toSelect, jsClick=True)
        self.totalClientViewApplyButton.jsClick()
        PrintMessage("ISA and PP products checkbox unchecked", inStepMessage=True)

    def waitForFinancialCrimeLabel(self, financialCrimeText):
        # If no such expectedLabel element is found then page reload is needed then validation of the label will be performed
        # If element already exist then only label validation will be performed
        expectedLabel = (By.XPATH, "//p[contains(text(),'Client ID')]//following::p[contains(@class,'text-negative')]")
        if not self.webdriver.find_elements(*expectedLabel):
            self.reload()
        self.financialCrimeLabel.waitForText(financialCrimeText)

    @retry(exceptions=TimeoutException, delay=20, tries=7)
    def waitForTotalValueToLoad(self, totalAmount):
        """
        This method is created to wait for the single payment amount to reflect on Summary page after cash matching.
        Manually also it is taking same time to reflect the amount so added retry and reload to validate the data.
        Total amount is in currency format, hence converted the format type to validate actual amount.
        """
        totalAmountFormat = convertCurrencyInStringFormatToFloat(self.totalValueLabel.text)
        if tryToInt(totalAmountFormat) != totalAmount:
            self.reload()
            raise TimeoutException("Total value did not load as expected.")
        PrintMessage("Total value is loaded and available", inStepMessage=True)

    def navigateToAbrdnJSIPPCashAvailablePopUp(self):
        from TestPages.ClientsTabs.SearchResults.ABRDNJSIPPCashAvailablePopUpPage import ABRDNJSIPPCashAvailablePopUpPage
        self.abrdnJSIPPAccountCardTable.getRow(
            textPropertyName=PageEnums.PRODUCT_CARD_ITEM_NAME_LABEL,
            value=PageEnums.CASH_AVAILABLE,
            comparisonOperator=operator.contains).productCardItemValueHyperlinkButton.click(
            jsClick=True)
        return ABRDNJSIPPCashAvailablePopUpPage(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']")

    @property
    def dateSelector(self):
        return

    @property
    def createClientPorfolioReport(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='document-button']")

    @property
    def accountsTable(self):
        return SearchSummaryAccountTable(self.webdriver, self.webdriver, By.XPATH, ".//table[@class='accounts-table']")

    @property
    def isaAccountCard(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[contains(@class,'card-heading  isa')]/parent::div")

    @property
    def isaAccountCardQuickMenu(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='card-heading  isa']//span[@class='icon']")

    @property
    def isaAccountCardQuickMenuExpanded(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='card-heading  isa']//span[@class='icon']/parent::button[@aria-expanded='true']")

    @property
    def ppAccountCard(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[contains(@class,'card-heading  pp')]/parent::div")

    @property
    def ppAccountCardQuickMenu(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='card-heading  pp']//span[@class='icon']")

    @property
    def ppAccountCardQuickMenuExpanded(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='card-heading  pp']//span[@class='icon']/parent::button[@aria-expanded='true']")

    @property
    def financialCrimeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Client ID')]//following::p[contains(@class,'text-negative')]")

    @property
    def totalClientViewExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='controls-wrap']/button")

    @property
    def totalClientViewCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Total account view')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def totalClientViewJointCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Joint')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def totalClientViewApplyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Apply']")

    @property
    def firmValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Firm:')]//b")

    @property
    def adviserValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Adviser:')]//b")

    @property
    def clientIdValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Client ID')]//b")

    @property
    def totalValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='client-account-value']")

    @property
    def isaTotalViewCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@class='form-input']//following-sibling::span[contains(text(),'ISA')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def ppTotalViewCheckbox(self):
        checkbox = CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@class='form-input']//following-sibling::span[contains(text(),'Personal')]")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def abrdnJSIPPAccountCardTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Aberdeen JSIPP']//ancestor::div[@class='card-upper']//table")
        resultTable.rowType = ProductAccountCardTableRow
        return resultTable

    @property
    def cashAccountTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cash Account']/parent::div/parent::div//span[@class='icon']")

    @property
    def aberdeenJSIPPTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Aberdeen JSIPP']/parent::div/parent::div//span[@class='icon']")

    @property
    def isaSnSTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='ISA Stocks & Shares']/parent::div/parent::div//span[@class='icon']")

    @property
    def personalportfolioTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Personal Portfolio']/parent::div/parent::div//span[@class='icon']")

    @property
    def aberdeenSIPPTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Aberdeen SIPP']/parent::div/parent::div//span[@class='icon']")

    @property
    def addRegularPaymentExpandedTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Add regular payment' and @class='item']")

    @property
    def editRegularPaymentExpandedTileMenuButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Edit regular payment' and @class='item']")
