from selenium.webdriver.common.by import By
from TestPages.ClientsTabs.SearchResults.RemoveTrustMemberPage import RemoveTrustMemberPage
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox


class RemoveBeneficiaryPage(RemoveTrustMemberPage):
    def removeBeneficiary(self, removeReasonOptionToSelect):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.corporateCheckBox.click()
        self.saveButton.click()
        self.removeReasonDropdown.waitForElement()
        self.removeReasonDropdown.selectOption(removeReasonOptionToSelect)
        self.equalShareCheckBox.click()
        self.saveButton.click()
        return TrustServicingPage(self.webdriver)

    def saveAndNavigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.saveButton.jsClick()
        return TrustServicingPage(self.webdriver)

    @property
    def corporateCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, By.XPATH, "//span[text()='Beneficiary']")

    @property
    def equalShareCheckBox(self):
        return CheckBox(self.webdriver, self.parentElement, By.XPATH, "//span[text()='Equal share']")
