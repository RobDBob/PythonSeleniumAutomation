from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.Rows.MigrateFromMPSSubAccountHoldingsRow import MigrateFromMPSSubAccountHoldingsRow
from TestPages.PlatformPage import PlatformPage


class MigrateFromMPSPage(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.MigrateFromMPS)

    def checkSubAccountHoldingsTableExpandedWithUnderlyingAssets(self):
        numberOfRows = len(self.migrateFromMPSSubAccountHoldingsTable.dataRows)
        if numberOfRows > 1:
            for index in range(1, len(self.migrateFromMPSSubAccountHoldingsTable.dataRows)):
                if self.migrateFromMPSSubAccountHoldingsTable.dataRows[index].get_attribute("style") == "display: none;":
                    return False
            return True
        return False

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Migrate From MPS')]")

    @property
    def selectSubAccountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='1. Select your sub account to migrate assets TO']")

    @property
    def accountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account type')]")

    @property
    def accountTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='js-accountSelect']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def selectMPSModelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='2. Select MPS model to migrate assets FROM']")

    @property
    def investmentManagerMPSModelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Investment Manager (MPS) model')]")

    @property
    def investmentManagerMPSModelDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='dimModelInsCode']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def migrateFromMPSInstrumentSelectionTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, 'instrumentSelectionTable')
        table.rowType = GenericBaseRow
        table.headerCellLocator = (By.XPATH, ".//tr/th")
        return table

    @property
    def migrateFromMPSSubAccountHoldingsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, 'subAccountHoldingsTable')
        table.rowType = MigrateFromMPSSubAccountHoldingsRow
        table.headerCellLocator = (By.XPATH, ".//tr/th[text()]")
        return table

    @property
    def migrateFromMPSInstrumentSelectionTableHeaders(self):
        header = self.migrateFromMPSInstrumentSelectionTable.headers
        header = ["Select All Units" if k == "Select All Units\nSelect All Units" else k for k in header]
        return header

    @property
    def migrateFromMPSDisclaimerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@id='declaration']//p")

    @property
    def backToTopButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Back to top']")

    @property
    def migrateFromMPSSubmitButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, 'submitButton')
