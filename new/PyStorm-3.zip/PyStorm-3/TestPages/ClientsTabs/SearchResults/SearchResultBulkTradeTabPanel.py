from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.BulkTradeTabClientsAccountsTable import BulkTradeTabClientsAccountsTable


class SearchResultBulkTradeTabPanel(BaseTestObject):
    @property
    def bulkTradeTabClientsAccountsTable(self):
        return BulkTradeTabClientsAccountsTable(self.webdriver, self.element, By.XPATH, ".//table[@class='data-table table-grid-view']")
