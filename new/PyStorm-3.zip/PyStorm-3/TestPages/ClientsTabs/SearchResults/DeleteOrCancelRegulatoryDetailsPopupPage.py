from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.ClientDetails.RegulatoryPage import RegulatoryPage


class DeleteOrCancelRegulatoryDetailsPopupPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ARE_YOU_SURE_YOU_WANT_TO_DELETE)
        self.cancelButton.waitForElement()
        self.deleteButton.waitForElement()

    def navigateToRegulatoryTabPage(self, actionToPerform):
        if actionToPerform == 'Cancel':
            self.cancelButton.jsClick()
        else:
            self.deleteButton.jsClick()
        return RegulatoryPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Are you sure you want to delete?']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Delete']")
