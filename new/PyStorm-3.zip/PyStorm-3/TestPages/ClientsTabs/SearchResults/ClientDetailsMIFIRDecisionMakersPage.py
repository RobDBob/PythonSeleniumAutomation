from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import DataEnums, PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ClientDetailsMIFIRDecisionMakersPage(PlatformPage):
    SECTION_LOCATOR = "//h3[text()='{0}']//ancestor::div[@class='module']"
    wizardAccordionSection = None

    def _getSectionElement(self):
        if self.wizardAccordionSection:
            return self.webdriver.find_element(By.XPATH, self.wizardAccordionSection)
        return self.webdriver

    def wait(self):
        self.pageTitle.waitForText(PageEnums.ClientDetailsMIFIRDecisionMakers)

    def setMifirDecisionMakerData(self, testData):
        if testData.get(DataEnums.DECISION_MAKER_IS):
            self.selectDecisionMakerAs(testData.get(DataEnums.DECISION_MAKER_IS))
        if testData.get(DataEnums.FIRST_NAME):
            self.personNameEditField.enterValue(testData.get(DataEnums.FIRST_NAME))
        if testData.get(DataEnums.SURNAME):
            self.personSurnameEditField.enterValue(testData.get(DataEnums.SURNAME))
        if testData.get(DataEnums.DOB):
            self.personDateOfBirthDatePicker.specify_date(testData.get(DataEnums.DOB))
        if testData.get(DataEnums.COUNTRY_OF_NATIONALITY):
            self.countryOfNationalityDropdown.selectOption(testData.get(DataEnums.COUNTRY_OF_NATIONALITY))
        if testData.get(DataEnums.NATIONAL_INSURANCE_NUMBER):
            self.nationalInsuranceNumberEditField.enterValue(testData.get(DataEnums.NATIONAL_INSURANCE_NUMBER))

    def selectDecisionMakerAs(self, decisionMakerType: str):
        PrintMessage(f"Selecting Decision maker type : '{decisionMakerType}'", inStepMessage=True)
        match decisionMakerType:
            case PageEnums.NATURAL_PERSON:
                self.naturalPersonRadioButton.click()

    def addDecisionMakers(self, decisionMakers):
        for index, decisionMakerData in enumerate(decisionMakers):
            self.wizardAccordionSection = self.SECTION_LOCATOR.format(f"Decision maker {index+1}")
            PrintMessage(f"Opening section for decision maker - 'Decision maker {index+1}'", inStepMessage=True)
            self.addDecisionMaker(decisionMakerData)

            if index < len(decisionMakers) - 1:
                self.addDecisionMakerButton.click()

    def addDecisionMaker(self, decisionMakerData: dict):
        if decisionMakerData.get(DataEnums.DECISION_MAKER_IS):
            option = decisionMakerData.get(DataEnums.DECISION_MAKER_IS)
            match option:
                case PageEnums.NATURAL_PERSON:
                    self.naturalPersonRadioButton.click()
                case PageEnums.ENTITY:
                    self.entityRadioButton.click()
        if decisionMakerData.get(DataEnums.FIRST_NAME):
            self.personNameEditField.enterValue(decisionMakerData.get(DataEnums.FIRST_NAME))
        if decisionMakerData.get(DataEnums.SURNAME):
            self.personSurnameEditField.enterValue(decisionMakerData.get(DataEnums.SURNAME))
        if decisionMakerData.get(DataEnums.DOB):
            self.personDateOfBirthDatePicker.specify_date(decisionMakerData.get(DataEnums.DOB))
        if decisionMakerData.get(DataEnums.COUNTRY_OF_NATIONALITY):
            self.countryOfNationalityDropdown.selectOption(decisionMakerData.get(DataEnums.COUNTRY_OF_NATIONALITY))
        if decisionMakerData.get(DataEnums.NATIONAL_INSURANCE_NUMBER):
            self.nationalInsuranceNumberEditField.enterValue(decisionMakerData.get(DataEnums.NATIONAL_INSURANCE_NUMBER))
        self.decisionMakerSaveButton.click()

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[@class]")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[@class]/span")

    @property
    def staticMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3//following::p")

    @property
    def decisionMakersLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Decision makers']")

    @property
    def addDecisionMakerButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[contains(text(),'Add decision maker')]")

    @property
    def decisionMaker1Label(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Decision maker 1']")

    @property
    def typeOfDecisionMakerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='Type of the decision maker']")

    @property
    def naturalPersonRadioButton(self):
        sectionElement = self._getSectionElement()
        return Button(self.webdriver, sectionElement, By.XPATH, ".//div[@class='controls-wrap mb-0']//label//span[contains(text(),'Natural')]")

    @property
    def entityRadioButton(self):
        sectionElement = self._getSectionElement()
        return Button(self.webdriver, sectionElement, By.XPATH, ".//div[@class='controls-wrap mb-0']//label//span[contains(text(),'Entity')]")

    @property
    def leiEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, 'DM1decisionMakerLeiCode')

    @property
    def personNameEditField(self):
        sectionElement = self._getSectionElement()
        return EditField(self.webdriver, sectionElement, By.XPATH, ".//input[contains(@name, 'PersonName')]")

    @property
    def personSurnameEditField(self):
        sectionElement = self._getSectionElement()
        return EditField(self.webdriver, sectionElement, By.XPATH, ".//input[contains(@name, 'PersonSurname')]")

    @property
    def personDateOfBirthDatePicker(self):
        sectionElement = self._getSectionElement()
        return DatePicker(self.webdriver, sectionElement, By.XPATH, ".//input[contains(@name, 'PersonDob')]//parent::div")

    @property
    def countryOfNationalityMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, ".//*[contains(text(),'countries of nationality')]")

    @property
    def countryOfNationalityDropdown(self):
        sectionElement = self._getSectionElement()
        dropDown = DropdownListbox(
            self.webdriver,
            sectionElement,
            By.XPATH,
            ".//select[contains(@name, 'nationalityCountrySelect1')]",
            optionsLocator=(
                By.TAG_NAME,
                "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def addAnotherNationalityHyperlink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, ".//a[text()='+ Add another nationality']")

    @property
    def decisionMakerSaveButton(self):
        sectionElement = self._getSectionElement()
        return Button(self.webdriver, sectionElement, By.XPATH, ".//button[contains(text(),'Save')]")

    @property
    def decisionMakerCancelButton(self):
        sectionElement = self._getSectionElement()
        return Button(self.webdriver, sectionElement, By.XPATH, ".//button[contains(text(),'Cancel')]")

    @property
    def decisionMakerLegalMessageLabel(self):
        sectionElement = self._getSectionElement()
        return Label(self.webdriver, sectionElement, By.XPATH, "//*[contains(text(),'legal power of representation')]")

    @property
    def nationalInsuranceNumberEditField(self):
        sectionElement = self._getSectionElement()
        return EditField(self.webdriver, sectionElement, By.XPATH, ".//input[contains(@name,'nationalityIdentifier1Value1')]")

    @property
    def deleteDecisionMakerButton(self):
        sectionElement = self._getSectionElement()
        return Button(self.webdriver, sectionElement, By.XPATH, ".//button[contains(text(),'Delete Decision Maker')]")

    @property
    def successMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[@class='warning-message']")

    @property
    def personDateOfBirthDateValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//input[@name='DM1decsisionMakerPersonDob']//parent::div//input")

    @property
    def editDecisionMakerButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, 'DM1EditDecisionMaker')
