from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.PerformanceRow import PerformanceRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.TableEditorAndFilter.FilterTablePopupPage import FilterTablePopupPage
from TestPages.TableEditorAndFilter.TableEditorPopupPage import TableEditorPopupPage
from TestPages.WebDriver import ExpectedConditions as EC
from TestPages.WebDriver.ObjProduction import manufacture


class AccountsPerformanceTabPage(ClientsBaseTab):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@role='tabpanel' and @id='panel-2']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def getProductNameAndAllTheInvestmentsFromPerformanceTable(self) -> list[dict]:
        """
        Retrieves all investment details from the performance table for each product.
        This method iterates through the performance tables, extracts the product name,
        and then retrieves the investment details for each investment under that product.

        Returns:
            list[dict]: A list of dictionaries.
                        Subsequent elements are dictionaries containing the investment details
                        for each investment, with keys defined in PageEnums.
        """
        waitCondition = EC.presence_of_element_located((By.XPATH, ".//table[contains(@class, 'investments-table')]"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        funds = []
        for table in self.performanceForProductViewTables:
            row: PerformanceRow
            for row in table.dataRows:
                funds.append({
                    PageEnums.INVESTMENT: row.investmentLabel.text,
                    PageEnums.OPENING_VALUE: row.openingValueLabel.text,
                    PageEnums.BUYS: row.buysLabel.text,
                    PageEnums.SELLS: row.sellsLabel.text,
                    PageEnums.REALISED_GAIN_LOSS: row.releasedGainLossLabel.text,
                    PageEnums.UNREALISED_GAIN_LOSS: row.unreleasedGainLossLabel.text,
                    PageEnums.INCOME: row.incomeLabel.text,
                    PageEnums.GAIN_LOSS: row.gainLossLabel.text,
                    PageEnums.RETURN_PERCENT: row.returnPercentLabel.text,
                    PageEnums.CLOSING_VALUE: row.closingValueLabel.text})
        return funds

    def navigateToTableEditorPopUpPage(self):
        self.tableEditorButton.click(jsClick=True)
        return TableEditorPopupPage(self.webdriver)

    def navigateToFilterByPopUpPage(self):
        self.tableFilterButton.click(jsClick=True)
        return FilterTablePopupPage(self.webdriver)

    @property
    def performanceForProductViewTables(self):
        """
        An individual big table in Product view (<thead><tbody><tfoot>) is designed for every single product,
        and this doesn't have any single big table to accommodate the sub-tables within.
        """
        performanceTables = manufacture(GenericTable, self.webdriver, self.webdriver, By.XPATH, ".//table[contains(@class, 'investments-table')]")
        for performanceTable in performanceTables:
            performanceTable.rowType = PerformanceRow
            performanceTable.dataLocator = (By.XPATH, ".//tbody//parent::table")
            performanceTable.rowLocator = (By.XPATH, ".//tbody//tr[contains(@class,'product-heading')] | .//tbody//tr[@class='']")
            performanceTable.headerCellLocator = (By.XPATH, ".//th")
            performanceTable.firstRowIsHeader = True
        return performanceTables

    @property
    def dateListBox(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/../..//select[@class='form-input']")

    @property
    def createClientPortfolioReportLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Create client portfolio report']")

    @property
    def chooseDataViewListBox(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH,
                                   "//label[text()='Choose data view']/../..//select[@class='form-input']",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def returnBasisToggle(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//fieldset[@class='radio-toggle']")

    @property
    def valuationMoneyMovementsTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel']")

    @property
    def columnsExplainedLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Columns explained']")

    @property
    def exportToExcelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='excel-download']")

    @property
    def performanceTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='ctable-scrollpane']")

    @property
    def viewChargesTransactionsLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='View charges transactions']")

    @property
    def tableFilterButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Open the table filter dropdown']")

    @property
    def tableEditorButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Open the table editor dropdown']")
