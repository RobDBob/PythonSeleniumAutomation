from datetime import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestHelpers.DocumentDownloader import DocumentDownloader
from TestPages.Admin.ReportRowWaiter import ReportRowWaiter
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.LegacyClientReportGenerationTable import LegacyClientReportGenerationRow, LegacyClientReportGenerationTable
from TestPages.WebDriver import ExpectedConditions as EC


class AccountsDocumentsTabPage(ClientsBaseTab, ReportRowWaiter):
    def __init__(self, webdriver):
        super().__init__(webdriver)
        self._documentDownloader = DocumentDownloader(self.webdriver, self.testContext)
        self._documentDownloader.HREF_LOCATOR = (By.XPATH, "//a[contains(@class,'download-button')]")

    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@role='tabpanel' and @id='panel-6']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def getTheReportGeneratedRow(self) -> LegacyClientReportGenerationRow:
        currentMinute = datetime.now().minute
        firstRow = self.legacyClientReportTable.getFirstRow()
        self.waitForReportToAppear(currentMinute, dateTime=firstRow.dateTimeStamp, tableToSearch=self.legacyClientReportTable)
        return firstRow

    @property
    def selectAccountDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Select account']/../..//select[@class='form-input']")

    @property
    def selectViewDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Select view']/../..//select[@class='form-input']")

    @property
    def dateDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/../..//select[@class='form-input']")

    @property
    def uploadDocumentsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='upload-button']")

    @property
    def filterDocumentsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Filter documents']")

    @property
    def expandFullScreen(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='full-screen-mode-button']")

    @property
    def presentationModeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='presentation-mode-button']")

    @property
    def legacyClientReportTable(self):
        return LegacyClientReportGenerationTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")

    @property
    def paginationButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='pagination']")
