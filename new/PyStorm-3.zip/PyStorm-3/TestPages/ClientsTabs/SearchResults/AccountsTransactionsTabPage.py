from retry import retry
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable, TableFilter
from TestPages.PageObjects.BaseObjects.Table.Rows.PaymentsTransactionRow import PaymentsTransactionRow
from TestPages.PageObjects.BaseObjects.Table.Rows.TransactionCashRow import TransactionCashRow
from TestPages.PageObjects.BaseObjects.Table.Rows.TransactionsInvestmentsRow import TransactionsInvestmentsRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class AccountsTransactionsTabPage(ClientsBaseTab):
    def wait(self):
        self.waitForElementLocated((By.XPATH, "//div[@role='tabpanel' and @id='panel-4']"))

    def waitForElementLocated(self, locator):
        waitCondition = EC.presence_of_element_located(locator)
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @retry(exceptions=(UIException), delay=15, tries=4)
    def waitForPaymentsWithdrawalTransactionRowToMatchFilter(self, tableRecordFilters: list[TableFilter]):
        """
        Returns row with expected state described in the filter
        Expected transaction dropdown to be in Payments/Withdrawals
        """
        PrintMessage(f"Waiting for 'Payments / withdrawals' row to be in state: {[k.getPrintable() for k in tableRecordFilters]}", inStepMessage=True)
        self.transactionsDropdown.selectOption(PageEnums.SUMMARY)
        self.transactionsDropdown.selectOption(PageEnums.PAYEMENTS_OR_WITHDRAWALS_DROPDOWN_OPTION)

        matchingRow = self.transactionPaymentsWithdrawalsTable.getRow(tableFilters=tableRecordFilters)

        if matchingRow:
            return matchingRow

        raise UIException(f"waitForPaymentsWithdrawalTransactionRowToMatchFilter > Expected '{[k.getPrintable() for k in tableRecordFilters]}'")

    @retry(exceptions=(UIException), delay=30, tries=30)
    def waitForNewPaymentsWithdrawalTransactionRowToBeInState(self, todaysDate, expectedState):
        """
        Returns newest row with expected state
        Expected transaction dropdown to be in Payments/Withdrawals
        """
        PrintMessage(f"Waiting for 'Payments / withdrawals' row to be in state: {expectedState}", inStepMessage=True)
        self.transactionsDropdown.selectOption(PageEnums.SUMMARY)
        self.transactionsDropdown.selectOption(PageEnums.PAYEMENTS_OR_WITHDRAWALS_DROPDOWN_OPTION)

        matchingRows = self.transactionPaymentsWithdrawalsTable.getNewlyCreatedRows(dateTimeStamp=todaysDate, rowFieldName="dateCreatedDate")
        matchingRows = list(filter(lambda x: x.statusLabel.text == expectedState, matchingRows))

        if matchingRows:
            return matchingRows[0]
        raise UIException(f"waitForNewPaymentsWithdrawalRowToBeInState > Expected '{expectedState}'")

    def cancelAuthorisedTransactions(self, transactionDate):
        rows: list[PaymentsTransactionRow] = self.transactionPaymentsWithdrawalsTable.getRows(columnName="Date created",
                                                                                              value=transactionDate)
        for row in rows:
            if row.statusLabel.text != "Authorised":
                continue
            with self.cancelSpecificDeposit(row) as cancelOrQuickDepositsCancelDepositPage:
                cancelOrQuickDepositsCancelDepositPage.cancelTransactionAndNavigateToTransactionTab()

    def cancelNewestTransaction(self, transactionType):
        matchingRow: PaymentsTransactionRow = self.transactionPaymentsWithdrawalsTable.getRow(textPropertyName="typeLabel", value=transactionType)
        matchingRow.cancelButton.click()
        match transactionType:
            case PageEnums.DEPOSIT:
                from TestPages.Transactions.CreateOrdersQuickDepositsCancelDepositPage import CreateOrdersQuickDepositsCancelDepositPage
                return CreateOrdersQuickDepositsCancelDepositPage(self.webdriver)

            case PageEnums.WITHDRAWAL_INSTRUCTION_PERCENTAGE:
                from TestPages.Withdrawals.CancelOrdersWithdrawalsPage import CancelOrdersWithdrawalsPage
                return CancelOrdersWithdrawalsPage(self.webdriver)

    def selectAccount(self, account):
        options = self.accountDropdown.getAvailableOptionsAsText()
        matchedOptions = [k for k in options if account in k]
        if matchedOptions:
            self.accountDropdown.selectOption(matchedOptions[0])
            self.waitForElementLocated((By.XPATH, "//table[@class='data-table']"))
        else:
            raise UIException(f"Failed to find matching account in Transactions. Expected account with numbers: '{account}' found: '{options}'")

    def checkStatusAsSettled(self):
        self.waitForElementLocated((By.XPATH, "//table[@class='data-table']"))
        row: TransactionsInvestmentsRow
        for row in self.transactionsInvestmentsTable.dataRows:
            if row.settleLabel.text == PageEnums.SETTLED:
                return True
        return False

    def cancelSpecificWithdrawal(self, rowData):
        from TestPages.Withdrawals.CancelOrdersWithdrawalsPage import CancelOrdersWithdrawalsPage
        rowData.cancelButton.click()
        return CancelOrdersWithdrawalsPage(self.webdriver)

    def cancelSpecificDeposit(self, rowData):
        from TestPages.Transactions.CreateOrdersQuickDepositsCancelDepositPage import CreateOrdersQuickDepositsCancelDepositPage
        rowData.cancelButton.waitForElement()
        rowData.cancelButton.jsClick()
        return CreateOrdersQuickDepositsCancelDepositPage(self.webdriver)

    @property
    def pendingTransactionsLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Pending transactions']")

    @property
    def selectAccountDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Select account']/../..//select[@class='form-input']")

    @property
    def selectViewDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Select view']/../..//select[@class='form-input']",
            checkAriaState=False)
        dropdown.optionsLocator = (By.XPATH, ".//option[@value]")
        return dropdown

    @property
    def transactionsDropdown(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Transactions']//parent::div//following-sibling::div//select[@class='form-input']",
                                   optionsLocator=(By.CSS_SELECTOR, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def transactionTypeDropdown(self):
        """
        This dropdown is only shown in specific circumstances i.e.
        Transactions dropdown set to Cash or Investments
        """
        dropdown = DropdownListbox(self.webdriver, self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Transaction type']//parent::div//following-sibling::div//select[@class='form-input']",
                                   optionsLocator=(By.CSS_SELECTOR, "option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def accountDropdown(self):
        dropdown = DropdownListbox(self.webdriver, self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Select account']//parent::div//following-sibling::div//select[@class='form-input']",
                                   optionsLocator=(By.XPATH, ".//option"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def dateDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Date']/../..//select[@class='form-input']")

    @property
    def summaryTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='ctable-root is-scrollable']//span[text()='Money in']")

    @property
    def moneyInTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//descendant::table[@class='data-table'][2]")

    @property
    def withdrawalsTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//descendant::table[@class='data-table'][3]")

    @property
    def chargesTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//descendant::table[@class='data-table'][4]")

    @property
    def transactionCashTable(self):
        """
        With Transactions dropdown set to Cash / Investments
        """
        tableLocator = (By.XPATH, "//table[@class='data-table']")
        self.transactionsDropdown.selectOption(PageEnums.Cash)
        self.waitForElementLocated(tableLocator)

        table = GenericTable(self.webdriver, self.webdriver, *tableLocator)
        table.rowType = TransactionCashRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, "//tbody[contains(@id, 'drag-sort-table')]")
        return table

    @property
    def transactionPaymentsWithdrawalsTable(self):
        """
        With Transactions dropdown set to Payments/Withdrawals
        """
        tableLocator = (By.XPATH, "//table[@class='data-table']")
        self.transactionsDropdown.selectOption(PageEnums.PAYEMENTS_OR_WITHDRAWALS_DROPDOWN_OPTION)
        self.waitForElementLocated(tableLocator)

        table = GenericTable(self.webdriver, self.webdriver, *tableLocator)
        table.rowType = PaymentsTransactionRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, "//tbody[contains(@id, 'drag-sort-table')]")
        table.waitForDataToRender()
        return table

    @property
    def transactionsInvestmentsTable(self):
        tableLocator = (By.XPATH, "//table[@class='data-table']")
        self.transactionsDropdown.selectOption(PageEnums.INVESTMENTS)
        self.waitForElementLocated(tableLocator)

        table = GenericTable(self.webdriver, self.webdriver, *tableLocator)
        table.rowType = TransactionsInvestmentsRow
        table.headerCellLocator = (By.XPATH, ".//th")
        table.dataLocator = (By.XPATH, ".//tbody[contains(@id, 'drag-sort-table')]")
        return table
