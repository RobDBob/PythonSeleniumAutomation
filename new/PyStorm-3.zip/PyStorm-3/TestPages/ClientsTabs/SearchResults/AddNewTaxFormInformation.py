from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.ClientDetails.RegulatoryPage import RegulatoryPage


class AddNewTaxFormInformation(RegulatoryPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TaxFormInformation)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Tax form information']")

    @property
    def formTypeDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Form type']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def doYouHaveThisFormYesRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Do you have this form?']//ancestor::div[@class='row no-gutter']//following-sibling::div//span[text()='Yes']")

    @property
    def doYouHaveThisFormNoRadioButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Do you have this form?']//ancestor::fieldset//span[text()='No']/parent::label")

    @property
    def doYouHaveThisFormWarningLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//legend[text()='Do you have this form?']//ancestor::fieldset//div//div[@class='inline-error-message error']//p[text()='Please select']")

    @property
    def expiryDateEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Expiry date']//parent::div//following-sibling::div//input")

    @property
    def expiryDateWarningLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Expiry date']//parent::div//following-sibling::div//div[@class='inline-error-message error']//p[text()='required']")

    @property
    def taxResidencyForPensionReliefDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Tax residency for pension relief']/../..//select",
            optionsLocator=(
                By.CSS_SELECTOR,
                'option[value]'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def clientTaxExemptYesRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Client tax exempt?']//ancestor::fieldset//span[text()='Yes']")

    @property
    def clientTaxExemptNoRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//legend[text()='Client tax exempt?']//ancestor::fieldset//span[text()='No']")

    @property
    def taxExemptionReasonDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Tax exemption reason']//parent::div//parent::div//select",
            optionsLocator=(
                By.TAG_NAME,
                'option'))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def taxExemptionReasonWarningLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Tax exemption reason']/../../div//p[text()='Please select']")

    @property
    def cancelButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h1[text()='Tax form information']//parent::div//following-sibling::div//button[text()='Cancel']")

    @property
    def saveChangesButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h1[text()='Tax form information']//parent::div//following-sibling::div//button[text()='Save changes']")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Tax form information']//parent::div[@class='header']//button")
