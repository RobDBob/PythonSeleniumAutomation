from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class BuyInvestmentCancelWarningPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.DO_YOU_WANT_TO_CANCEL)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Do you want to cancel?']")

    @property
    def cancelConfirmationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='If you cancel, you lose the information you have entered during this process.']")

    @property
    def yesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Yes']")

    @property
    def noButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//button[text()='No']")
