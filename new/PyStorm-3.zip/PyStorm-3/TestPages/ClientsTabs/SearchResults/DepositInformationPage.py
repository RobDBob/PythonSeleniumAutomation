from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.TermsAndConditionsRow import TermsAndConditionsRow


class DepositInformationPage(BasePage):
    def _getSectionElement(self, text):
        return self.webdriver.find_element(By.XPATH, f"//span[contains(text(),'{text}')]")

    def wait(self):
        self.pageTitle.waitForText(PageEnums.DEPOSIT_INFORMATION)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Deposit information']")

    @property
    def depositTakerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Deposit taker:')]")

    @property
    def depositTakerValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.DEPOSIT_TAKER)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def depositTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Deposit type:')]")

    @property
    def depositTypeValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.DEPOSIT_TYPE)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def noticePeriodLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Notice period:')]")

    @property
    def noticePeriodValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.NOTICE_PERIOD)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def termValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.TERM)
        return Label(self.webdriver, sectionElement, By.XPATH, "//span[contains(text(),'Term')]//following-sibling::span")

    @property
    def grossInterestRateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Gross interest rate:')]")

    @property
    def grossInterestRateValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.GROSS_INTEREST_RATE)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def aerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'AER*:')]")

    @property
    def aerValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.AER)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def minimumInvestmentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Minimum investment:')]")

    @property
    def minimumInvestmentValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.MINIMUM_INVESTMENT)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def maximumInvestmentLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[contains(text(),'Maximum investment:')]")

    @property
    def maximumInvestmentValueLabel(self):
        sectionElement = self._getSectionElement(PageEnums.MAXIMUM_INVESTMENT)
        return Label(self.webdriver, sectionElement, By.XPATH, ".//following-sibling::span")

    @property
    def informationOnCashAccountInterestRatesHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Information on cash account interest rates')]")

    @property
    def informationOnCashAccountInterestRatesTextLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Information on cash account interest rates')]//following-sibling::p")

    @property
    def termsAndConditionsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Terms and conditions')]")

    @property
    def aerStandsForLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='panel']//small[contains(text(),'AER stands for Annual Equivalent Rate')]")

    @property
    def termsAndConditionTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Terms and conditions']//parent::div//following-sibling::div//table")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = TermsAndConditionsRow
        return table
