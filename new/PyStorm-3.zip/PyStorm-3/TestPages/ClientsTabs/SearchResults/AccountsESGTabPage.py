from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from TestPages import LongPageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ESG.ESGOverviewPage import ESGOverviewPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class AccountsESGTabPage(ClientsBaseTab):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@role='tabpanel' and @id='panel-6']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
        self.esgHubProvidesInformationLabel.waitForText(LongPageEnums.THE_ESG_HUB_PROVIDES_INFORMATION)

    @retry(exceptions=(UIException, TimeoutException), delay=3, tries=5)
    def clickLaunchESGHubButtonAndNavigateToESGOverviewPage(self):
        if len(self.webdriver.find_elements(By.XPATH, "//a[text()='Launch ESG Hub']")) > 0:
            self.launchESGHubButton.jsClick()
            return ESGOverviewPage(self.webdriver)
        raise UIException("Failed to Launch ESG Page")

    def clickLaunchESGHubAndNavigateToESGOverviewPageForConsolidatedAndJointAccountButton(self):
        # For Consolidated account, after selecting "Launch ESG," an account selection is displayed before navigating to the ESG page.
        self.launchESGHubButton.click()
        self.launchESGHubButtonForConsolidatedAccountButton.click()
        return ESGOverviewPage(self.webdriver)

    @property
    def esgHubTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='ESG Hub']")

    @property
    def launchESGHubButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Launch ESG Hub']")

    @property
    def launchESGHubButtonForConsolidatedAccountButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Launch ESG Hub']")

    @property
    def esgHubProvidesInformationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'The ESG Hub provides')]")

    @property
    def selectedAccountDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@class='form-input']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown
