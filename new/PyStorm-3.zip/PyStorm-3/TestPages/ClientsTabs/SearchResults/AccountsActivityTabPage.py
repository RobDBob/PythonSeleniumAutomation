from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.Admin.EditWebsiteUserPage import EditWebsiteUserPage
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ClientsTabs.SearchResults.DeleteOrCancelActivityDetailsPopupPage import DeleteOrCancelActivityDetailsPopupPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.ClientActivityTable import ClientActivityTable, ClientActivityTableRow
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable


class AccountsActivityTabPage(ClientsBaseTab):
    def wait(self):
        self.notificationMessage.waitForElement()
        self.activityDataTable.waitForDataToRender()

    def navigateToEditWebsiteUserPage(self):
        PrintMessage("Attempting to open Edit Website User page.", inStepMessage=True)
        self.editUserButton.click()
        return EditWebsiteUserPage(self.webdriver)

    def navigateToActivityDetailsPopupPage(self, filteredRow: ClientActivityTableRow):
        """
        Delete the activity row at the given index
        Performs either a delete or cancel action on the activity details popup. This can be extended to use the
        Delete or cancel activity for all other incomplete activity types(Example : Edit Income payment, Top Up With ITFLS Etc)
        """
        filteredRow.deleteButton.click()
        return DeleteOrCancelActivityDetailsPopupPage(self.webdriver)

    @property
    def notificationMessage(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='notification-message undefined']")

    @property
    def newProductButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='New product']")

    @property
    def workflowTableFilterButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Workflow table filter']")

    @property
    def expandFullScreenButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Expand full screen']")

    @property
    def dataTable(self):
        return ClientActivityTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")

    @property
    def rolesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Roles']")

    @property
    def editUserButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Edit User']")

    @property
    def applyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Apply']")

    @property
    def activityTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Activity type']//parent::div//following-sibling::div/select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def dateDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Date']//parent::div//following-sibling::div/select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def activityStatusDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Activity status']//parent::div//following-sibling::div/select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def activityDataTable(self):
        resultTable = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        resultTable.rowType = ClientActivityTableRow
        resultTable.headerCellLocator = (By.XPATH, ".//tr//th")
        resultTable.headerSectionLocator = (By.XPATH, ".//thead//tr")
        resultTable.headerCellLocator = (By.XPATH, ".//th")
        resultTable.waitForDataToRender()
        return resultTable
