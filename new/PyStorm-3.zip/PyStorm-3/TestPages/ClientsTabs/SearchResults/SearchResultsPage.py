from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class SearchResultsPage(PlatformPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, './/th[@class]'))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def clientId(self):
        content = self.webdriver.find_elements(By.XPATH, "//div[@role='main']//p[contains(text(),'Client ID')]")
        if content:
            return content[0].text.split(": ")[1]
        return None

    @property
    def clientsSubAccountsListButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@class='name']//parent::span//parent::button[@class='trigger']")
