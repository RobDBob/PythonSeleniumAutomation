from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class TrustRequiredOneBeneficiaryWarningPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ARE_YOU_SURE)

    def deleteAndNavigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingDetailsPage import TrustServicingDetailsPage
        self.deleteButton.click()
        return TrustServicingDetailsPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH,
                     "//div[@class='inner']//div[@class='content']//p[contains(text(),'Are you sure')]")

    @property
    def trustMemberExplainedMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH,
                     "//div[@class='inner']//div[@class='content']//p[contains(text(),'For new trusts where trust category')]")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH,
                      "//div[@class='inner']//div[@class='content']//div[contains(@class,'row')]//button[text()='Cancel']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH,
                      "//div[@class='inner']//div[@class='content']//div[contains(@class,'row')]//button[text()='Delete']")
