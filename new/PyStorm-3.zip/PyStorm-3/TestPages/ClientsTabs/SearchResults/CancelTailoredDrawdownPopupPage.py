from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class CancelTailoredDrawdownPopupPage(BasePage):
    def wait(self):
        self.areYouSureYouWantToCancelTheDrawdownLabel.waitForText(PageEnums.ARE_YOU_SURE_YOU_WANT_TO_CANCEL_THE_TAILORED_DRAWDOWN)

    @property
    def areYouSureYouWantToCancelTheDrawdownLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Are you sure you want to cancel the tailored drawdown?']")

    @property
    def yesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Yes']")

    @property
    def noButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='No']")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='close-btn']")
