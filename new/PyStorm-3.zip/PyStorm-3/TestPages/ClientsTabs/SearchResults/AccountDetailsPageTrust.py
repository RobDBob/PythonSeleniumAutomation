from datetime import date
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.Rows.TrustTrackerOutStandingDocumentationRow import TrustTrackerOutStandingDocumentationRow
from TestPages.PlatformPage import PlatformPage
from TestPages.WebDriver import ExpectedConditions as EC


class AccountDetailsPageTrust(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CLIENT_DETAILS_ACCOUNT_INFO)

    def updateNewBusinessTrustTracker(self, testData: dict):
        self.newBusinessTrustTrackerExpandButton.click()
        if testData.get("Tracker", None):
            trackerTestData = testData["Tracker"]
            if trackerTestData.get("TrackerStatus", None):
                self.trackerStatusDropdown.selectOption(trackerTestData["TrackerStatus"])
            if trackerTestData.get("AdditionalNotes", None):
                self.auditLogAdditionalNotesEditField.send_keys(trackerTestData["AdditionalNotes"])
            self.saveTrackerDetailsButton.click()

        self.newBusinessTrustTrackerExpandButton.click()
        if testData.get("ReceivedOutstandingDocumentation", []):
            for receivedOutstandingDoc in testData["ReceivedOutstandingDocumentation"]:
                row: TrustTrackerOutStandingDocumentationRow = self.outstandingDocumentationTable.getRow(columnName="Document",
                                                                                                         value=receivedOutstandingDoc)
                row.receivedCorrectlyCheckBox.click()
            self.saveDocumentationDetailsButton.click()

    @retry(exceptions=TimeoutException, tries=2, delay=5)
    def updateAccountDetails(self, testData: dict):
        # assume Account Details is expanded by default upon entry
        self.accountDetailsEditButton.click()
        self.accountDetailsSaveButton.waitForElement()

        if testData.get("DateOfTrust", None):
            if testData["DateOfTrust"] == "Today":
                self.accountDetailsDateOfTrustDatePicker.specify_date(date.today())

        if testData.get("AccountStatus", None):
            self.accountDetailsStatusDropdown.selectOption(testData["AccountStatus"])

        self.accountDetailsSaveButton.click()

        waitcondition = EC.text_to_be_present_in_element((By.XPATH, "//div[@class='warning-message']/p"), "successfully updated")
        WebDriverWait(self.webdriver, 60).until(waitcondition)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Client Details - Account Info']")

    @property
    def trustName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3")

    @property
    def selectViewDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='subclaccountid']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountDetailsExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Account Details']")

    @property
    def mailingPreferenceExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Mailing Preference']")

    @property
    def bankAccountsExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Bank Accounts']")

    @property
    def reportingOptionsExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Reporting Options']")

    @property
    def moneyLaunderingExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Money Laundering']")

    @property
    def agreedContactMethodExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Agreed Contact Method']")

    @property
    def accountDetailsEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Account Details']//parent::h2//following-sibling::span/a[text()='Edit']")

    @property
    def accountDetailsSaveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Account Details']//parent::h2//following-sibling::span/span/a[text()='Save']")

    @property
    def accountDetailsCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Account Details']//parent::h2//following-sibling::span/span/a[text()='Cancel']")

    @property
    def accountDetailsNewExistingTrustLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'New/Existing Trust:')]")

    @property
    def accountDetailsNameOfWrapAccountEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Name of Wrap Account:')]//following-sibling::div[@id='txtAccountName']/input")

    @property
    def accountDetailsTrustLEILabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Trust LEI:')]")

    @property
    def accountDetailsAccountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Type:')]")

    @property
    def accountDetailsEntityTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Entity Type')]")

    @property
    def accountDetailsLawToApplyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Law to Apply:')]")

    @property
    def accountDetailsCompanyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Company:')]")

    @property
    def accountDetailsAdvisorCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Advisor Code:')]")

    @property
    def accountDetailsAgencyCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Agency Code:')]")

    @property
    def accountDetailsDateOfTrustLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Date of Trust:')]")

    @property
    def accountDetailsDateOfTrustDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.ID, "txtDateOfTrust")

    @property
    def accountDetailsBusinessTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Business Type')]")

    @property
    def accountDetailsBusinessTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='BusinessType']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountDetailsTaxOtherThanUKLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Is the entity resident for tax purposes')]")

    @property
    def accountDetailsStatusLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Status')]")

    @property
    def accountDetailsStatusDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='Status']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountDetailsInceptionDateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Inception Date:')]")

    @property
    def accountDetailsCommissionPayingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Commission Paying?')]")

    @property
    def accountDetailsAdviceTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Advice Type')]")

    @property
    def accountDetailsAdviceTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='AdviceTypeDrop']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountDetailsTrustEmailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Trust Email Address:')]")

    @property
    def accountDetailsTrustEmailEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Trust Email Address:')]//following-sibling::input")

    @property
    def mailingPreferenceGoPaperlessLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Go Paperless:')]")

    @property
    def mailingPreferenceGoPaperlessYesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='MailingPreferenceYes']")

    @property
    def mailingPreferenceGoPaperlessNoButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//input[@id='MailingPreferenceNo']")

    @property
    def mailingPreferenceEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Mailing Preference']//parent::h2//following-sibling::span/a[text()='Edit']")

    @property
    def mailingPreferenceChangeHistoryLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Change History')]")

    @property
    def mailingPrefenceChangeHistoryTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@id='MailingPreferenceHistory']")
        table.firstRowIsHeader = True
        table.headerSectionLocator = (By.XPATH, ".//tbody/tr[1]")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = GenericBaseRow
        return table

    @property
    def mailingpPreferenceDeclarationCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='MailingPreferenceConfirmation']")

    @property
    def mailingPreferenceCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='cancel3' and text()='Cancel']")

    @property
    def mailingPreferenceSubmitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='save3' and text()='Submit']")

    @property
    def bankAccountsEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Bank Accounts']//parent::h2//following-sibling::span/a[text()='Edit']")

    @property
    def bankAccountsBankAccountHistoryButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Bank Account History']")

    @property
    def bankAccountsAccountOneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'BANK ACCOUNT 1')]")

    @property
    def bankAccountsAccountOneButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h3[contains(text(),'BANK ACCOUNT 1')]//following-sibling::span[contains(@id,'expandBankAccountButton')]")

    @property
    def bankAccountsOwnerLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Owner')]")

    @property
    def bankAccountOwnerDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='Owner1']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def bankAccountsNameEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Account Name:')]//parent::div//following-sibling::div/input[@id='holdername1']")

    @property
    def bankAccountsNumberEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Account Number:')]//parent::div//following-sibling::div/input[@id='accbank1']")

    @property
    def bankAccountsSortCode1EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Sort Code:')]//parent::div//following-sibling::div/div//input[@id='sortcode1_1']")

    @property
    def bankAccountsSortCode2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Sort Code:')]//parent::div//following-sibling::div/div//input[@id='sortcode1_2']")

    @property
    def bankAccountsSortCode3EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Sort Code:')]//parent::div//following-sibling::div/div//input[@id='sortcode1_3']")

    @property
    def bankAccountsRollNumberEditField(self):
        return EditField(self.webdriver,
                         self.webdriver,
                         By.XPATH,
                         "//label[contains(text(),'Building Society Roll Number:')]//parent::div//following-sibling::div/input[@id='rollnum1']")

    @property
    def bankAccountsBankNameEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Bank Name:')]//parent::div//following-sibling::div/input[@id='bankname1']")

    @property
    def bankAccountsAddress1EditField(self):
        return EditField(self.webdriver,
                         self.webdriver,
                         By.XPATH,
                         "//label[contains(text(),'Address Line 1:')]//parent::div//following-sibling::div/input[@id='bankaddress11']")

    @property
    def bankAccountsAddress2EditField(self):
        return EditField(self.webdriver,
                         self.webdriver,
                         By.XPATH,
                         "//label[contains(text(),'Address Line 2:')]//parent::div//following-sibling::div/input[@id='bankaddress21']")

    @property
    def bankAccountsAddress3EditField(self):
        return EditField(self.webdriver,
                         self.webdriver,
                         By.XPATH,
                         "//label[contains(text(),'Address Line 3:')]//parent::div//following-sibling::div/input[@id='bankaddress31']")

    @property
    def bankAccountsPostCodeEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[contains(text(),'Postcode:')]//parent::div//following-sibling::div/input[@id='bankpostcode1']")

    @property
    def bankAccountsDDInstructionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Direct Debit Instruction:')]")

    @property
    def bankAccountsDDInstructionCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='directdebit1']//ancestor::div[@class='square-checkbox ']")

    @property
    def bankAccountsNominatedWithdrawalsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Nominated account for withdrawals:')]")

    @property
    def bankAccountsNominatedWithdrawalsCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='externaldefault1']//ancestor::div[@class='square-checkbox ']")

    @property
    def bankAccountsDDIReceivedLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'DDI Received:')]")

    @property
    def bankAccountsDDIReceivedCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='DDIrec1']//ancestor::div[@class='square-checkbox ']")

    @property
    def bankAccountsDDSetupLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Direct Debit Set Up:')]")

    @property
    def bankAccountsBankWizardAbsoluteLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'BankWizardAbsoluteStatus:')]")

    @property
    def bankAccountsSourceMandate(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Source of Mandate:')]")

    @property
    def bankAccountsVerificationLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Verification of account received:')]")

    @property
    def bankAccountsVerificationCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='verificationrec1']//ancestor::div[@class='square-checkbox ']")

    @property
    def bankAccountsCancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Bank Accounts']//parent::h2//following-sibling::span/span/a[text()='Cancel']")

    @property
    def bankAccountsSaveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Bank Accounts']//parent::h2//following-sibling::span/span/a[text()='Save']")

    @property
    def reportingOptionsEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Reporting Options']//parent::h2//following-sibling::span/a[text()='Edit']")

    @property
    def reportingOptionsBaseCurrenyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Base Currency:')]")

    @property
    def reportingOptionsReviewFrequencyLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Review Frequency:')]")

    @property
    def reportingOptionsReviewFrequencyDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='reviewfrequency']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def reportingOptionsReviewDateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Review Date:')]")

    @property
    def reportingOptionsReviewDateDatePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//input[@id='FirstReviewDate']")

    @property
    def reportingOptionsCancelButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//span[text()='Reporting Options']//parent::h2//following-sibling::span/span/a[text()='Cancel']")

    @property
    def reportingOptionsSaveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Reporting Options']//parent::h2//following-sibling::span/span/a[text()='Save']")

    @property
    def moneyLaunderingTrusteesLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Details of Trustees')]")

    @property
    def moneyLaunderingConfirmation(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Confirmation']")

    @property
    def moneyLaunderingIntroducingFirm(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[contains(text(),'Details of Trustees')]")

    @property
    def agreedContactMethodEditButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Agreed Contact Method']//parent::h2//following-sibling::span/a[text()='Edit']")

    @property
    def agreedContactMethodPermissionLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[contains(text(),'Client has given permission for contact by:')]")

    @property
    def agreedContactMethodMailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Mail:')]")

    @property
    def agreedContactMethodMailCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='protectionmail']")

    @property
    def agreedContactMethodPhoneLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Phone:')]")

    @property
    def agreedContactMethodPhoneCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='protectionphone']")

    @property
    def agreedContactMethodEmailLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Email:')]")

    @property
    def agreedContactMethodEmailCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='protectionemail']")

    @property
    def agreedContactMethodSMSLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'SMS:')]")

    @property
    def agreedContactMethodSMSCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='protectionsms']")

    @property
    def agreedContactMethodExceptionsEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Exceptions:')]//following-sibling::p/textarea[@id='protectionex']")

    @property
    def agreedContactMethodOptOutLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Client has opted-out of receiving:')]")

    @property
    def agreedContactMethodContractLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//Label[contains(text(),'Contract Note:')]")

    @property
    def agreedContactMethodContractCheckBox(self):
        return CheckBox(self.webdriver, self.webdriver, By.XPATH, "//input[@id='optout2']")

    @property
    def agreedContactMethodCancelButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//span[text()='Agreed Contact Method']//parent::h2//following-sibling::span/span/a[text()='Cancel']")

    @property
    def agreedContactMethodSaveButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//span[text()='Agreed Contact Method']//parent::h2//following-sibling::span/span/a[text()='Save']")

    # New bussiness Trust Tracker Section

    @property
    def newBusinessTrustTrackerExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='New Business Trust Tracker']")

    @property
    def trackerStatusDropdown(self):
        return DropdownListbox(self.webdriver, self.webdriver,
                               By.ID,
                               "details_StatusNote",
                               optionsLocator=(By.XPATH, ".//option"),
                               checkAriaState=False)

    @property
    def auditLogAdditionalNotesEditField(self):
        return EditField(self.webdriver, self.webdriver, By.ID, "details_AuditLogTxt")

    @property
    def saveTrackerDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "SaveTrackerDetails")

    @property
    def outstandingDocumentationTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.ID, "ContentPlaceHolder_documentation_OutstandingDocumentationSection")
        table.headerSectionLocator = (By.ID, "documentation_DocumentationRepeater_DocumentationHeadingRow")
        table.headerCellLocator = (By.XPATH, ".//td[contains(@class, 'TableSubHead')]")
        table.dataLocator = None
        table.rowLocator = (By.XPATH, ".//tr[contains(@id, 'documentation_DocumentationRepeater_AuditLogRow')]")
        table.rowType = TrustTrackerOutStandingDocumentationRow
        return table

    @property
    def saveDocumentationDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "SaveDocumentationDetails")
