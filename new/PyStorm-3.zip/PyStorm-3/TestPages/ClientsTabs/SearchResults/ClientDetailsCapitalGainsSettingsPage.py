from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ClientDetailsCapitalGainsSettingsPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CapitalGainsSettings)
        self.pageSubHeading.waitForText(PageEnums.CapitalGainSettings)

    def submitCapitalGainSettings(self):
        from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
        self.submitButton.click()
        return AccountSummaryTabPage(self.webdriver)

    def cancelAndNavigateBackToSummaryPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
        self.yesButton.click()
        return AccountSummaryTabPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def pageSubHeading(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2")

    @property
    def cgtAllowanceValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[text()='CGT allowance']//parent::dt//following-sibling::dd")

    @property
    def cgtPercentageEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='CGT percentage']//parent::div//following-sibling::div//input")

    @property
    def submitButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Submit']")

    @property
    def cancelButton(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Cancel']")

    @property
    def doYouWantToCancelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Do you want to cancel?']")

    @property
    def yesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Yes']")

    @property
    def noButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='No']")
