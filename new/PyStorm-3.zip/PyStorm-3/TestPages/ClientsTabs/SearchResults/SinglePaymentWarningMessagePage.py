from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ClientsTabs.SearchResults.SearchResultsPage import SearchResultsPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class SinglePaymentWarningMessagePage(SearchResultsPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WARNING)

    def clickOkAndNavigateToSummaryPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
        self.okButton.click(jsClick=True)
        return AccountSummaryTabPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Warning']")

    @property
    def warningMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Warning']//parent::div//following-sibling::div[@class='content']//p")

    @property
    def okButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Warning']//parent::div//following-sibling::div//button")
