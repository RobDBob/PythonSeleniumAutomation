from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.WebDriver import ExpectedConditions as EC


class AccountsInsightsTabPage(ClientsBaseTab):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@role='tabpanel' and @id='panel-3']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    @property
    def datePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//input[@class='form-input']")

    @property
    def createClientPortfolioReportLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Create client portfolio report']")

    @property
    def insightMap(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='insight-map']")

    @property
    def viewAllLink(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='View all']")

    @property
    def pieChartViewButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='pie-chart-view-button']")

    @property
    def dataTableViewButtonACA(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Asset class allocation']/../..//button[@class='table-view-button']")

    @property
    def filterAssetClassButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Filter asset class']")

    @property
    def assetClassAllocationTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table asset-class-table']")

    @property
    def columnChartViewButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='column-chart-view-button']")

    @property
    def dataTableViewButtonSA(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Sector allocation']/../..//button[@class='table-view-button']")

    @property
    def sectorAllocationTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//div[@class='react-auto-height ']/div[@class='column-chart']")
