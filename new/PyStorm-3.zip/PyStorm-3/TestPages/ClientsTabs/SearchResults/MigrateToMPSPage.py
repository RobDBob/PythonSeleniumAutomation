from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from TestPages import PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.GenericBaseRow import GenericBaseRow
from TestPages.PageObjects.BaseObjects.Table.Rows.MigrateToMPSSubAccountHoldingsRow import MigrateToMPSSubAccountHoldingsRow
from TestPages.PlatformPage import PlatformPage
from TestPages.Trackingorders.InvestmentSelectionToolPage import InvestmentSelectionToolPage


class MigrateToMPSPage(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.MigrateToMPS)

    def getTotalOfAvailableValues(self):
        total = 0
        for k in self.migrateToMPSSubAccountHoldingsTable.dataRows:
            total += float(k.valueAvailableLabel.replace('£', '').replace(',', ''))
        return total

    def navigateToInvestmentSelectionToolPage(self):
        self.investmentManagerMPSModelFindButton.click()
        return InvestmentSelectionToolPage(self.webdriver)

    def setInvestment(self, dataLabel):
        with self.navigateToInvestmentSelectionToolPage() as investmentSelectionToolPage:
            investmentSelectionToolPage.navigateToMPSPortfoliosPage().selectProduct(dataLabel)

    def getDeclarationCombinedPartBPartCPartD(self):
        return f"{self.declarationTextPartB.textOnly}{self.declarationTextPartC.textOnly}{self.declarationTextPartD.textOnly}"

    def isFindButtonDisabled(self):
        disabledIndex = self.investmentManagerMPSModelFindButton.get_attribute("class").find("disabled")
        return disabledIndex > 0

    def getUnitsToMigrateValue(self):
        unitsToMigrate = self.getTotalOfAvailableValues()
        if unitsToMigrate - 50.00 > 0:
            return "50"
        raise UIException("Test data account do not have sufficient units")

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[contains(text(),'Migrate To MPS')]")

    @property
    def selectSubAccountLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='1. Select your sub account to migrate assets FROM']")

    @property
    def accountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account type')]")

    @property
    def accountTypeDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.webdriver, By.XPATH, "//select[@id='js-accountSelect']", optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def selectMPSModelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='2. Select MPS model to migrate assets TO']")

    @property
    def investmentManagerMPSModelLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Investment Manager (MPS) model')]")

    @property
    def investmentManagerMPSModelFindButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='js-findDimModel']")

    @property
    def backToTopButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Back to top']")

    @property
    def migrateToMPSSubAccountHoldingsTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@id='subAccountHoldingsTable']")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr[1]")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = MigrateToMPSSubAccountHoldingsRow
        return table

    @property
    def totalAvailableValue(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//td[contains(text(),'Total Available Value:')]//following-sibling::td")

    @property
    def declarationTextPartA(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h2[text()='Declaration']/parent::div/following-sibling::div/p")

    @property
    def declarationTextPartB(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h2[text()='Declaration']/parent::div/following-sibling::div/div/div/following-sibling::div/p[1]")

    @property
    def declarationTextPartC(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h2[text()='Declaration']/parent::div/following-sibling::div/div/div/following-sibling::div/p[2]")

    @property
    def declarationTextPartD(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h2[text()='Declaration']/parent::div/following-sibling::div/div/div/following-sibling::div/p[3]")

    @property
    def migrateAssetToTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@id='instrumentSelectionTable']")
        table.headerSectionLocator = (By.XPATH, ".//thead/tr[1]")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = GenericBaseRow
        return table

    @property
    def migrateAssetToTableHeader(self):
        header = self.migrateAssetToTable.headers
        header = ["Select All Units" if k == "Select All Units\nSelect All Units" else k for k in header]
        return header

    @property
    def invesmentManagerModel(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='dimModelName']")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@id='submitButton']")

    @property
    def inputUnitsToMigrate(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//input[@id='unitsToMigrate_GBP']")
