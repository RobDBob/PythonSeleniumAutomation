from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.StringMethods import sortListOfDicts
from TestPages import PageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DatePicker import DatePicker
from TestPages.PageObjects.BaseObjects.Table.InvestmentHoldingsTable import InvestmentHoldingsTable
from TestPages.PageObjects.BaseObjects.Table.InvestmentsHoldingsTable import InvestmentsHoldingsTable
from TestPages.PageObjects.BaseObjects.Table.Rows.InvestmentHoldingsRow import InvestmentHoldingsRow
from TestPages.WebDriver import ExpectedConditions as EC
from TestPages.WebDriver.ObjProduction import manufacture


class AccountsInvestmentsTabPage(ClientsBaseTab):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//div[@role='tabpanel' and @id='panel-1']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def getAllInvestmentDetailsForProductView(self):
        """
        Retrieves all investment details from the product view of the Investments table.

        It waits for the 'Target allocation' header to be present, then iterates through each investment holding,
        extracting details such as investments, allocation, target allocation, fund code, quantity, location,
        unit cost, unit price, total cost, market value, and difference.

        :return: A sorted list of dictionaries, where each dictionary represents an investment and its details.
             The list is sorted by the 'INVESTMENTS' key.
        """
        waitCondition = EC.presence_of_element_located((By.XPATH, "//th[text() = 'Target allocation']"))
        WebDriverWait(self.webdriver, 30).until(waitCondition)
        funds = []
        InvestmentHoldingsRow.HEADER_INDICES = self.investmentsTable.headerIndices
        investmentHoldings = self.investmentsTable.getCurrentInvestmentHoldings()
        for investmentHolding in investmentHoldings:
            productInvestments = self.investmentsTable.getInvestmentHoldingsTableProductView(investmentHolding).getAllInvestments()
            for productInvestment in productInvestments:
                investmentRow = self.investmentsTable.getInvestmentHoldingsTableProductView(investmentHolding).getInvestmentRow(productInvestment)
                fund = {
                    PageEnums.INVESTMENTS: investmentRow.investmentsLabel.text,
                    PageEnums.ALLOCATION: investmentRow.allocationPercentageLabel.text,
                    PageEnums.Quantity: investmentRow.quantityLabel.text,
                    PageEnums.UNIT_COST: investmentRow.unitCosLabel.text,
                    PageEnums.UNIT_PRICE: investmentRow.unitPriceLabel.text,
                    PageEnums.TOTAL_COST: investmentRow.totalCostLabel.text,
                    PageEnums.MARKET_VALUE2: investmentRow.marketLabel.text,
                    PageEnums.DIFFERENCE: investmentRow.differenceLabel.text
                }
                if PageEnums.TARGET_ALLOCATION in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.TARGET_ALLOCATION] = investmentRow.targetAllocationLabel.text
                if PageEnums.FUND_CODE in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.FUND_CODE] = investmentRow.fundCodeLabel.text
                if PageEnums.LOCATION in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.LOCATION] = investmentRow.locationLabel.text
                funds.append(fund)
        PrintMessage(f"Investment holdings: '{funds}'", inStepMessage=True)
        return sortListOfDicts(funds, PageEnums.INVESTMENTS)

    def getAllInvestmentDetailsForAssetView(self):
        """
        Retrieves all investment details for the asset view of the Investments table.

        It iterates through each investment row, extracting details such as investments,
        allocation, target allocation, fund code, quantity, location, unit cost, unit price,
        total cost, market value, and difference.

        :return: A sorted list of dictionaries, where each dictionary represents an investment and its details.
             The list is sorted by the 'INVESTMENTS' key.
        """
        funds = []
        InvestmentHoldingsRow.HEADER_INDICES = self.investmentsTable.headerIndices
        for row in self.investmentsTable.dataRows:
            if not isinstance(row, InvestmentHoldingsTable):
                continue
            for investment in row.getAllInvestments():
                investmentRow = row.getInvestmentRow(investment)
                fund = {
                    PageEnums.INVESTMENTS: investmentRow.investmentsLabel.text,
                    PageEnums.ALLOCATION: investmentRow.allocationPercentageLabel.text,
                    PageEnums.Quantity: investmentRow.quantityLabel.text,
                    PageEnums.UNIT_COST: investmentRow.unitCosLabel.text,
                    PageEnums.UNIT_PRICE: investmentRow.unitPriceLabel.text,
                    PageEnums.TOTAL_COST: investmentRow.totalCostLabel.text,
                    PageEnums.MARKET_VALUE2: investmentRow.marketLabel.text,
                    PageEnums.DIFFERENCE: investmentRow.differenceLabel.text
                }
                if PageEnums.TARGET_ALLOCATION in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.TARGET_ALLOCATION] = investmentRow.targetAllocationLabel.text
                if PageEnums.FUND_CODE in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.FUND_CODE] = investmentRow.fundCodeLabel.text
                if PageEnums.LOCATION in InvestmentHoldingsRow.HEADER_INDICES:
                    fund[PageEnums.LOCATION] = investmentRow.locationLabel.text
                funds.append(fund)
        PrintMessage(f"Investment holdings: '{funds}'", inStepMessage=True)
        return sortListOfDicts(funds, PageEnums.INVESTMENTS)

    def setInvestmentsByTableFilterAssetTier1View(self):
        PrintMessage("*****Select Filter table by Asset and Tier 1.  click on apply*****", inStepMessage=True)
        self.tableFilterButton.click(jsClick=True)
        if not self.filterTableByTier1RadioButton.isActive:
            self.filterTableByTier1RadioButton.click(jsClick=True)
        if not self.filterTableByAssetRadioButton.isActive:
            self.filterTableByAssetRadioButton.click(jsClick=True)
        self.filterTableApplyButton.click(jsClick=True)

    def setInvestmentsByTableEditor(self):
        PrintMessage("****** Open column filter options ******* check All elements*** and click on apply*****", inStepMessage=True)
        self.tableEditorButton.click(jsClick=True)
        elements = manufacture(CheckBox, self.webdriver, self.webdriver, By.XPATH,
                               "//input[@type='checkbox' and not(@checked) and not(@disabled)]/following-sibling::span/span[@class='label-inner']")
        for element in elements:
            PrintMessage(f"Checking the optional element: {element.text}", inStepMessage=True)
            element.click(jsClick=True)
        self.tableEditorApplyButton.click(jsClick=True)
        PrintMessage("Table editor applied successfully.", inStepMessage=True)

    def applyDefaultsSettingsToTableEditor(self):
        PrintMessage("Applying default settings to ensure consistent test execution in subsequent runs.", inStepMessage=True)
        self.tableEditorButton.click(jsClick=True)
        self.tableEditorApplyDefaultButton.click(jsClick=True)
        PrintMessage("Default settings applied.", inStepMessage=True)

    @property
    def datePicker(self):
        return DatePicker(self.webdriver, self.webdriver, By.XPATH, "//input[@class='form-input' and @type='text']")

    @property
    def exportToExcelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Export to Excel']")

    @property
    def tableFilterButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Filter table']")

    @property
    def tableEditorButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Table editor']")

    @property
    def presentationModeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@title='Presentation mode']")

    @property
    def investmentsTable(self):
        return InvestmentsHoldingsTable(self.webdriver, self.webdriver, By.XPATH, "//table[contains(@class, 'investments-table')]")

    @property
    def filterTableByTier1RadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@class='rb-design']//following-sibling::span[contains(text(),'Tier 1')]")

    @property
    def filterTableByAssetRadioButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@class='rb-design']//following-sibling::span[contains(text(),'Asset')]")

    @property
    def filterTableApplyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='row narrow-gutter']/div/button[@class='btn primary block-xxs']")

    @property
    def tableEditorApplyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='row narrow-gutter']/div/button[@class='btn primary block-xxs']")

    @property
    def tableEditorApplyDefaultButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Apply default']")
