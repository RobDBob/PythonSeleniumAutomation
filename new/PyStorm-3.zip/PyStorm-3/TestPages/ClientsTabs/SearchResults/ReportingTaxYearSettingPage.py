from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.ClientDetails.RegulatoryPage import RegulatoryPage
from TestPages.WebDriver import ExpectedConditions as EC


class ReportingTaxYearSettingPage(BasePage):
    REPORTING_TAX_YEAR_SETTING_LABEL_LOCATOR = "//label[text()='Tax reporting country*']//ancestor::div[@class='content']//preceding-sibling::div//h1"

    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.REPORTING_TAX_YEAR_SETTING)
        waitCondition = EC.presence_of_element_located(
            (By.XPATH, self.REPORTING_TAX_YEAR_SETTING_LABEL_LOCATOR))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def cancelAndNavigateToRegulatoryPage(self):
        self.cancelNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    def saveAndNavigateToRegulatoryPage(self):
        self.saveNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    def addAndNavigateToRegulatoryPage(self):
        self.addNationalityDetailsButton.waitForElement()
        self.addNationalityDetailsButton.jsClick()
        return RegulatoryPage(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h1[text()='Reporting tax year setting']")

    @property
    def taxReportingCountryDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[text()='Tax reporting country*']//parent::div//following-sibling::div//select",
                                   optionsLocator=(
                                       By.TAG_NAME,
                                       "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def cancelNationalityDetailsButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "//h1[text()='Reporting tax year setting']//parent::div//following-sibling::div//button[text()='Cancel']")

    @property
    def addNationalityDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Add']")

    @property
    def closeNationalityDetailsButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//h1[text()='Reporting tax year setting']//parent::div//button//span[text()='close']")

    @property
    def saveNationalityDetailsButton(self):
        return Button(self.webdriver,
                      self.webdriver,
                      By.XPATH,
                      "//h1[text()='Reporting tax year setting']//parent::div//following-sibling::div//div//button[text()='Save']")

    @property
    def atLeastOneNationalityNeededOkButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//p[text()='Client must have at least one nationality']//parent::div//div//button[text()='OK']")
