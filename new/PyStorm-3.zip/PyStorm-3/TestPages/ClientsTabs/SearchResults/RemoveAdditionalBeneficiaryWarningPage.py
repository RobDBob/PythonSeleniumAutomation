from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class RemoveAdditionalBeneficiaryWarningPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WARNING)

    def clickOkAndNavigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingDetailsPage import TrustServicingDetailsPage
        self.okButton.click()
        return TrustServicingDetailsPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']//h1")

    @property
    def warningMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']//div[@class='content']//p")

    @property
    def okButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='inner']//button[text()='OK']")
