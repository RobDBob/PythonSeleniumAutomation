from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.CurrentAvailableLocalToolTipTableRow import CurrentAvailableLocalToolTipTableRow


class ABRDNJSIPPCashAvailablePopUpPage(BaseTestObject):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ABRDN_JSIPP)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//h1")

    @property
    def currentlyAvailableLocalToolTipButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//*[ contains(text(),'Currently available local')]/div/button")

    @property
    def callBalanceValueLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//*[contains(text(),'Call balance')]//following-sibling::*")

    @property
    def buyOrderCommitmentsValueLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//*[contains(text(),'Buy order commitments')]//following-sibling::*")

    @property
    def currentAvailableLocalToolTipTable(self):
        resultTable = GenericTable(self.webdriver, self.parentElement, By.XPATH, "//table[@class='simple-table no-sided-padding']")
        resultTable.rowType = CurrentAvailableLocalToolTipTableRow
        return resultTable
