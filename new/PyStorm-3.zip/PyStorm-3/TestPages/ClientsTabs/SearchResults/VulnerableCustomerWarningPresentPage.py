from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class VulnerableCustomerWarningPresentPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.VULNERABLE_CUSTOMER_WARNING_PRESENT)

    def navigateToContactDetailsPageClickingViewDetailsButton(self):
        from TestPages.PageObjects.ClientDetails.ContactDetailsPage import ContactDetailsPage
        self.viewDetailsButton.click()
        return ContactDetailsPage(self.webdriver)

    def navigateToAccountSummaryTabPageClickingOkButton(self):
        from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
        self.okButton.click()
        return AccountSummaryTabPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def okButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Ok']")

    @property
    def viewDetailsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='View details >']")
