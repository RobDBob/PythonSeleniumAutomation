from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.AddInterestParty.AddInterestedPartyPage import AddInterestedPartyPage
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.ClientsTabs.SearchResults.AccountDetailsPage import AccountDetailsPage
from TestPages.ClientsTabs.SearchResults.AccountDetailsPageTrust import AccountDetailsPageTrust
from TestPages.ClientsTabs.SearchResults.JointAccountSummaryPage import JointAccountSummaryPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.PageObjects.BaseObjects.Table.Rows.AddInterestedPartyRow import AddInterestedPartyRow
from TestPages.PageObjects.BaseObjects.Table.Rows.TrustMemberRow import TrustMemberRow
from TestPages.PageObjects.BaseObjects.Table.SearchResultsTable import SearchResultsTable
from TestPages.PageObjects.ClientDetails.CompanyDetails import CompanyDetails
from TestPages.PageObjects.ClientDetails.OrganisationDetails import OrganisationDetails
from TestPages.PageObjects.ClientDetails.PersonalDetailsPage import PersonalDetailsPage
from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
from TestPages.WebDriver import ExpectedConditions as EC


class AccountsRolesTabPage(ClientsBaseTab):
    TRUST_ACCOUNT_TYPE = "Trust account holder"
    INDIVIDUAL_ACCOUNT_TYPE = "Individual account holder"
    JOINT_ACCOUNT_TYPE = "Joint account holder"

    def wait(self):
        waitCondition = EC.presence_of_element_located(
            (By.XPATH, "//div[@role='tabpanel' and @id='panel-6']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def navigateToAddInterestedPartyPage(self):
        self.addInterestedPartyButton.click()
        return AddInterestedPartyPage(self.webdriver)

    def navigateToAccountDetailsPage(self):
        """
        Need to determine what type of account we're opening details for
        """
        match self.getAccountType():
            case self.TRUST_ACCOUNT_TYPE:
                detailsPage = AccountDetailsPageTrust
            case self.INDIVIDUAL_ACCOUNT_TYPE:
                detailsPage = AccountDetailsPage
            case self.JOINT_ACCOUNT_TYPE:
                detailsPage = AccountDetailsPage
            case _:
                detailsPage = AccountDetailsPage
        self.viewAccountInformationButton.click()
        return detailsPage(self.webdriver)

    def navigateToPersonalDetailsPage(self):
        """
        closeHintDialogIfPresent added here because sometimes Tips Dialog pop up appear which hides the visibility of the element to be clicked
        """
        self.closeHintDialogIfPresent()
        self.clientNameIDButton.click()
        return PersonalDetailsPage(self.webdriver)

    def navigateToCompanyDetailsPage(self):
        self.clientNameIDButton.click()
        return CompanyDetails(self.webdriver)

    def navigateToOrganisationDetailsPage(self):
        self.clientNameIDButton.click()
        return OrganisationDetails(self.webdriver)

    def clickOnAddInterestedPartyName(self, addInterestedPartyName):
        interestedPartysName = self.webdriver.find_element(
            By.XPATH, f"//button[@class='rd-client tree-node']//div[contains(text(),'{addInterestedPartyName}')]")
        interestedPartysName.click()
        return PersonalDetailsPage(self.webdriver)

    def navigateToOrganisationCorporateDetailsPage(self):
        self.clientNameIDButton.jsClick()
        return OrganisationDetails(self.webdriver)

    def getAccountType(self):
        holdingElements = self.webdriver.find_elements(By.XPATH, "//li[contains(@class,'list-container')]//span/b")
        if holdingElements:
            return holdingElements[0].text
        return None

    def editLastRowOfInterestedPartyTableAndNavigateToPersonalDetailsPage(self):
        newRow: AddInterestedPartyRow = self.addInterestedPartiesTable.getLastRow()
        newRow.editButton.click()
        return PersonalDetailsPage(self.webdriver)

    def getRoleTypeBoxCustomerNameLabel(self, roleType):
        return Label(self.webdriver, self.webdriver,
                     By.XPATH, f"//b[text()='{roleType}']//following-sibling::p")

    def navigateToTrustServicingPage(self):
        self.addTrustMemberButton.jsClick()
        return TrustServicingPage(self.webdriver)

    def hierarchicalDiagramAccount(self, expectedAccounts):
        """Confirm the presence of the expected accounts in the hierarchical Diagram"""
        for expectedAccount in expectedAccounts:
            valueWaiter = EC.text_to_be_present_in_any_of_elements(
                (By.XPATH, "//li[@class='product-item']/span/div/span[@class='product-id']"), expectedAccount)
            WebDriverWait(self.webdriver, 60).until(valueWaiter)

    def navigateToJointAccountSummaryPage(self):
        self.jointAccountIDButton.click()
        return JointAccountSummaryPage(self.webdriver)

    @retry(exceptions=(UIException, TimeoutException), delay=5, tries=4)
    def updateAccountStatusToActive(self):
        self.webdriver.refresh()
        PrintMessage("Set account status as 'Wrap: Active'")
        accountDetailsPage: AccountDetailsPage = self.navigateToAccountDetailsPage()
        accountDetailsPage.updateAccountStatusToActive()

        return accountDetailsPage.navigateToRolesPageFromAccountInformationPage()

    @property
    def presentationModeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='presentation-mode-button']")

    @property
    def clientNameIDButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='rd-client tree-node']")

    @property
    def jointAccountIDButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//b[text()='Joint account holder']//following-sibling::p//a")

    @property
    def holdingContainer(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[@class='rd-node holding-container']")

    @property
    def viewAccountInformationButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='View account information']")

    @property
    def productListContainer(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//ul[@class='product-list-container']")

    @property
    def interestedPartiesHeader(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Interested parties']")

    @property
    def interestedPartiesTooltipButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='tooltip-button']")

    @property
    def dataTable(self):
        return SearchResultsTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")

    @property
    def addInterestedPartyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Add interested party']")

    @property
    def addTrustMemberButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Add trust member']")

    @property
    def rolesPageHierarchicalDiagram(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//ul[@class='rd-holding-list']")

    @property
    def rolesTabPageButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Roles']")

    @property
    def customerInHierarchicalDiagramWithRoleButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//b[text()='Legal representative/Executor']//following-sibling::p")

    @property
    def addInterestedPartiesTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
        table.rowType = AddInterestedPartyRow
        table.headerCellLocator = (By.XPATH, ".//th")
        return table

    @property
    def editOnlineAccessButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Edit online access']//parent::button")

    @property
    def cancelEditOnlineAccessButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def deleteAddInterestedPartyButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@type='button' and text()='Delete']")

    @property
    def clientName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//button[@class='rd-client tree-node']//div[@class='rd-client-name']")

    @property
    def productNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[@class='product-name']")

    @property
    def productIDLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[@class='product-id']")

    @property
    def trustMemberTable(self):
        table = GenericTable(self.webdriver, self.webdriver, By.XPATH, "(//h3[text()='Trust members']//parent::div//following-sibling::div//table)[1]")
        table.headerCellLocator = (By.XPATH, ".//th")
        table.rowType = TrustMemberRow
        return table
