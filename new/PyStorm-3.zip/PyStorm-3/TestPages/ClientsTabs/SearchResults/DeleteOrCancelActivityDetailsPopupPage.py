from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class DeleteOrCancelActivityDetailsPopupPage(BasePage):
    def wait(self):
        self.pageTitleLabel.waitForText(PageEnums.ARE_YOU_SURE_YOU_WANT_TO_DELETE_THIS_ACTIVITY)
        self.cancelButton.waitForElement()
        self.deleteButton.waitForElement()

    def performDeleteOrCancelActivity(self, actionToPerform: str):
        """
        Performs either a delete or cancel action on the activity details popup.
        Delete or cancel activity for all other incomplete activity types(Example : Edit Income payment, Top Up With ITFLS Etc)
        """
        if actionToPerform == PageEnums.CANCEL:
            self.cancelButton.jsClick()
        else:
            self.deleteButton.jsClick()

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//p[text()='Are you sure you want to delete this activity?']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Cancel']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Delete']")
