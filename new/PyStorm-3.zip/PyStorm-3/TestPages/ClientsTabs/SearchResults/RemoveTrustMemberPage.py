from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.StateCallbacks import isPrecedingSiblingInputCheckedCB


class RemoveTrustMemberPage(BaseTestObject):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.TRUST_MEMBER_REMOVE_TRUST_MEMBER)

    def removeTrustMemberDetails(self):
        self.corporateCheckBox.click()
        self.saveButton.click()
        self.removeReasonDropdown.waitForElement()
        self.removeReasonDropdown.selectOption(PageEnums.REMOVED)
        self.saveButton.click()

    def cancelAndNavigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.cancelButton.jsClick()
        return TrustServicingPage(self.webdriver)

    def saveAndNavigateToTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingPage import TrustServicingPage
        self.saveButton.jsClick()
        return TrustServicingPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//h1")

    @property
    def corporateCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, By.XPATH, "//span[text()='Corporate trustee']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def removeReasonDropdown(self):
        dropDown = DropdownListbox(self.webdriver, self.parentElement, By.XPATH, "//label[text()='Remove reason']//parent::div//following-sibling::div//select",
                                   optionsLocator=(By.TAG_NAME, "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def saveButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Save']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Cancel']")

    @property
    def beneficiariesCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, By.XPATH, "//span[text()='Beneficiary']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def individualCheckBox(self):
        checkbox = CheckBox(self.webdriver, self.parentElement, By.XPATH, "//span[text()='Individual trustee']")
        checkbox.isCheckedFuncCB = isPrecedingSiblingInputCheckedCB
        return checkbox

    @property
    def validationMessageLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//div[@class='inline-error-message error']")

    @property
    def trustMemberNameLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//div[@class='content']//h4")

    @property
    def removeReasonValidationMessageLabel(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//label[text()='Remove reason']")
