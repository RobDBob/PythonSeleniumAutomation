from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.BackToSummaryPageHelper import BackToSummaryPageHelper
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class AccountDetailsAccountInfoPage(PlatformPage, BackToSummaryPageHelper):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CLIENT_DETAILS_ACCOUNT_INFO)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()]")

    @property
    def consolidationNameWithAccountNumber(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[@class='mb-20 text-size-18 text-normal']//span")

    @property
    def selectViewDropdown(self):
        dropDown = DropdownListbox(self.webdriver,
                                   self.webdriver,
                                   By.XPATH,
                                   "//label[contains(text(),'Select view')]//parent::div//following-sibling::select",
                                   optionsLocator=(
                                       By.TAG_NAME,
                                       "option"))
        dropDown.checkAriaState = False
        return dropDown

    @property
    def accountDetailsLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//span[text()='Account Details']")

    @property
    def minimizeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='hide1']")

    @property
    def maximizeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='show1']")

    @property
    def editButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[text()='Edit']")

    @property
    def accountNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Name:')]")

    @property
    def accountTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Account Type:')]")

    @property
    def agencyCodeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Agency Code')]")

    @property
    def statusLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Status')]")

    @property
    def inceptionDateLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Inception Date:')]")

    @property
    def commissionPayingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Commission Paying?')]")

    @property
    def adviceTypeLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Advice Type:')]")
