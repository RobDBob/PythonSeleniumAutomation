from selenium.webdriver.common.by import By
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class FutureRegularPaymentPopupPage(BasePage):
    def wait(self):
        self.pageTitleLabel.waitForElement()

    def navigateToProductPaymentInTab(self):
        from TestPages.ClientsTabs.ProductOverview.ProductPaymentInTab import ProductPaymentInTab
        self.yesButton.click()
        return ProductPaymentInTab(self.webdriver)

    @property
    def pageTitleLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Are you sure you want to cancel all future regular payments?']")

    @property
    def yesButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Yes']")

    @property
    def noButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='No']")
