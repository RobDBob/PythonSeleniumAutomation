from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from TestPages.ClientsTabs.SearchResults.AccountSummaryTabPage import AccountSummaryTabPage
from TestPages.Support.NewTabPage import NewTabPage
from TestPages.WebDriver import ExpectedConditions as EC


class JointAccountSummaryPage(AccountSummaryTabPage, NewTabPage):
    def wait(self):
        waitCondition = EC.presence_of_element_located((By.XPATH, "//button[@aria-selected='true' and text()='Summary']"))
        WebDriverWait(self.webdriver, 60).until(waitCondition)
