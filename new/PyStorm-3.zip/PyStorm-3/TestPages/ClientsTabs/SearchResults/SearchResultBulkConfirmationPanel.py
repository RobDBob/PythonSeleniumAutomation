from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Table.BulkConfirmationTabTable import BulkConfirmationTabTable
from TestPages.PageObjects.BaseObjects.Table.BulkRebalanceConfirmationTable import BulkRebalanceConfirmationTable
from TestPages.PageObjects.BaseObjects.Table.BulkRebalanceRebalanceTabTable import BulkRebalanceRebalanceTabTable
from TestPages.PageObjects.BaseObjects.Table.BulkRebalanceRegularInvestmentTabTable import BulkRebalanceRegularInvestmentTabTable


class SearchResultBulkConfirmationPanel(BaseTestObject):
    @property
    def bulkConfirmationClientsTable(self):
        return BulkConfirmationTabTable(self.webdriver, self.element, By.XPATH, ".//table[@class='data-table table-grid-view']")

    @property
    def bulkSwitchTable(self):
        return BulkConfirmationTabTable(self.webdriver, self.element, By.XPATH, ".//table[@class='data-table table-grid-view mb-30']")

    @property
    def bulkRebalanceRegularInvestmentTabTable(self):
        return BulkRebalanceRegularInvestmentTabTable(self.webdriver, self.element, By.XPATH, ".//table[@class='data-table table-grid-view']")

    @property
    def bulkRebalanceRebalanceTabTable(self):
        return BulkRebalanceRebalanceTabTable(self.webdriver, self.element, By.XPATH, ".//table[@class= 'data-table']")

    @property
    def bulkRebalanceConfirmationTable(self):
        return BulkRebalanceConfirmationTable(self.webdriver, self.element, By.XPATH, ".//table[@class='data-table table-grid-view']")
