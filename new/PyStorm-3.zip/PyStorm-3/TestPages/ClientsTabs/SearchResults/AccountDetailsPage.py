
from retry import retry
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.BasePage import BasePage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.Labels import Label


class AccountDetailsPage(BasePage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.AccountInformation)

    @retry(exceptions=TimeoutException, delay=6, tries=2)
    def updateAccountStatus(self, newStatus):
        PrintMessage(f"Update account status to '{newStatus}'", inStepMessage=True)
        self.editButtonAccountInformation.jsClick()
        self.saveButton.waitForElement()
        self.selectAccountStatusDropdown.selectOption(newStatus)
        self.saveButton.jsClick()
        self.saveButton.waitForElementToCeaseExist()
        self.accountStatusValueLabel.waitForText(newStatus)

    def updateAccountStatusToActive(self):
        """
        Update account to active, in order to do so, account must be set as pending prior to being active
        """
        # Updating the code to active Wrap account from Submitted to Active, Skipping Pending temporarily
        if self.accountStatusValueLabel.text == PageEnums.ACCOUNT_STATUS_SUBMITTED:
            self.updateAccountStatus(PageEnums.ACCOUNT_STATUS_ACTIVE)

        # if self.accountStatusValueLabel.text == PageEnums.ACCOUNT_STATUS_SUBMITTED:
        #     self.updateAccountStatus(PageEnums.ACCOUNT_STATUS_PENDING)

        # if self.accountStatusValueLabel.text == PageEnums.ACCOUNT_STATUS_PENDING:
        #     self.updateAccountStatus(PageEnums.ACCOUNT_STATUS_ACTIVE)

    def navigateToRolesPageFromAccountInformationPage(self):
        from TestPages.ClientsTabs.SearchResults.AccountsRolesTabPage import AccountsRolesTabPage
        self.closeButton.click()
        return AccountsRolesTabPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def accountInformation(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Account information']")

    @property
    def paperlessPreference(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Paperless Preference']")

    @property
    def changeHistory(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='Change History']")

    @property
    def clientHasOptOutOfReceiving(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h4[text()='Client has opt out of receiving']")

    @property
    def customersInformation(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//b[contains(text(),'s information')]")

    @property
    def accountName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account name']")

    @property
    def accountType(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account type']")

    @property
    def adviserName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Adviser name']")

    @property
    def adviserCode(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Adviser code']")

    @property
    def agencyCode(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Agency code']")

    @property
    def companyName(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Company name']")

    @property
    def adviceType(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Advice type']")

    @property
    def accountStatusLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account status']")

    @property
    def accountStatusValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Account status']/following-sibling::dd")

    @property
    def dateOfClosure(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Date of closure']")

    @property
    def inceptionDate(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Inception Date']")

    @property
    def commissionPaying(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Commission Paying']")

    @property
    def dateCommissionStoppedBeingPaid(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Date commission stopped being paid']")

    @property
    def contractNote(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Contract note']")

    @property
    def readOnlyAccess(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Read only access']")

    @property
    def editButtonAccountInformation(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//h4[text()='Account information']//parent::div//following-sibling::div//button)[1]")

    @property
    def editButtonPaperlessPreference(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//button[@title='Edit'])[2]")

    @property
    def editButtonChangeHistory(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//button[@title='Edit'])[3]")

    @property
    def editButtonCustomerInformation(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//button[@title='Edit'])[4]")

    @property
    def closeButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@class='close-btn']")

    @property
    def selectAccountStatusDropdown(self):
        dropDownListBox = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text() ='Account Status']//parent::div//following-sibling::div//select",
            (By.TAG_NAME,
             'option'))
        dropDownListBox.checkAriaState = False
        return dropDownListBox

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//div[@class='col-auto']//button[text() = 'Save']")

    @property
    def holdExecutionOfOrdersForSIPPLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Hold Execution of Orders For SIPP']")

    @property
    def readOnlyAccessValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//dt[text()='Read only access']//following-sibling::dd")
