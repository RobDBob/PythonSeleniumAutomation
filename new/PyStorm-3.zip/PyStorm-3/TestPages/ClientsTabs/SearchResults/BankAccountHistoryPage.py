from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.BaseObjects.Table.GenericTable import GenericTable
from TestPages.Support.NewTabPage import NewTabPage


class BankAccountHistoryPage(NewTabPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.BankAccountHistory)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def bankAccountHistoryTable(self):
        return GenericTable(self.webdriver, self.webdriver, By.XPATH, "//table[@class='data-table']")
