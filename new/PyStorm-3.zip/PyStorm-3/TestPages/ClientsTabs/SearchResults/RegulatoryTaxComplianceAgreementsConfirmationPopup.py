from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PageObjects.ClientDetails.RegulatoryPage import RegulatoryPage


class RegulatoryTaxComplianceAgreementsConfirmationPopup(RegulatoryPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.Regulatory)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1[text()='Regulatory']")

    @property
    def confirmationMessageLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[contains(text(),'This update will be reflected on all of the following accounts')]")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@id='cancelBtn' and text()='Cancel']")

    @property
    def submitButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[@id='submitBtn' and text()='Submit']")
