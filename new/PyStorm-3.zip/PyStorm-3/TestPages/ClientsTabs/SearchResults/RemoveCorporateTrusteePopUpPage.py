from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label


class RemoveCorporateTrusteePopUpPage(BaseTestObject):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.ARE_YOU_SURE)

    def clickOnDeleteAndNavigateToDetailsTrustServicingPage(self):
        from TestPages.PageObjects.ClientDetails.TrustServicingDetailsPage import TrustServicingDetailsPage
        self.deleteButton.jsClick()
        return TrustServicingDetailsPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.parentElement, By.XPATH, "//p")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Cancel']")

    @property
    def deleteButton(self):
        return Button(self.webdriver, self.parentElement, By.XPATH, "//button[text()='Delete']")
