from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.ClientsTabs.SearchResults.BankAccountHistoryPage import BankAccountHistoryPage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.CheckBox import CheckBox
from TestPages.PageObjects.BaseObjects.DropdownListbox import DropdownListbox
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class ClientDetailsBankDetailsPage(PlatformPage):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.CLIENT_DETAILS_ACCOUNT_INFO)

    def navigateToBankAccountHistoryPage(self):
        self.bankAccountLinkTextButton.click()
        return BankAccountHistoryPage(self.webdriver)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@id='Hubert']//h1")

    @property
    def clientNameLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='module-header-row']//h3")

    @property
    def accountNumberLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//div[@class='module-header-row']//h3//span")

    @property
    def saveButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='savepanel3']//span//a[text()='Save']")

    @property
    def cancelButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='savepanel3']//span//a[text()='Cancel']")

    @property
    def selectViewDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[@class='control-label']//parent::div//select[@id='subclaccountid']",
            (By.XPATH,
             ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def bankAccountExpandButton(self):
        return Button(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//div[@class='main-module-row expandable-module-header']//h2//span[contains(text(),'Bank Accounts')]")

    @property
    def editBankAccountButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='editpanel3']//a[@id='btnedit3' and contains(text(),'Edit')]")

    @property
    def saveBankAccountButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='savepanel3']//a[@id='save3' and contains(text(),'Save')]")

    @property
    def bankAccountLinkTextButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//a[@class='inline-link' and contains(text(),'Bank Account History')]")

    @property
    def firstBankAccountHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='BANK ACCOUNT 1']")

    @property
    def bankAccountOwnerDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Owner:']//parent::div//following-sibling::div//select[@id='Owner1']",
            (By.XPATH,
             ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def accountNameEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Account Name:']//parent::div//following-sibling::div//input[@id='holdername1']")

    @property
    def accountNumberEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Account Number:']//parent::div//following-sibling::div//input[@id='accbank1']")

    @property
    def sortCodeWithFindButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//label[text()='Sort Code:']//parent::div//following-sibling::div//div//a[text()='Find'])[1]")

    @property
    def buildingSocietyRollNumber(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Building Society Roll Number:']//parent::div//following-sibling::div//input[@id='rollnum1']")

    @property
    def bankNameEditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Bank Name:']//parent::div//following-sibling::div//input[@id='bankname1']")

    @property
    def addressLine1EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 1:']//parent::div//following-sibling::div//input[@id='bankaddress11']")

    @property
    def addressLine2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 2:']//parent::div//following-sibling::div//input[@id='bankaddress21']")

    @property
    def addressLine3EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 3:']//parent::div//following-sibling::div//input[@id='bankaddress31']")

    @property
    def postcodeEditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Postcode:']//parent::div//following-sibling::div//input[@id='bankpostcode1']")

    @property
    def directDebitInstructionCheckBox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='directdebit1']/ancestor::div[@class='square-checkbox ']")

    @property
    def nominatedAccountForWithdrawalChekbox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='externaldefault1']/ancestor::div[@class='square-checkbox ']")

    @property
    def ddiReceivedCheckBox(self):
        return CheckBox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//input[@id='oldDdiRec1']/parent::div")

    @property
    def directDebitSetupWithoutCheckBox(self):
        return CheckBox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "(//label[contains(text(),'Direct Debit Set Up:')]//parent::div//following-sibling::div//input)[1]")

    @property
    def verificationOfAccountReceivedCheckBox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='oldVerificationRec1']/parent::div")

    @property
    def secondBankAccountHeadingLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h3[text()='BANK ACCOUNT 2']")

    @property
    def bankAccount2OwnerDropdown(self):
        dropdown = DropdownListbox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Owner:']//parent::div//following-sibling::div//select[@id='Owner2']",
            (By.XPATH,
             ".//option[@value]"))
        dropdown.checkAriaState = False
        return dropdown

    @property
    def accountName2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Account Name:']//parent::div//following-sibling::div//input[@id='holdername2']")

    @property
    def accountNumber2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Account Number:']//parent::div//following-sibling::div//input[@id='accbank2']")

    @property
    def sortCode2WithFindButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "(//label[text()='Sort Code:']//parent::div//following-sibling::div//div//a[text()='Find'])[2]")

    @property
    def buildingSociety2RollNumber(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Building Society Roll Number:']//parent::div//following-sibling::div//input[@id='rollnum2']")

    @property
    def bankName2EditField(self):
        return EditField(self.webdriver, self.webdriver, By.XPATH, "//label[text()='Bank Name:']//parent::div//following-sibling::div//input[@id='bankname2']")

    @property
    def secondAddressLine1EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 1:']//parent::div//following-sibling::div//input[@id='bankaddress12']")

    @property
    def secondAddressLine2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 2:']//parent::div//following-sibling::div//input[@id='bankaddress22']")

    @property
    def secondAddressLine3EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Address Line 3:']//parent::div//following-sibling::div//input[@id='bankaddress32']")

    @property
    def postcode2EditField(self):
        return EditField(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//label[text()='Postcode:']//parent::div//following-sibling::div//input[@id='bankpostcode2']")

    @property
    def directDebitInstruction2CheckBox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='directdebit2']/parent::label")

    @property
    def nominatedAccountForWithdrawal2Chekbox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='externaldefault2']/parent::label")

    @property
    def ddiReceived2CheckBox(self):
        return CheckBox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "//input[@id='oldDdiRec2']/parent::div")

    @property
    def directDebitSetup2WithoutCheckBox(self):
        return CheckBox(
            self.webdriver,
            self.webdriver,
            By.XPATH,
            "(//label[contains(text(),'Direct Debit Set Up:')]//parent::div//following-sibling::div//input)[2]")

    @property
    def verificationOfAccountReceived2CheckBox(self):
        return CheckBox(self.webdriver,
                        self.webdriver,
                        By.XPATH,
                        "//input[@id='oldVerificationRec2']/parent::div")

    @property
    def addAnotherBankAccountButton(self):
        return Button(self.webdriver, self.webdriver, By.ID, "addbank3")

    @property
    def bankAccount1ExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='expandBankAccountButton0']")

    @property
    def bankAccount1CollapsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='collapseBankAccountButton0']")

    @property
    def bankAccount2ExpandButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='expandBankAccountButton1']")

    @property
    def bankAccount2CollapsButton(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//span[@id='collapseBankAccountButton1']")

    @property
    def ddiValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Direct Debit Instruction:')]/parent::div//p")

    @property
    def nominatedAccountForWithdrawalsValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Nominated account for withdrawals:')]/parent::div//p")

    @property
    def directDebitSetUpValueLabel(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//label[contains(text(),'Direct Debit Set Up:')]/parent::div//p")

    @property
    def accountNumber1Label(self):
        return Label(self.webdriver, self.webdriver, By.XPATH,
                     "//h3[contains(text(),'BANK ACCOUNT 1')]/parent::div//following-sibling::label[contains(text(),'Account Number:')]//following-sibling::p")

    @property
    def accountNumber2Label(self):
        return Label(self.webdriver, self.webdriver, By.XPATH,
                     "//h3[contains(text(),'BANK ACCOUNT 2')]/parent::div//following-sibling::label[contains(text(),'Account Number:')]//following-sibling::p")
