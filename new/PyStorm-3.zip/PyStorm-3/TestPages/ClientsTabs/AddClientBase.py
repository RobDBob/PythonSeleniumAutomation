from selenium.webdriver.common.by import By
from TestPages import PageEnums
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.PlatformPage import PlatformPage


class AddClientBase(PlatformPage):
    def wait(self):
        self.activityTab.waitForText(PageEnums.Activity)

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//h1")

    @property
    def clientId(self):
        return Label(self.webdriver, self.webdriver, By.XPATH, "//b[contains(text(),'Client ID:')]")

    @property
    def activityTab(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Activity']")

    @property
    def documentsTab(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Documents']")

    @property
    def rolesTab(self):
        return Button(self.webdriver, self.webdriver, By.XPATH, "//button[text()='Roles']")
