from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ClientsTabs.ClientsBaseTab import ClientsBaseTab
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.HintDialog import HintDialog
from TestPages.PageObjects.BaseObjects.Labels import Label
from TestPages.WebDriver import ExpectedConditions as EC


class ClientsPage(ClientsBaseTab):
    def wait(self):
        self.pageTitle.waitForText(PageEnums.WhatDoYouWantToSearchFor)

    def verifyClientsPageSearchOptions(self, expectedSearchOptions):
        PrintMessage(f"Attempting to locate Clients Page search options {expectedSearchOptions}")
        for expectedLink in expectedSearchOptions:
            valueWaiter = EC.text_to_be_present_in_any_of_elements(
                (By.XPATH, "//button[@class='btn square secondary ml-10' or @class='btn square primary']"), expectedLink)
            WebDriverWait(self.webdriver, 60).until(valueWaiter)
        PrintMessage(f"Verified presence of '{expectedSearchOptions}'")

    def verifyHighlightedIndividualSearchOption(self, clientSearchOption):
        PrintMessage(f'Verifying selected {clientSearchOption} menu...')
        waitCondition = EC.text_to_be_present_in_element((By.XPATH, "//button[@class='btn square primary' and text()='Individual']"), clientSearchOption)
        WebDriverWait(self.webdriver, 60).until(waitCondition)

    def getSelectedClientsSearchTab(self):
        valueWaiter = EC.visibility_of_all_elements_located((By.XPATH, "//button[contains(@class,'btn square primary')]"))
        WebDriverWait(self.webdriver, 60).until(valueWaiter)
        selectedClientSearchTab = self.webdriver.find_element(By.XPATH, "//button[contains(@class,'btn square primary')]")
        return selectedClientSearchTab.text

    @property
    def pageTitle(self):
        return Label(self.webdriver, self.webdriver, By.CSS_SELECTOR, '#main > h1')

    @property
    def pageTipsDialog(self):
        return HintDialog(self.webdriver, self.webdriver, By.XPATH, "//div[@role='dialog']")

    @property
    def platformTipsButton(self):
        return Button(self.webdriver, self.webdriver, By.CLASS_NAME, "coach-marker-tutorial")
