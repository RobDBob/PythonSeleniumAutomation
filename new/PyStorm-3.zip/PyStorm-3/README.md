# QA Functional Automation beans

## Pre-requisites
 - Python 3.11.2
 - Pip

## Purpose
Testing framework for beans feature (to expand ;)

## Setup

Required extensions: 
- Statical code analysis **pyLint** - https://aamdev.visualstudio.com/Platform%20Transformation/_wiki/wikis/Platform-Transformation---TS2.wiki/6154/Static-code-analysis (config file .pylintrc)

Linter, ISORT and autopep8 will reformat and update files automatically on an attempt to commit.

Clone PyStorm to new folder
Create new virtual environment
Initialize pre-commit
```pre-commit install```

After staging file and using commit command, tools will make an attempt to process added files.
In some instances where modification was applied after commit, updated files will need to be staged again.

![alt text](README_LINTER.png)

## Contributing
autopep8 requires manual fixes
isort will rewrite the violations automatically, however the files are unstaged and should staged again.

### Linter

```>> pylint Tests\LegacyQuickRegression\TestsQRP.py ```

https://pylint.pycqa.org/en/latest/user_guide/usage/run.html

### ISORT

Available options: 

```>> isort```
Updating imports in single file: 

```>> isort Tests\Advisor\TestsNewBusinessWizardPPPayments.py```

https://pypi.org/project/isort/

### autopep8

```> autopep8 --in-place --aggressive --aggressive <filename> ``` 

https://pypi.org/project/autopep8/#toc-entry-3

## Using chrome driver
Chrome driver will be automatically installed following configuration details from configuration file or command line
Framework expects a full chrome version number i.e. 112.0.5615.28

Available versions:

- Chrome versions: https://github.com/GoogleChromeLabs/chrome-for-testing#json-api-endpoints > per-m,ilestone-with-downloads: https://googlechromelabs.github.io/chrome-for-testing/latest-versions-per-milestone-with-downloads.json
- Edge versions: https://msedgedriver.azureedge.net/


## PIP ini file
Python Package Index is repository of available packages created by community. For python to know where to look for required packages, pip.ini file is required.

```[global]
trusted-host = pypi.python.org
               pypi.org
               files.pythonhosted.org
```

File location (must be created if does not exist): %APPDATA%\pip

## Running Tests

```python -m StandAlone.ExecuteTest -c <ConfigName> -t <TestId>```

### Usage

Example flags:
   
    -c stands for config - this is a must

    --luf - executes in a loop until first failure
    --headless - executes tests in headless mode without spawning browser

    -class <class names>- is only used if you want to run a class of tests. This uses partial string matching. All matched classes are executed.
    -t <test_ids> - is only used if you want to run a specific test(s), separate test ids with a blank space
    --gatherScreenshotEvidence - ensures framework will make screenshot at various points during test execution

### Browser selection
Browser can be configured via configuration file i.e. see TestRunConfig_te5chrome

Or supplied via command line: `-browser chrome -driverVersion 112.0.5615.28`

## Configuration files
Configuration file serve as a simple way to pass instructions to test framework

There might me multiple configuration files per environments / browsers / users 

## Running standalone commands in Python's console

Prior running any scripts ensure 
- virtual environment is enabled (.\.venv\Scripts\activate)
- all packages from requirements.txt are installed (pip install -r requirements.txt)
- console is open at the root of your repository (python)


Available standalone scripts:
- Get open orders for an account
- Create HTML report for an overnight run
- Find test account matching specific criteria

Details on standalone scripts and how to execute them are available on 
[wiki pages](https://aamdev.visualstudio.com/Platform%20Transformation/_wiki/wikis/Platform-Transformation---TS2.wiki/8854/Standalone-scripts)


## Access tokens & connection strings
Sensitive data is now stored in Azure Key Vault

- ResourceGroup: PyStorm_RG
- KeyVault: akv-pystorm-dev

Secrets are passed over to CICD pipeline via Variable Library > Environment variables, where from PyStorm picks them up via os.environ.get function 


## Known issues
### Error: fatal: unable to access 'https://github.com/pycqa/isort/': SSL certificate problem: unable to get local issuer certificate
Run in the command line: git config --global http.sslbackend schannel