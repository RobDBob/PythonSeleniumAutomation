import unittest
from CommonCode.API.BackOffice.BackOfficeHelper import BackOfficeHelper
from CommonCode.API.BackOffice.BackOfficeUserHelper import BackOfficeUserHelper
from CommonCode.API.Wrap.PlatformRequestsHelper import PlatformRequestsHelper
from CommonCode.CustomExceptions import UIException, WebDriverException
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.HelperFunctions import getTestIdFromTestName
from CommonCode.Models.AccountDataObj import AccountDataObj
from CommonCode.TestExecute import Constants as Const
from CommonCode.TestExecute.BrowserSetup import BrowserSetup
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestExecute.PyStormTestResult import PyStormTextTestResult
from CommonCode.TestExecute.TestContext import Test_Context, TestContext
from CommonCode.TestHelpers.BrowserHelper import BrowserHelper
from TestData.TestDataLoader import TestDataLoader
from TestData.TestUsers.TestUsersEnum import UserType
from TestPages import DataEnums
from TestPages.BatemanLoginPage import BatemanLoginPage
from TestPages.PlatformGenericLoginPage import PlatformGenericLoginPage
from TestPages.PlatformLoginPage import PlatformLoginPage
from TestPages.PlatformPage import PlatformPage
from TestPages.Raptor.WRaptorLogin import WRaptorLogin
from TestPages.SLADMIN.SLAdminLoginPage import SLAdminLoginPage


class BaseTestClass(unittest.TestCase):
    ADO_TEST_SUITE = None
    TEST_USER_NUMBER = None
    _webdriver: PyStormDriver | None = None
    testContext: TestContext = None
    _platformAPIRequestsHelper: PlatformRequestsHelper | None = None

    def _callCleanup(self, function, /, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except Exception as e:
            self.makeScreenshotFailedWindow()
            raise e

    @classmethod
    def setUpClass(cls):
        cls.testContext = Test_Context
        cls.testContext.currentTestClassName = cls.__name__
        cls.longMessage = True

    @classmethod
    def tearDownClass(cls):
        if cls._webdriver:
            cls._webdriver.quit()

    def setUp(self):
        PrintMessage(Const.TEST_HEAD.format(self._testMethodName))

        self.testContext.failedWindowHandle = None

        self.addCleanup(self.closeBrowser)
        self.testContext.currentTestId = getTestIdFromTestName(self._testMethodName)

    def tearDown(self):
        PrintMessage(Const.TEST_TEARDOWN)
        result: PyStormTextTestResult = getattr(getattr(self, "_outcome", object), "result", None)
        ok = all(test != self for test, _ in result.errors + result.failures)
        if not ok:
            self.makeScreenshotFailedWindow()
        self.saveNetworkLog()

    def makeScreenshotFailedWindow(self):
        failedTab = self.testContext.failedWindowHandle
        baseTab = self.testContext.initialWindowHandle
        try:
            if failedTab and self._webdriver:
                # Switch to failed tab for screenshot
                self.webdriver.switch_to.window(failedTab)
            PrintMessage(f"Capturing screenshot at webdriver url: '{self.webdriver.current_url}'")
            BrowserHelper(self.webdriver, self.testContext).makeScreenshot(self._testMethodName)
        except (WebDriverException, UIException) as e:
            PrintMessage(f">>>>>>>>>> Error during screenshot capture: '{e}'")

        finally:
            # Attempt to close the failed tab and switch back to base page tab
            try:
                if self._webdriver and failedTab and baseTab and failedTab != baseTab:
                    self.webdriver.close()
                    self.webdriver.switch_to.window(baseTab)
            except (WebDriverException, UIException) as e:
                PrintMessage(f">>>>>>>>>> Error during tab cleanup: '{e}'")

    def saveNetworkLog(self):
        if self.testContext.getSetting(ConfigOptions.CAPTURE_NETWORK_LOGS):
            BrowserHelper(self.webdriver, self.testContext).saveNetworkLogs()

    def closeBrowser(self):
        if self._webdriver:
            self._webdriver.quit()
            self._webdriver = None
            self._platformAPIRequestsHelper = None

    def resetPlatformRequestHelper(self):
        self._platformAPIRequestsHelper = None

    def logAsUser(self, userNumber, reLog=False) -> PlatformPage:
        if reLog:
            self.closeBrowser()

        platformPage: PlatformPage = PlatformLoginPage(self.webdriver).logAsUser(userNumber)
        return platformPage

    def logAsUserToDisplayDashboardPage(self, userNumber, reLog=False):
        """
        Login function where the user redirects to Dashboard page as Platform page after successful Login
        """
        if reLog:
            self.closeBrowser()

        platformPage: PlatformPage = PlatformLoginPage(self.webdriver).logAsUserToDisplayDashboardPage(userNumber)
        return platformPage

    def logAsUserAsAdviserInternalManagement(self, userNumber, reLog=False):
        """
        Login function where the user redirects to Landing page as Platform page after successful Login for L2_Adviser_Management
        """
        if reLog:
            self.closeBrowser()

        return PlatformLoginPage(self.webdriver).logAsUserAsAdviserInternalManagement(userNumber)

    def logOntoPlatformWithUserType(self, userType: UserType, reLog=False):
        if reLog:
            self.closeBrowser()

        platformPage: PlatformPage = PlatformLoginPage(self.webdriver).performLoginWithUserType(userType)
        return platformPage

    def logOntoWraptor(self, user, reLog=False):
        if reLog:
            self.closeBrowser()

        wraptorPage = WRaptorLogin(self.webdriver).login(*self.testContext.testUsers.getUserByKey(user))
        return wraptorPage

    def getTestData(self, fileName, sectionName=None):
        dataLoader = TestDataLoader(self.environmentName)

        if "yaml" in fileName or "yml" in fileName:
            return dataLoader.getTestDataFromYmlFile(fileName, sectionName)
        return dataLoader.getTestDataFromYmlFile(fileName, sectionName)

    def getTestDataObject(self, fileName, sectionName=None):
        return AccountDataObj(self.getTestData(fileName, sectionName))

    def getExpectedLoginPage(self, expectedLoginPage=None, reLog=False):
        if reLog:
            self.closeBrowser()
        if expectedLoginPage == DataEnums.SL_ADMIN_PAGE:
            return SLAdminLoginPage(self.webdriver)
        if expectedLoginPage == DataEnums.BATEMAN_PAGE:
            return BatemanLoginPage(self.webdriver)

        raise UIException("getExpectedLoginPage > expectedLoginPage not provided")

    def loginAsUniPass(self, userKey, expectedLoginPage, expectedPageToOpen=None, relog=False) -> PlatformPage:
        genericLogInPage = self.getExpectedLoginPage(expectedLoginPage, reLog=relog)
        unipassLoginPage = genericLogInPage.navigateToUnipassLogin()
        platformPage: PlatformPage = unipassLoginPage.performLogin(*self.testContext.testUsers.getUserByKey(userKey), expectedPageToOpen=expectedPageToOpen)
        return platformPage

    def getPlatformAdviserLoginPage(self, reLog=False):
        if reLog:
            self.closeBrowser()
        platformPage: PlatformPage = PlatformGenericLoginPage(self.webdriver)
        return platformPage

    def closeAnyOpenOrdersForAccount(self, accountNumber):
        PrintMessage(f">>> closeAnyOpenOrdersForAccount - closing any open deals for account: '{accountNumber}'", inStepMessage=True)
        self.platformAPIRequestsHelper.closeAnyOpenOrdersForAccount(accountNumber, self.TEST_USER_NUMBER)
        PrintMessage(f">>> closeAnyOpenOrdersForAccount - closing any open deals for account: '{accountNumber}' - DONE", inStepMessage=True)

    def uploadCashForCheques(self, accountNumber, amount):
        """
        Function : Login to BackOffice and Upload cash for cheque payment method for a particular WP
        """
        boUserName, boUserPassword = self.testContext.testUsers.getBOUserByNumber(self.TEST_USER_NUMBER)
        backOffice = BackOfficeHelper(self.testContext.getSetting(ConfigOptions.BACK_OFFICE_URL), boUserName, boUserPassword)
        backOffice.uploadCash(accountNumber, amount)

    def setDealToComplete(self, batchNumber, orderNumber):
        boUserName, boUserPassword = self.testContext.testUsers.getBOUserByNumber(self.TEST_USER_NUMBER)
        backOffice = BackOfficeHelper(self.testContext.getSetting(ConfigOptions.BACK_OFFICE_URL), boUserName, boUserPassword)
        backOffice.setDealToComplete(batchNumber, orderNumber)

    def getBOUser(self, userNumber):
        """
        Function : Login to BackOffice and get the UserType and User Site access Status
        """
        PrintMessage("BaseTestClass > Get the Back office Credentials, UserLogon details from the UserNumber and Login to BackOffice", inStepMessage=True)
        boUserName, boUserPassword = self.testContext.testUsers.getBOUserByNumber(userNumber)
        userName, _ = self.testContext.testUsers.getUserByNumber(userNumber)
        backOfficeUsers = BackOfficeUserHelper(str(self.testContext.getSetting(ConfigOptions.BACK_OFFICE_URL)), boUserName, boUserPassword)
        PrintMessage("BaseTestClass > Get the Back office User type and User Site access Status", inStepMessage=True)
        return backOfficeUsers.getBOUserByUserLogon(userName)

    @property
    def environmentName(self) -> str:
        return str(self.testContext.getSetting(ConfigOptions.ENVIRONMENT))

    @property
    def webdriver(self) -> PyStormDriver:
        if not self._webdriver:
            self._platformAPIRequestsHelper = None
            self._webdriver = BrowserSetup(self.testContext).setup()
        assert self._webdriver
        return self._webdriver

    @property
    def platformAPIRequestsHelper(self):
        if not self._platformAPIRequestsHelper:
            self._platformAPIRequestsHelper = PlatformRequestsHelper(self.webdriver.apiSessionHeaders, self.testContext)

        return self._platformAPIRequestsHelper
