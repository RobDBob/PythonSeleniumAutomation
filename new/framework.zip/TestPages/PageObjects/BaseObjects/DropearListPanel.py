from retry import retry
from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages import PageEnums
from TestPages.ClientsTabs.SearchResults.SinglePaymentWarningMessagePage import SinglePaymentWarningMessagePage
from TestPages.NoChangeTool.NoChangeToolPage import NoChangeToolPage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.WebDriver.ObjProduction import manufacture
from TestPages.Withdrawals.CreateOrdersWithdrawalsPage import CreateOrdersWithdrawalsPage
from TestPages.Wizards.ProductWizards.ISA.ISABuyOrderSetupPage import ISABuyOrderSetupPage
from TestPages.Wizards.ProductWizards.ISA.ISACurrentClientRegularPaymentInstructionsPage import ISACurrentClientRegularPaymentInstructionsPage
from TestPages.Wizards.ProductWizards.ISA.ISAEditRegularPaymentInPage import ISAEditRegularPaymentInPage
from TestPages.Wizards.ProductWizards.ISA.ISAPaymentsInWizard import ISAPaymentsInWizard
from TestPages.Wizards.ProductWizards.ISA.ISASellOrderSetupPage import ISASellOrderSetupPage
from TestPages.Wizards.ProductWizards.ISA.ISAStocksAndSharesRegularPaymentInPage import ISAStocksAndSharesRegularPaymentInPage
from TestPages.Wizards.ProductWizards.ISA.ISASwitchOrderSetupPage import ISASwitchOrderSetupPage
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PersonalPortfolioPaymentsInWizard import PersonalPortfolioPaymentsInWizard
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PersonalPortfolioRegularPaymentInPage import PersonalPortfolioRegularPaymentInPage
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PersonalPortfolioToASIPP import PersonalPortfolioToASIPP
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PersonalPortfolioToSharesAndStocksISA import PersonalPortfolioToSharesAndStocksISA
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PPBuyOrderSetupPage import PPBuyOrderSetupPage
from TestPages.Wizards.ProductWizards.PersonalPortfolio.PPEditRegularPaymentInPage import PPEditRegularPaymentInPage
from TestPages.Wizards.ProductWizards.SIPP.ABERDEENJSIPPSellOrderSetupPage import ABERDEENJSIPPSellOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.ABERDEENJSIPPSwitchOrderSetupPage import ABERDEENJSIPPSwitchOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.ABERDEENSIPPSellOrderSetupPage import ABERDEENSIPPSellOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.ABERDEENSIPPSwitchOrderSetupPage import ABERDEENSIPPSwitchOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.ABRDNJSIPPBuyOrderSetupPage import ABRDNJSIPPBuyOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.ABRDNSIPPBuyOrderSetupPage import ABRDNSIPPBuyOrderSetupPage
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPCancelTailoredDrawdownReviewPage import AbrdnSIPPCancelTailoredDrawdownReviewPage
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPEditIncomeDrawdownDetailsWizard import AbrdnSIPPEditIncomeDrawdownDetailsWizard
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPGadReviewIncomePaymentDetailsPage import AbrdnSIPPGadReviewIncomePaymentDetailsPage
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPOneOffPaymentIncomePaymentDetails import AbrdnSIPPOneOffPaymentIncomePaymentDetails
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPPaymentsInWizard import AbrdnSIPPPaymentsInWizard
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPSelectArrangementsToConvertPage import AbrdnSIPPSelectArrangementsToConvertPage
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPTakePensionBenefitPensionBenefitsDetails import AbrdnSIPPTakePensionBenefitPensionBenefitsDetails
from TestPages.Wizards.ProductWizards.SIPP.AbrdnSIPPTopupWithImmediateTFLSPaymentsInWizard import AbrdnSIPPTopupWithImmediateTFLSPaymentsInWizard
from TestPages.Wizards.ProductWizards.SIPP.SIPPDealPlaceOrderSetupPage import SIPPDealPlaceOrderSetupPage
from TestPages.Wizards.ProductWizards.WhatIfToolPage import WhatIfToolPage
from TestPages.Wizards.Transfers.SIPP.PensionTransfersToWrapWizard import PensionTransfersToWrapWizard


class DropearListPanel(BaseTestObject):
    """
    Class used in search summary
    """

    def __init__(self, webdriver, parentElement, locator, productName):
        super().__init__(webdriver, parentElement, *locator)
        self.productName = productName

    # pylint: disable=R0911
    def getPage(self, optionName):
        match self.productName:
            case PageEnums.PRODUCT_ISA_STOCKS_AND_SHARES:
                match optionName:
                    case PageEnums.SINGLE_PAYMENT:
                        return ISAPaymentsInWizard(self.webdriver)
                    case PageEnums.ADD_REGULAR_PAYMENT:
                        return ISAStocksAndSharesRegularPaymentInPage(self.webdriver)
                    case PageEnums.EDIT_REGULAR_PAYMENT:
                        return ISAEditRegularPaymentInPage(self.webdriver)
                    case PageEnums.LaunchWhatIfTool:
                        return WhatIfToolPage(self.webdriver)
                    case PageEnums.LaunchNoChangeTool:
                        return NoChangeToolPage(self.webdriver)
                    case PageEnums.BUY:
                        return ISABuyOrderSetupPage(self.webdriver)
                    case PageEnums.SELL:
                        return ISASellOrderSetupPage(self.webdriver)
                    case PageEnums.SWITCH:
                        return ISASwitchOrderSetupPage(self.webdriver)
                    case PageEnums.WITHDRAW:
                        return CreateOrdersWithdrawalsPage(self.webdriver)
                    case PageEnums.THIRD_PARTY_EDIT_REGULAR_PAYMENT:
                        return ISACurrentClientRegularPaymentInstructionsPage(self.webdriver)
                    case _:
                        return SinglePaymentWarningMessagePage(self.webdriver)

            case PageEnums.PRODUCT_PP:
                match optionName:
                    case PageEnums.SINGLE_PAYMENT:
                        return PersonalPortfolioPaymentsInWizard(self.webdriver)
                    case PageEnums.ADD_REGULAR_PAYMENT:
                        return PersonalPortfolioRegularPaymentInPage(self.webdriver)
                    case PageEnums.EDIT_REGULAR_PAYMENT:
                        return PPEditRegularPaymentInPage(self.webdriver)
                    case PageEnums.LaunchNoChangeTool:
                        return NoChangeToolPage(self.webdriver)
                    case PageEnums.BUY:
                        return PPBuyOrderSetupPage(self.webdriver)
                    case PageEnums.PP_TO_S_AND_S_ISA:
                        return PersonalPortfolioToSharesAndStocksISA(self.webdriver)
                    case PageEnums.PP_TO_ABERDEEN_SIPP:
                        return PersonalPortfolioToASIPP(self.webdriver)
                    case _:
                        return SinglePaymentWarningMessagePage(self.webdriver)
            case PageEnums.CASH_ACCOUNT:
                match optionName:
                    case PageEnums.SINGLE_PAYMENT:
                        from TestPages.Wizards.ProductWizards.Cash.CashAccountPaymentsInWizard import CashAccountPaymentsInWizard
                        return CashAccountPaymentsInWizard(self.webdriver)
                    case PageEnums.ADD_REGULAR_PAYMENT:
                        from TestPages.Wizards.ProductWizards.Cash.CashAccountPaymentsInWizard import CashAccountPaymentsInWizard
                        return CashAccountPaymentsInWizard(self.webdriver)
                    case PageEnums.WITHDRAW:
                        return CreateOrdersWithdrawalsPage(self.webdriver)
                    case PageEnums.EDIT_REGULAR_PAYMENT:
                        from TestPages.Wizards.ProductWizards.Cash.CashAccountPaymentsInWizard import CashAccountPaymentsInWizard
                        return CashAccountPaymentsInWizard(self.webdriver)
            case PageEnums.SIPP:
                match optionName:
                    case PageEnums.SINGLE_PAYMENT:
                        return PensionTransfersToWrapWizard(self.webdriver)
                    case PageEnums.BUY | PageEnums.SELL:
                        return SIPPDealPlaceOrderSetupPage(self.webdriver)
            case PageEnums.ABRDN_SIPP | PageEnums.ABERDEEN_SIPP:
                match optionName:
                    case PageEnums.BUY:
                        return ABRDNSIPPBuyOrderSetupPage(self.webdriver)
                    case PageEnums.SELL:
                        return ABERDEENSIPPSellOrderSetupPage(self.webdriver)
                    case PageEnums.SWITCH:
                        return ABERDEENSIPPSwitchOrderSetupPage(self.webdriver)
                    case PageEnums.ADD_REGULAR_PAYMENT:
                        return AbrdnSIPPPaymentsInWizard(self.webdriver)
                    case PageEnums.EDIT_REGULAR_PAYMENT:
                        return AbrdnSIPPPaymentsInWizard(self.webdriver)
                    case PageEnums.SINGLE_PAYMENT:
                        return AbrdnSIPPPaymentsInWizard(self.webdriver)
                    case PageEnums.ONE_OFF_INCOME_PAYMENT:
                        return AbrdnSIPPOneOffPaymentIncomePaymentDetails(self.webdriver)
                    case PageEnums.CONVERT_CAPPED_TO_FLEXIBLE_DRAWDOWN:
                        return AbrdnSIPPSelectArrangementsToConvertPage(self.webdriver)
                    case PageEnums.TAKE_PENSION_BENEFITS:
                        return AbrdnSIPPTakePensionBenefitPensionBenefitsDetails(self.webdriver)
                    case PageEnums.TOP_UP_WITH_IMMEDIATE_TAXFREE_LUMP_SUM:
                        return AbrdnSIPPTopupWithImmediateTFLSPaymentsInWizard(self.webdriver)
                    case PageEnums.GAD_REVIEW:
                        return AbrdnSIPPGadReviewIncomePaymentDetailsPage(self.webdriver)
                    case PageEnums.CANCEL_TAILORED_DRAWDOWN:
                        return AbrdnSIPPCancelTailoredDrawdownReviewPage(self.webdriver)
                    case PageEnums.EDIT_INCOME_DRAWDOWN:
                        return AbrdnSIPPEditIncomeDrawdownDetailsWizard(self.webdriver)
                    case _:
                        return SinglePaymentWarningMessagePage(self.webdriver)
            case PageEnums.ABRDN_JSIPP | PageEnums.ABERDEEN_JSIPP:
                match optionName:
                    case PageEnums.BUY:
                        return ABRDNJSIPPBuyOrderSetupPage(self.webdriver)
                    case PageEnums.SELL:
                        return ABERDEENJSIPPSellOrderSetupPage(self.webdriver)
                    case PageEnums.SWITCH:
                        return ABERDEENJSIPPSwitchOrderSetupPage(self.webdriver)
                    case PageEnums.ADD_REGULAR_PAYMENT:
                        from TestPages.Wizards.ProductWizards.SIPP.AbrdnJSIPPPaymentsInWizard import AbrdnJSIPPPaymentsInWizard
                        return AbrdnJSIPPPaymentsInWizard(self.webdriver)
                    case PageEnums.EDIT_REGULAR_PAYMENT:
                        from TestPages.Wizards.ProductWizards.SIPP.ABERDEENJSIPPEditRegularPaymentInPage import ABERDEENJSIPPEditRegularPaymentInPage
                        return ABERDEENJSIPPEditRegularPaymentInPage(self.webdriver)
                    case PageEnums.SINGLE_PAYMENT:
                        from TestPages.Wizards.ProductWizards.SIPP.AbrdnJSIPPPaymentsInWizard import AbrdnJSIPPPaymentsInWizard
                        return AbrdnJSIPPPaymentsInWizard(self.webdriver)
                    case PageEnums.LaunchWhatIfTool:
                        return WhatIfToolPage(self.webdriver)

    @retry(exceptions=UIException, delay=2, tries=5)
    def selectOption(self, optionName, requiredPageToOpen: str | None = None):
        # optionToSelect = [k for k in self.availableOptions if k.text == optionName]
        optionToSelect = [k for k in self.availableOptions if optionName in k.text]
        if optionToSelect:
            PrintMessage(f"Selecting '{optionName}' option", inStepMessage=True)
            optionToSelect[0].click()
            optionName = optionName if not requiredPageToOpen else requiredPageToOpen
            return self.getPage(optionName)
        raise UIException(f"Option '{optionName}' not found, available options are: {[k.text for k in self.availableOptions]}")

    @property
    def availableOptions(self):
        return manufacture(Button, self.webdriver, self.element, By.XPATH, ".//a[@class='item']")
