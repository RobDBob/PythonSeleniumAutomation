COLUMN_CASH_TRANSACTION = "Cash transaction"
COLUMN_STATUS = "Status"
COLUMN_DATE_CREATED = "Date Created"

PARAM_COLUMN_NAME = "columnName"
PARAM_PROPERTY_NAME = "propertyName"

# extraction from row property by either .value or .text
PARAM_TEXT = "text"
PARAM_VALUE = "value"
PARAM_COMPARISON_OPERATOR = "comparisonOperator"
PARAM_USE_PAGINATION = "usePagination"

PARAM_DATETIME_STAMP = "dateTimeStamp"
PARAM_REVERSE_ORDER = "reverseOrder"
PARAM_TABLE_FILTERS = "tableFilters"


ARG_DATE_CREATED = "dateCreated"
