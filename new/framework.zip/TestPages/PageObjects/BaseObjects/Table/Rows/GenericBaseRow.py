from selenium.webdriver.common.by import By
from CommonCode.CustomExceptions import UIException
from CommonCode.Driver.PyStormElement import PyStormElement
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject


class GenericBaseRow(BaseTestObject):
    CELL_LOCATOR = [By.XPATH, ".//td"]

    def getCell(self, index) -> PyStormElement:
        cellElements = self.element.findElements(*self.CELL_LOCATOR)
        if cellElements and len(cellElements) > index:
            return cellElements[index]
        raise UIException(f"getCell > element not found, index: {index}, locator: {self.CELL_LOCATOR}")
