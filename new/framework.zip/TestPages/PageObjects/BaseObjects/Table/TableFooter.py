from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject


class TableFooter(BaseTestObject):
    @property
    def footers(self) -> list:
        footerGroup = self.element.findElement(By.XPATH, ".//tr[@class='total cells-right']")
        if footerGroup:
            return [k.text for k in footerGroup.findElements(By.XPATH, ".//td") if k.text]
        return []
