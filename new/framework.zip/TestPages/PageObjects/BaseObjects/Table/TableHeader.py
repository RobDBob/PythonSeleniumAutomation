from selenium.webdriver.common.by import By
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject


class TableHeader(BaseTestObject):
    @property
    def headers(self) -> list:
        headerGroup = self.element.findElement(By.XPATH, ".//tr[@class='sub-head']")
        if headerGroup:
            return [k.text for k in headerGroup.findElements(By.XPATH, ".//th") if k.text]
        return []
