import logging
import time
from retry import retry
from selenium.common import ElementNotInteractableException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from CommonCode.CustomExceptions import ContentNotClearException, UIException
from CommonCode.HelperFunctions import tryExecute
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject


class EditField(BaseTestObject):
    # >> Private Methods

    def _enterNewContent(self, textToEnter, **kwargs):
        """
        Params in kwargs:
        - enterSlowly: bool
        - waitForText: bool
        - followedByKey: from selenium.webdriver.common.keys import Keys
        """
        if "enterSlowly" in kwargs:
            self._enterSlowly(textToEnter)
        else:
            self.element.send_keys(textToEnter)

        if "waitForText" in kwargs:
            self.waitForText(str(textToEnter))

        if "followedByKey" in kwargs:
            self.element.send_keys(kwargs.get("followedByKey", ""))

    @retry(exceptions=ContentNotClearException, delay=2, tries=2)
    def _clearWithActions(self):
        self.element.click()
        ActionChains(self.webdriver).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).perform()
        self.element.send_keys(Keys.DELETE)

        if self.text or self.value:
            raise ContentNotClearException()

    def _enterSlowly(self, value):
        PrintMessage(f"entering slowly: '{value}'", inStepMessage=True)
        for character in str(value):
            self.element.send_keys(character)
            time.sleep(0.05)

    @retry(exceptions=ContentNotClearException, delay=2, tries=2)
    def _clearWithBackspace(self):
        textToClear = self.text if self.text else self.value
        PrintMessage(f"EditField > clearUsingBackspace: '{textToClear}'.", inStepMessage=True, level=logging.DEBUG)
        for _ in range(0, len(textToClear) + 1):
            self.element.send_keys(Keys.BACK_SPACE)

        if self.text or self.value:
            raise ContentNotClearException()

    @retry(exceptions=(UIException, ElementNotInteractableException), delay=2, tries=2)
    def enterText(self, textToEnter, **kwargs):
        """
        Params in kwargs:
        - waitForText: bool, defaults None / False
        - skipClear: bool, defaults None / False
        - comparisonOperator: Callable defaults to operator.contains
        - attributeName list[str] / str: defaults to "placeholder" and "value", used in waitForText when waiting for expected text
        """
        self.scrollToElement()

        if textToEnter not in [Keys.ENTER, Keys.TAB, Keys.BACK_SPACE]:
            PrintMessage(f"EditField > enterText Typing in: '{textToEnter}'.", inStepMessage=True)

        self.clearContent(**kwargs)
        self._enterNewContent(textToEnter, **kwargs)

        if "waitForText" in kwargs:
            self.waitForText(textToEnter, **kwargs)

    @retry(exceptions=UIException, delay=2, tries=2)
    def clearContent(self, **kwargs):
        """
        Params in kwargs:
        - waitForText: bool, defaults None / False
        - skipClear: bool, defaults None / False
        """
        if "skipClear" in kwargs:
            return

        if self.value or self.text:
            tryExecute(self._clearWithBackspace)

        if self.value or self.text:
            tryExecute(self.element.clear)

        if self.value or self.text:
            tryExecute(self._clearWithActions)

    def typeCharacters(self, numberOfChar: int, charToAdd: str | None = None):
        """
        This code works if specific consecutive characters from end of string
        are required to be replaced or removed
        """
        PrintMessage(f"EditField > clearAndAddCharacters Typing in: '{charToAdd}'.", inStepMessage=True)
        if charToAdd is None:
            for _ in range(0, numberOfChar):
                self.element.send_keys(Keys.BACK_SPACE)
                time.sleep(0.05)
            PrintMessage(f"EditField > clearAndAddCharacters > Number of character as '{numberOfChar} removed", inStepMessage=True)
        else:
            for _ in range(0, numberOfChar):
                self.element.send_keys(Keys.BACK_SPACE)
            self.element.send_keys(charToAdd)
            self.element.send_keys(Keys.ENTER)
            PrintMessage(f"EditField > clearAndAddCharacters> Number of character as '{numberOfChar}' removed and '{charToAdd}' entered.", inStepMessage=True)
