import logging
from typing import Callable
from retry import retry
from selenium.common.exceptions import TimeoutException
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.Button import Button
from TestPages.PageObjects.BaseObjects.StateCallbacks import defaultIsCheckedCB


class RadioButton(Button):
    isSelectedFuncCB: Callable

    def __init__(self, webdriver, parentElement, *args):
        super().__init__(webdriver, parentElement, *args)
        self.isSelectedFuncCB = defaultIsCheckedCB

    @property
    def isSelected(self):
        self.waitForElement()
        if not self.isSelectedFuncCB:
            raise UIException("RadioButton.isSelectedFuncCB has not been set.")
        return self.isSelectedFuncCB(self, self.webdriver)

    @retry(exceptions=(TimeoutException, UIException), delay=2, tries=2)
    def waitForSelected(self, expectedState=True):
        """
        Wait until radio button is visually selected
        """
        PrintMessage(f"RadioButton Waiter --- waiting for state to be: '{expectedState}'",
                     inStepMessage=True,
                     level=logging.DEBUG)
        if self.isSelected == expectedState:
            return
        raise UIException(f"Failed to select radio button, expected state isSelected:'{expectedState}'")

    @retry(exceptions=(TimeoutException, UIException), delay=5, tries=5, backoff=2)
    def selectRadioButtonAndWait(self, newState=True, jsClick=False):
        """
        Click and verify radio button is actually selected,
        if radio button not selected, TimeoutException/UIException is raised and re-attempt the action.
        """
        PrintMessage(f"selectRadioButtonAndWait expected new state: '{newState}', actual: '{self.isSelected}', jsClick: '{jsClick}'",
                     inStepMessage=True,
                     level=logging.DEBUG)
        if self.isSelected == newState:
            return

        self.click(jsClick=jsClick)
        self.waitForSelected(newState)
