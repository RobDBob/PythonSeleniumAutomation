from datetime import date
from retry import retry
from selenium.common import TimeoutException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestHelpers.DateMethods import addDaysToDate, strpTime
from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
from TestPages.PageObjects.BaseObjects.EditField import EditField
from TestPages.WebDriver import ExpectedConditions as EC


class DatePicker(BaseTestObject):
    """
    Class currently defaults to UK date format
    see: https://docs.python.org/2/library/datetime.html#strftime-strptime-behavior
    """
    DATE_FORMAT = "%d/%m/%Y"
    inputElement = ".//input"

    @retry(TimeoutException, tries=2)
    def _closeOverlayIfOpen(self):
        # test if the overlay is open
        # if open then  close it and confirm
        try:
            condition = EC.visibility_of_element_located([By.XPATH, ".//table[@class='calendar']"])
            WebDriverWait(self.element, 3).until(condition)

            ActionChains(self.webdriver).click(self.dateEdit.element).send_keys(Keys.TAB).pause(1).perform()
        except TimeoutException:
            pass

        WebDriverWait(self.element, 3).until_not(condition, "Expected calendar overlay to not be displayed.")

    def waitForText(self, expectedText: str, **kwargs):
        """
        overwrite of BaseTestObject.waitForText for DatePicker where actual date text is found in self.dateEdit
        """
        condition = EC.text_in_element(self.dateEdit.element, expectedText=expectedText, **kwargs)
        WebDriverWait(self.parentElement, self.defaultWait).until(condition, message=f"Text: '{expectedText}' not found")

    @retry(exceptions=(UIException, TimeoutException), delay=2, tries=3)
    def specifyDate(self, value):
        self.webdriver.waitForNetworkActivityToCease()

        if isinstance(value, date):
            value = value.strftime(self.DATE_FORMAT)

        PrintMessage(f"Setting Date to: {value}.", inStepMessage=True)

        ActionChains(self.webdriver).click(self.dateEdit.element).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(value).pause(1).perform()

        self._closeOverlayIfOpen()

        # date picker xpath must be on with 'datepicker-container' class to access warning messages
        if "datepicker-container" in self.getAttribute("class"):
            try:
                condition = EC.text_to_be_present_in_element([By.XPATH, ".//p[text()]"], "Date must be a business day.")
                WebDriverWait(self.element, 5).until_not(condition, "Warning message: 'Date must be a business day.' still shows")
            except TimeoutException:
                # work around issue with date validation on CICD server User Story 1942696: 'Date must be a business day.' still shows
                PrintMessage(f"Validation shown: date must be a business date, adding 1 day to '{value}'", inStepMessage=True)
                self.specifyDate(addDaysToDate(value, 1))

        condition = EC.text_value_in_attribute_in_element(self.dateEdit.element, "value", value)
        WebDriverWait(self.element, 5).until(condition, f"Expected: '{value}', got: '{self.dateEdit.element}'")

    @property
    def dateEdit(self):
        return EditField(self.webdriver, self.element, By.XPATH, self.inputElement)

    @property
    def value(self):
        return self.dateEdit.value

    @property
    def date(self):
        currentValue = self.dateEdit.value
        return strpTime(currentValue, self.DATE_FORMAT)
