import logging
from typing import Callable
from retry import retry
from selenium.common.exceptions import ElementClickInterceptedException, StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.support.ui import WebDriverWait
from CommonCode.CustomExceptions import UIException
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.Driver.PyStormElement import PyStormElement
from CommonCode.TestExecute.Logging import PrintMessage
from TestPages.PageObjects.BaseObjects.StateCallbacks import defaultIsDisabledCB
from TestPages.WebDriver import ExpectedConditions as EC


class BaseTestObject:
    webdriver: PyStormDriver
    _element: PyStormElement | None = None
    isDisabledFuncCB: Callable

    def __init__(self, webdriver, parentElement: PyStormElement | PyStormDriver, *args):
        """
        :param parentElement:
        :param byType:
        :param value:

        See if this can be rewritten in more pythonic way, replace args with class methods
        https://stackoverflow.com/questions/682504/what-is-a-clean-pythonic-way-to-implement-multiple-constructors
        """
        self.webdriver: PyStormDriver = webdriver
        self.parentElement: PyStormDriver | PyStormElement = parentElement

        self._element = None
        self.findByType = None
        self.findByValue = None

        if len(args) == 1 and isinstance(args[0], PyStormElement):
            self.element = args[0]
        elif len(args) == 2:
            self.findByType = args[0]
            self.findByValue = args[1]
        else:
            raise UIException(f"BaseTestObject > Init > Wrong arguments: '{list(args)}'")

        self.defaultWait = 60
        self.isDisabledFuncCB = defaultIsDisabledCB

    def _getLocator(self) -> PyStormElement | list[str]:
        if self._element:
            return self._element

        if self.findByType and self.findByValue:
            return [self.findByType, self.findByValue]

        raise UIException("BaseTestObject._getLocator >> Undefined findByType and/or findByValue")

    def _waitForCondition(self, expectedCondition, *args, **kwargs):
        waiterCriteria = expectedCondition(self._getLocator(), *args)

        waitTimeout = kwargs.get("waitTimeout", self.defaultWait)
        WebDriverWait(self.parentElement, waitTimeout).until(waiterCriteria, message=kwargs.get("message", ""))

    def _findElements(self) -> list[PyStormElement]:
        if self.findByType and self.findByValue:
            return [k for k in self.parentElement.findElements(self.findByType, self.findByValue) if k.is_displayed]

        raise UIException("BaseTestObject._findElements >> Undefined findByType and/or findByValue")

    def waitForElement(self):
        """
        Waiting for element to be present before allowing to continue.
        If this fails after self.defaultWait we let it go as subsequent code might handle missing element case.

        15/10/24 RobD: counternote: allowing it to fail hides issues with locators and causes test framework to run exceedingly long,
         - removed try - except - pass
        This needs further considerations on how to deal with these issues
        :return:
        """
        visibleElement = EC.visibility_of_element_located(self._getLocator())
        WebDriverWait(self.parentElement, self.defaultWait).until(visibleElement, f"Failed presence_of_element_located: {self._getLocator()}")

    def waitForElementToCeaseExist(self):
        invisibleElement = EC.invisibility_of_element_located(self._getLocator())
        WebDriverWait(self.parentElement, self.defaultWait).until(invisibleElement, message="Failed: element is still visible")

    def waitForText(self, expectedText: str, **kwargs):
        """
        checks for text present in element.text, element.get_attribute

        Params:
        - expectedText

        Params in kwargs:
        - comparisonOperator: Callable defaults to contains
        - attributeName list[str] / str: defaults to "placeholder" and "value", used in waitForText when waiting for expected text
        """
        condition = EC.text_in_element(self._getLocator(), expectedText=expectedText, **kwargs)
        WebDriverWait(self.parentElement, self.defaultWait).until(condition, message=f"Text: '{expectedText}' not found")

    def waitToBeDisplayed(self):
        waitCondition = EC.presence_of_element_located(self._getLocator())
        WebDriverWait(self.webdriver, 90).until(waitCondition)

    @retry(exceptions=UIException, delay=2, tries=4)
    def waitForDisabled(self, isDisabled=True):
        """
        Waits and checks if element is in disabled state.
        Cannot use Expected Conditions here as passing in property getter passes its value not the function itself

        :param self: Description
        :param isDisabled: Description
        """
        PrintMessage(f"Checkbox Waiter --- waiting for state to be disabled: '{isDisabled}'",
                     inStepMessage=True,
                     level=logging.DEBUG)

        if self.isDisabled == isDisabled:
            return
        raise UIException(f"Failed to action checkbox, expected outcome isDisabled:'{isDisabled}'")

    def getAttribute(self, value):
        return self.element.getAttribute(value)

    def findElements(self, by, value) -> list[PyStormElement]:
        return self.element.findElements(by, value)

    def findElement(self, by, value) -> PyStormElement:
        return self.element.findElement(by, value)

    # ---=== Additional functionality shared between UI elements ---===

    def exists(self):
        """
        Test method checking if UI element was found
        Rather than failing if does not exist outright, framework will wait default timeout before failing
        :return:
        """
        return self.element is not None

    @retry(AttributeError, delay=2, tries=2)
    def scrollToElement(self, adjustX=0, adjustY=0):
        from selenium.webdriver.common.action_chains import ActionChains
        ActionChains(self.webdriver).scroll_to_element(self.element).scroll_by_amount(adjustX, adjustY).perform()

    def scrollToEndOfElement(self):
        """
        This logic will work as a workaround for those element which are hidden due to page resolution change
        And to scroll horizontally till the end of the element.
        """
        self.webdriver.execute_script("arguments[0].scrollIntoView({inline: 'end'})", self.element)

    @retry(exceptions=(ElementClickInterceptedException, WebDriverException, UIException, StaleElementReferenceException, TimeoutException), delay=2, tries=3)
    def click(self, skipScrollTo=False, jsClick=False):
        waiterCriteria = EC.element_to_be_clickable(self.element)
        WebDriverWait(self.parentElement, 15).until(waiterCriteria, message="Failed: element is unclickable.")

        skipScrollTo = self.element.tag_name in ["option"] or skipScrollTo

        if jsClick:
            self.jsClick(skipScrollTo)
            return

        if not skipScrollTo:
            self.scrollToElement()

        self.element.click()

    @retry(exceptions=(ElementClickInterceptedException, WebDriverException, UIException, StaleElementReferenceException), tries=3)
    def jsClick(self, skipScrollTo=False):
        """This works under assumption that parentElement is the pystorm webdriver"""

        waiterCriteria = EC.element_to_be_clickable(self.element)
        WebDriverWait(self.parentElement, 15).until(waiterCriteria, message="Failed: element is unclickable.")

        if not skipScrollTo:
            self.scrollToElement()
        self.webdriver.execute_script("arguments[0].click();", self.element)

    @property
    @retry(exceptions=UIException, tries=60, delay=1)
    def element(self) -> PyStormElement:
        """
        Added this property to find element each time it is called, due to web browser refreshes on re-size
        :return:
        """
        if self._element:
            return self._element

        self.waitForElement()

        foundElements = self._findElements()

        if len(foundElements) > 0:
            return foundElements[0]

        raise UIException(f"BaseTestObject > element not found [{self.findByType}, {self.findByValue}]")

    @element.setter
    def element(self, value):
        self._element = value

    @property
    def textOnly(self):
        return self.element.getAttribute("textContent").strip()

    @property
    def text(self):
        return self.element.text

    @property
    def innerHTMLText(self):
        return self.element.getAttribute("innerHTML").strip()

    @property
    def value(self):
        return self.element.getAttribute("value")

    @property
    def innerText(self):
        return self.element.getAttribute("innerText")

    @property
    def placeholderText(self):
        return self.element.getAttribute("placeholder")

    @property
    def isDisabled(self):
        self.waitForElement()
        return self.isDisabledFuncCB(self, self.webdriver)

    @property
    def spotCheckExists(self):
        """
        Quick check for element being available
        This bypasses waitForElement and so use with caution
        """
        if self._element:
            return True
        return len(self._findElements()) > 0

    @property
    def spotCheckHidden(self):
        """
        Quick check for element being visible
        This bypasses waitForElement and so use with caution
        """
        if self._element:
            return self._element.isHidden
        elements = self._findElements()
        if elements:
            element = elements[0]
            return element.isHidden
        return True

    @property
    def spotCheckDisplayed(self):
        """
        Quick check for element being displayed (visible in DOM and not hidden).
        This bypasses waitForElement and so use with caution.
        """
        if self._element:
            return self._element.is_displayed()
        elements = self._findElements()
        if elements:
            return elements[0].is_displayed()
        return False

    @property
    def isHidden(self):
        return self.element.isHidden

    @property
    def isAriaExpanded(self):
        return self.element.getAttribute("aria-expanded") == "true"

    @property
    def isAreaSelected(self):
        return self.element.getAttribute("aria-selected") == "true"

    @property
    def isElementInViewport(self):
        # unused but might come handy
        # for future ref: https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect
        return self.webdriver.execute_script("var elem = arguments[0],                 "
                                             "  box = elem.getBoundingClientRect(),    "
                                             "  cx = box.left + box.width / 2,         "
                                             "  cy = box.top + box.height / 2,         "
                                             "  e = document.elementFromPoint(cx, cy); "
                                             "for (; e; e = e.parentElement) {         "
                                             "  if (e === elem)                        "
                                             "    return true;                         "
                                             "}                                        "
                                             "return false;                            ", self.element)

    @property
    def elementAttributes(self):
        if not self.webdriver:
            return ""
        return self.webdriver.execute_script("""var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index)
                                             { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;""", self.element)

    @property
    def convertCurrencyInStringFormatToFloat(self) -> float:
        return float(self.text.replace("£", "").replace(",", ""))

    @property
    def borderColor(self):
        return self.element.value_of_css_property("border-color")
