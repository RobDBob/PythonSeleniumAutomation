from selenium.webdriver.common.by import By
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.Driver.PyStormElement import PyStormElement

CSS_CHECK_SUB_ELEMENT_LOCATOR = [By.XPATH, ".//span[@aria-hidden]"]
CSS_CHECK_PSEUDO_ELEMENT = "::after"

# These callbacks are used to determine the state of various elements, such as checkboxes, RadioButtons and inputs.


def defaultIsCheckedCB(element: PyStormElement, _):
    return bool(element.getAttribute("checked"))


def boldFontIsCheckedCB(element: PyStormElement, _):
    return element.findElement(By.XPATH, ".//span[contains(@class, 'label')]").getAttribute("style") == "font-weight: bold;"


def isPrecedingSiblingInputCheckedCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//preceding-sibling::input")
    return bool(inputElement.getAttribute("checked"))


def isFollowingSiblingInputCheckedCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//following-sibling::input")
    return bool(inputElement.getAttribute("checked"))


def isInputChildCheckedCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//input")
    return inputElement.is_selected()


def isCSSCheckedCB(element: PyStormElement, webdriver: PyStormDriver):
    from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
    jsScript = f"return window.getComputedStyle(arguments[0], '{CSS_CHECK_PSEUDO_ELEMENT}').getPropertyValue('content');"
    baseElement = BaseTestObject(webdriver, element, *CSS_CHECK_SUB_ELEMENT_LOCATOR)
    return webdriver.execute_script(jsScript, baseElement.element) != "none"


def defaultIsDisabledCB(element: PyStormElement, _) -> bool:
    return bool(element.getAttribute("disabled"))


def isPrecedingSiblingInputDisabledCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//preceding-sibling::input")
    return bool(inputElement.getAttribute("disabled"))


def isInputChildDisabledCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//input")
    return bool(inputElement.getAttribute("disabled"))


def isPrecedingSiblingInputRadioButtonCheckedCB(element: PyStormElement, _):
    inputElement = element.findElement(By.XPATH, ".//preceding-sibling::input[@type='radio']")
    return bool(inputElement.getAttribute("checked"))


def isBackgroundColourCSSCheckedRadioButtonCB(element: PyStormElement, webdriver: PyStormDriver):
    """
        Radio button state is not reflected in the input element. DOM is not changed.
        The UI shows selection is with CSS styling. Here checking the .rb-design background-color to confirm selection.
    """
    from TestPages.PageObjects.BaseObjects.BaseTestObject import BaseTestObject
    jsScript = "return window.getComputedStyle(arguments[0]).backgroundColor;"
    baseElement = BaseTestObject(webdriver, element, By.XPATH, ".//ancestor::label//span[contains(@class,'rb-design')]")
    backgroundColorStyle = webdriver.execute_script(jsScript, baseElement.element)
    return backgroundColorStyle != "rgba(0, 0, 0, 0)"
