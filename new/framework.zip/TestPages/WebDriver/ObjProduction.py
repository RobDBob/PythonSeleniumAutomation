from CommonCode.Driver.PyStormDriver import PyStormDriver


def manufacture(typeToManufacture: type, webdriver: PyStormDriver, parentElement, by, value):
    """
    factory method, returns multiple instances of an ui element (type_to_manufacture)
    :param type_to_manufacture:
    :param parentElement:
    :param by:
    :param value:
    :return:
    """
    return [typeToManufacture(webdriver, parentElement, element) for element in parentElement.findElements(by, value)]
