import operator
from datetime import datetime
from typing import Callable
from selenium.common.exceptions import NoAlertPresentException, NoSuchElementException, NoSuchFrameException, StaleElementReferenceException
from CommonCode.CustomExceptions import AccessBlockedException, AccessDeniedException, PageUnavailableException
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.Driver.PyStormElement import PyStormElement
from CommonCode.TestHelpers.DateMethods import strpTime

# Licensed to the Software Freedom Conservancy (SFC) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The SFC licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

# pylint: disable=invalid-name, no-else-return


class datetime_stamp_changed:
    """
    Check if datetime stamp is as expected
    """

    def __init__(self, labelLocator, expectedDateTime: datetime, dateTimeFormat: str, operator: Callable = operator.lt):
        self.labelLocator = labelLocator
        self.expectedDateTime = expectedDateTime
        self.dateTimeFormat = dateTimeFormat
        self.operator = operator

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.labelLocator)
            actualDateTime = strpTime(element.text, self.dateTimeFormat)

            return self.operator(self.expectedDateTime, actualDateTime)

        except (StaleElementReferenceException, NoSuchElementException):
            return False


class presence_of_element_located:
    """ An expectation for checking that an element is present on the DOM
    of a page. This does not necessarily mean that the element is visible.
    locator - used to find the element
    returns the WebElement once it is located
    """

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        return _find_element(driver, self.locator)


class url_contains:
    """ An expectation for checking that the current url contains a
    case-sensitive substring.
    url is the fragment of url expected,
    returns True when the url matches, False otherwise
    """

    def __init__(self, url):
        self.url = url

    def __call__(self, driver):
        return self.url in driver.current_url


class url_matches:
    """An expectation for checking the current url.
    pattern is the expected pattern, which must be an exact match
    returns True if the url matches, false otherwise."""

    def __init__(self, pattern):
        self.pattern = pattern

    def __call__(self, driver):
        import re
        match = re.search(self.pattern, driver.current_url)

        return match is not None


class url_to_be:
    """An expectation for checking the current url.
    url is the expected url, which must be an exact match
    returns True if the url matches, false otherwise."""

    def __init__(self, url):
        self.url = url

    def __call__(self, driver):
        return self.url == driver.current_url


class url_changes:
    """An expectation for checking the current url.
    url is the expected url, which must not be an exact match
    returns True if the url is different, false otherwise."""

    def __init__(self, url):
        self.url = url

    def __call__(self, driver):
        return self.url != driver.current_url


class visibility_of_element_located:
    """ An expectation for checking that an element is present on the DOM of a
    page and visible. Visibility means that the element is not only displayed
    but also has a height and width that is greater than 0.
    locator - used to find the element
    returns the WebElement once it is located and visible
    """

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        try:
            return _element_if_visible(_find_element(driver, self.locator))
        except (StaleElementReferenceException, NoSuchElementException):
            return False


class visibility_of:
    """ An expectation for checking that an element, known to be present on the
    DOM of a page, is visible. Visibility means that the element is not only
    displayed but also has a height and width that is greater than 0.
    element is the WebElement
    returns the (same) WebElement once it is visible
    """

    def __init__(self, element):
        self.element = element

    def __call__(self, ignored):
        return _element_if_visible(self.element)


def _element_if_visible(element: PyStormElement, visibility=True):
    if visibility:
        return element if element and element.is_displayed() and not element.isHidden else False
    else:
        return element is None or element.is_displayed() == visibility


class presence_of_all_elements_located:
    """ An expectation for checking that there are all elements present on a web page.
    locator is used to find the elements
    returns the list of WebElements once they are located

    Default comparison is greater equal
    """

    def __init__(self, locator, expectedElementsCount, compareOperator: Callable = operator.ge):
        self.compareOperator = compareOperator
        self.locator = locator
        self.expectedElementsCount = expectedElementsCount

    def __call__(self, driver):
        return self.compareOperator(len(_find_elements(driver, self.locator)), self.expectedElementsCount)


class visibility_of_any_elements_located:
    """ An expectation for checking that there is at least one element visible
    on a web page.
    locator is used to find the element
    returns the list of WebElements once they are located
    """

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        return [element for element in _find_elements(driver, self.locator) if _element_if_visible(element)]


class visibility_of_just_one_element_located:
    """ An expectation for checking that only one element is present on the DOM of a
    page.
    locator - used to find the elements
    returns the WebElement once it is the only one located
    """

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        try:
            elements = _find_elements(driver, self.locator)
            return len(elements) == 1
        except StaleElementReferenceException:
            return False


class visibility_of_all_elements_located:
    """ An expectation for checking that all elements are present on the DOM of a
    page and visible. Visibility means that the elements are not only displayed
    but also has a height and width that is greater than 0.
    locator - used to find the elements
    returns the list of WebElements once they are located and visible
    """

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        try:
            elements = _find_elements(driver, self.locator)
            for element in elements:
                if _element_if_visible(element, visibility=False):
                    return False
            return elements
        except (StaleElementReferenceException, NoSuchElementException):
            return False


class text_to_be_present_in_any_of_elements:
    """
    An expectation for checking if the given text is present in any of found elements.
    """

    def __init__(self, locator, text):
        self._locator = locator
        self._text = text

    def __call__(self, driver):
        try:
            elements = _find_elements(driver, self._locator)
            for element in elements:
                if element and element.text:

                    # Removing all white spaces as there is some text formatting happening on webpage dropdown input
                    element_text_no_spaces: str = element.text.replace(' ', '').lower()
                    text_no_spaces: str = self._text.replace(' ', '').lower()

                    if text_no_spaces in element_text_no_spaces:
                        return True
            return False
        except StaleElementReferenceException:
            return False


class text_to_be_present_in_any_of_locators:
    """
    An expectation for checking if the given text is present in any of found elements.
    """

    def __init__(self, locators: tuple, text):
        self._locators = locators
        self._text = text

    def __call__(self, driver):
        try:
            for locator in self._locators:
                elements = _find_elements(driver, locator)
                for element in elements:
                    if element and element.text:

                        # Removing all white spaces as there is some text formatting happening on webpage dropdown input
                        element_text_no_spaces = element.text.replace(' ', '').lower()
                        text_no_spaces = self._text.replace(' ', '').lower()

                        if text_no_spaces in element_text_no_spaces:
                            return True
            return False
        except StaleElementReferenceException:
            return False


class text_to_be_present_in_element:
    """
    An expectation for checking if the given text is present in the specified element.
    locator, text
    """

    def __init__(self, locator, expectedText, comparisonOperator: Callable = operator.contains):
        self.locator = locator
        self.expectedText: str = expectedText
        self.comparisonOperator: Callable = comparisonOperator

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.locator)

            if not element:
                return False

            # Removing all white spaces as there is some text formatting happening on webpage dropdown input
            actualValue = element.text.replace(' ', '').lower()
            expectedValue = self.expectedText.replace(' ', '').lower()

            return self.comparisonOperator(actualValue, expectedValue)
        except StaleElementReferenceException:
            return False


class float_to_be_present_in_element:
    """
    An expectation for checking if the given text is present in the specified element.
    locator, text
    """

    def __init__(self, locator, expectedLoatText, comparisonOperator: Callable = operator.contains):
        self.locator = locator
        self.expectedFloat: float = float(expectedLoatText)
        self.comparisonOperator: Callable = comparisonOperator

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.locator)

            if not element:
                return False

            return self.comparisonOperator(float(element.text), self.expectedFloat)
        except StaleElementReferenceException:
            return False


class float_value_in_attribute_is_as_expected:
    """
    An expectation for checking if the given text is present in the element's
    locator, text
    """

    def __init__(self, locator, attributeName, expectedValue, operatorValue: Callable):
        self.locator = locator
        self.attributeName = attributeName
        self.expectedValue: str = expectedValue
        self.operatorValue: Callable = operatorValue

    def __call__(self, driver):
        try:
            actualValue = float(_find_element(driver, self.locator).getAttribute(self.attributeName))
            if actualValue:
                return self.operatorValue(self.expectedValue, actualValue)
            else:
                return False
        except StaleElementReferenceException:
            return False


class text_value_in_attribute_in_element:
    """
    An expectation for checking if the given text is present in the element's
    locator, text
    """

    def __init__(self, locator, attributeName, expectedValue, comparisonOperator: Callable = operator.contains):
        self.locator = locator
        self.attributeName = attributeName
        self.expectedValue = expectedValue
        self.comparisonOperator = comparisonOperator

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.locator)

            if not element:
                return False

            # Removing all white spaces as there is some text formatting happening on webpage dropdown input
            actualValue = element.getAttribute(self.attributeName).replace(' ', '')
            expectedValue = self.expectedValue.replace(' ', '')
            return self.comparisonOperator(actualValue, expectedValue)
        except (StaleElementReferenceException, AttributeError):
            return False


class text_in_element:
    """
    checks for text present in element.text, element.get_attribute

    Params:
    expectedText
    comparisonOperator
    attributeName list[str] / str:
    """

    def __init__(self, locator, **kwargs):
        self.locator = locator
        self.expectedText: str = str(kwargs.get("expectedText", "")).replace(" ", "").lower()
        self.comparisonOperator: Callable = kwargs.get("comparisonOperator", operator.contains)

        self.attributeName: list[str] = kwargs.get("attributeName", ["value", "placeholder"])
        if not isinstance(self.attributeName, list):
            self.attributeName = [self.attributeName]

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.locator)

            if not element:
                return False

            # first check if text is available via attribute either "value" or "placeholder"
            for attributeName in self.attributeName:
                actualAttributeValue = element.getAttribute(attributeName)
                actualAttributeValue = actualAttributeValue.replace(" ", "").lower() if actualAttributeValue else ""
                if actualAttributeValue and self.comparisonOperator(actualAttributeValue, self.expectedText):
                    return True

            actualText = element.text.replace(' ', '').lower()
            # if no text found in attribute try ".text"
            return self.comparisonOperator(actualText, self.expectedText)

        except (StaleElementReferenceException, AttributeError):
            return False


class attribute_present_in_element:
    """
    An expectation for checking if an attribute is present in given element
    """

    def __init__(self, locator, attributeName):
        self.locator = locator
        self.attributeName = attributeName

    def __call__(self, driver):
        try:
            return _find_element(driver, self.locator).getAttribute(self.attributeName) is not None
        except StaleElementReferenceException:
            return False


class attribute_present_in_one_of_elements:
    """
    An expectation for checking if the given text is present in the element's
    locator, text
    """

    def __init__(self, locator, attributeName):
        self.locator = locator
        self.attributeName = attributeName

    def __call__(self, driver):
        try:
            foundElements = _find_elements(driver, self.locator)
            if foundElements:
                return [k for k in foundElements if k.getAttribute(self.attributeName)]
            else:
                return False
        except StaleElementReferenceException:
            return False


class frame_to_be_available_and_switch_to_it:
    """ An expectation for checking whether the given frame is available to
    switch to.  If the frame is available it switches the given driver to the
    specified frame.
    """

    def __init__(self, locator):
        self.frame_locator = locator

    def __call__(self, driver):
        try:
            if isinstance(self.frame_locator, tuple):
                driver.switch_to.frame(_find_element(driver,
                                                     self.frame_locator))
            else:
                driver.switch_to.frame(self.frame_locator)
            return True
        except NoSuchFrameException:
            return False


class invisibility_of_element_located:
    """ An Expectation for checking that an element is either invisible or not
    present on the DOM.

    locator used to find the element
    """

    def __init__(self, locator):
        self.target = locator

    def __call__(self, driver):
        try:
            target = self.target
            if not isinstance(target, PyStormElement):
                target = _find_element(driver, target)
            return _element_if_visible(target, False)
        except (NoSuchElementException, StaleElementReferenceException):
            # In the case of NoSuchElement, returns true because the element is
            # not present in DOM. The try block checks if the element is present
            # but is invisible.
            # In the case of StaleElementReference, returns true because stale
            # element reference implies that element is no longer visible.
            return True


class element_to_be_clickable:
    """ An Expectation for checking an element is visible and enabled such that
    you can click it."""

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        element: PyStormElement = visibility_of_element_located(self.locator)(driver)
        if element and element.is_enabled():
            return element
        else:
            return False


class staleness_of:
    """ Wait until an element is no longer attached to the DOM.
    element is the element to wait for.
    returns False if the element is still attached to the DOM, true otherwise.
    """

    def __init__(self, element):
        self.element = element

    def __call__(self, ignored):
        try:
            # Calling any method forces a staleness check
            self.element.is_enabled()
            return False
        except StaleElementReferenceException:
            return True


class element_to_be_selected:
    """ An expectation for checking the selection is selected.
    element is WebElement object
    """

    def __init__(self, element):
        self.element = element

    def __call__(self, ignored):
        return self.element.is_selected()


class element_located_to_be_selected:
    """An expectation for the element to be located is selected.
    locator is a tuple of (by, path)"""

    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        return _find_element(driver, self.locator).is_selected()


class element_selection_state_to_be:
    """ An expectation for checking if the given element is selected.
    element is WebElement object
    is_selected is a Boolean."
    """

    def __init__(self, element, is_selected):
        self.element = element
        self.is_selected = is_selected

    def __call__(self, ignored):
        return self.element.is_selected() == self.is_selected


class element_located_selection_state_to_be:
    """ An expectation to locate an element and check if the selection state
    specified is in that state.
    locator is a tuple of (by, path)
    is_selected is a boolean
    """

    def __init__(self, locator, is_selected):
        self.locator = locator
        self.is_selected = is_selected

    def __call__(self, driver):
        try:
            element = _find_element(driver, self.locator)
            return element.is_selected() == self.is_selected
        except StaleElementReferenceException:
            return False


class alert_is_present:
    """ Expect an alert to be present."""

    def __init__(self):
        pass

    def __call__(self, driver):
        try:
            alert = driver.switch_to.alert
            return alert
        except NoAlertPresentException:
            return False


def element_exists(by):
    if isinstance(by, PyStormElement):
        return by
    elif hasattr(by, 'element') and by.element is None:
        raise NoSuchElementException()
    else:
        raise NoSuchElementException()


def _find_element(driver, by) -> PyStormElement:
    """
    Looks up an element. Logs and re-raises ``WebDriverException``
    if thrown.
    Locator (by) can be an element as well.
    """
    if isinstance(by, (list, tuple)):
        elements = _find_elements(driver, by)

        if elements and len(elements) > 0:
            return elements[0]
        else:
            raise NoSuchElementException(f"Element with locator ${by} not found.")
    else:
        return element_exists(by)


def _find_elements(driver: PyStormElement | PyStormDriver, by) -> list[PyStormElement]:
    if driver.findElements("xpath", "//*[text()='Access Denied']"):
        raise AccessDeniedException("Access denied is shown")

    if driver.findElements("xpath", "//*[contains(text(), 'We are sorry, the page you are looking')]"):
        raise PageUnavailableException("Page is unavailable")

    if driver.findElements("xpath", "//*[text()='Access blocked']"):
        raise AccessBlockedException("Access blocked is shown")
    return driver.findElements(*by)
