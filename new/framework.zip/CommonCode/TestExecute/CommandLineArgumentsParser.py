import argparse
import os
from CommonCode.TestExecute.TestContext import TestContext

# Parse Argument messages
HOST_ADDRESS = "Host name, IP Address."
TEST_IDS = "Specify test ID (s)."
TEST_CLASS_NAME = "Specify name of the test class, partial name is sufficient. Tests from all matched classes " \
                  "will be executed."
TEST_ATTRIBUTE_NAME = "Specify test attribute name i.e. smoke. All tests matching this attribute will be executed."
RUN_HEADLESS = "Option to tell framework to execute tests in headless mode."
RUN_DEBUG = "Option to tell framework to execute tests in debug mode. " \
            "Used to print out more in depth data (i.e. REST API body request)."
RUN_LUF = "Option to tell framework to execute test in a loop until first failure"
GATHER_SCREENSHOOT_EVIDENCE = "Switch, when on, instructs framework to gather screenshot evidence at implemented steps."
CAPTURE_NETWORK_LOGS = "Switch, when on, instructs framework to capture network logs."
DRY_RUN = "Switch, when on, instructs framework to run SKIP upload test results to ADO."
RE_RUN_FAILED = "Switch, when on, instructs framework to re run failed tests."
WIQL_TESTS_TO_RUN = "ID to ADO WIQL Query with a list of tests to execute. " \
    "Results of query will be crossreferenced with local tests. If not provided, all tests will be executed."
WIQL_TESTS_TO_BLOCK = "ID to ADO WIQL Query with a list of tests to mark as blocked. " \
    "Results of query will be crossreferenced with local tests. If not provided no filter be used to exclude."
RUN_TITLE = "Title to be used for the test run and reporting."
BROWSER = "Option to select browser, available options: EDGE, CHROME"
DRIVER_PATH = "Path to executable driver, either for chrome or edge. Used as an altternative to selenium driver manager."
TEST_CLASS_NAME_OR_TEST_CASE_ID = "Required either test class name(s) or test case ID(s)."
RUN_CONFIG_SELECTION = "Configuration file used during test execution."
TEST_PLAN = "Specify ADO test plan where test suite resides"
REPORT_HYPERLINK_MESSAGE = "Specify link to be included in tes report."
SRC_FILE_MESSAGE = "Provide name of the source file (yaml). FileNMame will be matched with content from TestData/AccountData folder"


class CommandLineArgumentsParser:
    @staticmethod
    def getAvailableConfigFiles(prefix, postfix):
        """
        Configuration files are expected to be in format TestRunConfig_XYZ.json
        The TestRunConfig_ and .json are stripped off.
        :param prefix:
        :param postfix:
        :return:
        """
        availableConfigFields = []

        for configFile in os.listdir("./ConfigFiles"):
            if configFile.startswith(prefix) and configFile.endswith(postfix):

                # 14:-5 remove TestRunConfig_ and .json
                availableConfigFields.append(configFile[14:-5])

        return availableConfigFields

    @staticmethod
    def addArgumentConfigurationFile(parser: argparse.ArgumentParser):
        configFiles = CommandLineArgumentsParser.getAvailableConfigFiles("TestRunConfig_", ".json")

        parser.add_argument("-c",
                            dest="CURRENT_CONFIG_NAME",
                            help=RUN_CONFIG_SELECTION,
                            choices=configFiles,
                            required=True)

    @staticmethod
    def addArgumentTestPlan(parser: argparse.ArgumentParser):
        parser.add_argument("-testPlan",
                            dest="TEST_PLAN",
                            help=TEST_PLAN)

    @staticmethod
    def addArgumentListOfTestIDs(parser: argparse.ArgumentParser):
        parser.add_argument("-t",
                            nargs="*",
                            dest="TEST_IDS",
                            type=int,
                            help=TEST_IDS,
                            default=[])

    @staticmethod
    def addArgumentListOfClassNames(parser: argparse.ArgumentParser):
        parser.add_argument("-class",
                            nargs="*",
                            dest="TEST_CLASS_NAMES",
                            type=str,
                            help=TEST_CLASS_NAME,
                            default=[])

    @staticmethod
    def addArgumentTestAttribute(parser: argparse.ArgumentParser):
        """
        For now and simplicity we only support a single parameter
        :param parser:
        :return:
        """
        parser.add_argument("-attribute",
                            dest="TEST_ATTRIBUTE",
                            type=str,
                            help=TEST_ATTRIBUTE_NAME,
                            default=None)

    @staticmethod
    def addArgumentRunHeadless(parser: argparse.ArgumentParser):
        parser.add_argument("--headless",
                            dest="RUN_HEADLESS",
                            default=False,
                            help=RUN_HEADLESS,
                            action="store_true")

    @staticmethod
    def addArgumentLoopUntilFailure(parser: argparse.ArgumentParser):
        parser.add_argument("--luf",
                            dest="LUF",
                            default=False,
                            help=RUN_LUF,
                            action="store_true")

    @staticmethod
    def addArgumentGatherScreenshotEvidence(parser: argparse.ArgumentParser):
        parser.add_argument("--gatherScreenshotEvidence",
                            dest="GATHER_SCREENSHOT_EVIDENCE",
                            help=GATHER_SCREENSHOOT_EVIDENCE,
                            default=False,
                            action="store_true")

    @staticmethod
    def addArgumentGatherCaptureNetworkLogs(parser: argparse.ArgumentParser):
        parser.add_argument("--captureNetworkLogs",
                            dest="CAPTURE_NETWORK_LOGS",
                            help=CAPTURE_NETWORK_LOGS,
                            default=False,
                            action="store_true")

    @staticmethod
    def addArgumentUploadTestResultsToAdo(parser: argparse.ArgumentParser):
        parser.add_argument("--dryRun",
                            dest="DRY_RUN",
                            help=DRY_RUN,
                            default=False,
                            action="store_true")

    @staticmethod
    def addArgumentReRunFailedTests(parser: argparse.ArgumentParser):
        parser.add_argument("--reRunFailed",
                            dest="RE_RUN_FAILED",
                            help=RE_RUN_FAILED,
                            default=False,
                            action="store_true")

    @staticmethod
    def addArgumentWIQLFilterTestsToRun(parser: argparse.ArgumentParser):
        parser.add_argument("-testsToRunWIQL",
                            dest="WIQL_TESTS_TO_RUN",
                            help=WIQL_TESTS_TO_RUN,
                            default="0287db7f-49f0-418d-b954-c203f0108b7c",
                            type=str)

    @staticmethod
    def addArgumentWIQLFilterTestsToBlock(parser: argparse.ArgumentParser):
        parser.add_argument("-testsToBlockWIQL",
                            dest="WIQL_TESTS_TO_BLOCK",
                            help=WIQL_TESTS_TO_BLOCK,
                            default="",
                            type=str)

    @staticmethod
    def addArgumentRunTitle(parser: argparse.ArgumentParser):
        parser.add_argument("-runTitle",
                            dest="RUN_TITLE",
                            help=RUN_TITLE,
                            default="",
                            type=str)

    @staticmethod
    def addArgumentBrowser(parser: argparse.ArgumentParser):
        parser.add_argument("-browser",
                            dest="BROWSER",
                            help=BROWSER,
                            default="chrome",
                            type=str,
                            choices=["chrome", "edge"])

    @staticmethod
    def addArgumentDriverPath(parser: argparse.ArgumentParser):
        parser.add_argument("-driverPath",
                            dest="DRIVER_PATH",
                            help=DRIVER_PATH,
                            default="",
                            type=str)

    @staticmethod
    def validateTestParameters(parser: argparse.ArgumentParser, parsedArgs):
        if len(parsedArgs.TEST_IDS) == 0 and len(parsedArgs.TEST_CLASS_NAMES) == 0 and not parsedArgs.TEST_ATTRIBUTE:
            parser.error(TEST_CLASS_NAME_OR_TEST_CASE_ID)

    @staticmethod
    def processArgumentsSingleTestRun(testContext: TestContext):
        """
        Method to arrange standard argument options.
        It allows test framework to utilize its own parser with additional options on top of the standard ones.
        :param testContext:
        :return:
        """
        parser = argparse.ArgumentParser(prefix_chars="-")

        CommandLineArgumentsParser.addArgumentConfigurationFile(parser)
        CommandLineArgumentsParser.addArgumentListOfTestIDs(parser)
        CommandLineArgumentsParser.addArgumentListOfClassNames(parser)
        CommandLineArgumentsParser.addArgumentTestAttribute(parser)
        CommandLineArgumentsParser.addArgumentRunHeadless(parser)
        CommandLineArgumentsParser.addArgumentLoopUntilFailure(parser)
        CommandLineArgumentsParser.addArgumentGatherScreenshotEvidence(parser)
        CommandLineArgumentsParser.addArgumentGatherCaptureNetworkLogs(parser)
        CommandLineArgumentsParser.addArgumentBrowser(parser)
        CommandLineArgumentsParser.addArgumentDriverPath(parser)

        parsedArgs = parser.parse_args()

        CommandLineArgumentsParser.validateTestParameters(parser, parsedArgs)

        testContext.update(parsedArgs)
        testContext.updateFromConfigFile()

    @staticmethod
    def processArgumentsGroupTestRun(testContext: TestContext):
        """
        This method is used by the RunUIAutomation

        Method to arrange standard argument options.
        It allows test framework to utilize its own parser with additional options on top of the standard ones.
        :param parser:
        :return:
        """
        parser = argparse.ArgumentParser(prefix_chars="-")

        CommandLineArgumentsParser.addArgumentConfigurationFile(parser)
        CommandLineArgumentsParser.addArgumentTestPlan(parser)
        CommandLineArgumentsParser.addArgumentGatherScreenshotEvidence(parser)
        CommandLineArgumentsParser.addArgumentUploadTestResultsToAdo(parser)
        CommandLineArgumentsParser.addArgumentReRunFailedTests(parser)
        CommandLineArgumentsParser.addArgumentWIQLFilterTestsToRun(parser)
        CommandLineArgumentsParser.addArgumentWIQLFilterTestsToBlock(parser)
        CommandLineArgumentsParser.addArgumentRunTitle(parser)
        CommandLineArgumentsParser.addArgumentBrowser(parser)
        CommandLineArgumentsParser.addArgumentDriverPath(parser)

        parsedArgs = parser.parse_args()

        testContext.update(parsedArgs)
        testContext.updateFromConfigFile()

    @staticmethod
    def processArgumentsEnvironmentSelection(testContext: TestContext):
        parser = argparse.ArgumentParser(prefix_chars="-")

        CommandLineArgumentsParser.addArgumentConfigurationFile(parser)
        CommandLineArgumentsParser.addArgumentBrowser(parser)
        parsedArgs = parser.parse_args()
        testContext.update(parsedArgs)
        testContext.updateFromConfigFile()

    @staticmethod
    def processArgumentsForBackOfficeUserCreation(testContext: TestContext):
        parser = argparse.ArgumentParser(prefix_chars="-")

        parser.add_argument("-userName", required=True, type=str, help="Provide Name for new user")
        parser.add_argument("-userCompany", required=True, type=str, help="Provide Company for new user")
        parser.add_argument("-userGroup", required=True, type=str, help="Provide Group name for new user")

        CommandLineArgumentsParser.addArgumentConfigurationFile(parser)
        parsedArgs = parser.parse_args()
        testContext.update(parsedArgs)
        testContext.updateFromConfigFile()
        return parsedArgs

    @staticmethod
    def processArgumentsForWrapAccountCreation(testContext: TestContext):
        parser = argparse.ArgumentParser(prefix_chars="-")

        parser.add_argument("-wrapLoginUserName", required=True, type=str, help="Provide login name for wrap platform")
        parser.add_argument("-wrapLoginPassword", required=True, type=str, help="Provide password for wrap platform")
        parser.add_argument("-srcFileName", required=True, type=str, help=SRC_FILE_MESSAGE)

        CommandLineArgumentsParser.addArgumentConfigurationFile(parser)
        parsedArgs = parser.parse_args()
        testContext.update(parsedArgs)
        testContext.updateFromConfigFile()
        return parsedArgs
