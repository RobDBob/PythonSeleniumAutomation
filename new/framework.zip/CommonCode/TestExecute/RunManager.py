# pylint: disable = E0611, E0401
# pyright: reportArgumentType=false

import copy
import itertools
import locale
import os
import platform
import sys
import unittest
from concurrent.futures import ProcessPoolExecutor
from pprint import pformat
from dotenv import load_dotenv
from CommonCode.API.ADORequests import AccessTokenEnum, ADORequests
from CommonCode.HelperFunctions import tryExecute
from CommonCode.TestExecute import Constants
from CommonCode.TestExecute.ExecuteEnums import ConfigOptions
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestExecute.Objects.TestBucket import TestBucket
from CommonCode.TestExecute.Objects.TestsResultsContainer import TestsResultsContainer
from CommonCode.TestExecute.PyStormTestResult import PyStormTextTestResult
from CommonCode.TestExecute.TestContext import Test_Context, TestContext
from CommonCode.TestExecute.TestResultsADOUploader import TestResultsADOUploader
from CommonCode.TestHelpers.DataTransformation import flattenSublists


def logFailures(testFailures):
    """
    Log test failures to log files
    Log only if any failures are present
    """
    if not testFailures:
        return

    for testName in testFailures:
        erroMessage = testFailures[testName][1] if len(testFailures[testName]) > 1 else ""

        PrintMessage(f"------------ Error log START for: {testName}")
        PrintMessage(f"\n{erroMessage}")
        PrintMessage(f"------------ Error log END for: {testName}")


def executeSingleSuiteAndUploadResults(testBucket: TestBucket, topLevelTestContext: TestContext):
    """
    Method to execute tests in parallel
    :return:
    """
    # Setting a global variable for the process itself to use in test execution
    Test_Context.update(topLevelTestContext._settings)

    # Python3 unit test runner removes references to test within the runner.run > suite > _removeTestAtIndex
    # This behaviour could be overridden but we might get into a new sort of troubles that _removeTestAtIndex is
    # trying to resolve, so we'll make a copy of test suite instead.
    testSuite = copy.deepcopy(testBucket.unitTestSuite)

    try:
        if testSuite._tests:
            testClassName = testSuite._tests[0].__class__.__name__
            PrintMessage(f"Starting PROCESS - bucket test count: {testSuite.countTestCases()} for {testClassName}")
    except AttributeError:
        PrintMessage(f"Starting PROCESS - this bucket test count: {testSuite.countTestCases()}")

    runner = unittest.TextTestRunner(stream=sys.stdout,
                                     resultclass=PyStormTextTestResult)

    try:
        testResults = runner.run(testSuite)
    except UnicodeEncodeError:
        PrintMessage(f">>>>>>>>>>>>> THIS CLASS IS CAUSING ERROR: '{testClassName}'")

    testResultsContainer = TestsResultsContainer(Test_Context, testResults, testBucket)

    if not Test_Context.getSetting(ConfigOptions.DRY_RUN):
        tryExecute(TestResultsADOUploader(Test_Context).uploadResultsToADO, testResultsContainer)

    # remove duplicates in case of same test having failure & error
    tryExecute(logFailures, testResultsContainer.allFailures)

    return list(testResultsContainer.allFailures.keys())


class RunManager:
    def __init__(self, testContext: TestContext):
        load_dotenv()
        locale.setlocale(locale.LC_ALL, 'en_GB.UTF-8')
        self.testContext = testContext
        self.createFrameworkFolders(self.testContext)
        self._printSetupDetails()

    def __enter__(self):
        return self

    # pylint: disable = invalid-name
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Place to add post class cleaning steps i.e. delete temp folders if we decide to go this path
        :param exc_type:
        :param exc_val:
        :param exc_tb:
        :return:
        """
        self.setRunState(Constants.RUN_STATE_COMPLETED)

    @staticmethod
    def createFrameworkFolders(testContext: TestContext):
        """
        Method creates folders required by the framework
        List of folders to create is available via EnvironmentConfig.yaml file
        :return:
        """
        requiredFolders: dict = testContext.setupConfig.getSetting(ConfigOptions.REQUIRED_FOLDERS, {})
        for _, value in requiredFolders.items():
            os.makedirs(value, exist_ok=True)

    @staticmethod
    def _setExitCode(result):
        """
        Exit code set by test execution
        This is used in building process of tested projects (currently in Direct Data jenkins pipeline)
        :param result:
        :return:
        """
        if result:
            endMessage = "All selected tests finished with PASS status - exit code - 0"
            exitCode = 0
        else:
            endMessage = "Some of selected tests finished with FAIL status - exit code: 1"
            exitCode = 1

        PrintMessage(endMessage)
        return exitCode

    def _executePostTestCallbacks(self, postExecutionCBs):
        # Used for zipping up test logs and etc
        for callback in postExecutionCBs:
            tryExecute(callback, self.testContext)

    def _printMessagePostTest(self, testBuckets, failures):
        totalNumberOfTestsExecuted = sum(len(k.unitTestSuiteTests) for k in testBuckets)
        totalNumberOfPassedTests = totalNumberOfTestsExecuted - len(failures)
        try:
            passRate = 100 * ((totalNumberOfPassedTests) / totalNumberOfTestsExecuted)
        except ZeroDivisionError:
            passRate = float(0)

        passRateMessage = f"{totalNumberOfPassedTests}/{totalNumberOfTestsExecuted} ({format(passRate, '.2f')}% pass)"
        runId = self.testContext.getSetting(ConfigOptions.RUN_ID)
        PrintMessage(f"\n<<<<<<<<<<<<<<<< Automated Test run; runId: '{runId}' - complete {passRateMessage}!>>>>>>>>>>>>>>>>\n")

    def _printSetupDetails(self):
        PrintMessage(f"Python version: {platform.python_version()}")
        PrintMessage(f"Test environment: {self.testContext.getSetting(ConfigOptions.ENVIRONMENT)}")
        PrintMessage(f"Browser set: {self.testContext.getSetting(ConfigOptions.BROWSER)}")

    def _printTestContext(self):
        formatted = f"TestContext configuration: \n{pformat(self.testContext.getPrintable())}"
        PrintMessage(formatted)

    def setRunState(self, runState):
        if self.testContext.getSetting(ConfigOptions.RUN_ID):
            adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_WRITE_ACCESS_TOKEN)
            adoRequests.updateTestRun(self.testContext.getSetting(ConfigOptions.RUN_ID), runState=runState)

    def createTestRunID(self):
        """
        Create test run if one does not exist.
        This method will get called more than one during run time.
        1. Execute all tests
        2. Execute all failures from 1.
        """
        if self.testContext.getSetting(ConfigOptions.RUN_ID):
            return

        adoRequests = ADORequests(AccessTokenEnum.TEST_PLAN_WRITE_ACCESS_TOKEN)

        testPlanName = adoRequests.getTestPlanName(self.testContext.getSetting(ConfigOptions.TEST_PLAN))
        runTitle = self.testContext.getSetting(ConfigOptions.RUN_TITLE)
        testRunName = f"{testPlanName} - {runTitle}"

        runId = adoRequests.createADOTestRun(self.testContext.getSetting(ConfigOptions.TEST_PLAN), testRunName)
        self.testContext.setSetting(ConfigOptions.RUN_ID, runId)

        # this is to set environment variable in ADO Pipelines
        print(f"##vso[task.setvariable variable=TESTRUNID;]{runId}")

    def runInParallel(self, testBuckets, postExecutionCBs=()):
        """
        On bulk test run, test user comes from file path_to_users_file

        :param custom_pool_context: Pool context for multiprocessor execution
        :param path_to_users_file: list of users used in parallel testing, each process runs of a different user
        :param postExecutionCBs: list of callbacks to be executed post test execution i.e. upload results up to magic_repo
        :return:
        """
        self._printTestContext()

        availableCPUCount = os.cpu_count()
        PrintMessage(f"Executor Context. Available CPUs: {availableCPUCount}")

        with ProcessPoolExecutor(max_workers=availableCPUCount) as executor:
            failures = list(
                executor.map(
                    executeSingleSuiteAndUploadResults,
                    testBuckets,
                    itertools.repeat(self.testContext)
                )
            )

        failures = flattenSublists(failures)

        TestResultsADOUploader(self.testContext).updateTestRunWithScreenshots(self.testContext.getSetting(ConfigOptions.RUN_ID))

        self._executePostTestCallbacks(postExecutionCBs)
        self._printMessagePostTest(testBuckets, failures)

        return failures

    def executeTestsOnDemand(self, unitTestSuite, postExecutionCBs=()):
        """
        Run tests either from test ids or test class names (partial is ok)

        On demand, test user comes from test config i.e. TestRunConfig_dev.json

        :param post_execution_cb:
        :return:
        """
        runResult = None
        runner = unittest.TextTestRunner(stream=sys.stdout,
                                         resultclass=PyStormTextTestResult)
        luf = self.testContext.getSetting(ConfigOptions.LOOP_UNTIL_FAILURE)
        lufCounter = 1

        try:
            while True:
                unitTestSuiteCopy = copy.deepcopy(unitTestSuite)
                runResult = runner.run(unitTestSuiteCopy)

                if not (luf and runResult and runResult.wasSuccessful()):
                    break

                PrintMessage(f" >>>>>> Loop number: {lufCounter} <<<<<<")
                lufCounter += 1

            # Used for zipping up test logs and etc
            for callback in postExecutionCBs:
                tryExecute(callback, self.testContext)

        finally:
            if luf:
                PrintMessage(f"LUF > Test executed successfully '{lufCounter}-times' before failing.")

        if runResult and not runResult.wasSuccessful():
            sys.exit(1)
