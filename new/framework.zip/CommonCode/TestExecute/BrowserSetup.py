import platform
from selenium.webdriver.chromium.options import ChromiumOptions
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.remote.remote_connection import RemoteConnection
from selenium.webdriver.remote.webdriver import WebDriver
from CommonCode.CustomExceptions import UIException
from CommonCode.Driver.PyStormDriver import PyStormDriver
from CommonCode.Driver.PyStormElement import PyStormElement
from CommonCode.TestExecute.ExecuteEnums import BrowserEnum, ConfigOptions
from CommonCode.TestExecute.Logging import PrintMessage
from CommonCode.TestExecute.TestContext import TestContext


class BrowserSetup:
    def __init__(self, testContext: TestContext):
        self.testContext = testContext

    def _disableDownloadPrompt(self, webdriver: WebDriver):
        if isinstance(webdriver.command_executor, RemoteConnection):
            webdriver.command_executor._commands["send_command"] = (
                "POST", "/session/$sessionId/chromium/send_command")

        params = {
            "cmd": "Page.setDownloadBehavior",
            "params": {
                "behavior": "allow",
                "downloadPath": self.testContext.testDownloadFolder
            }
        }
        webdriver.execute("send_command", params)

    def _logToConsole(self, webdriver: WebDriver):
        PrintMessage(f"  >> New browser setup. {webdriver.capabilities.get('browserName')}: {webdriver.capabilities.get('browserVersion')}")

    def _configureBrowserOptions(self, browserOptions: ChromiumOptions):
        browserOptions.set_capability('goog:loggingPrefs', {'performance': 'ALL'})

        if self.testContext.getSetting(ConfigOptions.RUN_HEADLESS):
            PrintMessage("Browser Setup > HEADLESS ", inStepMessage=True)
            browserOptions.add_argument("--headless")

        if platform.system() == "Linux":
            browserOptions.add_argument("--no-sandbox")
            browserOptions.add_argument("--disable-dev-shm-usage")
            browserOptions.add_argument("--ignore-gpu-blacklist")
            browserOptions.add_argument("--use-gl")

        # decreases number of non PyStorm related output
        browserOptions.add_argument('--log-level=3')
        browserOptions.add_argument("start-maximized")
        browserOptions.add_experimental_option("excludeSwitches", ["enable-logging"])
        return browserOptions

    def setup(self) -> PyStormDriver:
        """
        Browser can be selected either via configuration file or via command line
        Command line has precedence over configuration file
        """
        browserToSelect = self.testContext.getSetting(ConfigOptions.BROWSER, defaultValue="chrome")
        driverPath = str(self.testContext.getSetting(ConfigOptions.DRIVER_PATH, defaultValue=""))

        match browserToSelect:
            case BrowserEnum.CHROME:
                from selenium.webdriver.chrome.options import Options
                from selenium.webdriver.chrome.service import Service

                browserOptions = self._configureBrowserOptions(Options())

                webdriver = PyStormDriver(
                    browser_name=DesiredCapabilities.CHROME["browserName"],
                    vendor_prefix="goog",
                    options=browserOptions,
                    service=Service(executable_path=driverPath))

            case BrowserEnum.EDGE:
                from selenium.webdriver.edge.options import Options
                from selenium.webdriver.edge.service import Service

                browserOptions = self._configureBrowserOptions(Options())

                webdriver = PyStormDriver(
                    browser_name=DesiredCapabilities.EDGE["browserName"],
                    vendor_prefix="ms",
                    options=browserOptions,
                    service=Service(executable_path=driverPath))

            case _:
                raise UIException("Unknown browser/ browser version")

        webdriver.set_window_size(width=1920, height=1080)
        webdriver._web_element_cls = PyStormElement
        self._logToConsole(webdriver)
        self._disableDownloadPrompt(webdriver)

        return webdriver
