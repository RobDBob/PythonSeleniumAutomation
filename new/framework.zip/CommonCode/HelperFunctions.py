
import re
import traceback

# pylint: disable=broad-exception-caught


def tryExecuteAndRetry(method, *args, **kwargs):
    from retry import retry
    from CommonCode.TestExecute.Logging import PrintMessage

    expectedExceptions = kwargs.pop("expectedExceptions")
    delay = kwargs.pop("delay", 10)
    tries = kwargs.pop("tries", 5)

    @retry(exceptions=expectedExceptions, delay=delay, tries=tries)
    def wrappedMethod(method, *args, **kwargs):
        return method(*args, **kwargs)

    try:
        return wrappedMethod(method, *args, **kwargs)
    except Exception as e:
        tb = traceback.format_exc()
        PrintMessage(f"Encountered exception {type(e)}, with args {e.args}")
        PrintMessage(str(e))
        PrintMessage(f"traceback: {tb}")
        raise


def tryExecute(method, *args, **kwargs):
    from CommonCode.TestExecute.Logging import PrintMessage
    try:
        return method(*args, **kwargs)
    except Exception as e:
        tb = traceback.format_exc()
        PrintMessage(f"Encountered exception {type(e)}, with args {e.args}")
        PrintMessage(str(e))
        PrintMessage(f"traceback: {tb}")
    return None


def getTestIdFromTestName(testName: str) -> int | None:
    from CommonCode.TestExecute.Logging import PrintMessage
    try:
        match = re.search(r'C(\d+)', testName)
        if match:
            return int(match.group(1))
        return None
    except AttributeError:
        PrintMessage(f"Failed processing test {testName}, id failed to extract")
        return None


def instanceDir(obj):
    """
    Same as dir with exception, it'll ignore internal variables
    :param obj:
    :return:
    """
    return [k for k in dir(obj) if not k.startswith('__') and getattr(type(obj), k, None) in [False, True, None]]
