import json
import logging
from time import sleep
from retry import retry
from selenium.webdriver.chromium.webdriver import ChromiumDriver
from CommonCode.API import APIConstants
from CommonCode.API.Wrap.Requests.WrapDriverSessionToAPI import WrapDriverSessionToAPI
from CommonCode.CustomExceptions import APIException, UIException
from CommonCode.Driver.PyStormElement import PyStormElement
from CommonCode.Driver.PyStormSwitchTo import PyStormSwitchTo
from CommonCode.TestExecute.Logging import PrintMessage


class PyStormDriver(ChromiumDriver):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._switch_to = PyStormSwitchTo(self)

    def download_file(self, *args, **kwargs):
        """Only implemented in RemoteWebDriver."""
        raise NotImplementedError

    def get_downloadable_files(self, *args, **kwargs):
        """Only implemented in RemoteWebDriver."""
        raise NotImplementedError

    def delete_downloadable_files(self, *args, **kwargs):
        """Only implemented in RemoteWebDriver."""
        raise NotImplementedError

    def _cookiesAreAvailable(self):
        return self.get_cookie(APIConstants.ANTIFORGERY_COOKIE_NAME)

    @retry(exceptions=APIException, delay=5, tries=3)
    def _forceNavigationAndWaitForCookies(self, currentUrl):
        from urllib.parse import urljoin
        hostUrl = urljoin(currentUrl, '/')
        if self._cookiesAreAvailable():
            return

        self.get(f"{hostUrl}/wpadviser/en-gb/dashboard/home/main/customer")
        sleep(2)
        self.get(currentUrl)

        if not self._cookiesAreAvailable():
            raise APIException("No cookies found.")

    def findElements(self, by: str, value: str) -> list["PyStormElement"]:
        """
        Unfortunate work around to for pylance (pyright) allow use of PyStormElement type
        Eventho Webdriver._web_element_cls is set to PyStormElement in BrowserSetup
        If performance is affected, this code change will need to be re-assesed
        """
        toReturn: list["PyStormElement"] = []
        for k in self.find_elements(by, value):
            toReturn.append(PyStormElement.createPyStormElement(k))
        return toReturn

    def findElement(self, by: str, value: str) -> "PyStormElement":
        elements: list["PyStormElement"] = self.findElements(by, value)

        if len(elements) > 0:
            return elements[0]

        raise UIException(f"PyStormDriver > element not found [{by}, {value}]")

    def waitForNetworkActivityToCease(self):
        @retry(APIException, tries=10, delay=2)
        def innerWait():
            perfLogs = self.get_log("performance")
            if perfLogs:
                raise APIException()

        try:
            innerWait()
        except APIException:
            pass

    @retry(exceptions=APIException, tries=10, delay=2)
    def waitForAPIRequestToFinish(self, partialURL):
        """
        Method to slow down test execution
        It checks for performance logs containing unfinished requests for given URL

        URL: partial URL of an request that executes last on navigating to a webpage
        """
        if self.getNetworkResponseReceived(partialURL):
            PrintMessage("waitForAPIRequestToFinish > Request logs exists - retrying", inStepMessage=True, level=logging.DEBUG)
            raise APIException("perf logs there, retry")

    def getNetworkResponseReceived(self, partialURL) -> list[str | None]:
        perfLogs = [json.loads(k["message"]) for k in self.get_log("performance")]
        method = "Network.responseReceived"

        matchingLogs = [k for k in perfLogs if method in k.get("message", {}).get("method", "")]

        if matchingLogs:
            return [k for k in matchingLogs if partialURL in k.get("message", {}).get("params", {}).get("response", {}).get("url", "")]

        return []

    def getAttribute(self, element: PyStormElement, attrName: str):
        return element.getAttribute(attrName)

    def setAttribute(self, element: PyStormElement, attrName: str, attrValue: str):
        self.execute_script("arguments[0].setAttribute(arguments[1], arguments[2]);", element, attrName, attrValue)

    @property
    def apiSessionHeaders(self) -> dict:
        self._forceNavigationAndWaitForCookies(self.current_url)

        PrintMessage("Platform requests session configured.", logging.DEBUG, inStepMessage=True)
        return WrapDriverSessionToAPI(self.get_cookies()).headers
