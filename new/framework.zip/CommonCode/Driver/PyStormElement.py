from selenium.webdriver.remote.webelement import WebElement
from CommonCode.CustomExceptions import UIException


class PyStormElement(WebElement):
    @staticmethod
    def createPyStormElement(element: WebElement) -> "PyStormElement":
        return PyStormElement(element.parent, element.id)

    def findElements(self, by: str, value: str) -> list["PyStormElement"]:
        """
        workaround pylance / pyright recast issue by recasting webelements to pystormelement
        """
        toReturn: list["PyStormElement"] = []
        for k in self.find_elements(by, value):
            toReturn.append(self.createPyStormElement(k))
        return toReturn

    def findElement(self, by: str, value: str) -> "PyStormElement":
        elements: list["PyStormElement"] = self.findElements(by, value)

        if len(elements) > 0:
            return elements[0]

        raise UIException(f"PyStormElement > element not found [{by}, {value}]")

    def getAttribute(self, attrName) -> str:
        attrValue = self.get_attribute(attrName)
        if attrValue:
            return attrValue
        return ""

    def checkIfClickable(self):
        if self.is_enabled() and self.is_displayed():
            return
        raise UIException(f"Element clickable: '{self.is_enabled()}', or visible: '{self.is_displayed()}'")

    def click(self):
        self.checkIfClickable()
        super().click()

    @property
    def isHidden(self):
        """
        if detects 'display: none' assumes it is hidden
        """
        attrValue = self.getAttribute("style")
        return "display" in attrValue and "none" in attrValue
