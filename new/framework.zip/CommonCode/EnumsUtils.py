def listEnum(enum):
    """
    List values for all non private / system variables in the class.
    Often used to print out enum values.
    :param enum:
    :return:
    """
    assert isinstance(enum, type)
    return [getattr(enum, i) for i in listParameters(enum)]


def listParameters(enum):
    """
    Lists names ofr non private / system variables in the class.
:param enum:
    :return:
    """
    assert isinstance(enum, type)
    return [i for i in dir(enum) if not i.startswith('_')]
